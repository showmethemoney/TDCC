package com.fubon.esb.service.txn;

import java.io.File;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import junit.framework.Assert;


/**
 * @author Ethan Lee
 * @version $2015年11月5日 下午5:36:06
 */
public class TestPrintHex
{
	private Logger logger = LoggerFactory.getLogger( TestPrintHex.class );

	public static boolean isHexDigit(char c) {
		return (('0' <= c) && (c <= '9')) || (('A' <= c) && (c <= 'F')) || (('a' <= c) && (c <= 'f'));
	}

	@Ignore
	@Test
	public void testToHex() {
		logger.info( StringUtils.leftPad( Integer.toHexString( 1 * 16 ).toUpperCase(), 8, "0" ) );
	}

	@Ignore
	@Test
	public void testStringToHex() throws UnsupportedEncodingException {
		logger.info( Hex.encodeHexString( "Hello World".getBytes( "UTF-8" ) ) );
		Assert.assertEquals( "48656c6c6f20576f726c64", Hex.encodeHexString( "Hello World".getBytes( "UTF-8" ) ) );
	}

	@Ignore
	@Test
	public void testHexToString() throws UnsupportedEncodingException, DecoderException {
		String hexString = "48656C6C6F20576F726C64";
		logger.info( new String( Hex.decodeHex( hexString.toCharArray() ), "UTF-8" ) );
	}

	@Test
	public void testPrintHex() {
		try {
			String hex = "E3F0F0F0F0F1F0F4F1F1F0F5F1F2F4F1F0F0C9D5E5D9404040404040F1F9F4F2F5F6F9F0F2F7F44040404040404040404040404040404040404040C2C4F4F0F04040404040C5C1D8F6F8F1F1F3F4404040404040404040404040404040404040F2F0F0F4F0F8F0404040E3D7F1F8F1F1F5F34040404040404040404040404040C10300000000F0D5F0F0F0F0F0F0F0F040404040404040404040404040404040404040404040404040404040F1F0F0F0F0F0F0F0F040F0404040404040404040F040F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040F9F9B8F2F0F1F5F1F1F0F55050F8F8F8B8404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040B8FE";
			logger.info( "start" );
			PrintHexLine instance = new PrintHexLine();
			FileUtils.write( new File("D:\\test-data\\runTxn\\.hex.txt"), instance.transfer( hex, "EBCDIC" ) );
			logger.info( "end" );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
