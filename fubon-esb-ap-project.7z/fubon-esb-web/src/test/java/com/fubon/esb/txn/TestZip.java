package com.fubon.esb.txn;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.junit.Test;

/**
 * @author nice
 * @createdDate 2014-11-17
 */
public class TestZip {

    public static final String ZIP_EXTENSION = ".zip";

    private static String tempZipDir = "F:\\Tomcat7.0_7047_x86\\temp\\1416218551538";

    public TestZip() {
    }

    @Test
    public void clearCurTempZipDir() {
        removeFileAndChildrenFiles(new File(tempZipDir + ZIP_EXTENSION));
        removeFileAndChildrenFiles(new File(tempZipDir));
    }

    public void removeFileAndChildrenFiles(File file) {
        if (file == null)
            return;
        if (!file.exists()) {
            return;
        }
        if (file.isFile()) {
            System.out.println("delete file " + file.getName());
            file.delete();
        }
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; files != null && i < files.length; i++) {
                removeFileAndChildrenFiles(files[i]);
            }
            file.delete();
        }
    }

    public void copress() {
        String tempZipDir = "C:\\Users\\Administrator\\Desktop\\Downloads\\temp";
        // String newZipPath = "C:\\Users\\Administrator\\Desktop\\Downloads\\newreportTxnExcel.zip";
        // String readZipPath = "C:\\Users\\Administrator\\Desktop\\Downloads\\reportTxnExcel.rar";
        // String textExcel = "C:\\Users\\Administrator\\Desktop\\Downloads\\reportTxnExcel.xls";
        try {
            ZipOutputStream zipOs = new ZipOutputStream(new FileOutputStream(new File(tempZipDir + ".zip")));
            File[] files = new File(tempZipDir).listFiles();
            InputStream is = null;
            byte[] buf = new byte[1024];
            int readLen = 0;
            if (files != null && files.length != 0) {
                for (File file : files) {
                    ZipEntry zipEntry = new ZipEntry(file.getName());
                    zipEntry.setSize(file.length());
                    zipEntry.setTime(file.lastModified());
                    zipOs.setMethod(ZipOutputStream.DEFLATED);
                    zipOs.putNextEntry(zipEntry);
                    is = new BufferedInputStream(new FileInputStream(file));
                    while ((readLen = is.read(buf, 0, 1024)) != -1) {
                        zipOs.write(buf, 0, readLen);
                    }
                    is.close();
                    zipOs.closeEntry();
                }
                zipOs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
