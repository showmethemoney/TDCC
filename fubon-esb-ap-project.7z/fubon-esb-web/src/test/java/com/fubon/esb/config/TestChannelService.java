package com.fubon.esb.config;

import javax.inject.Inject;

import org.junit.Test;

import com.fubon.esb.SpringTest;
import com.fubon.esb.controller.config.view.EditChannelView;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.service.config.ChannelService;

public class TestChannelService extends SpringTest {

    @Inject
    private ChannelService channelService;

    EditChannelView editChannelView = new EditChannelView();
    Channel channel = new Channel();

    public EditChannelView createEditChannelView() {
        editChannelView.setWorkstationCodes(new String[] {"test1", "test2"});
        editChannelView.setBranchIps(new String[] {"192.168.5.100"});

        return editChannelView;
    }

    public Channel createChannel() {
        channel.setCode("test1");
        channel.setName("textName");
        channel.setStatus(ConfigActiveStatus.A);
        channel.setEffectType(EffectType.I);
        return channel;
    }

    @Test
    public void saveChannelTest() {
        try {
            channelService.saveChannel(createChannel(), createEditChannelView());
        } catch (Exception e) {
        }

    }

    @Test
    public void updateChannelTest() {
        channel.setEffectType(EffectType.B);
        editChannelView.setEffectDate("2014/11/05");
        editChannelView.setEffectHour("18");
        editChannelView.setEffectMinute("20");
        try {
            channelService.updateChannel(channel, editChannelView);
        } catch (Exception e) {
        }
    }

}
