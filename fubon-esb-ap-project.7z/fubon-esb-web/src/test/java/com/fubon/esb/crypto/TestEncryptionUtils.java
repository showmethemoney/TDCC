package com.fubon.esb.crypto;

import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Ethan Lee
 * @version $2016年7月6日 下午5:17:26
 */
public class TestEncryptionUtils
{
	protected static final Logger logger = LoggerFactory.getLogger( TestEncryptionUtils.class );

	@Test
	public void testEncrypt() throws Throwable {
		MessageDigest md = MessageDigest.getInstance( "MD5" );
		logger.info( new String( Hex.encodeHex( md.digest( "1234".getBytes( "big5" ) ), false ) ) );
		// dgupC/8CnFOkWvVUuHhTbw==
		Base64 base64 = new Base64();
//		logger.info( new String( Hex.encodeHex( "81DC9BDB52D04DC20036DBD8313ED055".getBytes( "big5" ) ) ) );
		logger.info( base64.encodeToString( "81DC9BDB52D04DC20036DBD8313ED055".getBytes() ) );
	}
}
