package com.fubon.esb.schedule.ems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.antlr.stringtemplate.StringTemplate;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Ethan Lee
 */
public class TestEMSMonitorScheduler
{
	protected static final Logger logger = LoggerFactory.getLogger( TestEMSMonitorScheduler.class );

	@Test
	public void testExecuteInternal() {
		try {
			StringTemplate engine = new StringTemplate( IOUtils.toString( getClass().getClassLoader().getResourceAsStream( "com/fubon/esb/schedule/ems/EMSMonitor.html"  ) ) );
			
			Map<String, Object> data = new HashMap<String, Object>();
			
			Map result = new HashMap();
			List<String> a = new ArrayList<String>();
			a.add( "1" );
			a.add( "2" );
			a.add( "3" );
			
			List<String> b = new ArrayList<String>();
			b.add( "a" );
			b.add( "b" );
			b.add( "c" );
			
			result.put( "123", a );
			result.put( "abc", b );
			
			data.put( "result", result );
			
			engine.setAttribute( "result", result );
			
			logger.info( engine.toString() );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
