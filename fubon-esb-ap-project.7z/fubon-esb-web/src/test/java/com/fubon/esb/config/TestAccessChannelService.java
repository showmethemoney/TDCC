package com.fubon.esb.config;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;

import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.service.config.AccessChannelService;

public class TestAccessChannelService extends SpringTest {

    @Inject
    private AccessChannelService accessChannelService;

    List<AccessChannel> accessChannelList = new ArrayList<>();

    public List<AccessChannel> createAccessChannel() {

        for (int i = 1; i <= 2; i++) {
            AccessChannel accessChannel = new AccessChannel();
            accessChannel.setCode("testCode" + i);
            accessChannel.setName("testName" + i);
            if (i % 2 == 0) {
                accessChannel.setEffectType(EffectType.I);
                accessChannel.setStatus(ConfigActiveStatus.A);
            } else {
                accessChannel.setEffectType(EffectType.B);
                accessChannel.setStatus(ConfigActiveStatus.I);
            }
            accessChannelList.add(accessChannel);
        }

        return accessChannelList;
    }

    @Test
    public void saveAccessChannel1() { // 新增-立即生效
        try {
            accessChannelService.saveAccessChannel(accessChannelList.get(0), null, null, null);
        } catch (Exception e) {
        }

    }

    @Test
    public void updateAccessChannel() {
        try {
            accessChannelService.updateAccessChannel(accessChannelList.get(0), "2014-11-5", "18", "25");
        } catch (Exception e) {
        }
    }
}
