package com.fubon.esb;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.hibernate.dialect.SQLServer2012Dialect;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.comwave.core.database.JPAAccess;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
@Profile("test")
@Configuration
public class TestDefaultDBConfig {

    @Bean
    public DataSource dataSource() {
//        return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).setName(DefaultDBConfig.DEFAULT_DB).build();
    	DriverManagerDataSource datasource = new DriverManagerDataSource();
    	
    	datasource.setDriverClassName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
    	datasource.setUrl( "jdbc:sqlserver://172.16.244.181:1433;DatabaseName=fubon_ap_system" );
    	datasource.setUsername( "esbadmin" );
    	datasource.setPassword( "1qaz2wsx" );
    	
    	return datasource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setDataSource(dataSource());
        factoryBean.setPackagesToScan(DefaultDBConfig.class.getPackage().getName() + ".domain");
        factoryBean.setPersistenceUnitName(DefaultDBConfig.DEFAULT_DB);

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
//        vendorAdapter.setDatabasePlatform(HSQLDialect.class.getName());
        vendorAdapter.setDatabasePlatform(SQLServer2012Dialect.class.getName());
        vendorAdapter.setShowSql(true);
        vendorAdapter.setGenerateDdl(true);
        factoryBean.setJpaVendorAdapter(vendorAdapter);
        return factoryBean;
    }

    @Bean
    @Primary
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setDataSource(dataSource());
        transactionManager.setPersistenceUnitName(DefaultDBConfig.DEFAULT_DB);
        return transactionManager;
    }

    @Bean
    @Primary
    public JPAAccess jpaAccess() {
        return new JPAAccess() {
            @Override
            @PersistenceContext(unitName = DefaultDBConfig.DEFAULT_DB)
            public void setEntityManager(final EntityManager entityManager) {
                super.setEntityManager(entityManager);
            }
        };
    }

}
