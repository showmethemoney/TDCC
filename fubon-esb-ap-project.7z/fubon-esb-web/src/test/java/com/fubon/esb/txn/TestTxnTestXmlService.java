package com.fubon.esb.txn;

import javax.inject.Inject;

import org.junit.Test;

import com.fubon.esb.SpringTest;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnTestXmlService;

/**
 * @author nice
 * @createdDate 2015-1-16
 */
public class TestTxnTestXmlService extends SpringTest {

    @Inject
    private TxnFieldDefinitionService txnFieldService;

    @Inject
    private TxnTestXmlService txnTestXmlService;

    private static final String XML_STR =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Tx><FMPConnectionString><SPName>ROE_Client</SPName><LoginID>ROE_Client</LoginID><Password>OycBbkVTjqTJIhUsoQGWeQ==</Password><TxnId>AAA</TxnId></FMPConnectionString><TxHead></TxHead><TxBody><b>3</b><TxRepeat><A>1</A><TxRepeat><B>12</B><TxRepeat><sdsd></sdsd><sdgsdg></sdgsdg></TxRepeat><TxRepeat><sdsd></sdsd><sdgsdg></sdgsdg></TxRepeat></TxRepeat></TxRepeat><TxRepeat><A>1</A><TxRepeat><B></B><TxRepeat><sdsd></sdsd><sdgsdg></sdgsdg></TxRepeat><TxRepeat><sdsd></sdsd><sdgsdg></sdgsdg></TxRepeat></TxRepeat></TxRepeat><TxRepeat><c>2</c></TxRepeat></TxBody></Tx>";
    private static final String DIR_ID = "f5932c90-4b48-4b5c-8b39-7b72da761b55";

    @Test
    public void testReadTxnFieldFromXmlStr() {
        try {
            txnTestXmlService.saveTxTestValues(XML_STR, DIR_ID);
        } catch (Exception e) {
        }
    }
}
