package com.fubon.esb.txn;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.txn.TxnDefinitionService;

/**
 * @author nice
 * @createdDate 2014-11-10
 */
public class TestTxnDefinitionService extends SpringTest {
	
	protected static final Logger logger = LoggerFactory.getLogger( TestTxnDefinitionService.class );
    @Inject
    private TimeZoneService timeZoneService;

    @Inject
    private TxnDefinitionService txnDefService;

    @Test
    public void findByCodeNameAndStatus() {
        String code = "";
        String name = "";
        String status = "";
        List<TxnDefinition> result = txnDefService.findPageByCodeNameAndStatus(code, name, status, null);
        if (result != null && result.size() != 0) {
            for (TxnDefinition def : result) {
                if (StringUtils.isNoneBlank(code)) {
                    Assert.assertEquals(code, def.getTxnCode());
                }
                if (StringUtils.isNoneBlank(name)) {
                    Assert.assertEquals(name, def.getName());
                }
                if (StringUtils.isNoneBlank(status)) {
                    Assert.assertEquals(status, def.getStatus().toString());
                }
            }
        }
    }

    @Test
    public void saveOrUpdate() {
        List<TxnDefinition> all = txnDefService.findAll();
        if (all != null && !all.isEmpty()) {
            all.get(0).setUpdatedTime(timeZoneService.getTZDateByService(new Date()));
            all.get(0).setUpdatedUser("TESTUSER");
            txnDefService.saveOrUpdate(all.get(0));
        }
    }

    @Test
    public void getCopyTxnDefinition() {
        List<TxnDefinition> mainDefs = txnDefService.findPageByCodeNameAndStatus(null, null, "M", null);
        if (mainDefs != null && !mainDefs.isEmpty()) {
            List<TxnDefinition> copyDefs = txnDefService.getCopyTxnDefinition(mainDefs.get(0).getId());
            if (copyDefs != null && copyDefs.size() != 0) {
                for (TxnDefinition def : copyDefs) {
                    Assert.assertEquals(mainDefs.get(0).getId(), def.getMainId());
                    logger.info( "{}", def );
                }
            }
        }
    }
}
