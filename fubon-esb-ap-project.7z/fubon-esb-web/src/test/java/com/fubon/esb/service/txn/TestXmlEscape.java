package com.fubon.esb.service.txn;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Ethan Lee
 * @version $2015年7月27日 下午4:32:49
 */
public class TestXmlEscape
{
	protected static final Logger logger = LoggerFactory.getLogger( TestXmlEscape.class );
	private static final String PATTERN_XML10 = "[^"
            + "\u0009\r\n"
            + "\u0020-\uD7FF"
            + "\uE000-\uFFFD"
            + "\ud800\udc00-\udbff\udfff"
            + "]";
	
	@Test
	public void testXmlEscape() {
		try {
			logger.info( FileUtils.readFileToString( new File( "D:\\test-data\\runTxn\\txnDefinition\\source\\TP181153.xml" )  ).replaceAll(PATTERN_XML10, "") );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
