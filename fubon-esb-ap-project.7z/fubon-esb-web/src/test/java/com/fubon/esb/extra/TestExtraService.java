package com.fubon.esb.extra;

import com.fubon.esb.SpringTest;


/**
 * @author Ethan Lee
 * @version $2015年6月30日 上午11:29:02
 */
public class TestExtraService extends SpringTest
{
//	protected static final Logger logger = LoggerFactory.getLogger( TestExtraService.class );
//	@Inject
//	private ExtraService extraService = null;
//
//	@Test
//	public void testQuery() {
//		logger.info("hello - {}", extraService.query( "select * from TXN_DIRECTION" ).size() );
//	}
}
