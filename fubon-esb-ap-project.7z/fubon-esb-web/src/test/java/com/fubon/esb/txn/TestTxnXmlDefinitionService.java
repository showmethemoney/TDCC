package com.fubon.esb.txn;

import java.io.File;
import java.util.List;

import javax.inject.Inject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.sun.org.apache.xml.internal.serializer.OutputPropertiesFactory;


/**
 * @author Ethan Lee
 * @version $2015年6月17日 上午9:55:45
 */
public class TestTxnXmlDefinitionService extends SpringTest
{
	protected static final Logger logger = LoggerFactory.getLogger( TestTxnDefinitionService.class );
	protected static final String NAMED_ELEMENT_BODY = "TxBody";
	protected static final String NAMED_ELEMENT_CASE = "TxCase";
	protected static final String NAMED_ELEMENT_FIELD = "TxField";
	protected static final String NAMED_ELEMENT_HEAD = "TxHead";
	protected static final String NAMED_ELEMENT_REPEAT = "TxRepeat";
	protected static final String NAMED_ELEMENT_ROOT = "TxDef";
	protected static final String NAMED_ELEMENT_SWITCH = "TxSwitch";
	protected static final String NAMED_ELEMENT_TITA = "TITA";
	protected static final String NAMED_ELEMENT_TOTA = "TOTA";

	@Inject
	private TxnDefinitionService txnDefService = null;

	@Inject
	private TxnDirectionService txnDirectionService = null;

	@Inject
	private TxnFieldDefinitionService txnFieldDefinitionService = null;

	@Test
	public void testToXml() {
		DocumentBuilder builder = null;
		Document document = null;
		DocumentBuilderFactory factory = null;

		try {
			factory = DocumentBuilderFactory.newInstance();
			factory.setValidating( false );

			builder = factory.newDocumentBuilder();

			document = builder.newDocument();

			List<TxnDefinition> definitions = (List<TxnDefinition>) txnDefService.findPageByCodeNameAndStatus( null, "FC032675", TxnStatus.M.name(), null );

			for (TxnDefinition definition : definitions) {
				Element root = document.createElement( NAMED_ELEMENT_ROOT );

				List<TxnDirection> directions = (List<TxnDirection>) txnDirectionService.getByTxnDefId( definition.getId() );

				for (TxnDirection direction : directions) {
					Element content = null;
					Element txHead = document.createElement( NAMED_ELEMENT_HEAD );
					txHead.setAttribute( "ref", ((TxnDirection) txnDirectionService.findHeadDirByID( direction.getHeadRefId() )).getName() );
					Element txBody = document.createElement( NAMED_ELEMENT_BODY );

					if (DirectionType.U.getDesc().equalsIgnoreCase( direction.getDirection().getDesc() )) {
						content = document.createElement( NAMED_ELEMENT_TITA );
						content.appendChild( txHead );

						processContent( direction.getId(), document, txBody, false );
					} else if (DirectionType.D.getDesc().equalsIgnoreCase( direction.getDirection().getDesc() )) {
						content = document.createElement( NAMED_ELEMENT_TOTA );
						content.appendChild( txHead );

						processContent( direction.getId(), document, txBody, false );
					}

					content.appendChild( txBody );
					root.appendChild( content );
				}

				document.appendChild( root );
			}

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty( OutputKeys.INDENT, "yes" );
			transformer.setOutputProperty( OutputKeys.OMIT_XML_DECLARATION, "yes" );
			transformer.setOutputProperty( OutputPropertiesFactory.S_KEY_INDENT_AMOUNT, "4" );

			transformer.transform( new DOMSource( document ), new StreamResult( new File( "D:\\test-data\\mw\\esb-FC032675.xml" ) ) );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}

	protected void processContent(String id, Document document, Element container, boolean recursive) {
		try {
			Element element = null;
			List<TxnFieldDefinition> txnFieldDefinitions = null;
			
			if (!recursive) {
				txnFieldDefinitions = (List<TxnFieldDefinition>) txnFieldDefinitionService.findMainsByDirId( id );
			} else {
				txnFieldDefinitions = (List<TxnFieldDefinition>) txnFieldDefinitionService.findChildren( id );
			}
			
			for (TxnFieldDefinition txnFieldDefinition : txnFieldDefinitions) {
				if (FieldType.F.name().equalsIgnoreCase( txnFieldDefinition.getFieldType().name() )) {
					element = document.createElement( NAMED_ELEMENT_FIELD );

					element.setAttribute( "id", txnFieldDefinition.getCode() );
					element.setAttribute( "cname", txnFieldDefinition.getName() );
					element.setAttribute( "datatype", txnFieldDefinition.getDataType().name() );
					element.setAttribute( "length",
					        String.valueOf( txnFieldDefinition.getLength() ).length() > 1 ? 
					        	String.valueOf( txnFieldDefinition.getLength() ) : 
					        	StringUtils.leftPad( String.valueOf( txnFieldDefinition.getLength() ), 2, "0" ) 
					       );
					element.setAttribute( "scale", String.valueOf( txnFieldDefinition.getScale() ) );
					element.setAttribute( "padchar", txnFieldDefinition.getPadChar() );
					element.setAttribute( "justify", txnFieldDefinition.getJustify().name() );
					element.setAttribute( "default", txnFieldDefinition.getDefaultV() );
					element.setAttribute( "orderNo", String.valueOf( txnFieldDefinition.getOrderNo() ) );
				} else if (FieldType.C.name().equalsIgnoreCase( txnFieldDefinition.getFieldType().name() )) {
					element = document.createElement( NAMED_ELEMENT_CASE );
					element.setAttribute( "value", txnFieldDefinition.getValue() );

					processContent( txnFieldDefinition.getId(), document, element, true );
				} else if (FieldType.R.name().equalsIgnoreCase( txnFieldDefinition.getFieldType().name() )) {
					element = document.createElement( NAMED_ELEMENT_REPEAT );
					if (NumberUtils.isNumber( txnFieldDefinition.getValue() )) {
						element.setAttribute( "timesValue", txnFieldDefinition.getValue() );
					} else {
						element.setAttribute( "timesField", txnFieldDefinition.getValue() );
					}

					processContent( txnFieldDefinition.getId(), document, element, true );
				} else if (FieldType.S.name().equalsIgnoreCase( txnFieldDefinition.getFieldType().name() )) {
					element = document.createElement( NAMED_ELEMENT_SWITCH );
					element.setAttribute( "switchField", txnFieldDefinition.getValue() );

					processContent( txnFieldDefinition.getId(), document, element, true );
				} else {
				}

				if (null != element) {
					container.appendChild( element );
				}
			}

		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
};
