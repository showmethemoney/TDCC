package com.fubon.esb.txn;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.inject.Inject;

import org.junit.Test;

import com.fubon.esb.SpringTest;
import com.fubon.esb.controller.txn.view.EditTxnField;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;

/**
 * @author nice
 * @createdDate 2014-10-29
 */
public class TestTxnFieldService extends SpringTest {

    @Inject
    private TxnFieldDefinitionService txnFieldService;

    private Random r = new Random();

    private Map<Integer, String> editTypes = new HashMap<Integer, String>();
    {
        editTypes.put(0, EditTxnField.EDIT_TYPE_ADD);
        editTypes.put(1, EditTxnField.EDIT_TYPE_MODIFY);
        editTypes.put(2, EditTxnField.EDIT_TYPE_MOVE);
        editTypes.put(3, EditTxnField.EDIT_TYPE_DELETE);
    }

    private Map<Integer, String> trids = new HashMap<Integer, String>();
    {
        trids.put(0, "TR1");
        trids.put(1, "TR2");
        trids.put(2, "TR3");
        trids.put(3, "TR4");
        trids.put(4, "TR5");
        trids.put(5, "TR6");
        trids.put(6, "TR7");
        trids.put(7, "TR8");
        trids.put(8, "TR9");
        trids.put(9, "TR10");
    }

    private Map<Integer, String> parentIds = new HashMap<Integer, String>();
    {
        parentIds.put(0, "");
        parentIds.put(1, "40288539495a76b401495a85df390001");
    }

    public String randomEditType() {
        return editTypes.get(r.nextInt(editTypes.size() - 1));
    }

    public String randomTrid() {
        return trids.get(r.nextInt(trids.size() - 1));
    }

    public String randomParentTrid(String trid) {
        Map<Integer, String> ptrids = trids;
        ptrids.entrySet().remove(trid);
        return ptrids.get(r.nextInt(ptrids.size() - 1));
    }

    public String randomParentId() {
        return parentIds.get(r.nextInt(parentIds.size()));
    }

    public EditTxnField[] createETxnFields() {
        EditTxnField[] eFields = new EditTxnField[10];
        EditTxnField eField = null;
        TxnFieldDefinition txnField = null;
        for (int i = 0; i < 10; i++) {
            eField = new EditTxnField();
            txnField = new TxnFieldDefinition();
            eField.setEditType(randomEditType());
            eField.setTrid(randomTrid());
            eField.setParentTrid(randomParentTrid(eField.getTrid()));
            if ("modify".equals(eField.getEditType())) {
                txnField.setId("40288539495a76b401495a85df390001");
            } else if ("move".equals(eField.getEditType())) {
                txnField.setId("40288539495a76b401495a85df390001");
                txnField.setOrderNo(2);
            } else if ("delete".equals(eField.getEditType())) {
                txnField.setId("40288539495a76b401495a8591cc0000");
            }
            txnField.setCode("CUS_" + i);
            txnField.setName("NAME_" + i);
            txnField.setParentId(randomParentId());
            txnField.setDirectionId("4028853949505d750149505db3be0001");
            txnField.setFieldType(FieldType.F);
            eField.setTxnField(txnField);
            eFields[i] = eField;
        }
        return eFields;
    }

    @Test
    public void testBatchProcessFromVOs() {
        // txnFieldService.batchProcessFromVOs(createETxnFields(), "4028853949505d750149505db3be0001", "40288539495a76b401495a87673b0002");
    }
}
