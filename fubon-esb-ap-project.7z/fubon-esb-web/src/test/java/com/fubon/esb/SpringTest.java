package com.fubon.esb;

import org.springframework.test.context.ContextConfiguration;

import com.comware.core.test.SpringTestSupport;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
@ContextConfiguration(classes = {WebConfig.class, TestDefaultDBConfig.class, TestLogDBConfig.class, TestProfileConfig.class})
public abstract class SpringTest extends SpringTestSupport {
}
