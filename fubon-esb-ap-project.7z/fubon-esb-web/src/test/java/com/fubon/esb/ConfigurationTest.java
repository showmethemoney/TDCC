package com.fubon.esb;

import javax.inject.Inject;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.comware.core.test.common.ConfResourcesTest;
import com.comware.core.test.common.ContainerTest;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public class ConfigurationTest extends SpringTest {

    @Inject
    private ApplicationContext applicationContext;

    @Test
    public void testContainer() throws Exception {
        ContainerTest test = new ContainerTest(applicationContext);
        test.verifyBeanConfiguration();
    }

    @Test
    public void testProperties() throws Exception {
        ConfResourcesTest test = new ConfResourcesTest();

        test.initializeEnvResourceDirs();
        test.validateEnvConfigFiles();
        test.validateTestPropertyFiles();
        test.validateEnvPropertyFiles();
    }

}
