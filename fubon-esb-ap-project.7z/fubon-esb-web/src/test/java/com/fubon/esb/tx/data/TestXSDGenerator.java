package com.fubon.esb.tx.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.transform.Result;
import javax.xml.transform.dom.DOMResult;

import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.database.OrderBy;
import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;


/**
 * @author Ethan Lee
 * @version $2016年3月7日 上午10:47:08
 */
public class TestXSDGenerator extends SpringTest
{
	protected static final Logger logger = LoggerFactory.getLogger( TestXSDGenerator.class );
	@Inject
	private TxnDefinitionService txnDefService = null;

	@Inject
	private TxnDirectionService txnDirectionService = null;

	@Inject
	private TxnFieldDefinitionService txnFieldDefinitionService = null;

	@Test
	public void testPojoToXSD() {
		try {
			final List<DOMResult> results = new ArrayList<DOMResult>();
			
			JAXBContext context = JAXBContext.newInstance( "com.fubon.esb.tx.data" );

			context.generateSchema( new SchemaOutputResolver() {
				@Override
				public Result createOutput(String ns, String file) throws IOException {
					DOMResult result = new DOMResult();
					result.setSystemId( file );
					results.add( result );
					return result;
				}
			} );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}

	@Ignore
	@Test
	public void testGenerate() {
		List<TxnDefinition> definitions = (List<TxnDefinition>) txnDefService.findPageByCodeNameAndStatus( null, "FC032675", TxnStatus.M.name(), null );
		TxnData txnData = null;

		for (TxnDefinition definition : definitions) {
			List<TxnDirection> directions = (List<TxnDirection>) txnDirectionService.getByTxnDefId( definition.getId() );

			for (TxnDirection direction : directions) {
				txnData = new TxnData();

				Header header = new Header();

				List<TxnFieldDefinition> fieldDefintions = txnFieldDefinitionService.findByTxnDirId( direction.getHeadRefId(), new OrderBy( "orderNo" ) );
				List<Field> headerFields = new ArrayList<Field>();

				for (TxnFieldDefinition fieldDefintion : fieldDefintions) {
					Field field = new Field();
					field.setName( fieldDefintion.getName() );
					headerFields.add( field );
				}

				List<Body> bodies = new ArrayList<Body>();

				if (DirectionType.U.getDesc().equalsIgnoreCase( direction.getDirection().getDesc() )) {
				} else if (DirectionType.D.getDesc().equalsIgnoreCase( direction.getDirection().getDesc() )) {
				}

				header.setFields( headerFields );

				txnData.setHeader( header );
				txnData.setBodies( bodies );
			}
		}
	}
}
