package com.fubon.esb.service.log;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;

import com.comwave.core.database.JPAAccess;
import com.comwave.core.database.Query;
import com.fubon.esb.LogDBConfig;
import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.log.TxnRecordMsg;


/**
 * @author Ethan Lee
 * @version $2015年11月5日 下午1:35:42
 */
public class TestTxnDayRecordService extends SpringTest
{
	protected static final Logger logger = LoggerFactory.getLogger( TestTxnDayRecordService.class );

	@Inject
	private TxnDayRecordServive txnDayRecordServive;

	@Inject
	@Qualifier(LogDBConfig.LOG_DB_JPA_ACCESS)
	private JPAAccess jpaAccess = null;

	@Test
	public void testQuery() {
		try {
			List<String> trackingIds = new ArrayList<String>();
			trackingIds.add( "5508d8a9-6fdf-43f8-8ef9-f944c02768d8" );
			trackingIds.add( "e8517faa-4a49-4e96-a481-46cb895965f8" );
			trackingIds.add( "73d912dc-86cf-4bb9-bb5b-52d23de34507" );
			trackingIds.add( "6c7f186b-f560-4848-8b54-9a922c39bf91" );
			trackingIds.add( "63f827d6-f7b8-49eb-a403-93c46e91ee65" );
			trackingIds.add( "345e0487-5b13-40b8-9ad8-a0d868bac4f6" );
			trackingIds.add( "2518cc05-d628-42de-a51c-9d6c76f868fe" );
			trackingIds.add( "7fe110c5-f729-4b06-9f31-c7cd621acd6a" );
			trackingIds.add( "06238124-5be1-45ab-8a10-a258c1265370" );
			trackingIds.add( "ae993b9b-f4ec-4f08-89d3-2c088d12cc09" );
			trackingIds.add( "a5a10a4f-dbbd-4720-a2db-feba43ddb571" );
			trackingIds.add( "02f356ce-5150-4736-be34-cd3de08c54ed" );
			trackingIds.add( "954e2f40-4b67-40a5-8059-faf77e064114" );
			trackingIds.add( "71fff41e-c8dd-4d45-bc7a-fed3c8bd9124" );
			trackingIds.add( "7a88cc48-556a-41a4-9219-a5cd181bc5cd" );
			trackingIds.add( "d3c2764f-691e-4970-b105-865dc289d880" );
			trackingIds.add( "66323ee0-8d39-46e7-96f8-b9ef5c5d0e3f" );
			trackingIds.add( "91d1f23b-b061-45f2-8270-2fd2904dc294" );
			trackingIds.add( "cf18aa45-e341-4553-abdf-1a57246fe920" );
			trackingIds.add( "3b211d84-9c42-41dc-884a-e50668aae937" );
			trackingIds.add( "9dab6209-fd29-4d69-b541-ddd6212bfe2b" );
			trackingIds.add( "1d57b966-4939-4364-9225-3055dbbaca05" );
			trackingIds.add( "7adc0476-27a8-40c2-9589-a405de1b9e82" );
			trackingIds.add( "fe07a574-ad9a-46d4-9dd5-674831e51097" );
			trackingIds.add( "7674cb33-23c4-45b8-8951-64852e7edf6c" );
			trackingIds.add( "902a7d99-96ca-41a2-a581-c089ebf4e616" );
			trackingIds.add( "445efc73-b189-402f-8968-2ff2f033b643" );
			trackingIds.add( "c8684708-f144-4b63-97a6-90608beac1e3" );
			trackingIds.add( "f26c1678-e134-4273-a13f-495279416590" );
			trackingIds.add( "c3e118e6-a292-46d0-8af8-3858b006b227" );
			trackingIds.add( "3d28ad9c-0e97-4340-a895-5ba8d249901e" );
			trackingIds.add( "0ab3d2cf-de29-4e45-bcba-72bfbb91954f" );
			trackingIds.add( "72a75323-0b45-4bdf-9836-22ff5c9ea8d2" );
			trackingIds.add( "7c454129-7f58-4176-87b3-73f11ac91bb5" );
			trackingIds.add( "c9540cdd-31c5-4028-a02a-6d66b54fc795" );
			trackingIds.add( "31a955d7-9f5a-41e9-956d-8cee6d05b348" );
			trackingIds.add( "14945bb0-1049-4772-9846-8f5bcae0eddf" );
			trackingIds.add( "981a9a96-fe0e-4345-bc05-88f31463b888" );
			trackingIds.add( "8db9849a-b7f4-4cd3-a0e3-6ac616f0d54c" );
			trackingIds.add( "d5374f82-8971-41f3-96ac-fa37aa20c6aa" );
			trackingIds.add( "c7b413fb-e40b-458a-b8e2-1b45538c7eab" );
			trackingIds.add( "9c7c0bf5-88f4-4a30-8330-0926ae86b3af" );
			trackingIds.add( "8d74657d-7f5f-4038-bc88-d393bec09331" );
			trackingIds.add( "f3693ad5-04f5-4e08-b77c-1e666c0b4acd" );
			trackingIds.add( "47917ce2-c558-4f16-b3ea-1a7a1f4cfcbf" );
			trackingIds.add( "134589ff-d926-4c8b-8f3e-35b5f4736449" );
			trackingIds.add( "75a38977-ea29-4606-a4da-c6a3d135ef61" );
			trackingIds.add( "a20f3e8f-b7af-4d0c-aaef-5ca3fa10ab7e" );
			trackingIds.add( "d920898d-7a18-49f9-81b9-58416e1651ce" );
			trackingIds.add( "cf93de91-5d85-4419-bdee-1c7d4af6c2c0" );

			logger.info( "hello -0" );

			Query query = Query.create(
			        "SELECT o.trackingId, o.createTime FROM " + TxnRecordMsg.class.getName() + " o WHERE o.trackingId in :trackingIds AND o.layer = 'ListenerLayer' ORDER BY o.direction DESC" );
			query.setParam( "trackingIds", trackingIds );

			List<Object[]> txnRecordMsgs = jpaAccess.find( query );

			Map<String, Long> result = new HashMap<String, Long>();
			
			for (Object[] obj : txnRecordMsgs) {
				//logger.info( "tracking id : {}, direction : {}, createTime : {}", (String) obj[0], (String) obj[1], (Date) obj[2] );
				String trackingId = (String) obj[0];
				
				if (result.containsKey( trackingId )) {
					result.put( trackingId, (long) result.get( trackingId ) - ((Date) obj[1]).getTime() );					 
				} else {
					result.put( trackingId, ((Date) obj[2]).getTime() );
				}
			}

			logger.info( "hello -1 " );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}

}
