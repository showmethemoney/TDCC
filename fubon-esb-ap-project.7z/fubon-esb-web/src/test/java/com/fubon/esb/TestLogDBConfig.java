package com.fubon.esb;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.hibernate.dialect.HSQLDialect;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.comwave.core.database.JPAAccess;

/**
 * @author Robin
 * @createdDate Nov 17, 2014
 */
@Profile("test")
@Configuration
public class TestLogDBConfig {

    @Bean
    public DataSource logDbDataSource() {
        return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).setName(LogDBConfig.LOG_DB).build();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean logDbEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setDataSource(logDbDataSource());
        factoryBean.setPackagesToScan(LogDBConfig.class.getPackage().getName() + ".domain");
        factoryBean.setPersistenceUnitName(LogDBConfig.LOG_DB);

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabasePlatform(HSQLDialect.class.getName());
        vendorAdapter.setShowSql(true);
        vendorAdapter.setGenerateDdl(true);
        factoryBean.setJpaVendorAdapter(vendorAdapter);
        return factoryBean;
    }

    @Bean
    @Qualifier(LogDBConfig.LOG_DB_JPA_TXN)
    public PlatformTransactionManager logDbTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setDataSource(logDbDataSource());
        transactionManager.setPersistenceUnitName(LogDBConfig.LOG_DB);
        return transactionManager;
    }

    @Bean
    @Named(LogDBConfig.LOG_DB_JPA_ACCESS)
    public JPAAccess logDbJpaAccess() {
        return new JPAAccess() {
            @Override
            @PersistenceContext(unitName = LogDBConfig.LOG_DB)
            public void setEntityManager(EntityManager entityManager) {
                super.setEntityManager(entityManager);
            }
        };
    }

}
