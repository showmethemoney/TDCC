package com.fubon.esb.xslt;

import java.io.File;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Ethan Lee
 * @version $2015年8月3日 下午3:39:14
 */
public class TestXSLT  
{
	protected static final Logger logger = LoggerFactory.getLogger( TestXSLT.class );

	@Test
	public void testTransfer() {
		try {
			TransformerFactory factory = TransformerFactory.newInstance();
			Source xslt = new StreamSource( TestXSLT.class.getClassLoader().getResourceAsStream( "TxnData.xsl" ) );
			Transformer transformer = factory.newTransformer( xslt );

			Source text = new StreamSource( TestXSLT.class.getClassLoader().getResourceAsStream( "550327ba-2f1a-409e-abc8-74aac0287dd2.xml" ) );
			transformer.transform( text, new StreamResult( new File( "D:\\test-data\\output.xml" ) ) );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
