package com.fubon.esb.tx.data;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TxnData")
public class TxnData {

    @XmlElement(name = "Header")
    private Header header = new Header();

    // @XmlElement(name = "Body")
    // private Body body = new Body();

    @XmlElement(name = "Body")
    private List<Body> bodies = new ArrayList<Body>();

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public List<Body> getBodies() {
        return bodies;
    }

    public void setBodies(List<Body> bodies) {
        this.bodies = bodies;
    }

    public Body getBody() {
        if (bodies == null || bodies.isEmpty()) {
            bodies = new ArrayList<Body>();
            bodies.add(new Body());
        }
        return bodies.get(0);
    }

}
