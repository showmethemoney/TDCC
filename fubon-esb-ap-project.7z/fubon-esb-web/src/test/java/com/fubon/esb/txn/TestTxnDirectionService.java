package com.fubon.esb.txn;

import java.util.List;

import javax.inject.Inject;

import org.junit.Assert;
import org.junit.Test;

import com.fubon.esb.SpringTest;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.service.txn.TxnDirectionService;

/**
 * @author nice
 * @createdDate 2014-11-10
 */
public class TestTxnDirectionService extends SpringTest {

    @Inject
    private TxnDirectionService txnDirService;

    @Test
    public void saveOrUpdate() {
        List<TxnDirection> all = txnDirService.findHeadDirections();
        if (all != null && !all.isEmpty()) {
            all.get(0).setDefinitionId(null);
            txnDirService.saveOrUpdate(all.get(0));
        }
    }

    @Test
    public void findByDefIdAndDirection() {
        txnDirService.findByDefIdAndDirection("", DirectionType.H);
    }

    @Test
    public void findHeadDirections() {
        List<TxnDirection> headDirs = txnDirService.findHeadDirections();
        if (headDirs != null && headDirs.size() != 0) {
            for (TxnDirection headDir : headDirs) {
                Assert.assertEquals(DirectionType.H, headDir.getDirection());
            }
        }
    }
}
