package com.fubon.esb.controller.txn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fubon.esb.SpringTest;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.service.txn.TxnExcelWriteService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author Ethan Lee
 * @version $2016年1月21日 下午2:41:47
 */
public class TestTxnEditController extends SpringTest
{
	protected static final Logger logger = LoggerFactory.getLogger( TestTxnEditController.class );
    @Inject
    private TxnService txnService = null;
    @Inject 
    private TxnExcelWriteService txnExcelWriteService = null;;
    
    @Test
    public void writeToExcel() throws Exception {
    	String[] defIds = { "CEF237R","CEF216R","LM050153","CEF234R","CEF236R","LN312212","SC202672","SL382607","FC032173","FC032154","LN302607","LM060162","CEF235R","LM052666","CE6128R","LP372211","FC032157","CS012656","CEF238R","LN302611","FC032163","LM050172","LN370701","CEF215R","LM050505","CEF232R","FC032755","LN300713","TP190220","CCZIP","FC032187","PB112651","SC202652","LN300703","LM050154","PB110321","OT362611","CEF214R","LN110320","LM050164","FC032155","LM050150","LM050165","LN110229","LN300327","CCSCOREB","CEF231R","LN050166","FC032179","LM050163","PH352611","TP202656","LN300712","CEF233R","LM052664","LM052650","LM050176","LN372611","FC032612","FC032661","LN300326","LN312201","FC032153","CCSCOREA","FC032175","LP372208","LN190229","FC032655","LN312206","LM051162","TD142651","LM051164","LN300396","CEF223R","SC201175","FC032151","FC032659","FC032671","LM052671","PB112650","TP202650" };
        List<TxnVO> txnVOs = new ArrayList<TxnVO>();
        if (defIds != null && defIds.length != 0) {
            for (String defId : defIds) {
                txnVOs.add(txnService.findTxnVOForExcel(defId));
            }
        }
        File file = null;
        OutputStream os = null;
        
        for (TxnVO txnVO : txnVOs) {
            Workbook workbook = txnExcelWriteService.createTxnWorkbook(txnVO);
            if (workbook != null) {
                file = new File( "D:\\test-data\\NCLM\\" + txnVO.getDefinition().getTxnCode() + "." + txnVO.getDefinition().getName() + ".xls" );
                os = new FileOutputStream(file);
                workbook.write(os);
                os.flush();
            }
        }
    }
}
