package com.fubon.esb.txn;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fubon.esb.SpringTest;
import com.fubon.esb.controller.txn.view.EditTxn;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author nice
 * @createdDate 2014-11-10
 */
public class TestTxnService extends SpringTest {

    private final Logger logger = LoggerFactory.getLogger(TestTxnService.class);

    @Inject
    private TxnService txnService;

    @Inject
    private TimeZoneService timeZoneService;

    @Inject
    private TxnDefinitionService txnDefService;

    private String jsonStrs = "";

    {
        jsonStrs =
                " {\"txnDefi\":{\"id\":\"\",\"txnCode\":\"E01\",\"name\":\"E01\",\"group\":\"01\",\"branchCode\":\"01\",\"mainId\":\"0\"},\"upTxnDirec\":{\"id\":\"0dee1907-290c-4950-a1fb-6f5e91608113\",\"directionP\":\"U\",\"typeP\":\"X\",\"headRefId\":\"4DC54F6E-5C4A-492A-BB2A-5F21CCFF9866\",\"encoding\":\"U8\"},\"downTxnDirec\":{\"id\":\"503a167a-f8f5-42fe-8a4d-792dff8d668e\",\"directionP\":\"D\",\"typeP\":\"X\",\"headRefId\":\"7194DBD6-5299-4063-9ABD-DB49A9A9C865\",\"encoding\":\"B5\"},\"etxnFields\":[{\"trid\":\"TR_1\",\"parentTrid\":\"\",\"editType\":\"move\",\"blongDirec\":\"U\",\"txnField\":{\"id\":\"53a1572f-1cfe-4238-b46c-6531b64647c2\",\"orderNo\":\"1\"}},{\"trid\":\"TR_0\",\"parentTrid\":\"\",\"editType\":\"move\",\"blongDirec\":\"U\",\"txnField\":{\"id\":\"2c811e92-8f67-401f-ab38-9cfd011207fd\",\"orderNo\":\"6\"}}]}";

    }

    private EditTxn parserJasonObj() {
        ObjectMapper objectMapper = new ObjectMapper();
        EditTxn editTxn = null;
        try {
            editTxn = objectMapper.readValue(jsonStrs, EditTxn.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return editTxn;
    }

    @Test
    public void saveOrUpdateTxn() {
        EditTxn txn = parserJasonObj();
        Assert.assertNotNull(txn);
        try {
            txnService.saveOrUpdateEditTxn(txn.getTxnDefi(), txn.getUpTxnDirec(), txn.getDownTxnDirec(), txn.getEtxnFields());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        logger.info("create a new txn and return his definition id is " + txn.getTxnDefi().getId());
    }

    @Test
    public void removeTxn() {
        txnService.removeTxn("");
    }

    @Test
    public void testGetOrCreateCopyTxnDef() {
        try {
            getOrCreateCopyTxnDef();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void getOrCreateCopyTxnDef() {
        String logMsg = "";
        List<TxnDefinition> mainDefs = txnDefService.findPageByCodeNameAndStatus(null, null, "M", null);
        TxnDefinition mainDef = new TxnDefinition();
        if (mainDefs == null || mainDefs.isEmpty()) {
            mainDef.setMainId(TxnDefinition.INIT_MAIN_ID);
            mainDef.setStatus(TxnStatus.M);
            mainDef.setTxnCode("TEST001");
            mainDef.setName("TEST");
            mainDef.setUpdatedTime(new Date());
            mainDef.setUpdatedUser("TESTUSER");
            txnDefService.saveOrUpdate(mainDef);
        } else {
            mainDef = mainDefs.get(0);
        }
        logMsg = "the main definition his id[%s],name[%s],mainId[%s]!";
        logMsg = String.format(logMsg, mainDef.getId(), mainDef.getName(), mainDef.getMainId());
        logger.info(logMsg);

        TxnDefinition copyDef = txnService.getOrCreateCopyTxnDef(mainDef.getId(), "TESTUSER");
        Assert.assertNotNull(copyDef);

        logMsg = "create a copy definition success ! his id[%s],name[%s],mainId[%s]";
        logMsg = String.format(logMsg, copyDef.getId(), copyDef.getName(), copyDef.getMainId());
        logger.info(logMsg);
    }

    @Test
    public void copyDefToMainDef() {
        List<TxnDefinition> waitToCheckDefs = txnDefService.findPageByCodeNameAndStatus(null, null, TxnStatus.E.toString(), null);
        if (waitToCheckDefs != null && !waitToCheckDefs.isEmpty()) {
            for (TxnDefinition copyDef : waitToCheckDefs) {
                txnService.copyDefToMainDef(copyDef.getId(), "TESTUSER");
                logger.info(String.format("copy to main definition with copy's id[%s]", copyDef.getId()));
            }
        }
    }
}
