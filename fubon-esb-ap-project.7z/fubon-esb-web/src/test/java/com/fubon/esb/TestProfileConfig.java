package com.fubon.esb;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
@Profile("test")
@Configuration
public class TestProfileConfig {

}
