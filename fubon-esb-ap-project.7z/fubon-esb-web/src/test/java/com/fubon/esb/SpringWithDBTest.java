package com.fubon.esb;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.ITable;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;

import com.comware.core.dbunit.DBUnitTool;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public abstract class SpringWithDBTest extends SpringTest {

    private final Logger logger = LoggerFactory.getLogger(SpringWithDBTest.class);

    private DataSource dataSource;
    private DataSource secondDataSource;
    private EntityManager entityManager;
    private DBUnitTool dbunit;
    private DBUnitTool secondDbUnit;

    @Before
    public void init() throws Exception {
        logger.info("begin to initilize DBUnit");

        Connection conn = DataSourceUtils.getConnection(dataSource);
        Assert.assertNotNull(conn);

        dbunit = new DBUnitTool(conn);
        initializeDatas();

        initSecondDBIfNeed();
    }

    protected void initializeDatas() throws Exception {
        dbunit.truncateAllTables();
        dbunit.cleanInertDataSet(getDefaultDatafile());
    }

    protected String getDefaultDatafile() {
        String defaultDatafile = getPackagePath() + getTestClassName() + "-dataset.xml";
        if (getClass().getClassLoader().getResource(defaultDatafile) != null) {
            logger.info("begin to load default datafile: {}", defaultDatafile);
            return defaultDatafile;
        }
        return null;
    }

    protected void initSecondDBIfNeed() throws Exception {
        secondDataSource = getSecondDataSource();
        String secondDefaultDatafile = getSecondDefaultDatafile();

        if (secondDataSource != null) {
            Connection secondConn = DataSourceUtils.getConnection(secondDataSource);
            Assert.assertNotNull(secondConn);

            secondDbUnit = new DBUnitTool(secondConn);

            String[] schemaSqls = getSecondInitSchemaSqls();
            if (schemaSqls != null && schemaSqls.length > 0) {
                for (String schemaSql : schemaSqls) {
                    try {
                        secondDbUnit.execute(schemaSql);
                    } catch (Exception e) {
                        logger.error("Errors happened when executing schema sql: {}, error message: {}", schemaSql, e.getMessage());
                    }
                }
            }

            secondDbUnit.truncateAllTables();
            secondDbUnit.cleanInertDataSet(getValidDatafiles(secondDefaultDatafile));
        }
    }

    protected DataSource getSecondDataSource() {
        return null;
    }

    protected String[] getSecondInitSchemaSqls() {
        return null;
    }

    protected String getSecondDefaultDatafile() {
        String defaultDatafile = getPackagePath() + getTestClassName() + "-dataset-2nd.xml";
        if (getClass().getClassLoader().getResource(defaultDatafile) != null) {
            logger.info("begin to load default datafile: {}", defaultDatafile);
            return defaultDatafile;
        }
        return null;
    }

    @After
    public void dispose() throws SQLException {
        logger.info("begin to dispose DBUnit");
        DataSourceUtils.releaseConnection(dbunit.getConnection().getConnection(), dataSource);
        dbunit = null;

        if (secondDataSource != null && secondDbUnit != null) {
            DataSourceUtils.releaseConnection(secondDbUnit.getConnection().getConnection(), secondDataSource);
            secondDbUnit = null;
        }
    }

    protected DBUnitTool getDBUnit(boolean... inSecondDB) throws SQLException {
        if (inSecondDB != null && inSecondDB.length > 0 && inSecondDB[0])
            return secondDbUnit;

        if (flushWhenGetDBUnit())
            entityManager.flush();
        return dbunit;
    }

    protected boolean flushWhenGetDBUnit() {
        return false;
    }

    protected ITable query(String sql, boolean... inSecondDB) throws Exception {
        return getDBUnit(inSecondDB).query(sql);
    }

    protected void execute(String sql, boolean... inSecondDB) throws Exception {
        getDBUnit(inSecondDB).execute(sql);

        // to clean the entities cached before data updating
        entityManager.clear();
    }

    protected int count(String sql, boolean... inSecondDB) throws Exception {
        ITable table = query(sql, inSecondDB);
        return table.getRowCount();
    }

    protected String getString(ITable table, int row, String column) throws DataSetException {
        return (String) table.getValue(row, column);
    }

    protected Boolean getBoolean(ITable table, int row, String column) throws DataSetException {
        Object value = table.getValue(row, column);
        if (value == null)
            return null;
        if (value instanceof Boolean)
            return (Boolean) value;
        if (value instanceof String)
            return Boolean.valueOf(value.toString());
        if (value instanceof BigDecimal)
            return !(((BigDecimal) value).intValue() == 0);
        throw new IllegalStateException("It isn't a valid boolean value!");
    }

    protected BigDecimal getDecimal(ITable table, int row, String column) throws DataSetException {
        return (BigDecimal) table.getValue(row, column);
    }

    protected Double getDouble(ITable table, int row, String column) throws DataSetException {
        return (Double) table.getValue(row, column);
    }

    protected Integer getInteger(ITable table, int row, String column) throws DataSetException {
        return (Integer) table.getValue(row, column);
    }

    protected Date getDate(ITable table, int row, String column) throws DataSetException {
        return (Date) table.getValue(row, column);
    }

    protected void insertRecords(String... datafiles) throws Exception {
        getDBUnit().createDataSet(getValidDatafiles(datafiles));
    }

    protected void updateRecords(String... datafiles) throws Exception {
        getDBUnit().updateDataSet(getValidDatafiles(datafiles));

        // to clean the entities cached before data updating
        entityManager.clear();
    }

    protected void deleteRecords(String... datafiles) throws Exception {
        getDBUnit().deleteDataSet(getValidDatafiles(datafiles));
    }

    private String[] getValidDatafiles(String... datafiles) {
        List<String> files = new ArrayList<String>();
        if (datafiles == null || datafiles.length == 0)
            return null;

        String packagePath = getPackagePath();
        for (String datafile : datafiles) {
            if (getClass().getClassLoader().getResource(datafile) != null)
                files.add(datafile);
            else if (getClass().getClassLoader().getResource(packagePath + datafile) != null)
                files.add(packagePath + datafile);
            else
                logger.warn("can't find datafile: " + datafile);
        }
        return files.toArray(new String[0]);
    }

    private String getPackagePath() {
        String name = getClass().getPackage().getName();
        if (name != null)
            return name.replaceAll("\\.", "/") + "/";
        return "";
    }

    private String getTestClassName() {
        return getClass().getSimpleName();
    }

    @Inject
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

}
