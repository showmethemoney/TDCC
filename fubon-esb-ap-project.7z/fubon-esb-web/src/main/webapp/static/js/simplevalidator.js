loadi18n([ "validator_input_required", "validator_input_select", "validator_number_only", "validator_date_error","validator_integer_only","validator_upperletter_only","validator_letter_only","validator_must_contains_char","validator_email_only","validator_warn_msg","validator_maxlength_prefix","validator_maxlength_suffix","validator_hex_code","validator_chinese_except","validator_intNumber_only","validator_ip_error","validator_phone_only"]);
var errorMsg = new Array();
var alertMsg = {
	"input" : i18n.validator_input_required,
	"select" : i18n.validator_input_select,
	"number" : i18n.validator_number_only,
	"date" : i18n.validator_date_error,
	"integer": i18n.validator_integer_only,
	"upperletter": i18n.validator_upperletter_only,
	"letter": i18n.validator_letter_only,
	"containsChar": i18n.validator_must_contains_char,
	"email" : i18n.validator_email_only,
	"hexCode": i18n.validator_hex_code,
	"exceptChinese":i18n.validator_chinese_except,
	"intNumber":i18n.validator_intNumber_only,
	"ipStr":i18n.validator_ip_error,
	"phone":i18n.validator_phone_only
	
};
var regexMap = {
	"date":	"(^((1[8-9]\\d{2})|([2-9]\\d{3}))/(10|12|0?[13578])/(3[01]|[12][0-9]|0?[1-9])$)|(^((1[8-9]\\d{2})|([2-9]\\d{3}))/(11|0?[469])/(30|[12][0-9]|0?[1-9])$)|(^((1[8-9]\\d{2})|([2-9]\\d{3}))/(0?2)/(2[0-8]|1[0-9]|0?[1-9])$)|(^([2468][048]00)/(0?2)/(29)$)|(^([3579][26]00)/(0?2)/(29)$)|(^([1][89][0][48])/(0?2)/(29)$)|(^([2-9][0-9][0][48])/(0?2)/(29)$)|(^([1][89][2468][048])/(0?2)/(29)$)|(^([2-9][0-9][2468][048])/(0?2)/(29)$)|(^([1][89][13579][26])/(0?2)/(29)$)|(^([2-9][0-9][13579][26])/(0?2)/(29)$)",
	"number": "^(([1-9]\\d*)|(0))(\\.\\d+)?$",
	"integer": "^\\d+$",
	"letter": "^[A-Za-z]+$",
	"upperletter": "^[A-Z]+$",
	"containsChar": "[^0-9]+[0-9]*",
	//"email" : "^[a-zA-Z0-9_\\-]+@[a-zA-Z0-9_\\-]+(\\.[a-zA-Z0-9_\\-]+)+$",
	"email" :"^[\\w-]+(\\.[\\w-\\.]+)*@([\\w-]+\\.)+[a-zA-Z]+$",
	"hexCode" : "^(0x)?[0-9A-F]+$",
	"exceptChinese":"^[^\u4e00-\u9fa5]{0,}$",
	"intNumber":"^[0-9]*[1-9][0-9]*$",
	"ipStr":"^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$",
	"phone":"^09\\d*$"
};
function validationForm(form) {
	form = $(form);
	form.find(".required,textarea[maxlength],input[datatype],.datepicker").each(function() {
		if(validation(this)){
			$(this).addClass("validerror");
			if(isRadio(this)){
				$(":radio[name='"+this.name+"']").parent().css("color","red");
			}
		}else{
			$(this).removeClass("validerror");
			if(isRadio(this)){
				$(":radio[name='"+this.name+"']").parent().css("color","");
			}
		}
	});
	if (errorMsg.length > 0) {
		var maxlen = 0;
		var msg = "";
		for (i = 0; i < errorMsg.length; i++) {
			if (i > 0) {
				msg += "<br>";
			}
			msg += (i + 1) + "、" + errorMsg[i];
			if (errorMsg[i].length > maxlen) {
				maxlen = errorMsg[i].length;
			}
		}
		var height = 110 + 20 * errorMsg.length;
		var width = 80 + 15 * maxlen;
		$("#WRAN_DIV_SPAN").html(msg);
		errorMsg = new Array();
		openDialog("WRAN_DIV", i18n.validator_warn_msg, width, height);
		return false;
	}else{
		return true;
	}
}


function validation(obj) {
	if (isInput(obj)) {
		if ($(obj).hasClass("required")) {
			if (obj.value == "") {
				errorMsg[errorMsg.length] = getObjName(obj) + alertMsg["input"];
				return true;
			}
			if(isRadio(obj)){
				if($(":radio[name='"+obj.name+"']:checked").length==0){
					errorMsg[errorMsg.length] = getObjName(obj) + alertMsg["input"];
					return true;
				}
			}
		} 
		if ($(obj).attr("datatype") && $(obj).attr("datatype") != "" && obj.value != "") {
			var regexKey = $(obj).attr("datatype");
			var regex = regexMap[regexKey];
			if (regex != null && regex != "") {
				if (!new RegExp(regex, "g").test(obj.value)) {
					errorMsg[errorMsg.length] = getObjName(obj)	+ alertMsg[regexKey];
					return true;
				}
			}
		}else if($(obj).hasClass("datepicker") && obj.value != "" ){
			var regexKey = "date";
			var regex = regexMap[regexKey];
			if (regex != null && regex != "") {
				if (!new RegExp(regex, "g").test(obj.value)) {
					errorMsg[errorMsg.length] = getObjName(obj)	+ alertMsg[regexKey];
					return true;
				}
			}
		}
	}else if(isSelect(obj)){
		if ($(obj).attr("class") == "required") {
			if (obj.value == "") {
				errorMsg[errorMsg.length] = alertMsg["select"] + getObjName(obj);
				return true;
			}
		}
	}else if(isTextArea(obj)){
		if ($(obj).attr("class") == "required") {
			if (obj.value == "") {
				errorMsg[errorMsg.length] = getObjName(obj) + alertMsg["input"];
				return true;
			}
		}
		if($(obj).attr("maxlength")){
			var maxlen=$(obj).attr("maxlength");
			if(obj.value.length>maxlen){
				errorMsg[errorMsg.length] = getObjName(obj) + i18n.validator_maxlength_prefix+maxlen+i18n.validator_maxlength_suffix;
				return true;
			}
		}
		if ($(obj).attr("datatype") != "" && obj.value != "") {
			var regexKey = $(obj).attr("datatype");
			var regex = regexMap[regexKey];
			if (regex != null && regex != "") {
				if (!new RegExp(regex, "g").test(obj.value)) {
					errorMsg[errorMsg.length] = getObjName(obj)	+ alertMsg[regexKey];
					return true;
				}
			}
		}
	}
	return false;
}
function getObjName(obj){
	var jobj=$(obj);
	if(jobj.attr("showName")){
		return jobj.attr("showName");
	}else{
		var showName=jobj.parent().prev().text().replace(/\s+/g,'');
		if(showName.charAt(0)=="*"){
			showName=showName.replace("*","");
		}
		return showName.replace(/:|：/,'');
	}
}

function isRadio(obj) {
	return isInput(obj) && "radio" == obj.type;
}


function isInput(obj) {
	return "INPUT" == obj.tagName;
}

function isSelect(obj) {
	return "SELECT" == obj.tagName;
}

function isTextArea(obj) {
	return "TEXTAREA" == obj.tagName;
}
