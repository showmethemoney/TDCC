// this is important for IEs
var polyfilter_scriptpath = '/fubon-esb-web/static/js/effect/';



/**
 * Shim for "fixing" IE's lack of support (IE < 9) for applying slice
 * on host objects like NamedNodeMap, NodeList, and HTMLCollection
 * (technically, since host objects have been implementation-dependent,
 * at least before ES6, IE hasn't needed to work this way).
 * Also works on strings, fixes IE < 9 to allow an explicit undefined
 * for the 2nd argument (as in Firefox), and prevents errors when
 * called on other DOM objects.
 */
(function () {
  'use strict';
  var _slice = Array.prototype.slice;

  try {
    // Can't be used with DOM elements in IE < 9
    _slice.call(document.documentElement);
  } catch (e) { // Fails in IE < 9
    // This will work for genuine arrays, array-like objects, 
    // NamedNodeMap (attributes, entities, notations),
    // NodeList (e.g., getElementsByTagName), HTMLCollection (e.g., childNodes),
    // and will not fail on other DOM objects (as do DOM elements in IE < 9)
    Array.prototype.slice = function(begin, end) {
      // IE < 9 gets unhappy with an undefined end argument
      end = (typeof end !== 'undefined') ? end : this.length;

      // For native Array objects, we use the native slice function
      if (Object.prototype.toString.call(this) === '[object Array]'){
        return _slice.call(this, begin, end); 
      }

      // For array like object we handle it ourselves.
      var i, cloned = [],
        size, len = this.length;

      // Handle negative value for "begin"
      var start = begin || 0;
      start = (start >= 0) ? start : Math.max(0, len + start);

      // Handle negative value for "end"
      var upTo = (typeof end == 'number') ? Math.min(end, len) : len;
      if (end < 0) {
        upTo = len + end;
      }

      // Actual expected size of the slice
      size = upTo - start;

      if (size > 0) {
        cloned = new Array(size);
        if (this.charAt) {
          for (i = 0; i < size; i++) {
            cloned[i] = this.charAt(start + i);
          }
        } else {
          for (i = 0; i < size; i++) {
            cloned[i] = this[start + i];
          }
        }
      }

      return cloned;
    };
  }
}());



			

/*!
 * classie - class helper functions
 * from bonzo https://github.com/ded/bonzo
 * 
 * classie.has( elem, 'my-class' ) -> true/false
 * classie.add( elem, 'my-new-class' )
 * classie.remove( elem, 'my-unwanted-class' )
 * classie.toggle( elem, 'my-class' )
 */

/*jshint browser: true, strict: true, undef: true */
/*global define: false */

( function( window ) {

'use strict';

// class helper functions from bonzo https://github.com/ded/bonzo

function classReg( className ) {
  return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
}

// classList support for class management
// altho to be fair, the api sucks because it won't accept multiple classes at once
var hasClass, addClass, removeClass;

if ( 'classList' in document.documentElement ) {
  hasClass = function( elem, c ) {
    return elem.classList.contains( c );
  };
  addClass = function( elem, c ) {
    elem.classList.add( c );
  };
  removeClass = function( elem, c ) {
    elem.classList.remove( c );
  };
}
else {
  hasClass = function( elem, c ) {
    return classReg( c ).test( elem.className );
  };
  addClass = function( elem, c ) {
    if ( !hasClass( elem, c ) ) {
      elem.className = elem.className + ' ' + c;
    }
  };
  removeClass = function( elem, c ) {
    elem.className = elem.className.replace( classReg( c ), ' ' );
  };
}

function toggleClass( elem, c ) {
  var fn = hasClass( elem, c ) ? removeClass : addClass;
  fn( elem, c );
}

var classie = {
  // full names
  hasClass: hasClass,
  addClass: addClass,
  removeClass: removeClass,
  toggleClass: toggleClass,
  // short names
  has: hasClass,
  add: addClass,
  remove: removeClass,
  toggle: toggleClass
};

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( classie );
} else {
  // browser global
  window.classie = classie;
}

})( window );



/**
 * modalEffects.js v1.0.0
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2013, Codrops
 * http://www.codrops.com
 */



var ModalEffects = (function() {
	function init() {

		var overlay = document.querySelector(".md-overlay");
		
		
		//var nodeArray=[].slice.call(document.querySelectorAll( '.md-trigger' ) );
		var nodeArray=[].slice.call( jQuery( '.md-trigger' ) );
		
		var el, modal, close;
		
		for(var i=0;i <nodeArray.length; i++){
			el=nodeArray[i];
			
			modal = document.querySelector( '#' + el.getAttribute( 'data-modal' ) );
			close = modal.querySelector( '.md-close' );

			
			function removeModal( hasPerspective ) {							
				classie.remove( modal, 'md-show' );
				
				
				if( hasPerspective ) {
					classie.remove( document.documentElement, 'md-perspective' );
				}
				

			}
	
			function removeModalHandler() {
				removeModal( classie.has( el, 'md-setperspective' ) ); 
			}
			
			if(el.addEventListener){
				el.addEventListener( 'click', function( ev ) {
					classie.add( modal, 'md-show' );
					overlay.removeEventListener( 'click', removeModalHandler );
					overlay.addEventListener( 'click', removeModalHandler );
		
					if( classie.has( el, 'md-setperspective' ) ) {
						setTimeout( function() {
							classie.add( document.documentElement, 'md-perspective' );
						}, 25 );
					}
					
					 if(document.querySelector('#audioElem')!=null){
						 document.querySelector('#audioElem').play();
					 }
					
				});
			}else{	//for IE8
				el.attachEvent( 'onclick', function( ev ) {
					classie.add( modal, 'md-show' );
					overlay.detachEvent( 'onclick', removeModalHandler );
					overlay.attachEvent( 'onclick', removeModalHandler );
		
					if( classie.has( el, 'md-setperspective' ) ) {
						setTimeout( function() {
							classie.add( document.documentElement, 'md-perspective' );
						}, 25 );
					}
										
					
					 if(document.querySelector('#audioElem')!=null){
						 document.querySelector('#audioElem').play();
					 }
					
				});				
			}
			
			if(close.addEventListener){
				close.addEventListener( 'click', function( ev ) {
					ev.stopPropagation();
					removeModalHandler();
					
					if(document.querySelector('#audioElem')!=null){
						 document.querySelector('#audioElem').pause();
					}
				});
			}else{	//for IE8
				close.attachEvent( 'onclick', function( ev ) {
					if(ev.stopPropagation)
						ev.stopPropagation();
					else
						window.event.cancelBubble = true;
					
					removeModalHandler();
					
					
					if(document.querySelector('#audioElem')!=null){
						 document.querySelector('#audioElem').pause();
					}
	
				});			
			}

		}	
	}
	init();

})();





