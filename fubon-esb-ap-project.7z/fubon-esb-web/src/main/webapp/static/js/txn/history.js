$(function() {
	if(window.location.href.substring(window.location.href.lastIndexOf("/")+1)=="goHistory"){
		$("div.blockdw.wrapper").ready(function(){
			$(".history").click();
		});
	}
	window.onbeforeunload = function() {
		$("input").each(function(i, item) {
			$(item).attr("value", item.value);
		});
		$("select").each(function(i, item) {
			var selectVal = item.value;

			$(item).find("option").each(function(j, jItem) {
				if (selectVal == $(jItem).val()) {
					$(jItem).attr("selected", "selected");
				} else {
					$(jItem).removeAttr("selected");
				}
			});
		});
		$(":checkbox:checked").each(function(i, item) {
			$(item).attr("checked", "checked");
		});
		addHistory();
	};
})

function addHistory() {
	var html = document.documentElement.outerHTML;
	// console.log(html);
	$.ajax({
		url : contextPath + "/history/addHistory",
		method : "POST",
		data : {
			"url" : window.location.href,
			"html" : html
		},
		dataType : "json",
		async : false,
		success : function(data) {
			// console.log("addHistory:"+data);
		}
	});
}
