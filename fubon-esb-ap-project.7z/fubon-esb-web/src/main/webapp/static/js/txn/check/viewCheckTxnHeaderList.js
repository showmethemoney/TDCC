$(function(){
	seachCheckTxnList();
	
	$("#search_button").on("click",function(){
		seachCheckTxnList();
	});
})

function showWichImg(img){
	var direction = $(img).attr("direction");
	var orderField = $(img).attr("order-field");
	if (direction == "N") {
		$(img).hide();
		$("#cur_search_direction").val("D");
		getImgByDirection(orderField, "D").show();
	} else if (direction == "D") {
		$(img).hide();
		$("#cur_search_direction").val("U");
		getImgByDirection(orderField, "U").show();
	} else if (direction == "U") {
		$(img).hide();
		$("#cur_search_direction").val("N");
		getImgByDirection(orderField, "N").show();
	}
	seachCheckTxnList();
}

function seachCheckTxnList() {
	var params = {
		name : "",
		curPage : 1
	};
//	var cur_search_direction = $("#cur_search_direction").val();
//	if (cur_search_direction=="U") {
//		params.asc=false;
//		
//	}else if(cur_search_direction=="D"){
//		params.asc=true;
//	}
	if($("#currentPage").val() != undefined)
		params.curPage = $("#currentPage").val();
	params.name = $("#search_txn_code").val();
	$("#content_head").show();
	$("#content").load(contextPath + "txn/checkHeader/search",params);
}

function getImgByDirection(orderField,direction){
	return $("img[order-field='"+orderField+"'][direction='"+direction+"']").eq(0);
}

function selectAllBox(item){
	//console.log(item.checked);
	if(item.checked){
		$(":checkbox[name=txn-check]").each(function(i,item){
			if(!item.checked){
				$(item).click();
			}
		});
	}else{
		$(":checkbox[name=txn-check]").removeAttr("checked");
	}
}

function mutipleReCheck(){
	var $checkBoxs = $(":checkbox[name=txn-check]:checked");
	if($checkBoxs.length == 0){
		alertInfo("請至少選擇一筆!");
		return false;
	}
	var defIds = new Array();
	$checkBoxs.each(function(i,item){
		defIds[i] = $(item).val();
	});
	$.ajax({
		url : contextPath + "txn/checkHeader/mutipleCheck",
		data : {"defIds":defIds},
		async : false,
		method : "POST",
		dataType : "json" ,
		success : function (data) {
			//console.log(data);
			if(data){
				window.location.href = contextPath + "/txn/checkHeader/list";
			}
		}
	});
}
