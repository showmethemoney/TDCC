$(function() {
	$("#btn_commit").on("click", function(){
		var headDirId = $("#headDirId").val();
		var bodyDirId = $("#bodyDirId").val();
		var defId = $("#txn_defi_id").val();		
		var isValid = false;
		isValid = validationForm($("#tab_up"));
		if (!isValid)
			return;
		putTestValue("tab_content");
		saveTestValue();
		txnSend(headDirId, bodyDirId, defId);
	});

	$("#btn_xml").on("click", function() {
		openDialog('editXML', "電文測試", 700, 600);
	});

	$("#btn_cancel").on("click", function() {
		window.location.href = contextPath + "/history/goHistory";
	});

	document.onkeydown = function(e){
		return true;
	}

	ajaxReBindEvents();
});

function ajaxReBindEvents() {
	$("input[name=test_value]").on("change", function() {
		$(this).attr("changed", "");
	});
}

function goToDetailTxnContent(fieldId, div, index, value, repeatType) {
	var cycles;
	var caseValue=$("#caseValue").val();
	if (repeatType == "C" || repeatType == "S") {
		var $cyclesArr = $.grep($(".field_id").toArray(), function(item, i) {
			return $(item).html() == value;
		});
		var referField;
		if (index.length > 1) {
			referField = $cyclesArr[index.substring(index.length - 1) - 1];
		} else {
			referField = $cyclesArr[0];
		}

		if (referField == undefined) {
			referField = $cyclesArr[0];
		}
		if (referField != undefined) {
			cycles = $(referField).parent().find("input[name=test_value]").val();
			if (isNaN(parseInt(cycles)) && repeatType == "C") {
				cycles = "1";
			}
			if (repeatType == "S") {
				caseValue = cycles;
				cycles = "1";
			}
		}
	} else {
		cycles = value;
	}
	var isValid = false;
	isValid = validationForm($("#" + div));
	if (!isValid)
		return;
	putTestValue("tab_content_detail");
	putTestValue("tab_content");
	$.ajax({
		url : contextPath + "/txn/test/goToChildren",
		data : {
			"pFieldId" : fieldId,
			"cycles" : cycles,
			"pPageIndex" : index,
			"caseValue" :caseValue
		},
		dataType : "html",
		success : function(data) {
			$("#tab_content").hide();
			$("#tab_content_detail").show();
			$("#tab_content_detail").html(data);
			ajaxReBindEvents();
		}

	});
}

function backToPreTxnContent(preId, div) {
	var params;
	var isValid = false;
	var caseValue=$("#caseValue").val();
	isValid = validationForm($("#" + div));
	if (!isValid)
		return;
	putTestValue("tab_content_detail");
	if (preId != "") {
		params = {
			"pFieldId" : preId,
			"caseValue" : caseValue
		};
	}
	$.ajax({
		url : contextPath + "/txn/test/backToParent",
		data : params,
		dataType : "html",
		success : function(data) {
			if (preId == "") {
				$("#tab_content").show();
				$("#tab_content_detail").hide();
				return;
			}
			$("#tab_content").hide();
			$("#tab_content_detail").show();
			$("#tab_content_detail").html(data);
			ajaxReBindEvents();
		}
	});
	ajaxReBindEvents();
}

/**
 * 頁面數據傳入到后臺
 */
function putTestValue(containerId) {
//	var repeatedArr=repetaedPutOrderNumber(containerId,index,value);
	var repeatedArr=repetaedPut(containerId);
	var dataArr = $.map($("#" + containerId + " tr[fieldId]"), function(item) {
		if ($(item).find("input[name=test_value][changed]").length == 0) {
			return null;
		}
		return {
			"id" : $(item).attr("testId"),
			"fieldId" : $(item).attr("fieldId"),
			"testValue" : $(item).find("input[name=test_value][changed]").val(),
			"orderNo" : $(item).attr("orderNo"),
			"refDirectionId" :$("#bodyDirId").val()
		};
	})
	var mergerArr=$.merge(repeatedArr,dataArr);
	$.ajax({
		type : "POST",
		async : false,
		url : contextPath + "/txn/test/testPutValue",
		data : JSON.stringify({
			"testValues" : mergerArr
		}),
		contentType : "application/json",
		dataType : "json",
		success : function(data) {
			if (data) {

			}
		}
	});
}

function saveTestValue() {
	$.ajax({
		type : "POST",
		async : false,
		dataType : "json",
		url : contextPath + "/txn/test/testSaveValue",
		success : function(data) {
			if (data) {

			}
		}
	});
}

function txnSend(headDirId, bodyDirId, defId) {
	var url = contextPath + "/txn/test/sendTxn";
	var spName= $('#SPName').val();
	var loginId= $('#LoginId').val();
	var password= $('#Password').val();

	$.ajax({
		async : false,
		url : url,
		data : {
			"headDirId" : headDirId,
			"bodyDirId" : bodyDirId,
			"defId" : defId,
			"spName" : spName,
			"loginId" : loginId,
			"password" : password,
		},
		type : "POST",
		dataType : "html",
		success : function(data) {
			$("#returnXmlDetail").empty();
			sendTxnData(data);
			var $div = $("#sendXmlDetail");
			$div.empty();
			$div.text(formatXmlAddBlanks(xmlStrAsArray(data)));
			// console.log(formatXml(data));
			openDialog('txnSend', "電文測試", 700, 600);
		},
		error : function() {
			alertInfo("發生錯誤")
		}
	});
}

function saveEditXML() {
	var data = $("#editSendXml").val();
	if(data==""){
		alertInfo("XML不能為空！");
		return;
	}
	$.ajax({
		url : contextPath + "txn/test/saveFromXml",
		method : "POST",
		data : {
			xmlStr : data,
			dirId : $("#txn_dir_id").val()
		},
		dataType : "json",
		success : function(data) {
			if (data.success) {
				closeEditDiv();
				var headDirId = $("#headDirId").val();
				var bodyDirId = $("#bodyDirId").val();
				var defId = $("#txn_defi_id").val();
				txnSend(headDirId, bodyDirId, defId);
			} else {
				alertInfo(data.errorMsg);
			}
		},
		error : function(s, xml, status, e) {
//			if (s.responseText.indexOf("LoginRequiredException") != -1) {
//				window.location.href = contextPath + "/home";
//			}
//			if (s.responseText.indexOf("Exception")) {
//				alertInfo(s.responseText.substring(0, s.responseText.indexOf("Stack") == -1 ? 100 : s.responseText.indexOf("Stack")));
//			} else {
//				alertInfo(xml + e);
//			}
			
			alertInfo("格式錯誤！");

		}
	});
}

function sendTxnData(data) {
	sendData = data.replace(/&lt;/g,"<").replace(/&gt;/g,">");
	sendData = sendData.replace(/>\s*</g, "><");
	sendData = sendData.replace(/></g, ">\r\n<");
	sendData =sendData.replace(/\s*/g,"");
	$.ajax({
		type : "POST",
		async : false,
		dataType : "json",
		data : {
			"testData" : sendData,
			"txnCode" : $("#txn_defi_code").val(),
			"txnName" : $("#txn_defi_name").val()
		},
		url : contextPath + "/txn/test/sendTxnData",
		success : function(data) {
			var backStr = data ? data.back : undefined;
			if (backStr != undefined) {
				$("#returnXmlDetail").text(formatXmlAddBlanks(xmlStrAsArray(backStr)).replace(/##@##/g, ""));
			}
		},
		error : function(xml) {
			$("#returnErrorMsg").html(xml.responseText);
			$("#returnXmlDetail").hide();
			$("#returnErrorMsg").show();
		}
	});
}

function closeSendDiv() {
	window.location.href = contextPath + "/history/goHistory";
}

function closeEditDiv() {
	$("#editXML").dialog("close");
}

function repetaedPut(containerId){
	var dataArr = $.map($("#" + containerId + " tr[fieldId][repeated][orderNo]"), function(item) {
		var cycles;
		var $cyclesArr = $.grep($(".field_id").toArray(), function(items, i) {
			return $(items).html() == $(item).attr("fieldValue");
		});
		var referField;
		var orderNo=$(item).attr("orderNo");
		if (orderNo != null && orderNo.length > 1) {
			referField = $cyclesArr[orderNo.substring(orderNo.length - 1) - 1];
		} else {
			referField = $cyclesArr[0];
		}
		if (referField == undefined) {
			referField = $cyclesArr[0];
		}
		if (referField != undefined) {
			cycles = $(referField).parent().find("input[name=test_value]").val();
			var fieldType=$(item).attr("fieldType");
			if (isNaN(parseInt(cycles)) && fieldType=="R") {
				cycles = "1";
			}
		}
		return {
			"id" : $(item).attr("testId"),
			"fieldId" : $(item).attr("fieldId"),
			"testValue" : cycles,
			"orderNo" : $(item).attr("orderNo"),
			"refDirectionId" :$("#bodyDirId").val()
		};
	})
	return dataArr;
}

/**
 * 格式化xml
 */

function xmlStrAsArray(str) {
    str = str.replace(/&lt;/g,"<").replace(/&gt;/g,">");
	str = str.replace(/>\s*</g, "><");
	str = str.replace(/></g, ">\r\n<");
	str = str.replace(/##@##/g, "\n##@##\n");
	str = str.replace(/(<\w+>)(\s*)([^\f\n\r\t\v<>]*)(\s*)(<\/\w+>)/mg, "$1$3$5");
	return str.split("\n");
}

function formatXmlAddBlanks(strArr) {
	var outXmlStr = "";
	var b = 0;
	for ( var i = 0; i < strArr.length; i++) {
		var str = strArr[i];
		if (str == "")
			continue;
		if (/^<\?/.test(str)) {
			//
		} else if (/^<\w+(?!\/)>$/.test($.trim(str))) {
			str = buildBlanks(b) + str;
			b += 1;
		} else if (/^<\/\w+>$/.test($.trim(str))) {
			b -= 1;
			str = buildBlanks(b) + str;
		} else {
			str = buildBlanks(b) + str;
		}
		outXmlStr += str + "\n";
	}
	return outXmlStr;
}

function buildBlanks(blankCount) {
	var blanks = "";
	for ( var j = 0; j < blankCount; j++) {
		blanks += "   ";
	}
	return blanks;
}

