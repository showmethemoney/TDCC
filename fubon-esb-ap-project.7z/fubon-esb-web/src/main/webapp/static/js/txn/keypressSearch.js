var tempVal="";
$(function() {
	keypressSearch.bindKeypressSearchEvent();
})

var keypressSearch = {};

keypressSearch.bindKeypressSearchEvent = function() {
	$(".keypressSearch").bind(
			"keyup",
			function(e) {
				if (e.keyCode == 13) {// enter
					keypressSearch.hideSearchResult();
					return;
				}
				if (e.keyCode == 40) {// 向下鍵
					var $hovered = $(".keypress-hover");
					if ($hovered.length == 0) {
						var $first = $(".keypress-none").eq(0);
						if ($first.length != 0)
							$(this).val($first.attr("data"));
						$first.removeClass("keypress-none").addClass(
								"keypress-hover");
					} else {
						var $next = $hovered.next("li");
						if ($next.length == 0)
							return;
						$hovered.removeClass("keypress-hover").addClass(
								"keypress-none");
						$next.removeClass("keypress-none").addClass(
								"keypress-hover");
						$(this).val($next.attr("data"));
					}
					return false;
				}
				if (e.keyCode == 38) { // 向上鍵
					var $hovered = $(".keypress-hover");
					if ($hovered.length != 0) {
						var $pre = $hovered.prev("li");
						$hovered.removeClass("keypress-hover").addClass(
								"keypress-none");
						$pre.removeClass("keypress-none").addClass(
								"keypress-hover");
						$(this).val($pre.attr("data"));
					}
					return false;
				}
				keypressSearch.startSearch(this);
				tempVal="";
			});
	$(document).mousedown(function(e) {
		keypressSearch.hideSearchResult();
	});
	
	$(".keypressSearch").blur(function(){
		if(tempVal!=""){
			this.value=tempVal;
		}
	});
}

keypressSearch.startSearch = function(item) {
	keypressSearch.hideSearchResult();
	// console.log("call keypressSearch.startSearch!");
	var searchUrl = $(item).attr("search-url");
	var key2=$(item).attr("key2");
	var data = {
			key : $(item).val()
		};
	if(key2 != undefined){
		data["key2"]=key2;
	}
	$.ajax({
		url : searchUrl,
		data : data,
		type : "POST",
		async : false,
		dataType : "json",
		success : function(data) {
			keypressSearch.showSearchResult(item, data);
		}
	});

}

keypressSearch.showSearchResult = function(item, data) {
	// console.log("call keypressSearch.buildSearchResult!");
	if (data == undefined || $(data).length == 0)
		return;
	var $nextDiv = $(item).next("div .keypressSearchDiv");
	if ($nextDiv.length != 0) {
		$nextDiv.eq(0).remove();
	}
	var resultDiv = "<div style='z-index:200000' class=\"keypressSearchDiv\">";
	resultDiv += "<ul style='text-align:left;z-index:200000'>";
	for ( var i = 0; i < data.length; i++) {
		resultDiv += "<li style='z-index:200000' class=\"keypress-none\" data=\""
				+ data[i] + "\" style='cursor:pointer'>" + data[i] + "</li>";
	}
	resultDiv += "</ul>";
	resultDiv += "</div>";
	var $resultDiv = $(resultDiv);
	$resultDiv.find("li")
			.hover(
					function() {
						$resultDiv.find("li").removeClass("keypress-hover")
								.addClass("keypress-none");
						$(this).removeClass("keypress-none").addClass(
								"keypress-hover");
						$(item).val($(this).attr("data"));
						tempVal=$(this).attr("data");
					},
					function() {
						$(this).removeClass("keypress-hover").addClass(
								"keypress-none");
						$(this).css("background-color", "");
					});
	$resultDiv.css("width", $(item).css("width"));
	// $resultDiv.css("margin-left",$(item).get(0).offsetLeft-5);
	if ($.trim($(item).attr("modal")) == "true") {
		$resultDiv.css("margin-left", $(item).get(0).offsetLeft - 13);
	} else {
		$resultDiv.css("left", ($(item).offset().left - 20) + "px");
	}
	$resultDiv.insertAfter($(item));
}

keypressSearch.hideSearchResult = function() {
	$("div .keypressSearchDiv").remove();
}