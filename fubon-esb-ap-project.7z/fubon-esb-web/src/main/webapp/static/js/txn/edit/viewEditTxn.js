$(function() {
	ajaxReBinEvents();
})

function ajaxReBinEvents() {
	getUpContainer().add(getDownContainer()).find("tr[id][objid]").on("change", function(event) {
		var obj = event.target;
		var $default = $(this).find("input[name=field_default]");
		var $char = $(this).find("input[name=field_char]");
		var $dataType = $(this).find("select[name=data_type]");
		var $length = $(this).find("input[name=field_length]");
		if (obj.name == 'field_length') {
			if ($dataType.val() == "H") {
				$char.attr("maxlength", 4);
				$default.attr("maxlength", obj.value * 4);
				$char.val($char.val().substring(0, 4));
				$default.val($default.val().substring(0, obj.value * 4));
			}else{
				$char.attr("maxlength", 1);
				$default.attr("maxlength", $length.val());
				$char.val($char.val().substring(0, 1));
				$default.val($default.val().substring(0, obj.value));
			}
		}
		if (obj.name == 'data_type') {
			if (obj.value == "N") {
				$default.attr("datatype", "integer");
			} else if (obj.value == "H") {
				$default.attr("datatype", "hexCode");
				$default.attr("maxlength", $length.val() * 4);
				$char.attr("maxlength", 4);
			} else {
				$default.removeAttr("dataType");
			}
			if (obj.value != "H") {
				$char.attr("maxlength", 1);
				$default.attr("maxlength", $length.val());
				$char.val($char.val().substring(0, 1));
				$default.val($default.val().substring(0, $length.val()));
			}
		}
		localModify(obj);
	});

	$(":radio[name*=field_value]").on("click", function() {
		var $nextInput = $(this).next("input");
		var $sibInput = $(this).siblings(":radio[name='" + $(this).attr("name") + "']").next("input");
		$nextInput.addClass("required");
		if ($(this).val() == "9") {
			$nextInput.attr("datatype", "integer");
		} else {
			$nextInput.attr("datatype", "containsChar");
		}
		$sibInput.removeClass("required").removeClass("validerror").removeAttr("datatype");
	})
}

function validateCaseValue(item) {
	var $cInput = $(item);
	var cValue = $cInput.val();
	var $existedC = $.grep(getSearchScope().find("input[name=field_value]"), function(item, i) {
		return item.value == cValue;
	});
	if($existedC.length >= 2 ){
		$cInput.addClass("validerror");
		return false;
	}
	$cInput.removeClass("validerror");
	return true;
}


function txnValidator(form) {
	//可驗證同層是否有相同的field id
//	if(!checkLastFieldCode(form)){
//		return false;
//	}
	if (!checkRepeatByField()) {
		return false;
	}
	return validationForm(form);
}

function checkLastFieldCode(form){
	var $lastTr = $(form).find("tr[id][fieldType]").last();
	if($lastTr.attr("fieldType") != "F"){
		return true;
	}
	var $item = $lastTr.find("input[name=field_code]");
	var code = $item.val();
	var $sameArr = $.grep($(form).find("input[name=field_code]"), function(n, i) {
		return $.trim(n.value) == code;
	});
	if($sameArr.length > 1){
		$item.addClass("validerror");
		alertInfo("同層Field Id不能重復!");
		return false;
	}
	try{
		$.ajax({
			url : contextPath + "txn/edit/isExsitFieldCode",
			data :{"fieldCode":$item.val(),"dirId":getCurDirId()} ,
			dataType :"json",
			async : false,
			type : "POST",
			success : function(data){
				if(data && !data.isExist){
					$item.removeClass("validerror");
					return true;
				}else{
					throw "同層Field Id不能重復!"; 
				}
			},
			error: function(){
				throw "同層Field Id不能重復!"; 
			}
		});
	}catch(e){
		alertInfo(e);
		return false;
	}
	$item.removeClass("validerror");
	return true;
}

function checkRepeatByField() {
	var headId=getCurDirecContainer().find("#txn_direc_head_ref").val();
	var $switchRepeat = getCurDirecContainer().find("input[name=field_value][switch],:radio[name*=field_value]:checked");
	if ($switchRepeat.length == 0)
		return true;
	try {
		$switchRepeat.each(function(i, item) {
			var isSwitch = item.type == "text";
			var $item = $(item);
			var $dataInput = $item;
			var fieldCode;
			
			if (!isSwitch) {
				$dataInput = $item.next("input");
			}
			if (isSwitch || $item.val() == "C") {
				var $datas = $.grep(getCurDirecContainer().find("input[name=field_code]"), function(n, i) {
					return n.value == $dataInput.val();
				});
				var flag=false;
				if(headId!=""){
					$.ajax({
						url : contextPath + "txn/edit/isExsitFieldCode",
						data : {
							"fieldCode" : $dataInput.val(),
							"dirId" : headId
						},
						dataType : "json",
						async : false,
						type : "POST",
						success : function(data) {
							if (data && !data.isExist) {
								flag = false;
							} else {
								flag = true;
							}
						},
						error : function() {
							throw "未找到對應Field Id的欄位!";
						}
					});
				}
				
				if ($datas.length == 0 && !flag) {
					$dataInput.addClass("validerror");
					throw "未找到對應Field Id的欄位!";
				}
			}
		});
	} catch (e) {
		alertInfo(e);
		return false;
	}
	return true;
}

// nTabs
function editNTabs(thisObj, Num) {
	var lastTrIsValid = false;
	if (getCurDirection() == "U") {
		lastTrIsValid = txnValidator(getCommonContainer().add(getUpContainer()));
	} else {
		lastTrIsValid = txnValidator(getDownContainer());
	}
	if (!lastTrIsValid)
		return;
	if (thisObj.className == "active")
		return;
	var tabObj = thisObj.parentNode.id;
	var tabList = document.getElementById(tabObj).getElementsByTagName("li");
	for (i = 0; i < tabList.length; i++) {
		if (i == Num) {
			thisObj.className = "active";
		} else {
			tabList[i].className = "normal";
		}
	}
	if (Num == 0) {// up
		changeSearchScrope(getUpContainer().attr("id"));
		changeDirection("U");
		getUpContainer().show();
		getDownContainer().hide();
		var $visibleContainer = $("#tab_up").find("tbody[id][container]:visible").eq(0);
		if ($visibleContainer.attr("level") != undefined && $visibleContainer.attr("level") == 1) {
			getCommonContainer().show();
		}
	} else {// down
		changeSearchScrope(getDownContainer().attr("id"));
		changeDirection("D");
		getUpContainer().hide();
		getDownContainer().show();
		getCommonContainer().hide();
	}
	hideNeededMoveBtnInScope();
}

function getSearchScope() {
	return $("#" + $("#cur_search_scope").val());
}

function getCurDirection() {
	return $("#cur_direction").val();
}

function getCurDirId() {
	if(getCurDirection() == "U"){
		return $("#up_dir_id").val();
	}else if(getCurDirection() == "D"){
		return $("#down_dir_id").val();
	}
	return "";
}

function changeSearchScrope(containerId) {
	$("#cur_search_scope").val(containerId);
}

function changeDirection(direction) {
	$("#cur_direction").val(direction);
}

function getCommonContainer() {
	return $("#tab_common");
}

function getUpContainer() {
	return $("#tab_up");
}

function getDownContainer() {
	return $("#tab_down");
}

function getCurDirecContainer() {
	if (getCurDirection() == "U") {
		return getUpContainer();
	}
	return getDownContainer();
}

function getCurDirecHeader() {
	return getCurDirecContainer().find("#TB_DIREC");
}

function getCurTableContainer() {
	return getCurDirecContainer().find("#TB_CONTENT");
}

function getParentContainer(curContainer) {
	var pTbId = $(curContainer).attr("parentC");
	if (pTbId == undefined || pTbId == "") {
		return $(curContainer).closest("div[id][container]");
	}
	return getCurTableContainer().find("#" + pTbId);
}

function getCurContainer(item) {
	return $(item).closest("tbody[id][container]");
}

function getThisTr(item) {
	return $(item).closest("tr[id]");
}

function showWhichTbody(showTable, showTbody) {
	showTable.show();
	changeSearchScrope(showTable.attr("id"));
	if (showTbody != undefined) {
		showTable.children("tbody[id][container]").hide();
		showTbody.show();
		changeSearchScrope(showTbody.attr("id"));
	}
}

function backToParentContainer(item) {
	var $curContainer = getCurContainer(item);
	if (!txnValidator($curContainer)) {
		return;
	}
	var $parentContainer = getParentContainer($curContainer);
	var fieldType = $parentContainer.attr("fieldType");
	showWhichTbody(getCurTableContainer(), $parentContainer);
	if (fieldType == "S") {
		showTxnEditLink("a_clone", "a_add_c", "a_add_s");
		getCurTableContainer().find("#TB_HEAD_0").hide();
		getCurTableContainer().find("#TB_HEAD_1").show();
	} else {
		getCurTableContainer().find("#TB_HEAD_0").show();
		getCurTableContainer().find("#TB_HEAD_1").hide();
	}
	if ($parentContainer.attr("level") != undefined && $parentContainer.attr("level") == "1") {
		getCurDirecHeader().show();
		if (getCurDirection() != undefined && getCurDirection() == "U") {
			getCommonContainer().show();
		}
		showTxnEditLink("a_clone", "a_add_s", "a_add_r", "a_add_f", "a_view");
	}
}

function buildTBContainerId(trid) {
	return getCurDirection() + "_TB_" + trid;
}

function newFieldsContainer(pContainerId, parentTr, fieldType) {
	var parentTrid = $(parentTr).attr("id")
	var parentId = $(parentTr).attr("objId");
	if (parentTrid == undefined)
		return;
	if (parentId == undefined)
		parentId = "";
	var newId = buildTBContainerId(parentTrid);
	var $newTbody = $("<tbody id='" + newId + "' container parentC='" + pContainerId + "'" + " parentTr='" + parentTrid
			+ "'parentId='" + parentId + "'fieldType='" + fieldType + "' parentValue='"
			+ $(parentTr).find("input[name=field_value]").val() + "'></tbody>");
	$.ajax({
		url : contextPath + "txn/edit/children",
		data : {
			direction : getCurDirection(),
			parentId : $(parentTr).attr("objId"),
			beginIndex : getNewTROrderNo()
		},
		async : false,
		dataType : "html",
		success : function(data) {
			$newTbody.html(data);
		}
	});
	$newTbody.appendTo(getCurTableContainer());
	return $newTbody;
}

function showTxnEditLink(id) {
	getCurDirecContainer().find("#a_clone").hide();
	getCurDirecContainer().find("#a_add_s").hide();
	getCurDirecContainer().find("#a_add_c").hide();
	getCurDirecContainer().find("#a_add_r").hide();
	getCurDirecContainer().find("#a_add_f").hide();
	getCurDirecContainer().find("#a_view").hide();
	var args = arguments;
	for ( var i = 0; i < args.length; i++) {
		getCurDirecContainer().find("#" + args[i]).show();
	}
}

function buildChildContainer(item) {
	var $curContainer = getCurContainer(item);
	var parentCId = $curContainer.attr("id");
	var $parentContainer = getParentContainer($curContainer);
	var $parentTr = getThisTr(item);
	var fieldType = getThisTr(item).attr("fieldType");
	var $tbody = getCurTableContainer().find("#" + buildTBContainerId($parentTr.attr("id")));
	if ($tbody.length == 0) {
		$tbody = newFieldsContainer(parentCId, $parentTr, fieldType);
	}
	var parentValue = $parentTr.find("input[name=field_value]").val();
	$tbody.attr("parentValue", parentValue);
	$tbody.find("#show_switch_field_code").html(parentValue);
	return $tbody;
}

function goToChildFields(item) {
	if (!txnValidator(getSearchScope())) {
		return;
	}
	var $tbody = buildChildContainer(item);
	var fieldType = $tbody.attr("fieldType");
	showWhichTbody(getCurTableContainer(), $tbody);
	getCurTableContainer().find("#TB_HEAD_0").show();
	getCurTableContainer().find("#TB_HEAD_1").hide();
	if (fieldType == "S") {// 判斷欄位父
		showTxnEditLink("a_clone", "a_add_c", "a_add_s");
		getCurTableContainer().find("#TB_HEAD_0").hide();
		getCurTableContainer().find("#TB_HEAD_1").show();
	} else if (fieldType == "C") {// 判斷欄位子
		showTxnEditLink("a_clone", "a_add_r", "a_add_f");
	} else if (fieldType == "R") {
		showTxnEditLink("a_clone", "a_add_r", "a_add_f");
	}
	getCommonContainer().hide();
	getCurDirecHeader().hide();
	hideNeededMoveBtnInScope();
	ajaxReBinEvents();
}

function previewTxn() {
	var $trs = getCurTableContainer().find("tbody[id][level=1][container]").find("tr[id][orderno][fieldtype]");
	$("#pre_view").dialog({
		title : "預覽電文",
		modal : true,
		draggable : false,
		position : {
			my : "center top",
			at : "center top+20%"
		},
		width : 900,
		maxHeight : window.screen.height * 0.6,
		open : function() {
			if ($trs != 0) {
				$trs.each(function(i, item) {
					$("#pre_view_content").append(buildPreviewContent(item));
				});
			}
			$(this).find("#btn_close").on("click", function() {
				$("#pre_view").dialog("close");
			});
		},
		close : function() {
			$("#pre_view_child").hide();
			$("#pre_view_content").html("");
			$("#pre_view_child_content").html("");
		}
	});
}

function buildPreviewContent(contentTr) {
	var fieldObj = buildFieldObj($(contentTr));
	var fieldType = fieldObj.fieldTypeP;
	var tr = "";
	if (fieldType == "F") {
		tr = "<tr>";
		tr += "<td>" + fieldObj.code + "</td>";
		tr += "<td>" + fieldObj.name + "</td>";
		if (fieldObj.dataTypeP == "N") {
			tr += "<td>數值</td>";
		} else if (fieldObj.dataTypeP == "H") {
			tr += "<td>Hex Code</td>";
		} else {
			tr += "<td>字串</td>";
		}
		tr += "<td>" + fieldObj.length + "</td>";
		tr += "<td>" + fieldObj.scale + "</td>";
		tr += "<td>" + fieldObj.defaultV + "</td>";
		tr += "<td>" + fieldObj.padChar + "</td>";
		if (fieldObj.justify == "L") {
			tr += "<td>左對齊</td>";
		} else {
			tr += "<td>右對齊</td>";
		}
		if (fieldObj.includeChinese == 1) {
			tr += "<td>Y</td>";
		} else {
			tr += "<td></td>";
		}
		if (fieldObj.optional == 1) {
			tr += "<td>Y</td>";
		} else {
			tr += "<td></td>";
		}
		tr += "<td></td>";
		tr += "</tr>";

	} else if (fieldType == "R") {
		tr = "<tr><td colspan='10' style='text-align:left'>";
		if (/^\d+$/.test(fieldObj.value)) {
			tr += "依次數" + fieldObj.value;
		} else {
			tr += "依欄位" + fieldObj.value;
		}
		tr += "</td><td><a  style='color: blue' href=\"javascript:void(0);\" onclick=\"previewTxnDetail('"
				+ $(contentTr).attr("id") + "')\">詳細</a>";
		tr += "</td></tr>";

	} else if (fieldType == "S") {
		tr = "<tr>";
		tr += "<td colspan='10' style='text-align:left'>判斷欄位" + fieldObj.value + "</td>";
		tr += "<td><a style='color: blue' href=\"javascript:void(0);\" onclick=\"previewTxnDetail('"
				+ $(contentTr).attr("id") + "')\">詳細</a></td>";
		tr += "</tr>";

	} else if (fieldType == "C") {
		tr = "<tr>";
		tr += "<td colspan='10' style='text-align:left'>判斷值" + fieldObj.value + "</td>";
		tr += "<td><a style='color: blue' href=\"javascript:void(0);\" onclick=\"previewTxnDetail('"
				+ $(contentTr).attr("id") + "')\">詳細</a></td>";
		tr += "</tr>";
	}
	return tr;
}

function previewTxnDetail(parentTrId) {
	if (parentTrId == undefined)
		return;
	buildChildContainer($("#" + parentTrId)).hide();
	$("#pre_view_child_content").html("");
	$("#pre_view_child").show();
	var $childTbody = getCurTableContainer().find("tbody[id$=" + parentTrId + "][container]");
	if ($childTbody.length != 0) {
		$childTbody.find("tr[id][fieldType][orderNo]").each(function(i, item) {
			$("#pre_view_child_content").append(buildPreviewContent(item));
		});
	}
}
