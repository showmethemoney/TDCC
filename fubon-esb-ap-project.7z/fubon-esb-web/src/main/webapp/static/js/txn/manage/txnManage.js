function searchTxnByType() {
	var queryUrl = $.trim($("#queryType").find("option:selected").attr("url"));
	var url = contextPath + "/txnManage/query/"
			+ queryUrl;

	var currentPage = $("#currentPage").val();
	var isSearch = $("#isSearch").val();
	if (isSearch == "true") {
		currentPage = 1;
	}
	$.ajax({
		url : url,
		type : "post",
		async : false,
		dataType : "html",
		data : {
			queryType : $("#queryType").val(),
			currentPage : currentPage,
			isSearch : isSearch
		},
		success : function(data) {
			$("#queryContainer").empty();
			$("#queryContainer").html(data);
			$("#isSearch").val("true");
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			alert(XMLHttpRequest.status);
			alert(XMLHttpRequest.readyState);
			alert(textStatus);
		}
	});

}

function gotoPage2(currentPage) {
	$("#currentPage").val(currentPage);
	$("#isSearch").val(false);
	searchTxnByType();
}

function exportTxnByType(){
	$("#viewTxnSearchForm").attr("action", contextPath + "txnManage/exportTxnManage");
	$("#viewTxnSearchForm").submit();    
}