$(function() {
	$("#btn_commit").on("click", function() {
		window.location.href = contextPath + "/txn/checkHeader/commit/" + $("#txn_defi_id").val();
	});
	$("#btn_back").on("click", function() {
		window.location.href = contextPath + "txn/checkHeader/back/" + $("#txn_defi_id").val();
	});
	$("#btn_cancel").on("click", function() {
		window.location.href = contextPath + "/history/goHistory";
	});
	$("#btn_return").on("click", function() {
		window.location.href = contextPath + "/history/goHistory";
	});
});

function getContentContainer() {
	return $("#tab_content");
}

function getCommonContainer() {
	return $("#tab_common");
}

function getUpContainer() {
	return $("#tab_up");
}

function getDownContainer() {
	return $("#tab_down");
}
// nTabs
function checkNTabs(thisObj, Num) {
	if (thisObj.className == "active")
		return;
	var tabObj = thisObj.parentNode.id;
	var tabList = document.getElementById(tabObj).getElementsByTagName("li");
	for (i = 0; i < tabList.length; i++) {
		if (i == Num) {
			thisObj.className = "active";
		} else {
			tabList[i].className = "normal";
		}
	}
	if (Num == 0) {// up
		getUpContainer().show();
		getDownContainer().hide();
		getCommonContainer().show();
	} else {// down
		getUpContainer().hide();
		getDownContainer().show();
		getCommonContainer().hide();
	}
}

function goToDetailTxnContent(fieldId) {
	$.ajax({
		url : contextPath + "/txn/check/childContent",
		data : {
			pFieldId : fieldId
		},
		dataType : "html",
		success : function(data) {
			$("#tab_content").hide();
			$("#tab_content_detail").show();
			$("#tab_content_detail").html(data);
		}
	});
}

function backToPreTxnContent(preId) {
	if (preId == "") {
		$("#tab_content").show();
		$("#tab_content_detail").hide();
		return;
	}
	goToDetailTxnContent(preId);
}