function seachTxnList() {
	var params = {
		txnCode : "",
		txnName : "",
		txnStatus : "",
		curPage : 1,
	};
	params.txnCode = $("#search_txn_code").val();
	params.txnName = $("#search_txn_name").val();
	params.txnStatus = $("#search_txn_status").val();
	if ($("#currentPage").val() != undefined)
		params.curPage = $("#currentPage").val();
	$("#content").load(contextPath + "txn/test/search", params);
}

$(function() {
	seachTxnList();
	
	$("#search_button").on("click", function() {
		seachTxnList();
	});
});