$(function() {
	seachTxnList();
	
	$("#search_button").on("click",function(){
		seachTxnList();
	});
	
	$("#file_txn_excel").on("change", function() {

	});
})

function selectFileChange(item){
	var fileName = $(item).val();
	if (fileName != "") {
		$("#select_file_button").val(fileName.substring(fileName.lastIndexOf("\\") + 1));
	}
	var extension = fileName.substring(fileName.lastIndexOf(".") + 1);
	// console.log("extension:"+extension);
	if (extension == "zip" || extension == "rar") {
		$("#txnDef_txnCode").removeClass("required").removeClass("validerror");
		$("#txnDef_name").removeClass("required").removeClass("validerror");
		$("span[name='txnDef.txnCode']").hide();
		$("span[name='txnDef.name']").hide();
		$("#excel_iscompress").val("true");
	} else {
		$("#txnDef_txnCode").addClass("required");
		$("#txnDef_name").addClass("required");
		$("span[name='txnDef.txnCode']").show();
		$("span[name='txnDef.name']").show();
		$("#excel_iscompress").val("false");
	}
}

function addTxn() {
	window.location.href = contextPath + "txn/edit/add";
}

function deleteTxn(item) {
	confirmInfoAddtion(false, "刪除電文", "你確定要刪除此電文?",function() {
		$.ajax({
			url : contextPath + "txn/edit/delete/" + $(item).attr("_id"),
			beforeSend : function() {
			},
			async : false ,
			dataType : "json",
			success : function(data) {
				if (data.success) {
					seachTxnList();
				}
			},
			error : function(e) {
			}
		});
	})

}

function seachTxnList() {
	var params = {
		txnCode : "",
		txnName : "",
		txnStatus : "",
		curPage : 1
	};
	params.txnCode = $("#search_txn_code").val();
	params.txnName = $("#search_txn_name").val();
	params.txnStatus = $("#search_txn_status").val();
	if ($("#currentPage").val() != undefined)
		params.curPage = $("#currentPage").val();
	$("#content").load(contextPath + "txn/edit/search", params);
}

function choiceFile() {
	$("#file_txn_excel").click();
}

function selectAllBox(item) {
	// console.log(item.checked);
	if (item.checked) {
		$(":checkbox[name=txn-report]").each(function(i, item) {
			if (!item.checked) {
				$(item).click();
			}
		});
	} else {
		$(":checkbox[name=txn-report]").removeAttr("checked");
	}
}

function reportTxn() {
	var $checkBoxs = $(":checkbox[name=txn-report]:checked");
	if ($checkBoxs.length == 0) {
		alertInfo("請至少選擇一筆！");
		return false;
	}
	var defIds = new Array();
	$checkBoxs.each(function(i, item) {
		defIds[i] = $(item).val();
	});
	var url = contextPath + "/txn/edit/reportTxnExcel?defIds[]=" + defIds;
	$("#hidden_report_a").attr("href", url).find("span").click();
}

function readIn() {
	$("#read-txn-excel").dialog({
		title : "匯入電文",
		width : 500,
		modal : true,
		draggable : false,
		open : function() {

		},
		close : function() {
			document.getElementById("read-txn-form").reset();
		}
	});
}

function commitReadIn() {
	var isValid = false;
	isValid = validationForm($("#read-txn-form"));
	if (isValid) {
		$.ajaxFileUpload({
			url : contextPath + "/txn/edit/readFromExcel",
			secureuri : false,
			data : {
				"txnCode" : $("#txnDef_txnCode").val(),
				"txnName" : $("#txnDef_name").val(),
				"branchCode" : $("#txnDef_branchCode").val(),
				"group" : $("#txnDef_group").val(),
				"isCompress" : $("#excel_iscompress").val()
			},
			fileElementId : "file_txn_excel",
			dataType : "text",
			success : function(data, status) {
				if (isString(data) && data.indexOf("id=\"login_form\"") != -1) {
					window.location.href = contextPath + "viewLogin";
				}
				var result = jQuery.parseJSON(data);
				var errorMsgs =result.errorMsgs;
				var returnDefIds =result.returnDefIds;
				var errorMsg = "";
				var index = 0;
				if (errorMsgs) {
					for ( var r in errorMsgs) {
						index++;
						if (index != 1) {
							errorMsg += "<br/>";
						}
						errorMsg += "<span>" + index + "、" + r + ":</span>";
						var rowError = errorMsgs[r];
						if (rowError) {
							for ( var e in rowError) {
								errorMsg += "<br/><span>&nbsp;&nbsp;&nbsp;&nbsp;" + rowError[e] + "</span>";
							}
						}
					}
					if (index != 0) {
						alertInfo(errorMsg);
						$("#select_file_button").val("選擇檔案");
						$("#file_txn_excel").replaceWith("<input showname=\"檔案\" id=\"file_txn_excel\" name=\"file_txn_excel\" type=\"file\" style=\"width:80px;position:absolute; z-index:100; margin-left:-80px;height:26px;opacity:0;filter:alpha(opacity=0);\" class=\"required\" onchange=\"selectFileChange(this);\"/>");
						return false;
					}
				}
				$("#read-txn-excel").dialog("close");
				window.location.href = contextPath + "history/goHistory";
			},
			error : function(s, xml, status, e) {
				$("#select_file_button").val("選擇檔案");
				$("#file_txn_excel").replaceWith("<input showname=\"檔案\" id=\"file_txn_excel\" name=\"file_txn_excel\" type=\"file\" style=\"width:80px;position:absolute; z-index:100; margin-left:-80px;height:26px;opacity:0;filter:alpha(opacity=0);\" class=\"required\" onchange=\"selectFileChange(this);\"/>");
				if (s.responseText.indexOf("LoginRequiredException") != -1) {
					window.location.href = contextPath + "/home";
				}
				if(s.responseText.indexOf("Exception")){
					alertInfo(s.responseText.substring(0, s.responseText.indexOf("Stack")==-1?100:s.responseText.indexOf("Stack")));
				}else {
					alertInfo(xml+e);
				}
				
			}
		});
	}
}

function cancleReadIn() {
	document.getElementById("read-txn-form").reset();
	$("#select_file_button").val("選擇檔案");
	$("#read-txn-excel").dialog("close");
}


function refreshTxn(item){
		$.ajax({
			url : contextPath + "txn/check/refresh/" + $(item).attr("_id"),
			beforeSend : function() {
			},
			async : false ,
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					alert("ChangeEvent has sent to the server!");
				}else{
					alert("Incomplete action!!\nError happened while sending ChangeEvent.");
				}
			},
			error : function(e) {
				alert("Failed to refresh the setting!!");
			}
		});
}

