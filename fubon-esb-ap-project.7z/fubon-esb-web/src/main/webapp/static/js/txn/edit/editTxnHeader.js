var EditType = {
	ADD : "add",
	DELETE : "delete",
	MODIFY : "modify",
	MOVE : "move"
};

$(function() {
	editTrs = window['editTrs'] || new Array();
	hideNeededMoveBtnInScope();
});

function getNewTROrderNo() {
	var dbMax = $("#db_maxorder").val();
	var up_max = getTRArrayMaxOrder($("#tab_head").find("tr[id][orderNo]")
			.toArray());
	var down_max = getTRArrayMaxOrder($("#tab_down").find("tr[id][orderNo]")
			.toArray());
	if (dbMax == undefined)
		dbMax = 0;
	if (up_max == undefined)
		up_max = 0;
	if (down_max == undefined)
		down_max = 0;
	return Math.max(dbMax, up_max, down_max) + 1;
}

function getTRArrayMaxOrder(trArray) {
	if (!$.isArray(trArray))
		return -1;
	if (trArray.length != 0) {
		var sortArray = trArray.sort(function(a, b) {
			return $(a).attr("orderNo") - $(b).attr("orderNo")
		});
		return $(sortArray).last().attr("orderNo");
	}
	return 0;
}

/* get new tr id in cur direction container */
function getNewTRId() {
	return getCurDirection() + "_TR_" + getNewTROrderNo();
}

function getFirstTrInScope() {
	return getSearchScope().find("tr[id][orderno][fieldtype]").first();
}

function getLastTrInScope() {
	return getSearchScope().find("tr[id][orderno][fieldtype]").last();
}

function findMoveUpBtn(beLongTr) {
	return $(beLongTr).find("a[name='a_move_up']");
}

function findMoveDownBtn(beLongTr) {
	return $(beLongTr).find("a[name='a_move_down']");
}

function getCommonEditTr() {
	var editTr = {
		"searchScope" : getSearchScope(),
		"parentTrid" : getSearchScope().attr("parentTr"),
		"parentId" : getSearchScope().attr("parentId"),
		"blongDirec" : getCurDirection()
	};
	return editTr;
}

function putToEditTrArray(obj) {
	editTrs[editTrs.length] = obj;
}

function hideNeededMoveBtnInScope() {
	var $firstTr = getSearchScope().find("tr[fieldType]").first();
	var $lastTr = getSearchScope().find("tr[fieldType]").last();
	getSearchScope().find("a[name*=a_move]").show();
	findMoveUpBtn($firstTr).hide();
	findMoveDownBtn($lastTr).hide();
}

function localAdd(fieldType) {
	focusLastEditInput();
	if (!txnValidator(getSearchScope())) {
		return;
	}
	if (fieldType == undefined || fieldType == "") {
		alertInfo("欄位類型未找到！");
		return;
	}
	if (fieldType == "C") {
		var nextCase = getSearchScope().find("input[name=field_value]").last();
		if (nextCase.length != 0) {
			if (!validateCaseValue(nextCase)) {
				alertInfo("判斷值已存在！");
				return;
			}
		}
	}
	$.ajax({
		url : contextPath + "txn/editHeader/newTr",
		async : false,
		data : {
			fieldType : fieldType
		},
		success : function(trHtml) {
			var $newTr = $(trHtml);
			var newTrid = getNewTRId();
			$newTr.attr("id", newTrid);
			$newTr.attr("orderNo", getNewTROrderNo());
			$newTr.find(":radio[name*='field_value']").attr("name",
					"field_value_" + getCurDirection() + "_" + newTrid);
			if (fieldType == "C") {
				$newTr.find("#show_switch_field_code").html(
						getSearchScope().attr("parentValue"));
			}
			localAddPost($newTr);
			ajaxReBinEvents();
		}
	});

}

function focusLastEditInput() {
	var $lastTr = getSearchScope().find("tr[id][fieldType]").last();
	var fieldType = $lastTr.attr("fieldType");
	if (fieldType == "F") {
		$lastTr.find("input[name=field_code]").focus();
	} else if (fieldType == "R") {
		$lastTr.find(":radio[name*=field_value]:checked").next("input").focus();
	} else if (fieldType == "S") {
		$lastTr.find("input[name=field_value]").focus();
	} else if (fieldType == "C") {
		$lastTr.find("input[name=field_value]").focus();
	}
}

function localAddPost(newTr) {
	var $newTr = $(newTr);
	var $bottomTr = getSearchScope().find("tr[name='bottom']");
	if ($bottomTr.length > 0) {
		$newTr.insertBefore($bottomTr[0]);
	} else {
		getSearchScope().append($newTr);
	}
	var editTr = getCommonEditTr();
	editTr.trid = $newTr.attr("id");
	editTr.editType = EditType.ADD;
	putToEditTrArray(editTr);
	hideNeededMoveBtnInScope();
	focusLastEditInput();
}

function cloneTrs() {
	var $needs = getSearchScope().find(":checkbox[name='cb_copy']:checked");
	if ($needs.length == 0) {
		alertInfo("請選擇欲複製欄位");
		return;
	}
	$needs.each(function(i, item) {
		cloneTr(item);
	});
}

function cloneTr(checkBox) {
	if (!txnValidator(getSearchScope())) {
		return;
	}
	var $thisTr = getThisTr(checkBox);
	var order = getNewTROrderNo();
	var $cloneObj = $thisTr.clone();
	var newTrid = getNewTRId();
	$cloneObj.attr("id", newTrid);
	$cloneObj.attr("objId", "");
	$cloneObj.attr("orderNo", order);
	$cloneObj.find(":radio[name*=field_value]").attr("name",
			"field_value_" + getCurDirection() + "_" + newTrid);
	$cloneObj.find(":checkbox[name='cb_copy']").removeAttr("checked");
	findMoveDownBtn($cloneObj).hide();
	findMoveUpBtn($cloneObj).show();
	$cloneObj.insertBefore(getSearchScope().find("tr[name=bottom]"));
	var editTr = getCommonEditTr();
	editTr.trid = newTrid;
	editTr.editType = EditType.ADD;
	putToEditTrArray(editTr);
	hideNeededMoveBtnInScope();
}

function localModify(item) {
	var $thisTr = getThisTr(item);
	var trid = $thisTr.attr("id");
	var objId = $thisTr.attr("objId");
	if (objId == undefined || objId == "")
		return;
	var modifyTrs = $.grep(editTrs, function(item) {
		return item.editType == EditType.MODIFY && item.trid == trid;
	});
	if (modifyTrs == undefined || modifyTrs.length == 0) {
		var editTr = getCommonEditTr();
		editTr.trid = trid;
		editTr.editType = EditType.MODIFY;
		editTr.objId = objId;
		putToEditTrArray(editTr);
	}
}

function moveEffect(item) {
	getSearchScope().find("a[name*='a_move']").removeClass(EditType.MOVE);
	$(item).parent().children("a").addClass(EditType.MOVE);
}

function localMoveUp(item) {
	moveEffect(item);
	var $lastTr = getLastTrInScope();
	var $thisTr = getThisTr(item);
	var $preTr = $thisTr.prev();
	if ($preTr == undefined)
		return;
	if ($thisTr.index() == 0)
		return;
	var thisOrder = $thisTr.attr("orderNo");
	var preOrder = $preTr.attr("orderNo");
	buildOrderArr($thisTr, preOrder);
	buildOrderArr($preTr, thisOrder);
	$thisTr.attr("orderNo", preOrder);
	$preTr.attr("orderNo", thisOrder);
	$thisTr.find("a[name='a_move_down']").show();
	$thisTr.insertBefore($preTr);
	hideNeededMoveBtnInScope();
}

function localMoveDown(item) {
	moveEffect(item);
	var $firstTr = getFirstTrInScope();
	var $thisTr = getThisTr(item);
	var $nextTr = $thisTr.next();
	var thisOrder = $thisTr.attr("orderNo");
	var nextOrder = $nextTr.attr("orderNo");
	buildOrderArr($thisTr, nextOrder);
	buildOrderArr($nextTr, thisOrder);
	$thisTr.attr("orderNo", nextOrder);
	$nextTr.attr("orderNo", thisOrder);
	$thisTr.find("a[name='a_move_up']").show();
	$thisTr.insertAfter($nextTr);
	hideNeededMoveBtnInScope();
}

function buildOrderArr($tr, nowOrder) {
	var trid = $tr.attr("id");
	var preOrder = $tr.attr("orderNo");
	var objId = $tr.attr("objId");
	if (objId == undefined || objId == "")
		return;
	var moveTrs = $.grep(editTrs, function(item) {
		return item.editType == EditType.MOVE && item.trid == trid;
	});
	var editTr = getCommonEditTr();
	editTr.trid = trid;
	editTr.editType = EditType.MOVE;
	if (moveTrs != undefined && moveTrs.length > 0) {
		var tr = moveTrs[0];
		editTrs = $.grep(editTrs, function(item) {
			return item.editType == EditType.MOVE && item.trid == trid;
		}, true);
		if (tr.firstOrder != nowOrder) {
			editTr.objId = objId;
			editTr.firstOrder = tr.firstOrder;
			editTr.nowOrder = nowOrder;
		}
	} else {
		// 之前未移動
		editTr.objId = objId;
		editTr.firstOrder = preOrder;
		editTr.nowOrder = nowOrder;
	}
	putToEditTrArray(editTr);
}

function localDelete(item) {
	var $lastTr = getLastTrInScope();
	var $tr = getThisTr(item);
	var trid = $tr.attr("id");
	var objId = $tr.attr("objId");
	var editTr = getCommonEditTr($tr);
	if (objId != undefined && objId != "") {
		// console.log("sever want reomve objId:"+$tr.attr("objId"));
		editTr.trid = trid;
		editTr.editType = EditType.DELETE;
		editTr.objId = objId;
		putToEditTrArray(editTr);
	} else {
		editTrs = $.grep(editTrs, function(n) {
			// console.log("local array remove trid:"+trid);
			return n.trid == $tr.attr("id");
		}, true);
	}
	if ($tr.index() == 0) {
		if ($tr.next() != undefined)
			findMoveUpBtn($tr.next()).hide();
	}
	if ($tr.attr("id") == $lastTr.attr("id")) {
		if ($tr.prev() != undefined && $tr.prev().attr("id") != "")
			findMoveDownBtn($tr.prev()).hide();
	}
	$tr.remove();
	var $trFirstChildContainer = $("tbody[id][parentTr='" + trid + "']");
	if ($trFirstChildContainer.length != 0) {
		deleteChildrenContainers($trFirstChildContainer.attr("id"));
		$trFirstChildContainer.remove();
	}
}

function deleteChildrenContainers(parentCId) {
	if (parentCId == undefined || parentCId == "")
		return;
	$("tbody[id][container][parentC='" + parentCId + "']").each(
			function(i, item) {
				var pId = item.id;
				$(item).remove();
				deleteChildrenContainers(pId);
			});
}

function btn_save(isTemp) {
	if (isTemp == undefined)
		return;
	var isValid = false;
	isValid = txnValidator(getCommonContainer().add(getHeaderContainer()));
	if (!isValid)
		return;
	var editTxn = {
		"upTxnDirec" : {},
		"etxnFields" : new Array()
	};
	editTxn.upTxnDirec = buildTxnDirec("H");
	var dataEditTrs = new Array();
	for (var i = 0; i < editTrs.length; i++) {
		dataEditTrs.push(buildTxnField(editTrs[i].searchScope, editTrs[i]));
	}
	editTxn.etxnFields = dataEditTrs;
	// console.log(JSON.stringify(editTxn));
	var name = $("#txn_direc_code").val();
	var dirId = $("#txn_direc_id").val();
	var mainId = $("#txn_direc_mid").val();
	$.ajax({
		url : contextPath + "txn/editHeader/isExsitHeaderCode",
		data : {
			name : name,
			dirId : dirId,
			mainId : mainId
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alertInfo("Header代號重複，請重新輸入");
			} else {
				$
						.ajax({
							url : contextPath + "txn/editHeader/save/?isTemp="
									+ isTemp,
							async : false,
							type : "POST",
							data : JSON.stringify(editTxn),
							dataType : "json",
							contentType : "application/json",
							success : function(data) {
								if (data.success) {
									window.location.href = contextPath
											+ "history/goHistory";
								} else {
									alertInfo(data.errorMsg ? data.errorMsg
											: "保存失敗！");
								}
							},
							error : function(code, e) {
								// console.log(e);
							}
						});
			}
		}
	});
}

function buildTxnDirec(direction) {
	var txnDirec = {};
	txnDirec.name = $("#txn_direc_code").val();// Header代號
	txnDirec.mainId = $("#txn_direc_mid").val();// 對應正本
	txnDirec.createUser = $("#create_user").val();
	txnDirec.createTime = Date.parse($("#create_Time").val());
	txnDirec.updatedUser = $("#update_user").val();
	txnDirec.updatedTime = Date.parse($("#update_Time").val());
	txnDirec.id = $("#txn_direc_id").val();// id
	txnDirec.directionP = "H";// Header標志
	// txnDirec.typeP =
	// getHeaderContainer().find(":radio[name*='txn_direc_type']:checked").val();//
	// 接收文件格式
	// txnDirec.outTypeP =
	// getHeaderContainer().find(":radio[name*='txn_direc_out_type']:checked").val();//
	// 送出文件格式
	txnDirec.headRefId = getHeaderContainer().find("#txn_direc_head_ref").val();// 使用的電文頭部
	txnDirec.encoding = getHeaderContainer().find("#txn_direc_encoding").val();// 編碼
	return txnDirec;
}

function buildTxnField(searchScope, editTr) {
	var $thisTr = $(searchScope).find("#" + editTr.trid);
	var obj = {
		"trid" : editTr.trid,
		"parentTrid" : editTr.parentTrid,
		"editType" : "",
		"blongDirec" : editTr.blongDirec,
		"txnField" : {}
	};
	if (editTr.editType == EditType.ADD || editTr.editType == EditType.MODIFY) {
		obj.txnField = buildFieldObj($thisTr);
		if (editTr.editType == EditType.ADD) {
			obj.editType = EditType.ADD;
		} else if (editTr.editType == EditType.MODIFY) {
			obj.editType = EditType.MODIFY;
			obj.txnField.id = editTr.objId;
		}
		obj.txnField.parentId = editTr.parentId;
	} else if (editTr.editType == EditType.DELETE) {
		obj.editType = EditType.DELETE;
		obj.txnField.id = editTr.objId;
	} else if (editTr.editType == EditType.MODIFY) {
		obj.editType = EditType.MODIFY;
		obj.txnField.id = editTr.objId;
	} else if (editTr.editType == EditType.MOVE) {
		obj.editType = EditType.MOVE;
		obj.txnField.id = editTr.objId;
		obj.txnField.orderNo = editTr.nowOrder;
	}
	return obj;
}

function buildFieldObj($thisTr) {
	var txnField = {};
	var fieldType = $thisTr.attr("fieldType");
	if (fieldType == undefined)
		return txnField;
	var orderNo = $thisTr.attr("orderNo");// 序號
	var code = $thisTr.find("input[name='field_code']").val();// field id
	var name = $thisTr.find("input[name='field_name']").val();// 欄位名
	var dataType = $thisTr.find("select[name='data_type']").val();// 資料形態
	var length = $thisTr.find("input[name='field_length']").val();// 長度
	var scale = $thisTr.find("input[name='field_scale']").val();// 小數
	var defaultV = $thisTr.find("input[name='field_default']").val();// 默認值
	var padChar = $thisTr.find("input[name='field_char']").val();// 補充字元
	var justify = $thisTr.find("select[name='field_justify']").val();// 對其方式
	var includeChinese = $thisTr
			.find(":checkbox[name='field_chinese']:checked").length;// 中文
	var optional = $thisTr.find(":checkbox[name='field_optional']:checked").length;// 必填
	var value = $thisTr.find("input[name='field_value']").val();
	if (fieldType == "F") {
		txnField.blockTypeP = "B";// 默認body
		txnField.fieldTypeP = "F";// 欄位類型
		txnField.orderNo = orderNo;// 序號
		txnField.code = code;// field id
		txnField.name = name;// 欄位名
		txnField.dataTypeP = dataType;// 資料形態
		txnField.length = length;// 長度
		txnField.scale = scale;// 小數
		txnField.defaultV = defaultV;// 默認值
		txnField.padChar = padChar;// 補充字元
		txnField.justify = justify;// 對其方式
		txnField.includeChinese = includeChinese;// 中文
		txnField.optional = optional ^ 1;// 必填
	} else if (fieldType == "S") {
		txnField.fieldTypeP = "S";// 欄位類型
		txnField.orderNo = orderNo;// 序號
		txnField.value = value;
	} else if (fieldType == "C") {
		txnField.fieldTypeP = "C";// 欄位類型
		txnField.orderNo = orderNo;// 序號
		txnField.value = value;
	} else if (fieldType == "R") {
		value = $thisTr.find(":radio[name*='field_value']:checked").next(
				"input").val();
		txnField.fieldTypeP = "R";// 欄位類型
		txnField.orderNo = orderNo;// 序號
		txnField.value = value;
	}
	return txnField;
}

function btn_cancel() {
	/*
	var tmpEdit = $("#is_tmpEdit").val();
	if (tmpEdit != undefined && tmpEdit == "true") {
		$.get(contextPath + "txn/editHeader/removeTmpEditTxn", {
			"direcId" : $("#txn_direc_id").val()
		});
	}
	window.location.href = contextPath + "txn/editHeader/list";
	*/
	var back=true;
	var tmpEdit = $("#is_tmpEdit").val();
	if (tmpEdit != undefined && tmpEdit == "true") {
		back=false;
		$.ajax({
			url : contextPath + "txn/editHeader/removeTmpEditTxn",
			async : false,
			type : "GET",
			data : {"direcId" : $("#txn_direc_id").val()},
			dataType : "json",
			contentType : "application/json",
			success : function(data) {
				back=true;		
			},
			error : function(code, e) {
				// console.log(e);
			}
		});
	}
	if(back==true)
		window.location.href = contextPath + "txn/editHeader/list";
}