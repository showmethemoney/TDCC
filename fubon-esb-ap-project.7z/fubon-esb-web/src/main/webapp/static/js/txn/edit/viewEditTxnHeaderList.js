$(function() {
	seachTxnList();

	$("#search_button").on("click", function() {
		seachTxnList();
	});

	$("#file_txn_excel").on("change", function() {

	});
})

function selectFileChange(item) {
	var fileName = $(item).val();
	if (fileName != "") {
		$("#select_file_button").val(
				fileName.substring(fileName.lastIndexOf("\\") + 1));
	}
	var extension = fileName.substring(fileName.lastIndexOf(".") + 1);
	// console.log("extension:"+extension);
	if (extension == "zip" || extension == "rar") {
		$("#txnDef_txnCode").removeClass("required").removeClass("validerror");
		$("#txnDef_name").removeClass("required").removeClass("validerror");
		$("span[name='txnDef.txnCode']").hide();
		$("span[name='txnDef.name']").hide();
		$("#excel_iscompress").val("true");
	}else {
		$("#txnDef_txnCode").addClass("required");
		$("#txnDef_name").addClass("required");
		$("span[name='txnDef.txnCode']").show();
		$("span[name='txnDef.name']").show();
		$("#excel_iscompress").val("false");
	}
}

function addTxn() {
	window.location.href = contextPath + "txn/editHeader/add";
}

function deleteTxn(item) {
	confirmInfoAddtion(false, "刪除電文", "你確定要刪除此電文?", function() {
		$.ajax({
			url : contextPath + "txn/editHeader/delete/" + $(item).attr("_id"),
			beforeSend : function() {
			},
			async : false,
			dataType : "json",
			success : function(data) {
				if (data.success) {
					seachTxnList();
				}else{
					alert(data.message);
				}
			},
			error : function(e) {
			}
		});
	})

}

function seachTxnList() {
	var params = {
		name : "",
		txnHeaderStatus : "",
		curPage : 1,
		time:new Date()
	};
	params.name = $("#search_txn_code").val();
	params.txnHeaderStatus = $("#search_txn_status").val();
	if ($("#currentPage").val() != undefined)
		params.curPage = $("#currentPage").val();
	$("#content").load(contextPath + "txn/editHeader/search", params);
}

function choiceFile() {
	$("#file_txn_excel").click();
}

function selectAllBox(item) {
	// console.log(item.checked);
	if (item.checked) {
		$(":checkbox[name=txn-report]").each(function(i, item) {
			if (!item.checked) {
				$(item).click();
			}
		});
	} else {
		$(":checkbox[name=txn-report]").removeAttr("checked");
	}
}

function reportTxnHeader() {
	var $checkBoxs = $(":checkbox[name=txn-report]:checked");
	if ($checkBoxs.length == 0) {
		alertInfo("請至少選擇一筆！");
		return false;
	}
	var defIds = new Array();
	$checkBoxs.each(function(i, item) {
		defIds[i] = $(item).val();
	});
	var url = contextPath + "txn/editHeader/reportTxnExcel?defIds[]=" + defIds;
//	if (defIds.length == 1) {
//		var url = contextPath + "txn/editHeader/reportTxnExcel?defIds[]="
//				+ defIds[0];
//		// url = contextPath + "txn/editHeader/reportOneHeaderTxnExcel?direcId="
//		// + defIds[0];
//	}
	$("#hidden_report_a").attr("href", url).find("span").click();
}

function readIn() {
	$("#read-txn-excel").dialog({
		title : "匯入 Header",
		width : 500,
		modal : true,
		draggable : false,
		open : function() {

		},
		close : function() {
			document.getElementById("read-txn-form").reset();
		}
	});
}

function commitReadIn() {
	var isValid = false;
	isValid = validationForm($("#read-txn-form"));
	var fileName = $("#file_txn_excel").val();
	var extension = fileName.substring(fileName.lastIndexOf(".") + 1);
//	if(extension == "rar"){
//        alertInfo("導入請用Zip格式的文件,勿用RAR格式的文件！");
//        return;
//	}
	if(extension != "zip" && extension != "xls" && extension != "xlsx"){
		alertInfo("上傳檔案格式不對");
		return;
	}
	if (isValid) {
		$
				.ajaxFileUpload({
					url : contextPath + "/txn/editHeader/readFromExcel",
					secureuri : false,
					data : {
						"name" : $("#txnDef_txnCode").val(),
						"isCompress" : $("#excel_iscompress").val()
					},
					fileElementId : "file_txn_excel",
					dataType : "text",
					success : function(data, status) {
						if (isString(data)
								&& data.indexOf("id=\"login_form\"") != -1) {
							window.location.href = contextPath + "viewLogin";
						}
						var result = jQuery.parseJSON(data);
						var errorMsgs = result.errorMsgs;
						var returnDefIds = result.returnDefIds;
						var errorMsg = "";
						var index = 0;
						if (errorMsgs) {
							for ( var r in errorMsgs) {
								index++;
								if (index != 1) {
									errorMsg += "<br/>";
								}
								errorMsg += "<span>" + index + "、" + r
										+ ":</span>";
								var rowError = errorMsgs[r];
								if (rowError) {
									for ( var e in rowError) {
										errorMsg += "<br/><span>&nbsp;&nbsp;&nbsp;&nbsp;"
												+ rowError[e] + "</span>";
									}
								}
							}
							if (index != 0) {
								alertInfo(errorMsg);
								$("#select_file_button").val("選擇檔案");
								$("#file_txn_excel")
										.replaceWith(
												"<input showname=\"檔案\" id=\"file_txn_excel\" name=\"file_txn_excel\" type=\"file\" style=\"width:80px;position:absolute; z-index:100; margin-left:-80px;height:26px;opacity:0;filter:alpha(opacity=0);\" class=\"required\" onchange=\"selectFileChange(this);\"/>");
								return false;
							}
						}
						$("#read-txn-excel").dialog("close");
						window.location.href = contextPath
								+ "history/goHistory";
					},
					error : function(s, xml, status, e) {
						$("#select_file_button").val("選擇檔案");
						$("#file_txn_excel")
								.replaceWith(
										"<input showname=\"檔案\" id=\"file_txn_excel\" name=\"file_txn_excel\" type=\"file\" style=\"width:80px;position:absolute; z-index:100; margin-left:-80px;height:26px;opacity:0;filter:alpha(opacity=0);\" class=\"required\" onchange=\"selectFileChange(this);\"/>");
						if (s.responseText.indexOf("LoginRequiredException") != -1) {
							window.location.href = contextPath + "/home";
						}
						if (s.responseText.indexOf("Exception")) {
							alertInfo(s.responseText.substring(0,
									s.responseText.indexOf("Stack") == -1 ? 100
											: s.responseText.indexOf("Stack")));
						} else {
							alertInfo(xml + e);
						}

					}
				});
	}
}


function cancleReadIn() {
	document.getElementById("read-txn-form").reset();
	$("#select_file_button").val("選擇檔案");
	$("#read-txn-excel").dialog("close");
}


function refreshHTxn(item){
	$.ajax({
		url : contextPath + "txn/checkHeader/refresh/" + $(item).attr("_id"),
		beforeSend : function() {
		},
		timeout: 0,
		async : true,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("Header ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Unknown updating status! Sever may take too long to refresh related txn data.");
		}
	});
}


