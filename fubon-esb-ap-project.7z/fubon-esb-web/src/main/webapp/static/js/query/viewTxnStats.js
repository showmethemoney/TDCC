var cateJson = {
			"H" : "主機代號",
			"C" : "Channel 代號",
			"T" : "交易代號",
			"G" : "業務群組代號",
			"E" : "Channel 代號",
			"D" : "回應時間",
			"CT" : "Channel 代號",
			"CB" : "Channel 版塊",
			"GB" : "業務群組版塊",
			"U" : "應用系統代號"
	};

$(function(){
	changeCategory($("#category").val(), true);
});

function changeClass(classification) {
	if (classification == "2") {
		$("#classification2").show();
		$("#classification13").hide();
	} else {
		$("#classification2").hide();
		$("#classification13").show();
	}
}

function gotoPage(currentPage) {
	$("#txnStatForm").attr("action", contextPath + "/query/viewTxnStats");

	$("#currentPage").val(currentPage);
	$("#txnStatForm").submit();
}

function setOrder(field, obj) {
	var src = $(obj).attr("src");
	var asc = true;
	if (src.indexOf("normal") != -1) {
		asc = false;
	} else if (src.indexOf("up") != -1) {
		asc = false;
	} else {
		asc = true;
	}
	removeOrder();
	addOrder(field, asc);
	$("#txnStatForm").submit();
}

function searchTxnStats() {
	var result = validationForm($("#txnStatForm"));
	if(!result){
		return;
	}
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value;
	if (checkTime()) {
		$("#txnStatForm").submit();
	}
}

function checkTime() {
	var submit = true;
	var classification = $("#classification").val();
	if (classification == "2") {
		submit = checkDateRange($("#startYear").val() + "/"
				+ $("#startMonth").val() + "/01", $("#endYear").val() + "/"
				+ $("#endMonth").val() + "/01");
	} else {
		submit = checkDateRange($('#startDate').val(), $('#endDate').val());
	}
	return submit;
}

function removeOrder() {
	$("#txnStatForm").attr("action", contextPath + "/query/viewTxnStats");
	$("#asc").remove();
	$("#field").remove();
}

function addOrder(field, asc) {
	$("#txnStatForm").append(
			'<input type="hidden" id="asc" name="order.asc" value="' + asc
					+ '"/>');
	$("#txnStatForm").append(
			'<input type="hidden" id="field" name="order.field" value="'
					+ field + '"/>');
}

function exportExcel() {
	if (checkTime()) {
		$("#txnStatForm").attr("action", contextPath + "/query/exportTxnStats");
		$("#txnStatForm").submit();
	}
}

function changeCategory(category) {
	hideCategorySon(arguments[1]);
	if (category === "" || category == "A") {
		$("#valueD").val("");
		return;
	}
	var value1Font = $("#value1Font");
	value1Font.empty();
	value1Font.html(cateJson[category]);
	if (category == "D") {
		$("#dFont").show();
		return;
	}
	$("#valueD").val("");
	value1Font.show();
	$("#value1Input").show();
	
	if (category === "E") {
		$("#eFont").show();
	} else if (category === "CT") {
		$("#ctFont").show();
	}
}

function hideCategorySon(emptyable) {
	$("#categoryson").find("font").each(function(){
		$(this).hide();
	});
	if (emptyable) {
		;
	} else {
		$("#categoryson").find("input[type=text]").each(function(){
			$(this).val("");
		});
	}
}


