
function gotoNewPage(currentPage) {
	$("#currentPage").val(currentPage);
	var $form = $(document.getElementById('form1'));
	$form.find("#isAddLog").val("false");
	$form.trigger("submit");
}

function checkTime() {
	var startDate = $('#startDate').val();
    var endDate = $('#endDateStr').val();
    var flag = validationForm($("#form1"));
    if(!flag){
    	return false;
    }
	var submit = true;
	submit = checkDateRange(startDate, endDate);
	return submit;
}

