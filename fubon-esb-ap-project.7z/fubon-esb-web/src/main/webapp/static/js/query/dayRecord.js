 function gotoSubmit(){
	  var isSearch = $("#isSearch").val();
      $("#isSearch").val(true);
            if(checkCompareTime()){
            	$("#form1").attr("action", contextPath + "dayRecord/viewTxnDayRecordList");
                document.getElementById('form1').submit();
            }
        }
        
        function checkCompareTime(){
            var begin1 = document.getElementById("startHour").value;
            var begin2 = document.getElementById("startMinute").value;
            var end1 = document.getElementById("endHour").value;
            var end2 = document.getElementById("endMinute").value;
            var m =(end1*60+end2)-(begin1*60+begin2);
            if(m<0){
                alertInfo("開始日期應小於結束日期");
                return false;
            }else{
                return true;
            }
        }
        
        function gotoPage(currentPage){
        	$("#isSearch").val(false);
        	document.getElementById("currentPage").value=currentPage;
        	$("#form1").attr("action", contextPath + "/dayRecord/viewTxnDayRecordList");
            document.getElementById('form1').submit();
        }
        
        function setOrder(filed,obj) {
            $("#field").val(filed);
            $("#currentPage").val(1);
            var src = $(obj).attr("src");
            if (src.indexOf("normal.gif") > 0) {
                $("#asc").val(false);
            } else if (src.indexOf("up.gif") > 0) {
                $("#asc").val(false);
            } else if (src.indexOf("down.gif") > 0) {
                $("#asc").val(true);
            }
            $("#form1").attr("action", contextPath + "/dayRecord/viewTxnDayRecordList");
            $("#isSearch").val(false);
            $("#form1").submit();
        }
            
       function reportExcel() {
    	   if(checkCompareTime()){
    		   $("#form1").attr("action", contextPath + "/dayRecord/reportTxnRecordExcel");
    		$("#form1").submit();
       	}else{
    	   return;
       	}
       }
       
       function details(tId,rId) {
    	   $("#form1").attr("action", contextPath + "dayRecord/viewTxnRecordDetailList");
    	   $("#trackingId").val(tId);
    	   $("#recordId").val(rId);
    	   $("#isSearch").val(false);
    	   $("#currentPage").val(null);
//    	   $("asc1").value(true);
//    	   $("field1").value("txnCode");
    	   $("#form1").submit();
    	}
       
       function GoPre() {
           window.history.go(-1);
       }
