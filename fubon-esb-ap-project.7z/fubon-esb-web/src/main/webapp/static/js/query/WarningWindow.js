$(document).ready(function (){
	//create_alert_sound();
	get_host_status();	//get the current host status when page initialize
});


$.fn.redraw = function(){
	  $(this).each(function(){
	    var redraw = this.offsetHeight;
	  });
};


	if (!document.querySelectorAll) {
	  document.querySelectorAll = function (selectors) {
	    var style = document.createElement('style'), elements = [], element;
	    document.documentElement.firstChild.appendChild(style);
	    document._qsa = [];

	    style.styleSheet.cssText = selectors + '{x-qsa:expression(document._qsa && document._qsa.push(this))}';
	    window.scrollBy(0, 0);
	    style.parentNode.removeChild(style);

	    while (document._qsa.length) {
	      element = document._qsa.shift();
	      element.style.removeAttribute('x-qsa');
	      elements.push(element);
	    }
	    document._qsa = null;
	    return elements;
	  };
	}

	if (!document.querySelector) {
	  document.querySelector = function (selectors) {
	    var elements = document.querySelectorAll(selectors);
	    return (elements.length) ? elements[0] : null;
	  };
	}



function get_host_status(){
	$.ajax({
		url : contextPath + "/hostServer/updateHostServerStatusList",
		async : false,
		data : {
			
		},
		dataType : "json",
		success : function(statusList) {
			refresh_host_status(statusList);
			check_show_warning_window(statusList);
			do_next_check();
		},
		error : function(xhr, ajaxOptions, thrownError) {
			//alert("status code="+xhr.status+"\n"+thrownError);
			do_next_check();
		}
	});	
}


function do_next_check(){
	$(".md-trigger").oneTime('10s','CheckTimer',function(){
		get_host_status();
	},0,true);
}


function refresh_host_status(status_list){
	var host_table_content="";
	var server_table_content="";

	if( status_list["hostInfo"] != undefined ) {
		var hostInfo=status_list.hostInfo;
		for(var j=0;j<hostInfo.length;j++){
			host_table_content+="<tr><td>"+hostInfo[j].hostName+"</td>";
		    host_table_content+="<td>"+(hostInfo[j].hostStatus=="I"?"<font color='red'>連線中斷</font>":"啟動")+"</td>";
		    host_table_content+="<td>"+(hostInfo[j].updatedTime).replace("T"," ").replace("Z","")+"</td></tr>";
		}
		
		$('#host_connection_status table tbody:first').empty();
	    $('#host_connection_status table tbody:first').append(host_table_content);			
	}
		
	
	if( status_list["serverInfo"] != undefined ) {
		var serverInfo=status_list.serverInfo;
		for(var s=0;s<serverInfo.length;s++){
			server_table_content+="<tr><td>"+serverInfo[s].serverName+"</td>";
		    server_table_content+="<td>"+serverInfo[s].cpu+"</td>";
		    server_table_content+="<td>"+serverInfo[s].memory+"</td>";
		    server_table_content+="<td>"+serverInfo[s].disk+"</td></tr>";
		}
		
		$('#server_connection_status table tbody:first').empty();
	    $('#server_connection_status table tbody:first').append(server_table_content);			
	}	
}


function check_show_warning_window(status_list){
	var should_pop_window=false;
	$('#warning_content ul').empty();
	
	if( status_list["hostInfo"] != undefined ) {
		var hostInfo=status_list.hostInfo;		
		for(var j=0;j<hostInfo.length;j++){
			if(hostInfo[j].hostStatus=="I"){
				var li="<li><strong>"+hostInfo[j].hostName+"</strong> 主機目前無法連線! </li>";
				$('#warning_content ul:first').append(li);
				should_pop_window=true;
			}
		}
	}
	

	var window_state=document.querySelector('.md-show')==null?false:true;
	
	if(window_state==false && should_pop_window==true){
		$('.md-trigger').click();
		
		$('.md-trigger').parent().addClass('forceiepaint').removeClass('forceiepaint');
		var sel=document.getElementById('modal-5');
		sel.style.display='none';
		sel.offsetHeight; // no need to store this anywhere, the reference is enough
		sel.style.display='';
		
	}
	
	
	if(window_state==true && should_pop_window==false){
		$('.md-close').click();
		
		$('.md-close').parent().addClass('forceiepaint').removeClass('forceiepaint');
		var sel=document.getElementById('modal-5');
		sel.style.display='none';
		sel.offsetHeight; // no need to store this anywhere, the reference is enough
		sel.style.display='';
	}
}


function create_alert_sound(){
	 var audioElement;
	 
	 if(document.querySelector('#audioElem')==null){
		 audioElement = document.createElement('audio');
		 audioElement.setAttribute('id', 'audioElem');
		 audioElement.setAttribute('src', '../static/sound/alert.wav');
		 //audioElement.setAttribute('autoplay', 'autoplay');
		 audioElement.setAttribute('loop', 'loop');
		 //audioElement.load()
		 $.get();
		 $('.md-trigger').append(audioElement);
		 
		 audioElement.addEventListener("load", function() {
			 audioElement.play();
		 }, true);
		 
	 }
}



