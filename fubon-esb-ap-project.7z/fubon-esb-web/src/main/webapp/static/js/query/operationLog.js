function gotoNewPage() {
	$("#isSearch").val(false);
	document.getElementById('form1').submit();
}

function gotoSubmit() {
	var result = validationForm($("#form1"));
	if(!result){
		return;
	}
	var isSearch = $("#isSearch").val();
	$("#isSearch").val(true);
	if (checkCompareTime()) {
		document.getElementById('form1').submit();
	}
	$("#flag").val(false);
}

function selectChange(){
	$("#flag").val(true);
}

function checkCompareTime() {
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value;
	var begin2 = document.getElementById("startHour").value;
	var begin3 = document.getElementById("startMinute").value;
	var end2 = document.getElementById("endHour").value;
	var end3 = document.getElementById("endMinute").value;
	startDate = startDate+" "+begin2+":"+begin3;
	endDate = endDate+" "+end2+":"+end3;
	return checkDateRange(startDate, endDate);
}

function setOrder(filed, obj) {
	$("#field").val(filed);
	$("#currentPage").val(1);
	var src = $(obj).attr("src");
	if (src.indexOf("normal.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("up.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("down.gif") > 0) {
		$("#asc").val(true);
	}
	$("#form1").submit();
}