function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	document.getElementById('form1').submit();
}
function GoPre() {
	$("#currentPage").val($("#tempCurrentPage").val());
	$("#form1").attr("action",
			contextPath + "txnHisRecord/viewTxnHisRecordList");
	$("#isSearch").val(true);
	$("#form1").submit();
}

function setOrder(filed1,obj) {
    $("#field1").val(filed1);
    $("#currentPage").val(1);
    var src1 = $(obj).attr("src");
    if (src1.indexOf("normal.gif") > 0) {
        $("#asc1").val(false);
    } else if (src1.indexOf("up.gif") > 0) {
        $("#asc1").val(false);
    } else if (src1.indexOf("down.gif") > 0) {
        $("#asc1").val(true);
    }
    $("#form1").attr("action", contextPath + "/txnHisRecord/viewTxnHisRecordDetailList");
   // $("#isSearch").val(false);
    $("#form1").submit();
}

function reportHisDetailsExcel(trackingId,hisRecordId) {
	       var url = contextPath + "txnHisRecord/reportTxnHisRecordDetailExcel?trackingId=" + trackingId+"&hisRecordId="+hisRecordId;
	       $("#hidden_report_a").attr("href", url).find("span").click();
}