function gotoSubmit() {
	var result = validationForm($("#form1"));
	if (!result) {
		return;
	}
	var isSearch = $("#isSearch").val();
	$("#isSearch").val(true);
	if (checkCompareTime()) {
		$("#form1").attr("action",
				contextPath + "txnHisRecord/viewTxnHisRecordList");
		document.getElementById('form1').submit();
	}
}

function checkCompareTime() {
	var searchDate = document.getElementById("startDate").value;
	var begin1 = document.getElementById("startHour").value;
	var begin2 = document.getElementById("startMinute").value;
	var end1 = document.getElementById("endHour").value;
	var end2 = document.getElementById("endMinute").value;
	var startDate = searchDate + " " + begin1 + ":" + begin2;
	var endDate = searchDate + " " + end1 + ":" + end2;
	return checkDateRange(startDate, endDate);
}

function gotoPage(currentPage) {
	$("#isSearch").val(false);
	document.getElementById("currentPage").value=currentPage;
	$("#form1").attr("action",
			contextPath + "txnHisRecord/viewTxnHisRecordList");
	document.getElementById('form1').submit();
}

function setOrder(filed, obj) {
	$("#field").val(filed);
	$("#currentPage").val(1);
	var src = $(obj).attr("src");
	if (src.indexOf("normal.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("up.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("down.gif") > 0) {
		$("#asc").val(true);
	}
	$("#form1").attr("action",
			contextPath + "txnHisRecord/viewTxnHisRecordList");
	$("#isSearch").val(false);
	$("#form1").submit();
}

function reportExcel() {
	if (checkCompareTime()) {
		$("#form1").attr("action",
				contextPath + "txnHisRecord/reportTxnHisRecordExcel");
		$("#form1").submit();
	} else {
		return;
	}
}

function hisDetails(tId, rId) {
	$("#form1").attr("action",
			contextPath + "txnHisRecord/viewTxnHisRecordDetailList");
	$("#trackingId").val(tId);
	$("#hisRecordId").val(rId);
	$("#isSearch").val(false);
	$("#currentPage").val(null);
	$("#form1").submit();
}

function GoPre() {
	window.history.go(-1);
}