//$(function() {
//	var fieldName = $("#field").val();
//	var order = $("#asc").val();
//	$("#jobTable").find("img").each(function(i) {
//		if ($(this).attr("orderName") == fieldName) {
//			if (order == "true") {
//				$(this).attr("src", contextPath + "/static/images/up.gif");
//			} else if (order == "false") {
//				$(this).attr("src", contextPath + "/static/images/down.gif");
//			}
//		}
//	});
//});

function searchJobConfig() {
	if ($("#asc").val == "true") {
		$("#asc").val(true);
	} else if ($("#asc").val == "false") {
		$("#asc").val(false);
	}
	var startHour = $("#startHour").val();
	var startMinute = $("#startMinute").val();
	var endHour = $("#endHour").val();
	var endMinute = $("#endMinute").val();
	var startTime = parseInt(startHour, 10) * 100 + parseInt(startMinute, 10);
	var endTime = parseInt(endHour, 10) * 100 + parseInt(endMinute, 10);
	if (startTime > endTime) {
		alertInfo("開始時間要小於結束時間");
		return;
	}
	$("#field").val("");
	$("#viewSearchForm").submit();
}

function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewSearchForm").submit();
}

function removeJobConfig(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "/jobConfig/removeJobConfig",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/jobConfig/viewJobConfigList";
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest.status);
				alert(XMLHttpRequest.readyState);
				alert(textStatus);
			}
		});
	});

}

function setOrder(filed, obj) {

	$("#field").val(filed);
	$("#currentPage").val(1);
	var src = $(obj).attr("src");
	if (src.indexOf("normal.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("up.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("down.gif") > 0) {
		$("#asc").val(true);
	}
	$("#viewSearchForm").submit();
}

function executeJob() {
	// confirmInfo("執行", "你確定要執行?", function() {
	closeModalDiv('execuParamDialog');
	$.ajax({
		url : contextPath + "/jobConfig/jobExecute",
		data : {
			jobConfigId : $("#jobConfigId").val(),
			jobParam : $("#currParam").val()
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			if (!data.flag) {
				alertInfo(data.message);
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			alert(XMLHttpRequest.status);
			alert(XMLHttpRequest.readyState);
			alert(textStatus);
		}
	});
	// });
}

function openExecuteJob(id, paramsExample) {
	// 判斷系統排程是否暫停
	$.ajax({
		url : contextPath + "/jobConfig/isJobSysStop",
		data : {
			jobConfigId : id,
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			if (!data.flag) {
				alertInfo(data.message);
				return;
			} else {
				$("#jobConfigId").val(id);
				$("#paramTd").text(paramsExample);
				openDialog('execuParamDialog', "手動執行", 550, 190);
			}
		}
	});

}