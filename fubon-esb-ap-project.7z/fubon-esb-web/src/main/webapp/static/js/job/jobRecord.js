$(function() {
	// setTimeout(refresh(), 5000);
	setInterval(refresh, $("#refreshTime").val());
});
function refresh() {
	$("#searchRecordForm").submit();
}
function searchJobRecord() {
	if ($("#asc").val == "true") {
		$("#asc").val(true);
	} else if ($("#asc").val == "false") {
		$("#asc").val(false);
	}
	$("#field").val("");
	var flag = true;
	if ($.trim($("#runningTime").val()) != "") {
		flag = validationForm($("#searchRecordForm"));
	}
	if (flag) {
		if ($("#runningTime").val() != undefined
				&& $("#runningTime").val() != "") {
			$.ajax({
				url : contextPath + "/jobConfig/checkDate",
				data : {
					runningDate : $("#runningTime").val()
				},
				type : "POST",
				dataType : "json",
				success : function(data) {
					if (data.flag) {
						$("#searchRecordForm").submit();
					} else
						alertInfo("不能查詢一個月以前的數據!");
				}
			});
		} else
			$("#searchRecordForm").submit();
	}
}


function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#isSearch").val(false);
	$("#searchRecordForm").submit();
}

function openMemoDialog(id) {
	var url = contextPath + "/jobConfig/getJobConfig";
	$("#searchRunningTime").val($("#runningTime").val());
	$("#jobConfigId").val(id);
	$.ajax({
		url : url,
		data : {
			id : id,
			searchRunningTime : $("#searchRunningTime").val()
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			if (data.jobRecord == null) {
				alertInfo("沒有執行記錄,不能修改備註！");
				return;
			} else {
				$("#jobRecordId").val(data.jobRecord.id);
				openDialog('memoContainer', "排程備註", 500, 220);
				$("#memo").val(data.jobRecord.remark);
			}
		}
	});
}

function saveMemo() {
	var url = contextPath + "/jobConfig/saveMemo";
	ajaxSubmitForm("memoForm", url);
}

function setOrder(filed, obj) {

	$("#field").val(filed);
	$("#currentPage").val(1);
	var src = $(obj).attr("src");
	if (src.indexOf("normal.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("up.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("down.gif") > 0) {
		$("#asc").val(true);
	}
	$("#searchRecordForm").submit();
}

function jobRecordDetail(id) {
	var runDate = $("#runningTime").val();
	window.location.href = contextPath + "/jobConfig/viewJobConfigDetail?id="
			+ id + "&runningDate=" + runDate;
}
