$(function() {
	selectDurantion();
});
function saveOrUpdate() {
	var startHour = $("#startHour").val();
	var startMinute = $("#startMinute").val();
	var endHour = $("#endHour").val();
	var endMinute = $("#endMinute").val();
	var startTime = parseInt(startHour, 10) * 100 + parseInt(startMinute, 10);
	var endTime = parseInt(endHour, 10) * 100 + parseInt(endMinute, 10);
	var jobCode=$("#code").val();
	if(jobCode!="" && !new RegExp("^(?!.*?\\.).*$","g").test(jobCode)){////
		alertInfo("排程代號不能有'.'");
		return;
	}
	if (startTime > endTime) {
		alertInfo("排程時間設定的開始時間要小於結束時間");
		return;
	}
	var beforeDaysInteger = parseInt($("#beforeDays").val(), 10);
	if (beforeDaysInteger < 0 || beforeDaysInteger > 31) {
		$(":input[name='beforeDays']").addClass("validerror");
		alertInfo("時間必須在0-31之間！");
		return;
	}
	
	var url = contextPath + "/jobConfig/saveOrUpdateJobConfig";
	setMailNotification();
	setWorkTypeAndMonthType();
	var flag = validationForm($("#viewJobConfigForm"));
	if (flag) {
		ajaxSubmitForm("viewJobConfigForm", url);
	}

}
function selectDurantion() {
	var selectIndex = $("#dayType").get(0).selectedIndex;
	if (selectIndex == 0) {
		$("#dayType_W").hide();
		$("#dayType_M").hide();
		$("#dayType_D").show();
		$("#workType_D").removeAttr("disabled");
	} else if (selectIndex == 1) {
		$("#dayType_M").hide();
		// $("#dayType_W").css("display", "inline");
		$("#dayType_W").show();
		$("#dayType_D").hide();
		$("#dayW").addClass("required");
		$("#dayW").removeAttr("disabled");
		$("#day").removeClass("required");

	} else if (selectIndex == 2) {
		$("#dayType_W").hide();
		$("#dayType_M").show();
		$("#dayType_D").hide();
		// $("#dayType_M").css("display", "inline");
		$("#days").addClass("required");
		$("#days").removeAttr("disabled");
		$("#dayW").removeClass("required");
	}
	$("#dayType").parent().siblings("div").each(function() {
		if ($(this).is(":hidden")) {
			$(this).find(":input").attr('disabled', 'disabled');
		}
		if ($(this).is(":visible")) {
			$(this).find(":input").removeAttr("disabled");
		}
	});
}

function setMailNotification() {

	if ($("input[name='notificationOption']:checked").length == $("input[name='notificationOption']").length) {
		$("#notification").val(3);
	}else if($("input[name='notificationOption']:checked").length == 0){
		$("#notification").val(null);
	}else {
		$("input[name='notificationOption']:checked").each(function() {
			$("#notification").val($(this).val());
		});
	}
}

function loadMailsAndPhones() {
	var groupId = $("#mailGroupCode").find("option:selected").attr(
			"mailGroupId");
	$.ajax({
		url : contextPath + "/mailGroup/findMailsAndPhones",
		data : {
			id : groupId
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			$("#notificationMails").val(data.mails);
			$("#notificationPhones").val(data.phones);
		}
	});
}

function setWorkTypeAndMonthType() {
	$("#beforeDays").removeClass("required");
	var monthTypeValue = $(":radio[name='monthTypeRadio']:checked").val();
	if (monthTypeValue == 1) {
		$("#dayType_M").find("input[name='day']").val($("#days").val());
		// $("#workType").val(null);
		// $("#monthType").val(null);
	} else if (monthTypeValue == 2) {
		$("#workType").val($("#workType_M1").val());
		$("#monthType").val($("#monthType_1").val());
		$("#beforeDay").val($("#beforeDays").val());
		$("#beforeDays").addClass("required");

	} else if (monthTypeValue == 3) {
		$("#workType").val($("#workType_M2").val());
		$("#monthType").val($("#monthType_2").val());

	}
}