$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});
});

function serachTxn() {
	if ($("#asc").val == "true")
		$("#asc").val(true);
	else if ($("#asc").val == "false")
		$("#asc").val(false);
	$("#viewSearchTxnList").attr("action", contextPath + "txn/viewTxnList");
	$("#viewSearchTxnList").submit();
}

function setOrder(filed, obj) {
	$("#field").val(filed);
	$("#currentPage").val(1);
	var src = $(obj).attr("src");
	if (src.indexOf("normal.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("up.gif") > 0) {
		$("#asc").val(false);
	} else if (src.indexOf("down.gif") > 0) {
		$("#asc").val(true);
	}
	$("#viewSearchTxnList").attr("action", contextPath + "txn/viewTxnList");
	$("#viewSearchTxnList").submit();
}

function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewSearchTxnList").attr("action", contextPath + "txn/viewTxnList");
	$("#viewSearchTxnList").submit();
}

function findChannel(id) {
	var url = contextPath + "/txn/findChannels";
	$.ajax({
		url : url,
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			var $table = $("#channelTable tbody ");
			$table.empty();
			var thHtml = "<tr><th>Channel 代號</th></tr>";
			$table.append(thHtml);
			$.each(data.channels, function(i, item) {
				var trHtml = "<tr><td>" + item.code + "</tr></td>";
				$table.append(trHtml);
			});
			openDialog('channelContainer', "關聯Channel代號列表", 350, 370);
		}
	});
}

function reportExcel() {
	$("#viewSearchTxnList").attr("action",
			contextPath + "txn/reportTxnConfigExcel");
	$("#viewSearchTxnList").submit();
}

function deleteTxn(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "txn/deleteTxn",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
					+ "/txn/viewTxnList";
				}
				else if(!data.flag){
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});

}


function refreshTxn(item){
	$.ajax({
		url : contextPath + "/txn/refreshTxn?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}

