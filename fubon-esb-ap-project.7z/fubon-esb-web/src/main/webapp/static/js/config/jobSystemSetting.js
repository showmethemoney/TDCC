function searchJobSystemSetting() {
	$("#jobSystemConfigForm").submit();
}

function saveOrUpdateJobSystemConfig() {
	var url = contextPath + "jobSystemSetting/saveOrUpdate";
	var flagForm = validationForm($("#saveJobSystemSetting"));
	if (flagForm) {
		var id = $("#id").val();
		var systemCode = $("#systemCode").val();
		if(systemCode!="" && !new RegExp("^(?!.*?\\.)", "g").test(systemCode)){////
			alertInfo("系統代號不能有'.'");
			return;
		}
		$.ajax({
			url : contextPath + "jobSystemSetting/validateCode",
			data : {
				id : id,
				systemCode : systemCode
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					alertInfo("系統代號重複，請重新輸入");
				} else {
					ajaxSubmitForm("saveJobSystemSetting", url);
				}
			}
		});
	}
}

function isExistSameMail(mail) {
	if ($("tbody input[name=mails][value='" + mail + "']").length > 0) {
		return true;
	} else
		return false;
}

function removeTr(ele) {
	$(ele).parent().parent().remove();
}

function addMailItem() {
	if (validationForm($("#mailTD"))) {
		$("#mailAddDiv").show();
		var isExist;
		var addValue = $("#addMail").val();
		if (!isExistSameMail(addValue)) {
			if ($.trim(addValue) != "") {
				var trHtml = "<tr> <input type='hidden' name='mails' value='"
						+ addValue
						+ "' id='mails' /> <td style='text-align:center'>"
						+ addValue
						+ "<td style='text-align:center'> <a href='javascript:void(0);' value='刪除' class='tb001_delet'>刪除</a> </td></tr>";
				$("#mailAddTable").append(trHtml);
				$("#mailAddTable tr a").click(function() {
					$(this).parent().parent().remove();
				});
				$("#addMail").val("");
			}
		}
	}
}

function changeStatus(id) {
	$.ajax({
		url : contextPath + "jobSystemSetting/changeJobSystemSettingStatus",
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				if (data.isActive) {
					document.getElementById(data.getid).innerHTML = "暫停排程";
				} else {
					document.getElementById(data.getid).innerHTML = "啟動排程";
				}
			}
		}
	});
}
function removeJobSystemSetting(id) {
	confirmInfo("刪除", "你確定要刪除此排程系統設定?", function() {
		$.ajax({
			url : contextPath + "jobSystemSetting/removeJobSystemSetting",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					alertInfo("已有關聯排程設定，請先行刪除對應排程設定後再進行刪除！");
				}else{
					$("#jobSystemConfigForm").submit();
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest.status);
				alert(XMLHttpRequest.readyState);
				alert(textStatus);
			}
		});
	});
}

function removeQueueMsg(id) {
	confirmInfo("移除訊息", "你確定要移除訊息?", function() {
		$.ajax({
			url : contextPath + "jobSystemSetting/removeQueueMsg",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					$("#jobSystemConfigForm").submit();
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest.status);
				alert(XMLHttpRequest.readyState);
				alert(textStatus);
			}
		});
	});
}

function gotoNewPage() {
	document.getElementById('jobSystemConfigForm').submit();
}
