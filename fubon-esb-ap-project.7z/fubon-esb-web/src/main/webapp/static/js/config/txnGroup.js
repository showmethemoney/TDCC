$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});
});

function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#searchForm").submit();
}

function searchTxnGroup() {
	$("#searchForm").submit();
}

function validDate() {
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return false;
	} else
		return true;
}

/** 新增修改保存* */
function saveOrUpdate() {
	var url = contextPath + "/txnGroup/saveOrUpdateTxnGroup";
	var dateResult = validDate();
	var flag = validationForm($("#viewTxnGroupForm"));
	if (flag && dateResult) {
		ajaxSubmitForm("viewTxnGroupForm", url);
		// $.ajax({
		// url : url,
		// data : $("#viewTxnGroupForm").serialize(),
		// type : "POST",
		// dataType : "json",
		// success : function(data) {
		// if (!data.flag) {
		// alert(data.message);
		// } else if (data.flag) {
		// window.location.href = contextPath
		// + "/txnGroup/viewTxnGroupList";
		// }
		// }
		// });
	}
}

function findTxns(id) {
	var url = contextPath + "/txnGroup/findTxns";
	$.ajax({
		url : url,
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			var $table = $("#txnTable tbody ");
			$table.empty();
			var thHtml = "<tr><th>交易代號</th></tr>";
			$table.append(thHtml);
			$.each(data.txns, function(i, item) {
				var trHtml = "<tr><td>" + item.code + "</tr></td>";
				$table.append(trHtml);
			});
			openDialog('txnContainer', "關聯交易代號列表", 350, 370);
		}
	});
}

function findHosts(flag) {
	var url = contextPath + "/txnGroup/viewHostCodeList";
	var hostCode;
	if (flag == 1) {
		hostCode = "";
	} else if (flag == 2) {
		hostCode = $("#searchHostCode").val();
	}
	if (hostCode == "搜尋或鍵入關鍵字")
		hostCode = "";
	$("#currentPage").val($("#selPage").val());
	$.ajax({
		url : url,
		data : {
			hostCode : hostCode,
			currentPage : $("#currentPageSelect").val()
		},
		type : "POST",
		dataType : "html",
		success : function(data) {
			var div = $("#selectHost");
			div.empty();
			div.html(data);
			openDialog('selectHost', "選擇關聯主機代號", 450, 400);
		}
	});
}

function addHostCode() {
	var hostId = $("#hostCodeTable").find(
			"input:radio[name='hostRadio']:checked").attr("hostId");
	var hostCode = $("#hostCodeTable").find(
			"input:radio[name='hostRadio']:checked").attr("hostCode");
	$("#hostCode").val(hostCode);
	$("#hostId").val(hostId);
	closeModalDiv('selectHost');
}

function gotoPage2(currentPage) {
	$("#currentPage").val(currentPage);
	findHosts(2);
}

function deleteTxnGroup(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "txnGroup/deleteTxnGroup",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/txnGroup/viewTxnGroupList";
				} else if (!data.flag) {
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});
}


function refreshTxnGroup(item){
	$.ajax({
		url : contextPath + "/txnGroup/refreshTxnGroup?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}


