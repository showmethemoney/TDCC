$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});

	if ($("#bookTime").is(":visible")) {
		$("#effectDate").addClass("required");
	}

	$("#workStationIdTable tr a").click(function() {
		$(this).parent().parent().remove();
	})
	$("#branchIpTable tr a").click(function() {
		$(this).parent().parent().remove();
	})
});

function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewChannelForm").submit();
}

function firstClick(obj) {
	if (obj.value == "搜尋或鍵入關鍵字") {
		obj.value = "";
	}
}

function myBlur(obj) {
	if ($.trim(obj.value) == "") {
		obj.value = "搜尋或鍵入關鍵字";
	}
}

function showAdd(ele, showName) {
	if (validationForm($("#IPTD"))) {
		var div = $(ele).attr("showDiv");
		var addtable = $(ele).attr("showTable");
		var addInput = $(ele).attr("addInput");
		$("#" + div).css("display", "inline").show();
		var isExist;
		var addValue = $("#" + addInput).val();
		if ($.trim(addValue) != "") {
			$("#" + addtable + " tr").each(function() {
				var temp = $(this).find("input").val();
				if (temp == addValue) {
					isExist = true;
				}
			});
			if (isExist)
				return;
			var trHtml = "<tr>"
					+ "<input type='hidden' name='"
					+ showName
					+ "'  value='"
					+ addValue
					+ "' id='"
					+ showName
					+ "'/>"
					+ "<td style='text-align:center'>"
					+ addValue
					+ "<td style='text-align:center'> <a href='javascript:void(0);' value='刪除' class='tb001_delet'>刪除</a>"
					+ "</td></tr>";
			$("#" + addtable).append(trHtml);
			$("#" + addtable + " tr a").click(function() {
				$(this).parent().parent().remove();
			});
			$("#" + addInput).val("");
		}
	}
}

function searchChannel() {
	$("#viewChannelForm").submit();
}

function getAccessChannel(flag) {
	var url = contextPath + "/accessChannel/viewMainAccessChannel";
	var accessChanelCode;
	if (flag == 1) {
		accessChannelCode = "";
	} else if (flag == 2) {
		accessChanelCode = $("#searchAcCode").val();
	}
	if (accessChanelCode == "搜尋或鍵入關鍵字")
		accessChanelCode = "";
	$
			.ajax({
				url : url,
				data : {
					accessChannelCode : accessChanelCode,
					currentPage : $("#selPage").val()
				},
				type : "POST",
				dataType : "html",
				success : function(data) {
					var div = $("#selectAccessChannel");
					div.empty();
					div.html(data);
					openDialog('selectAccessChannel', "選擇關聯Access Channel代號",
							450, 400);
				}
			});
}

function gotoPage2(currentPage) {
	$("#currentPage").val(currentPage);
	getAccessChannel(2);
}

function addAccessChannel() {
	var acId = $("#selectAcTable")
			.find("input:radio[name='selAcItem']:checked").attr("acId");
	var acCode = $("#selectAcTable").find(
			"input:radio[name='selAcItem']:checked").attr("acCode");
	if (acCode != null) {
		$("#accessChannelCode").val(acCode);
		$("#accessChannelId").val(acId);
	}
	closeModalDiv('selectAccessChannel');
}

/** 提交新增Channel* */
function saveChannel() {
	validDate();
	var url = contextPath + "/channel/saveChannel";
	var flag = validationForm($("#saveChannelForm"));
	var dateResult = validDate();
	if (flag && dateResult) {
		ajaxSubmitForm("saveChannelForm", url);
	}
}
/** 修改 */
function updateChannel() {
	var url = contextPath + "/channel/updateChannel";
	var flag = validationForm($("#updateChannelForm"));
	var dateResult = validDate();
	if (flag && dateResult) {
		ajaxSubmitForm("updateChannelForm", url);
	}
}
function validDate() {
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return;
	} else
		return true;
}
function getWorkStation(id) {
	var url = contextPath + "/channel/findWorkstations";
	$
			.ajax({
				url : url,
				data : {
					id : id
				},
				type : "POST",
				dataType : "json",
				success : function(data) {
					if (data.flag) {
						$("#workstationTable tbody ").empty();
						var thHtml = "<tr><th>Workstation ID</th></tr>";
						$("#workstationTable tbody ").append(thHtml);
						$.each(data.workstations, function(i, item) {
							var trHtml = "<tr><td>" + item.code + "</td></tr>";
							$("#workstationTable tbody").append(trHtml);
						});
						openDialog('workstationContainer', "Workstation ID列表",
								400, 300);
					}
				}
			});
}

function deleteChannel(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "channel/deleteChannel",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/channel/viewChannelList";
				} else if (!data.flag) {
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});

}


function refreshChannel(item){
	$.ajax({
		url : contextPath + "/channel/refreshChannel?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}

