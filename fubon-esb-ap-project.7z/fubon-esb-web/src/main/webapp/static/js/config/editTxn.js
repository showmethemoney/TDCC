$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});

	if ($("#bookTime").is(":visible")) {
		$("#effectDate").addClass("required");
	}
});
function validDate() {
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return false;
	} else
		return true;
}
function saveOrUpdate() {
	var url = contextPath + "/txn/saveOrUpdateTxn";
	var dateResult = validDate();
	var flag = validationForm($("#viewTxnForm"));
	if (flag && dateResult) {
		ajaxSubmitForm("viewTxnForm", url);
	}
}

function findMainTxnGroup(flag) {
	var url = contextPath + "/txnGroup/findMainTxnGroup";
	var txnGroupCode = "";
	if (flag == 1) {
		txnGroupCode = "";
	} else if (flag == 2) {
		txnGroupCode = $("#searchTxnGroupCode").val();
	}
	if (txnGroupCode == "搜尋或鍵入關鍵字")
		txnGroupCode = "";
	// $("#currentPage").val($("#currentPage").val());
	$.ajax({
		url : url,
		data : {
			code : txnGroupCode,
			currentPage : $("#currentPage").val()
		},
		type : "POST",
		dataType : "html",
		success : function(data) {
			var div = $("#dialogContainer");
			div.empty();
			div.html(data);
			openDialog('dialogContainer', "選擇關聯業務群組代號", 450, 400);
		}
	});
}
function ajaxFindInfo(url, data, dialogDiv, dialogName) {
	$.ajax({
		url : url,
		data : data,
		type : "POST",
		dataType : "html",
		success : function(data) {
			var div = $("#" + dialogDiv);
			div.empty();
			div.html(data);
			openDialog(dialogDiv, dialogName, 450, 400);
		}
	});
}

function findMainService(flag) {
	var url = contextPath + "/service/findMainService";
	var serviceCode = "";
	if (flag == 1) {
		serviceCode = "";
	} else if (flag == 2) {
		serviceCode = $("#searchServiceCode").val();
	}
	if (serviceCode == "搜尋或鍵入關鍵字")
		serviceCode = "";
	var data = {
		code : serviceCode,
		currentPage : $("#currentPage").val()
	};
	ajaxFindInfo(url, data, 'dialogContainer', "選擇關聯 Service 代號");
}

function findMainChannel(flag) {
	var url = contextPath + "/channel/findMainChannels";
	var channelCode;
	if (flag == 1) {
		channelCode = "";
	} else if (flag == 2) {
		channelCode = $("#searchChannelCode").val();
	}
	if (channelCode == "搜尋或鍵入關鍵字")
		channelCode = "";
	var data = {
		code : channelCode,
		currentPage : $("#currentPage").val()
	};
	ajaxFindInfo(url, data, 'dialogContainer', "選擇關聯 Channel代號");
}

function findConnectors(flag) {
	var url = contextPath + "/connector/findConnectors";
	var connectorCode;
	if (flag == 1) {
		connectorCode = "";
	} else if (flag == 2) {
		connectorCode = $("#searchConnectorCode").val();
	}
	if (connectorCode == "搜尋或鍵入關鍵字")
		connectorCode = "";
	var data = {
		code : connectorCode,
		currentPage : $("#currentPage").val()
	};
	ajaxFindInfo(url, data, 'dialogContainer', "選擇關聯Connector代號");
}

function findMainTxn(flag) {
	var url = contextPath + "/txn/findMainTxn";
	var txnCode;
	if (flag == 1) {
		txnCode = "";
	} else if (flag == 2) {
		txnCode = $("#searchRelatedCode").val();
	}
	if (txnCode == "搜尋或鍵入關鍵字")
		txnCode = "";
	var data = {
		code : txnCode,
		currentPage : $("#currentPage").val(),
		id : $("#id").val()
	};
	ajaxFindInfo(url, data, 'dialogContainer', "選擇關聯交易代號");
}
// 限制textArea的長度
function checkLength(object, maxlength) {
	if (object.value.length > maxlength) {
		object.value = object.value.substring(0, maxlength);
		return false;
	}
}

function findAdapter(flag) {
	var url = contextPath + "/txn/findAdapters";
	var adapterName="";
	var connectorId=$("#connectorId").val();
	if ($.trim($("#connectorId").val()) == "") {
		alertInfo("請先選擇關聯Connector");
		return;
	}
	if (flag == 1) {
		adapterName = "";
	} else if (flag == 2) {
		adapterName = $("#searchAdapterName").val();
	}
    if (adapterName == "搜尋或鍵入關鍵字")
		adapterName = "";
	var data = {
		adapterName : adapterName,
		currentPage : $("#currentPage").val(),
		connectorId:connectorId		
	};
	ajaxFindInfo(url, data, 'dialogContainer', "選擇關聯 Adapter");
}