$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});
	if ($("#bookTime").is(":visible")) {
		$("#effectDate").addClass("required");
	}
});

function searchService() {
	$("#viewSearchForm").submit();
}
function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewSearchForm").submit();
}
function validDate() {
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return false;
	} else
		return true;
}
function saveOrUpdate() {
	var url = contextPath + "/service/saveOrUpdateService";
	var dateResult = validDate();
	var flag = validationForm($("#viewServiceForm"));
	if (flag && dateResult) {
		ajaxSubmitForm("viewServiceForm", url);
	}
}
function findTxns(id) {
	var url = contextPath + "/service/findTxns";
	$.ajax({
		url : url,
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			var $table = $("#txnTable tbody ");
			$table.empty();
			var thHtml = "<tr><th>交易代號</th></tr>";
			$table.append(thHtml);
			$.each(data.txns, function(i, item) {
				var trHtml = "<tr><td>" + item.code + "</tr></td>";
				$table.append(trHtml);
			});
			openDialog('txnContainer', "關聯交易代號列表", 350, 370);
		}
	});
}
function deleteService(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "service/deleteService",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/service/viewServiceList";
				} else if (!data.flag) {
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});
}


function refreshService(item){
	$.ajax({
		url : contextPath + "/service/refreshService?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}



