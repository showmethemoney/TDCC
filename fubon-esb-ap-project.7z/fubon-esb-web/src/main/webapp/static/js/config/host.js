$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		//$("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});
	if($("#bookTime").is(":visible")){
		$("#effectDate").addClass("required");
	}
});
function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewSearchForm").submit();
}

function validDate() {
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return false;
	} else
		return true;
}

/** 新增修改保存* */
function saveOrUpdate() {
	var url = contextPath + "/host/saveOrUpdateHost";
	var dateResult = validDate();
	var flag = validationForm($("#viewHostForm"));
	if (flag && dateResult) {
		$.ajax({
			url : url,
			data : $("#viewHostForm").serialize(),
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (!data.flag) {
					alertInfo(data.message);
				} else if (data.flag) {
					window.location.href = contextPath + "/host/viewHostList";
				}
			}
		});
	}
}

function searchHost(){
	$("#viewSearchForm").submit();
}

function deleteHost(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "host/deleteHost",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/host/viewHostList";
				} else if (!data.flag) {
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});
}


function refreshHost(item){
	$.ajax({
		url : contextPath + "/host/refreshHost?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}


