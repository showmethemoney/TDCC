function searchReturnCode() {
	$("#viewSearchForm").submit();
}

function saveOrUpdateReturnCode() {
	var url = contextPath + "returnCode/saveOrUpdate";
	var flagForm = validationForm($("#saveReturnCode"));
	var returnCode = $("#returnCode").val();
	var groupCode = $("#groupCode").val();
	var id = $("#id").val();
	if (flagForm) {
		$.ajax({
			url : contextPath + "returnCode/validateCode",
			data : {
				groupCode : groupCode,
				returnCode : returnCode,
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					alertInfo("業務群組代號交易回應代碼組合重複，請重新輸入");
				} else {
					ajaxSubmitForm("saveReturnCode", url);
				}
			}
		});
	}
}

function removeReturnCode(id) {
	confirmInfo("刪除", "你確定要刪除此交易回應代碼?", function() {
		$.ajax({
			url : contextPath + "returnCode/removeReturnCode",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					$("#viewSearchForm").submit();
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest.status);
				alert(XMLHttpRequest.readyState);
				alert(textStatus);
			}
		});
	});
}

function gotoNewPage() {
	document.getElementById('viewSearchForm').submit();
}


function refreshReturnCode(item){
	$.ajax({
		url : contextPath + "/returnCode/refreshReturnCode?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}



