function saveOrUpdateConnector(id) {
	var url = contextPath + "/connector/findConnector";
	var flag = validationForm($("#viewConnectorForm"));
	var code = $("#connectorCode").val();
	if (flag) {
		$.ajax({
			url : url,
			data : {
				code : code,
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (!data.flag) {
					openDialog('findConnector', "警告信息", 200, 150);
				} else {
					submitFrom(id);
					// $("#viewConnectorForm").submit();
				}
			}
		});
	}
}

function findTxns(id) {
	var url = contextPath + "/connector/findTxns";
	$.ajax({
		url : url,
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			var $table = $("#txnTable tbody ");
			$table.empty();
			var thHtml = "<tr><th>交易代號</th></tr>";
			$table.append(thHtml);
			$.each(data.txns, function(i, item) {
				var trHtml = "<tr><td>" + item.code + "</td></tr>";
				$table.append(trHtml);
			});
			openDialog('container', "關聯交易代號列表", 350, 370);
		}
	});
}

function checkSubmit() {
	$("#form1").submit();
}

function findAdapter(id) {
	var url = contextPath + "/connector/findAdapter";
	$.ajax({
		url : url,
		data : {
			id : id
		},
		type : "POST",
		dataType : "json",
		success : function(data) {
			var $table = $("#txnTable tbody ");
			$table.empty();
			var thHtml = "<tr><th style='width:250px'>Adapter 名稱</th><th>網址</th></tr>";
			$table.append(thHtml);
			$.each(data.adapter, function(i, item) {
				var trHtml = "<tr><td>" + item.adapterName + "</td><td>" + item.url + "</td></tr>";
				$table.append(trHtml);
			});
			openDialog('container', "Adapter 列表", 550, 370);
		}
	});
}

function addAdapter() {
	var name = $("#adapterName").val();
	var url = $("#adapterUrl").val();
	var flag = true;
	var $table = $("#tabContainer tbody ");
	
	var inputstring=$("#adapterName").val();
	var inputstring2=$("#adapterUrl").val();
	if(inputstring=="請輸入名稱"|| inputstring2=="請輸入網址"){
		return;
	}
	if (name != null && name != "" && url != null && url != "") {
		$("#tabContainer tbody tr td[class=adapterName] ").each(function(i, item) {
			if ($(item).text() == name) {
				alertInfo("有相同的adapterName");
				flag = false;
				return;
			}
			;
		});
		if (!flag)
			return;
		$table.append("<tr adapter adapterId><td class='adapterName'>" + name + "</td><td class='url'>" + url
				+ "</td><td><a href='#' onclick=deleteTr(this)>删除</a></td></tr>");
		$("#adapterName").val("");
		$("#adapterUrl").val("");
	} 
}

function deleteTr(object, id) {
	var flag=isDeleteAdapter(id)
	if(id==null || id==""){
		flag=true;
	}
	if(!flag){
		alertInfo("數據有關聯不可刪");
		return;
	}
	
	
	$("#viewConnectorForm").append("<input type='hidden' value="+id+" class='isDeleteAdapter'/>");
	$(object).parent().parent().remove();
	
}

function isDeleteAdapter(id) {
	var flag = true;
	$.ajax({
		url : contextPath + "/connector/isDeleteAdapter",
		data : {
			"adapterId" : id
		},
		type : "POST",
		async : false,
		dataType : "json",
		success : function(data) {
          if(data.message){
        	  flag=true;
          }else{
        	  flag=false;
          }
		}
	})
	return flag;
}

function submitFrom(id) {
	var dataArr = $.map($("#tabContainer tr[adapter]"), function(item) {
		return {
			"id" : $(item).attr("adapterId"),
			"connectorId" : "",
			"adapterName" : $(item).find("td[class=adapterName]").html(),
			"url" : $(item).find("td[class=url]").html()
		};
	})
	
	var deleteArray = $.map($("#viewConnectorForm input[class=isDeleteAdapter]"), function(item) {
		return {
			"id" : $(item).attr("value")
		};
	})

	$.ajax({
		type : "POST",
		async : false,
		url : contextPath + "/connector/saveOrUpdateConnector",
		data : JSON.stringify({
			"adapterArray" : dataArr,
			"deleteArray" : deleteArray,
			"code" : $("#connectorCode").val(),
			"name" : $("#connectorName").val(),
			"memo" : $("#connectorDesc").val(),
			"isAdd" : $("#isAdd").val(),
			"id" : id
		}),
		contentType : "application/json",
		dataType : "html",
		success : function(data) {
			if (data) {
				window.location.href = contextPath + "/connector/viewConnectorSetting";
			}
		}
	});
}


function refreshConnector(item){
	$.ajax({
		url : contextPath + "/connector/refreshConnector?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}



