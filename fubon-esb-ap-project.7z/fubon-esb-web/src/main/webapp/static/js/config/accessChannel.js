$(function() {
	$("#immediat").bind("click", function() {
		$("#bookTime").hide();
		$("#effectDate").removeClass("required");
	});
	$("#book").bind("click", function() {
		// $("#bookTime").show();
		$("#bookTime").css("display", "inline");
		$("#effectDate").addClass("required");
	});
	if ($("#bookTime").is(":visible")) {
		$("#effectDate").addClass("required");
	}
});

function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	$("#viewAccessChannel").submit();
}
function saveAccessChannel() {
	var url = contextPath + "/accessChannel/saveAccessChannel";
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();

	var flag = validationForm($("#saveAccessChannel"));
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return;
	}
	if (flag) {
		ajaxSubmitForm("saveAccessChannel", url);
	}
}

function searchAccessChannel() {
	$("#viewAccessChannel").submit();
}
function updateAccessChannel() {
	var url = contextPath + "/accessChannel/updateAccessChannel";
	var DateStr = $("#effectDate").val();
	var arys = DateStr.split('/');
	var year = parseInt(arys[0], 10);
	var month = parseInt(arys[1] - 1, 10);
	var day = parseInt(arys[2], 10);
	var hour = parseInt($("#effectHour").val(), 10);
	var minutes = parseInt($("#effectMinute").val(), 10);
	var eTime = new Date(year, month, day, hour, minutes);
	var eType = $("input[name='effectType']:checked").val();
	if (eType == "B" && eTime < new Date()) {
		alertInfo("預約生效時間不能小于當前時間！");
		return;
	}
	var flag = validationForm($("#updateAccessChannel"));
	if (flag) {
		ajaxSubmitForm("updateAccessChannel", url);
		// $.ajax({
		// url : url,
		// type : "POST",
		// dataType : 'json',
		// data : $("#updateAccessChannel").serialize(),
		// success : function(result) {
		// if (!result.flag) {
		// alert(result.message);
		// }
		// if (result.flag) {
		// window.location.href = contextPath
		// + "/accessChannel/viewAccessChannel";
		// }
		// }
		// });
	}
}

function getChannel(id) {
	$.ajax({
		url : contextPath + "/accessChannel/viewChannelByAcId",
		data : {
			accessChannelId : id
		},
		type : "POST",
		dataType : "html",
		success : function(data) {
			var div = $("#channelContainer");
			div.empty();
			div.html(data);
			openDialog('channelContainer', "對應 Channel", 400, 300);
		}
	});
	function closeDialog(divId) {
		$("#" + divId).dialog("close");
	}
}

function deleteAccessChannel(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "accessChannel/deleteAccessChannel",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/accessChannel/viewAccessChannelList";
				} else if (!data.flag) {
					alertInfo(data.message);
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});
	});
}

function refreshAccessChannel(item){
	$.ajax({
		url : contextPath + "/accessChannel/refreshAccessChannel?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}
