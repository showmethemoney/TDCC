function removeTr(ele) {
	$(ele).parent().parent().remove();
}

function addMailItem() {
	if (validationForm($("#mailTD"))) {
		$("#mailAddDiv").show();
		var isExist;
		var addValue = $("#addMail").val();
		if (!isExistSameMail(addValue)) {
			if ($.trim(addValue) != "") {
				var trHtml = "<tr> <input type='hidden' name='mails' value='"
						+ addValue
						+ "' id='mails' /> <td style='text-align:center'>"
						+ addValue
						+ "<td style='text-align:center'> <a href='javascript:void(0);' value='刪除' class='tb001_delet'>刪除</a> </td></tr>";
				$("#mailAddTable").append(trHtml);
				$("#mailAddTable tr a").click(function() {
					$(this).parent().parent().remove();
				});
				$("#addMail").val("");
			}
		}
	}
}

function addMailPhone() {
	if (validationForm($("#phoneTD"))) {
		$("#phoneAddDiv").show();
		var isExist;
		var addValue = $("#addPhone").val();
		if (!isExistSamePhone(addValue)) {
			if ($.trim(addValue) != "") {
				var trHtml = "<tr> <input type='hidden' name='phones' value='"
						+ addValue
						+ "' id='phones' /> <td style='text-align:center'>"
						+ addValue
						+ "<td style='text-align:center'> <a href='javascript:void(0);' value='刪除' class='tb001_delet'>刪除</a> </td></tr>";
				$("#phoneAddTable").append(trHtml);
				$("#phoneAddTable tr a").click(function() {
					$(this).parent().parent().remove();
				});
				$("#addPhone").val("");
			}
		}
	}
}
function isExistSameMail(mail) {
	if ($("tbody input[name=mails][value='" + mail + "']").length > 0) {
		return true;
	} else
		return false;
}

function isExistSamePhone(phone) {
	if ($("tbody input[name=phones][value='" + phone + "']").length > 0) {
		return true;
	} else
		return false;
}
function saveOrUpdateMaiGroup() {
	var url = contextPath + "/mailGroup/saveOrUpdate";
	var flag = validationForm($("#saveMailGroup"));
	if (flag) {
		ajaxSubmitForm("saveMailGroup", url);
	}
}

function removeMailGroup(id) {
	confirmInfo("刪除", "你確定要刪除?", function() {
		$.ajax({
			url : contextPath + "/mailGroup/removeMailGroup",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					window.location.href = contextPath
							+ "/mailGroup/viewMailGroupList";
				}
			}
		});
	});

}

function searchMaiGroup() {
	$("#viewSearchForm").submit();
}


function refreshMailGroup(item){
	$.ajax({
		url : contextPath + "/mailGroup/refreshMailGroup?id=" + $(item).attr("_id"),
		beforeSend : function() {
		},
		async : false ,
		dataType : "json",
		success : function(data) {
			if (data.flag) {
				alert("ChangeEvent has sent to the server!");
			}else{
				alert("Incomplete action!!\nError happened while sending ChangeEvent.");
			}
		},
		error : function(e) {
			alert("Failed to refresh the setting!!");
		}
	});
}

