/**
 * 加入Group修改頁面
 * 
 * @param id
 */
function viewGroupByAjax(id) {
	$.ajax({
		url : contextPath + "/system/viewGroup",
		type : "post",
		dataType : "html",
		data : {
			id : id
		},
		success : function(data) {
			$("#ajaxContent").html(data);
		}
	});
}

/**
 * 添加Group的修改
 */
function saveOrUpdateGroup() {
	var flag = validationForm($("#groupForm"));
	if (flag) {
//		$.ajax({
//			url : contextPath + "/system/saveOrUpdateGroup",
//			type : "post",
//			dataType : "json",
//			data : $("#groupForm").serialize(),
//			success : function(data) {
//				if (data.flag) {
//					viewGroupInfo(data.groupId);
//					refreshMenu();
//				}
//			}
//		});
		
		var url = contextPath + "/system/saveOrUpdateGroup";
		ajaxSubmitForm("groupForm", url, function(url) {
//			loadInfoByAjax(contextPath + url, null, 'ajaxContent');
//			alert(url);
			viewGroupInfo(url); // url is roleID
			refreshMenu();
		});
	}
	

}

/**
 * 
 * @param id
 */
function viewGroupInfo(id) {
	var url = contextPath + "/system/viewGroupInfo";
	var data = {
		"id" : id
	};
	loadInfoByAjax(url, data, "ajaxContent");
}

/**
 * 取消群組的新增或修改
 */
function cancelViewGroup() {
	if ($("#groupId").length < 1) {
		var welcomeStr = '<div><p style="color:#333; font-size:36px;padding:30px;">角色權限設定</p>'
				+ '<p style="color:#999; font-size:16px;padding-left:30px;">&lt;&lt; 請點選左方角色進行編輯。</p>'
				+ '<p style="color:#999; font-size:16px;padding-left:30px; padding-top:20px;">'
				+ '<input type="button" class="submit_btn" onclick="viewGroupByAjax();" value="新增群組"></p></div>';
		$('#ajaxContent').html(welcomeStr);
	} else {
		viewGroupInfo($("#originGroupId").val()); // 用最初的ID
	}
}

/**
 * 加入 角色 修改頁面
 * 
 * @param groupId
 * @param roleId
 */
function viewRole(groupId, roleId) {
	var url = contextPath + "/system/viewRole";
	var data = {
		"groupId" : groupId,
		"roleId" : roleId
	};
	loadInfoByAjax(url, data, "ajaxContent");
}

/**
 * 新增或修改角色
 */
function saveOrUpdateRole() {
	var flag = validationForm($("#roleForm"));
	if (flag) {
		$.ajax({
			url : contextPath + "/system/saveOrUpdateRole",
			type : "post",
			dataType : "json",
			data : $("#roleForm").serialize(),
			success : function(data) {
				if (data.flag) {
					viewGroupInfo(data.groupId);
					refreshMenu();
				}
			}
		});
	}
}

/**
 * 新增或修改角色,保存成功后，進入權限設定頁面
 */
function saveOrUpdateRole2() {
	var flag = validationForm($("#roleForm"));
	if (flag) {
		$.ajax({
			url : contextPath + "/system/saveOrUpdateRole",
			type : "post",
			dataType : "json",
			data : $("#roleForm").serialize(),
			success : function(data) {
				if (data.flag) {
					refreshMenu();
					viewFuncList2(data.roleId);
				}
			}
		});
	}
}

/**
 * 打開選擇單位彈窗
 */
function selectBranches() {
	loadInfoByAjax(contextPath + "/system/viewBranchList", null,
			"ajaxBranchList");
	$(":checkbox.branchClass").each(function() {
		$(this).prop("checked", false);
	});
	openDialog("popBranch", "帳號清單", 400, 380);
}

/**
 * 選擇單位彈窗中分頁
 * 
 * @param currentPage
 */
function gotoPage(currentPage) {
	$("#currentPage").val(currentPage);
	loadInfoByAjax(contextPath + "/system/viewBranchList", $("#branchListForm")
			.serialize(), "ajaxBranchList")
}

function addBranches() {
	$(".branchClass:checked")
			.each(
					function(index) {
						var branchCode = $(this).attr("branchCode");
						if (isBranchCodeExists(branchCode)) {
							var branchName = $(this).attr("branchName");
							var trStr = '<tr class="bg"><input type="hidden" name="userIds"  value="'
									+ branchCode
									+ '" /><td style="text-align:center">'
									+ branchName
									+ '</td><td style="text-align:center"><a href="javascript:void(0)" onclick="$(this).parents(\'tr:first\').remove();_changeRole();">刪除</a></td></tr>';
							$("#branchBody").append(trStr);
						}
					});
	$("#popBranch").dialog("close");
}

function isBranchCodeExists(branchCode) {
	if ($("input[name=userIds][value=" + branchCode + "]").length == 0) {
		return true;
	}

	return false;
}

/** 刷新左側菜單 */
function refreshMenu() {
	loadInfoByAjax(contextPath + "/system/refreshGroupList", null, "groupMenu");
}

function viewFuncList(roleId) {
	if (roleId == undefined) { // 新增角色
		confirmInfo("提示", "當前角色尚未保存，是否保存角色並繼續操作?", function() {  // yes
			saveOrUpdateRole2();
		}, function(){ // no
			;
		}, 350);
		return;
	}
	
	
	if ($("#_isChanged").val() == "true") { // 新增角色
//		confirmInfo("提示", "當前角色尚未保存，是否保存角色並繼續操作?", function() {  // yes
		confirmInfo2("提示", "角色未儲存，是否儲存?", true, function() {  // yes
			saveOrUpdateRole2();
		}, function(){ // no
			;
			var data = {
					"roleId" : roleId
				}
			loadInfoByAjax(contextPath + "/system/viewFuncList", data, "ajaxContent");
		}, 350);
		return;
	}
	
	
	var data = {
			"roleId" : roleId
		}
		loadInfoByAjax(contextPath + "/system/viewFuncList", data, "ajaxContent");
}

function viewFuncList2(roleId) {
	var data = {
			"roleId" : roleId
		}
		loadInfoByAjax(contextPath + "/system/viewFuncList", data, "ajaxContent");
}

/**
 * 更新權限
 */
function saveOrUpdateFuncList() {
	// $.ajax({
	// url : contextPath + "/system/saveOrUpdateFuncList",
	// type : "post",
	// async : false,
	// dataType : "json",
	// data : $("#functionForm").serialize(),
	// success : function(data) {
	// // $("#" + divId).html(data);
	// if (data.flag) {
	// viewRole(data.groupId, data.roleId)
	// }
	// }
	// });

	var url = contextPath + "/system/saveOrUpdateFuncList";
	ajaxSubmitForm("functionForm", url, function(url) {
		loadInfoByAjax(contextPath + url, null, 'ajaxContent');
	});
}

/**
 * 權限級聯
 * 
 * @param obj
 */
function relativeFunction(obj) {
	var obj = $(obj);
	var dependCode = obj.attr("dependCode");
	if (dependCode != undefined) {
		if (obj.prop("checked")) {
			var parent = $(":checkbox[value=" + dependCode + "]"); 
			parent.prop("checked", true);
			relativeFunction(parent);
		}
	}

	if (!obj.prop("checked")) {
		var v = obj.val();
		$(":checkbox[dependCode=" + v + "]").each(function(){
			$(this).prop("checked", false);
			relativeFunction(this);
		});
	}
}

function viewRoleFromFunc(roleId) {
	if (roleId == undefined || roleId == "") {
		var welcomeStr = '<div><p style="color:#333; font-size:36px;padding:30px;">角色權限設定</p>'
				+ '<p style="color:#999; font-size:16px;padding-left:30px;">&lt;&lt; 請點選左方角色進行編輯。</p>'
				+ '<p style="color:#999; font-size:16px;padding-left:30px; padding-top:20px;">'
				+ '<input type="button" class="submit_btn" onclick="viewGroupByAjax();" value="新增群組"></p></div>';
		$('#ajaxContent').html(welcomeStr);
		return;
	}
	var data = {
		roleId : roleId
	};
	loadInfoByAjax(contextPath + "/system/viewRoleFromFunc", data,
			"ajaxContent")
}

function _changeRole() {
	$("#_isChanged").val(true);
}

function checkEnterButton() {
	if (window.event && window.event.keyCode == 13) {
        window.event.returnValue = false;
        loadInfoByAjax(contextPath + "/system/viewBranchList", $("#branchListForm")
    			.serialize(), "ajaxBranchList");
    }
}

function loadInfoByAjax(url, data, divId) {
	$.ajax({
		url : url,
		type : "post",
		async : false,
		dataType : "html",
		data : data,
		success : function(data) {
			$("#" + divId).empty();
			$("#" + divId).html(data);
		}
	});
}
