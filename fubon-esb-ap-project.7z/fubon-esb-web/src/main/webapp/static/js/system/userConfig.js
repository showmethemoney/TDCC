function searchUserConfig() {
	$("#viewUserConfigForm").attr("action",
			contextPath + "system/viewUserConfigList");
	$("#viewUserConfigForm").submit();
}

function saveOrUpdateUserConfig(id) {
	var url1 = contextPath + "system/saveOrUpdate";
	var flagForm = validationForm($("#saveUserConfig"));
	var userId = $("#userId").val();
	var mainId = $("#mainId").val();
	if (flagForm) {
		$.ajax({
			url : contextPath + "system/validateId",
			data : {
				id : id,
				userId : userId,
				mainId : mainId
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					alertInfo("系統帳號重複，請重新輸入");
				} else {
					ajaxSubmitForm("saveUserConfig", url1);
				}
			}
		});
	}
}
//function deleteTemp(id,mainId) {
//	if(0!=mainId){
//		$.ajax({
//			url : contextPath + "system/removeUserConfig",
//			data : {
//				id : id
//			},
//			type : "POST",
//			dataType : "json",
//			success : function(data) {
//				if (data.flag) {
//					
//				}
//			},
//			error : function(XMLHttpRequest, textStatus, errorThrown) {
//				alert(XMLHttpRequest.status);
//				alert(XMLHttpRequest.readyState);
//				alert(textStatus);
//			}
//		});
//	}
//	location.href = contextPath + "/system/viewUserConfigList";
//}
function removeUserConfig(id) {
	confirmInfo("刪除", "你確定要刪除此帳號?", function() {
		$.ajax({
			url : contextPath + "system/removeUserConfig",
			data : {
				id : id
			},
			type : "POST",
			dataType : "json",
			success : function(data) {
				if (data.flag) {
					$("#viewUserConfigForm").attr("action",
							contextPath + "system/viewUserConfigList");
					$("#viewUserConfigForm").submit();
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest.status);
				alert(XMLHttpRequest.readyState);
				alert(textStatus);
			}
		});
	});
}

function gotoNewPage() {
	$("#viewUserConfigForm").attr("action",
			contextPath + "system/viewUserConfigList");
	$("#viewUserConfigForm").submit();
}

function reportExcel() {
	$("#viewUserConfigForm").attr("action",
			contextPath + "system/reportUserConfigExcel");
	$("#viewUserConfigForm").submit();
}