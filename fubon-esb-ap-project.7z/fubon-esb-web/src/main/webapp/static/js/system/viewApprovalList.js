/**
 * 加入Group修改頁面
 * @param id
 */
function viewApprovalList(isApproval, groupId, roleId) {
	if (roleId == undefined) {
		location.href = contextPath + "/system/viewApproval?isApproval=" + isApproval + "&groupId=" + groupId;
		return;
	}
	location.href = contextPath + "/system/viewApproval?isApproval=" + isApproval + "&groupId=" + groupId + "&roleId=" + roleId;
}

function onsubmits(){
	var result = validationForm($("#approvalForm"));
	if(!result){
		return;
	}
	var startDate = document.getElementById("startDateStr").value;
    var endDate = document.getElementById("endDateStr").value;
    if (checkDateRange($('#startDateStr').val(), $('#endDateStr').val())) {
	$("#approvalForm").submit();
	}
}

function cancelViewApproval() {
	location.href = contextPath + "/system/viewApprovalList";
}

function runApproval(groupId, roleId) {
	$("#modifyContentHidden").val($("#modifyContent").html());
	if (ajaxSubmitForm("approvalForm", contextPath + "/system/runApproval")) {
		cancelViewApproval()
	}
}

function checkBack(obj) {
	if (window.event.keyCode = 8) {
		window.event.returnValue = false;
		$(obj).val("");
	}
}
