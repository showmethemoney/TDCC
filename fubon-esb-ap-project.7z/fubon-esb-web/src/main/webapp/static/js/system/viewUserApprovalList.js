function onsubmits() {
	var result = validationForm($("#userApprovalForm"));
	if (!result) {
		return;
	}
	if (checkDateRange($('#startDateStr').val(), $('#endDateStr').val())) {
		$("#userApprovalForm").submit();
	}
}

function viewUserApprovalList(isApproval, id) {
	location.href = contextPath + "system/viewUserApproval?isApproval="
			+ isApproval + "&id=" + id;
}

function runUserApproval(id) {
	$.ajax({
		url : contextPath + "/system/runUserApproval",
		type : "post",
		async : false,
		dataType : "json",
		data : {
			id : id,
			modifyContent : $("#modifyContent").html()
		},
		success : function(data) {
			if (data.flag) {
				alertInfo("設定人不可和複核人為同一人員!");
			} else {
				location.href = contextPath + "/system/viewUserApprovalList";
				// window.history.go(-1);
				// $("#userApprovalForm").submit();
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			alert(XMLHttpRequest.status);
			alert(XMLHttpRequest.readyState);
			alert(textStatus);
		}
	});
}

function checkBack(obj) {
	if (window.event.keyCode = 8) {
		window.event.returnValue = false;
		$(obj).val("");
	}
}
