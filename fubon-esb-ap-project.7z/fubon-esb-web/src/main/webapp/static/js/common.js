function loadi18n(keys) {
	if (keys == null || keys.length == 0) {
		return;
	}
	//jQuery(document).ready(function() {
		var method = keys.length > 20 ? "POST" : "GET";
		jQuery.ajax({
			url: contextPath + "/js/resource",
			data: {
				"key[]": keys
			},
			type: method,
			cache: true,
			async : false,
			dataType: "script",
			success: function(data) {
			}
		});
	//});
}
// nTabs
function nTabs(thisObj,Num){
if(thisObj.className == "active")return;
var tabObj = thisObj.parentNode.id;
var tabList = document.getElementById(tabObj).getElementsByTagName("li");
for(i=0; i <tabList.length; i++)
{
if (i == Num)
{
   thisObj.className = "active"; 
      document.getElementById(tabObj+"_Content"+i).style.display = "block";
}else{
   tabList[i].className = "normal"; 
   document.getElementById(tabObj+"_Content"+i).style.display = "none";
}
} 
}

//Menu
function show(flag,ele)
{
	if(flag=="over")
	{
		document.getElementById(ele).style.display='block';
	}
	else if(flag=="out"){
		document.getElementById(ele).style.display='none';
	}
}

function tab(img,ele)
{
	var display=document.getElementById(ele).style.display;
	if(display=="block")
	{
		document.getElementById(img).src= contextPath + '/static/images/select.png';
		document.getElementById(ele).style.display='none';
	}
	else
	{
		document.getElementById(img).src=contextPath + '/static/images/selected_down.png';
		document.getElementById(ele).style.display='block';
	}
}

//彈出框
function openDialog(id,title,width,height){
	var id=document.getElementById(id);
	$(id).dialog({
		title:title,
		width:width,
		height:height,
		modal:true,
		draggable:false
	});
}
function closeModalDiv(id) {
	$("#"+id).dialog("close");
}

function disposeData(data, callback) {
	if (data && data.errorMessages && data.errorMessages.length > 0) {
		var maxlen = 0;
		var msg = "";
		for (i = 0; i < data.errorMessages.length; i++) {
			if (i > 0) {
				msg += "<br>";
			}
			msg += (i + 1) + "、" + data.errorMessages[i];
			if (data.errorMessages[i].length > maxlen) {
				maxlen = data.errorMessages[i].length;
			}
		}
		var height = 110 + 20 * data.errorMessages.length;
		var width = 80 + 15 * maxlen;
		$("#WRAN_DIV_SPAN").html(msg);
		openDialog("WRAN_DIV", "警告信息", width, height);
		return false;
	} else if (data && data.status == "SUCCESS") {
		if (callback) {
			callback(data.redirectUrl);
		} else if (data.redirectUrl) {
			linkto(contextPath + data.redirectUrl);
		}
		return true;
	}
}
function ajaxSubmitForm(fromId, url, callback) {
	var result = true;
	$.ajax({
		type : "POST",
		url : url,
		data : $('#' + fromId).serialize(),
		async : false,
		dataType : "json",
		error : function(request) {
			alert("Connection error");
			result = false;
		},
		success : function(data) {
			result = disposeData(data, callback);
		}
	});
	return result;
}

function linkto(href){location.href=href;}
function changeTimeZone(obj){
	jQuery.ajax({
		url: contextPath + "/changeTimeZone",
		data : {timeZone:obj.value},
		type: 'POST',
		cache: false,
		async : true,
		success: function(data) {
		}
	});
}
jQuery(document).ready(function() {
	jQuery.ajax({
		url: contextPath + "/timeZoneSet",
		type: 'POST',
		cache: false,
		async : true,
		dataType: "json",
		success: function(data) {
			var json = eval(data)
			$("#timeZone").find("option").remove();
			for(var i=0;i<json.length;i++){
				var name = json[i].name;  
	            var zone = json[i].zone;
	            var select = json[i].select;
	            var option="";
	            if("true" == select){
	            	option="<option selected value='"+zone+"'>"+name+"</option>";
	            }else{
	            	option="<option value='"+zone+"'>"+name+"</option>";
	            }
	            $("#timeZone").append(option);
			}
		}
	});
	
	$(".datepicker" ).each(function(){
		$(this).datepicker({
			showOn: "button",
			buttonImage: contextPath +"static/images/date.gif",
			buttonImageOnly: true,
			gotoCurrent: true, // True if today link goes back to current selection instead
			changeMonth: true, // True if month can be selected directly, false if only prev/next
			changeYear: true,
			showButtonPanel: true
		});
	});
});

function alertInfo(message) {
	alertInfo2(message,'auto');
}

function alertInfo2(message, width) {
	$("<div style='text-align:left'>" + message + "<br/><br/><p style='text-align:center'><button class='but01'>確定</button></p></div>").dialog({
		title : "提示",
		width : width,
		modal : true,
		draggable : false,
		minHeight : 0,
		open : function() {
			var $theDialog = $(this);
			$theDialog.find("button").eq(0).click(function() {
				$theDialog.dialog("close");
			});
		}
	}).Option;
}

function confirmInfoAddtion(async, title, text, yesFunc, noFunc, width) {
	if ("undefined" === $.type(title)) {
		title = "提示";
	}
	if ("undefined" === $.type(width)) {
		width = 240;
	}
	var $dialog=$("<div style=\"background:#fff ; padding-top:15px; text-align:center; color:#333;\">" + text + "</div>").dialog({
		title: title,
		width: width,
		height: 140,
		modal: true,
		draggable: false,
		close: function(event, ui) {
			if ("function" === (typeof noFunc)) {
				noFunc.call();
			}
		},
		buttons: [ {
			text: "確認",
			click: function() {
				if (!async) {
					if ("function" === (typeof yesFunc)) {
						yesFunc.call();
					}
					$dialog.dialog("close");
				}else{
					$(this).dialog("close");
					if ("function" === (typeof yesFunc)) {
						yesFunc.call();
					}
				}
			}
		}, {
			text: '取消',
			click: function() {
				if (!async) {
					if ("function" === (typeof noFunc)) {
						noFunc.call();
					}
					$dialog.dialog("close");
				}else{
					$(this).dialog("close");
					if ("function" === (typeof noFunc)) {
						noFunc.call();
					}
				}
			}
		} ]
	});
}

function confirmInfo(title, text, yesFunc, noFunc, width) {
	//console.log("ajax complete!");
	if ("undefined" === $.type(title)) {
		title = "提示";
	}

	if ("undefined" === $.type(width)) {
		width = 240;
	}
	$("<div style=\"background:#fff ; padding-top:15px; text-align:center; color:#333;\">" + text + "</div>").dialog({
		title: title,
		width: width,
		height: 140,
		modal: true,
		draggable: false,
		close: function(event, ui) {
			if ("function" === (typeof noFunc)) {
				noFunc.call();
			}
		},
		buttons: [ {
			text: "確認",
			click: function() {
				$(this).dialog("close");
				if ("function" === (typeof yesFunc)) {
					yesFunc.call();
				}
			}
		}, {
			text: '取消',
			click: function() {
				$(this).dialog("close");
				if ("function" === (typeof noFunc)) {
					noFunc.call();
				}
			}
		} ]
	});
}

/**confirm 2, 用flag來判斷是否close室執行noFunc*/
function confirmInfo2(title, text, flag, yesFunc, noFunc, width) {
	if ("undefined" === $.type(title)) {
		title = i18n['confirm'];
	}

	if ("undefined" === $.type(width)) {
		width = 240;
	}
	$("<div style=\"background:#fff ; padding-top:15px; text-align:center; color:#333;\">" + text + "</div>").dialog({
		title: title,
		width: width,
		height: 130,
		modal: true,
		draggable: false,
		close: function(ui) {
			if (flag) {
				if ("function" === (typeof noFunc)) {
					noFunc.call();
				}
			}
		},
		buttons: [ {
			text: "確認",
			click: function() {
				flag = false;
				$(this).dialog("close");
				if ("function" === (typeof yesFunc)) {
					yesFunc.call();
				}
			}
		}, {
			text: "取消",
			click: function() {
				flag = false;
				$(this).dialog("close");
				if ("function" === (typeof noFunc)) {
					noFunc.call();
				}
			}
		} ]
	});
}

/**
 * 判斷起訖時間是否符合日常需求
 * @param startDate
 * @param endDate
 * @returns {Boolean}
 */
function checkDateRange(startDate, endDate) {
	if (isNotNullOrEmpty(startDate) && isNotNullOrEmpty(endDate)) {
		var start = new Date(startDate);
		var end = new Date(endDate);
		if (start > end) {
			alertInfo("開始時間不能晚於結束時間!")
			return false;
		}
	}
	return true;
}

function isNotNullOrEmpty(str) {
	if (str == undefined || str == "") {
		return false;
	}
	return true;
}

function gotoPage(currentPage, callBack) {
	$("#currentPage").val(currentPage);
	if (callBack != undefined && (typeof callBack) == "function") {
		callBack.call();
	}
}

document.onkeydown = function(e){
   if(!e) e = window.event;
   if((e.keyCode || e.which) == 13){
	   e.returnValue = false;
     //TODO
	   enterTODO();
   }
}
function enterTODO(){};

$.ajaxSetup({
	dataFilter : function(data, type) {
		// console.log("ajax filter data:" + data);
		if (isString(data) && data.indexOf("id=\"login_form\"") != -1) {
			window.location.href = contextPath + "viewLogin";
		}
		return data;
	}
});

function isString(str) {
	return (typeof str == 'string') && str.constructor == String;
} 
