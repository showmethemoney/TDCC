package com.fubon.esb.controller.query;

import java.util.Calendar;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.service.query.HolidayService;

/**
 * 假日檔查詢Controller
 * @author Leckie Zhang
 * @createdDate 2014-11-12
 */
@Controller
@RequestMapping("query")
public class HolidayController extends BaseController {
    
    @Inject
    private HolidayService holidyService;
    
    @RequestMapping("viewHolidys")
    @RequirePermission("030401")
    public String viewHolidys(Model model, Integer year, Boolean isSearch) {
        if (isSearch != null && isSearch) {
            model.addAttribute("holidyList", holidyService.findHolidysByYear(year));
            model.addAttribute("year", year);
            model.addAttribute("isSearch", isSearch);
        } else {
            // 默認顯示今年的數據
            int thisYear = Calendar.getInstance().get(Calendar.YEAR);
            model.addAttribute("holidyList", holidyService.findHolidysByYear(thisYear));
            model.addAttribute("year", thisYear);
            model.addAttribute("isSearch", true);
        }
        return "/query/viewHolidys";
    }

}
