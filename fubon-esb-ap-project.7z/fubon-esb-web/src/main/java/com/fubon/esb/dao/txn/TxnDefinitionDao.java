package com.fubon.esb.dao.txn;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnStatus;


/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Repository
public class TxnDefinitionDao extends JPADaoSupport<TxnDefinition>
{

	public List<TxnDefinition> findAll() {
		Query query = Query.from( TxnDefinition.class ).orderBy( "txnCode" );
		return jpaAccess.find( query );
	}

	public List<TxnDefinition> findPageByCodeNameAndStatusAddtion(String txnCode, String txnName, TxnStatus txnStatus, Page page) {
		Query query = Query.from( TxnDefinition.class ).append( " m " ).where( " status !=:deleteStatus" ).param( "deleteStatus", TxnStatus.D );
		if (StringUtils.isNotBlank( txnCode )) {
			query.append( " and txnCode like :txnCode" );
			query.param( "txnCode", "%" + txnCode + "%" );
		}
		if (StringUtils.isNotBlank( txnName )) {
			query.append( " and name =:txnName" );
			query.param( "txnName", txnName );
		}
		if (txnStatus != null) {
			query.append( " and status=:txnStatus" );
			query.param( "txnStatus", txnStatus );
		}
		query.append( " and not exists(select 1 from " ).append( TxnDefinition.class ).append( " c where m.id=c.mainId)" );
		query.orderBy( "txnCode" );
		query.page( page );
		return jpaAccess.findPage( query );
	}

	public List<TxnDefinition> findPageByCodeNameAndStatus(String txnCode, String txnName, List<TxnStatus> txnStatuses, Page page) {
		Query query = Query.from( TxnDefinition.class ).where( "1=1" );
		if (StringUtils.isNotBlank( txnCode )) {
			query.append( " and txnCode like :txnCode" );
			query.param( "txnCode", "%" + txnCode + "%" );
		}
		if (StringUtils.isNotBlank( txnName )) {
			query.append( " and name =:txnName" );
			query.param( "txnName", txnName );
		}
		if (txnStatuses != null && !txnStatuses.isEmpty()) {
			query.append( " and status in(:txnStatus)" );
			query.param( "txnStatus", txnStatuses );
		}
		query.orderBy( "txnCode" );
		query.page( page );
		return jpaAccess.findPage( query );
	}

	public List<TxnDefinition> searchWaitToCheckTxnDefs(OrderBy orderBy, String txnCode, String txnName, String group, Page page) {
		Query query = Query.from( TxnDefinition.class ).where( " 1=1 " );
		query.append( " and (status = :savedStatus or status = :deleteStatus)" ).param( "savedStatus", TxnStatus.S ).param( "deleteStatus", TxnStatus.D );
		if (StringUtils.isNotBlank( txnCode )) {
			query.append( " and txnCode like :txnCode" );
			query.param( "txnCode", "%" + txnCode + "%" );
		}
		if (StringUtils.isNotBlank( txnName )) {
			query.append( " and name=:txnName" );
			query.param( "txnName", txnName );
		}
		if (StringUtils.isNotBlank( group )) {
			query.append( " and group like :group" );
			query.param( "group", "%" + group + "%" );
		}
		if (orderBy != null) {
			query.orderBy( orderBy );
		}
		query.page( page );
		return jpaAccess.findPage( query );
	}

	public List<TxnDefinition> getCopyTxnDefinition(String mainId) {
		Query query = Query.from( TxnDefinition.class );
		query.where( " mainId=:mainId" ).param( "mainId", mainId );
		return jpaAccess.find( query );
	}

	public List<String> searchTxnCodes(String key) {
		Query query = Query.create( "select distinct txnCode from " + TxnDefinition.class.getName() );
		query.where( " txnCode like :key and status!=:dStatus" ).param( "key", key + "%" ).param( "dStatus", TxnStatus.D );
		query.orderBy( "txnCode" );
		return jpaAccess.find( query );
	}

	public List<String> searchTxnDefnames(String key) {
		Query query = Query.create( "select distinct name from " + TxnDefinition.class.getName() );
		query.where( " name like :name and status!=:dStatus" ).param( "name", key + "%" ).param( "dStatus", TxnStatus.D );
		query.orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<String> searchTxnCheckDefnames(String key) {
		Query query = Query.create( "select distinct name from " + TxnDefinition.class.getName() );
		query.where( " (status=:status or status=:deleteStatus) and name like :name" ).param( "status", TxnStatus.S ).param( "deleteStatus", TxnStatus.D )
		        .param( "name", key + "%" );
		query.orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<String> searchTxnTestDefnames(String key) {
		Query query = Query.create( "select distinct name from " + TxnDefinition.class.getName() );
		query.where( " status=:mainStatus and name like :name" ).param( "mainStatus", TxnStatus.M ).param( "name", key + "%" );
		query.orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<TxnDefinition> getByTxnCodeButSelf(String selfId, String mainId, String txnCode) {
		return jpaAccess.find( Query.from( TxnDefinition.class )
		        .where( " (:selfId is null or id!=:selfId) and (:mainId is null or id!=:mainId) and txnCode=:txnCode and status!=:status" )
		        .param( "selfId", selfId ).param( "mainId", mainId ).param( "txnCode", txnCode ).param( "status", TxnStatus.M ) );
	}

	public List<TxnDefinition> findMainByTxnCode(String txnCode) {
		return jpaAccess.find(
		        Query.from( TxnDefinition.class ).where( " txnCode=:txnCode and status=:status" ).param( "txnCode", txnCode ).param( "status", TxnStatus.M ) );
	}

	public List<String> searchDefinitionCodesByHeadRefId(String key) {
		Query query = Query.create( "select distinct txnCode from " + TxnDefinition.class.getName() );
		query.append( " where id in (select distinct definitionId from " ).append( TxnDirection.class.getName() ).append( " where head_ref_Id = :headRefId )" )
		        .param( "headRefId", key );
		query.orderBy( "txn_def_code" );
		return jpaAccess.find( query );
	}

	public List<TxnDefinition> findByTxnCode(String txnCode) {
		return jpaAccess.find(
		        Query.from( TxnDefinition.class ).where( " txnCode=:txnCode and status=:status" ).param( "txnCode", txnCode ).param( "status", TxnStatus.M ) );
	}

	public List<TxnDefinition> findEByTxnCode(String txnCode) {
		return jpaAccess.find(
		        Query.from( TxnDefinition.class ).where( " txnCode=:txnCode and status=:status" ).param( "txnCode", txnCode ).param( "status", TxnStatus.E ) );
	}
}
