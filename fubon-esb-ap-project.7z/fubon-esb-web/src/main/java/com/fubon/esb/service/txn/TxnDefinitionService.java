package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.fubon.esb.dao.txn.TxnDefinitionDao;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnStatus;


/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Service
public class TxnDefinitionService extends TxnLogService
{

	@Inject
	private TxnDefinitionDao txnDefDao;

	public boolean isExistDefCodeButSelf(String selfId, String mainId, String defCode) {
		List<TxnDefinition> result = getByTxnCodeButSelf( selfId, mainId, defCode );
		if (result != null && !result.isEmpty())
			return true;
		return false;
	}

	public List<TxnDefinition> getByTxnCodeButSelf(String selfId, String mainId, String txnCode) {
		if (StringUtils.isBlank( txnCode )) {
			return null;
		}
		return txnDefDao.getByTxnCodeButSelf( selfId, mainId, txnCode );
	}

	public TxnDefinition getById(String id) {
		if (StringUtils.isBlank( id )) {
			return null;
		}
		return (TxnDefinition) txnDefDao.get( id );
	}

	public List<TxnDefinition> findAll() {
		return txnDefDao.findAll();
	}

	@Transactional
	public void saveOrUpdate(TxnDefinition txnDefi) {
		if (txnDefi == null) {
			return;
		}
		if (StringUtils.isBlank( txnDefi.getId() )) {
			txnDefi.setId( null );
			txnDefDao.save( txnDefi );
			logToDB( messages.getMessage( "txn.edit.log.definition.add", txnDefi.getTxnCode(), txnDefi.getName() ) );

		} else {
			TxnDefinition dbTxnDefi = txnDefDao.get( txnDefi.getId() );
			if (dbTxnDefi != null) {
				logToDB( messages.getMessage( "txn.edit.log.definition.update", dbTxnDefi.getTxnCode(), dbTxnDefi.getName() ) );
				BeanUtils.copyProperties( txnDefi, dbTxnDefi );
				txnDefDao.save( dbTxnDefi );
			}
		}
	}

	@Transactional
	public void removeById(String txnDefId) {
		if (StringUtils.isBlank( txnDefId )) {
			return;
		}
		TxnDefinition record = getById( txnDefId );
		if (record != null) {
			txnDefDao.delete( record );
			logToDB( messages.getMessage( "txn.edit.log.definition.delete", record.getTxnCode(), record.getName() ) );
		}
	}

	public List<TxnDefinition> findPageByCodeNameAndStatusAddtion(String code, String name, String status, Page page) {
		TxnStatus txnStatus = null;
		if (StringUtils.isNotBlank( status )) {
			txnStatus = TxnStatus.valueOf( status );
		}
		return txnDefDao.findPageByCodeNameAndStatusAddtion( code, name, txnStatus, page );
	}

	public List<TxnDefinition> findPageByCodeNameAndStatus(String code, String name, String status, Page page) {
		List<TxnStatus> txnStatuses = new ArrayList<TxnStatus>();
		if (StringUtils.isNotBlank( status )) {
			txnStatuses.add( TxnStatus.valueOf( status ) );
		}
		return txnDefDao.findPageByCodeNameAndStatus( code, name, txnStatuses, page );
	}

	public List<TxnDefinition> findTestPageByCodeName(String code, String name, Page page) {
		List<TxnStatus> txnStatuses = new ArrayList<TxnStatus>();
		txnStatuses.add( TxnStatus.M );
		return txnDefDao.findPageByCodeNameAndStatus( code, name, txnStatuses, page );
	}

	public List<TxnDefinition> searchWaitToCheckTxnDefs(OrderBy orderBy, String txnCode, String txnName, String group, Page page) {
		return txnDefDao.searchWaitToCheckTxnDefs( orderBy, txnCode, txnName, group, page );
	}

	public List<TxnDefinition> getCopyTxnDefinition(String mainId) {
		if (StringUtils.isBlank( mainId )) {
			return null;
		}
		return txnDefDao.getCopyTxnDefinition( mainId );
	}

	public List<String> searchTxnCodes(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDefDao.searchTxnCodes( key );
	}

	public List<String> searchTxnDefnames(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDefDao.searchTxnDefnames( key );
	}

	public List<String> searchTxnCheckDefnames(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDefDao.searchTxnCheckDefnames( key );
	}

	public List<String> searchTxnTestDefnames(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDefDao.searchTxnTestDefnames( key );
	}

	public String getMainDefIdByCopyDefId(String defId) {
		if (StringUtils.isBlank( defId ))
			return null;
		TxnDefinition copy = getById( defId );
		if (StringUtils.isBlank( copy.getMainId() ) || TxnDefinition.INIT_MAIN_ID.equals( copy.getMainId() )) {
			return copy.getId();
		} else {
			return copy.getMainId();
		}
	}

	public List<TxnDefinition> findMainByTxnCode(String txnCode) {
		return txnDefDao.findMainByTxnCode( txnCode );
	}

	public List<String> searchDefinitionCodesByHeadRefId(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDefDao.searchDefinitionCodesByHeadRefId( key );
	}

	public String findByTxnCode(String txnCode) {

		List<TxnDefinition> dirs = txnDefDao.findByTxnCode( txnCode );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 ).getId();
		}
		return null;
	}

	public String findEByTxnCode(String txnCode) {

		List<TxnDefinition> dirs = txnDefDao.findEByTxnCode( txnCode );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 ).getTxnCode();
		}
		return null;
	}

	public String findMByTxnCode(String txnCode) {

		List<TxnDefinition> dirs = txnDefDao.findByTxnCode( txnCode );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 ).getTxnCode();
		}
		return null;
	}

}
