package com.fubon.esb.service.job;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.job.view.JobRecordlView;
import com.fubon.esb.dao.job.JobConfigDao;
import com.fubon.esb.dao.job.JobRecordDao;
import com.fubon.esb.domain.job.JobConfig;
import com.fubon.esb.domain.job.JobRecord;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-13
 */

@Service
public class JobRecordService {
    @Inject
    private JobConfigDao jobConfigDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private Messages messages;
    @Inject
    private JobRecordDao jobRecordDao;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private JobConfigService jobConfigService;
    @Inject
    private Environment env;

    public List<JobConfig> findJobRecords(JobRecordlView jobRecordlView, List<String> userBranchCodeList, OrderBy orderBy, Page page) {
        List<JobConfig> findJobRecords = jobConfigDao.findJobRecords(jobRecordlView, userBranchCodeList, orderBy, page);
        jobConfigService.setJobSysCodeList(findJobRecords);
        return findJobRecords;
    }

    public List<JobRecord> findJobRecords(String configId) {
        return jobRecordDao.findRecordsByConfigId(configId);
    }

    public void jobQueryLog(JobRecordlView view) {
        StringBuilder logBuilder = new StringBuilder();
        logBuilder.append(messages.getMessage("job.record.log.query"));
        if (StringUtils.isNotBlank(view.getBranchCode())) {
            logBuilder.append(",").append(messages.getMessage("job.record.log.query.branchcode", view.getBranchCode()));
        }
        if (StringUtils.isNotBlank(view.getCode())) {
            logBuilder.append(",").append(messages.getMessage("job.record.log.query.jobcode", view.getCode()));
        }
        if (StringUtils.isNotBlank(view.getName())) {
            logBuilder.append(",").append(messages.getMessage("job.record.log.query.jobname", view.getName()));
        }
        if (StringUtils.isNotBlank(view.getRunningTime())) {
            logBuilder.append(",").append(
                    messages.getMessage("job.record.log.query.runtime", new SimpleDateFormat("yyyy/MM/dd").format(timeZoneService.getTZDate(jobConfigService.formatToDate(view.getRunningTime())))));
        }
        if (view.getStatus() != null) {
            logBuilder.append(",").append(messages.getMessage("job.record.log.query.status"));
            if ("R".equalsIgnoreCase(view.getStatus())) {
                logBuilder.append(messages.getMessage("job.record.log.query.status.r"));
            } else if ("S".equalsIgnoreCase(view.getStatus())) {
                logBuilder.append(messages.getMessage("job.record.log.query.status.s"));
            } else if ("F".equalsIgnoreCase(view.getStatus())) {
                logBuilder.append(messages.getMessage("job.record.log.query.status.f"));
            } else if ("N".equalsIgnoreCase(view.getStatus())) {
                logBuilder.append(messages.getMessage("job.record.log.query.status.n"));
            }
        }
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, logBuilder.toString(), LogType.JOB_MANAGE_SEARCH);
    }

    @SuppressWarnings("unchecked")
    public boolean isAdminGroup() {
        List<String> userGroupCodes = new ArrayList<>();
        List<Group> groups = loginContext.loginedUser(User.class).getGroups();
        List<String> adminGroupList = null;
        if (!groups.isEmpty()) {
            for (Group group : groups) {
                userGroupCodes.add(group.getName());
            }
        }
        String adminGroups = env.getProperty("ADMINGROUP");
        if (StringUtils.isNotBlank(adminGroups)) {
            adminGroupList = Arrays.asList(adminGroups.split(","));
        }
        if (!((List<String>) CollectionUtils.retainAll(adminGroupList, userGroupCodes)).isEmpty()) {
            return true;
        }
        return false;
    }

    public List<String> findUserBranchCodeList() {
        List<String> userGroupList = new ArrayList<>();
        List<Group> groups = loginContext.loginedUser(User.class).getGroups();
        if (!groups.isEmpty()) {
            for (Group group : groups) {
                String groupName = group.getName();
                userGroupList.add(groupName);
            }
        }
        return userGroupList;
    }

}
