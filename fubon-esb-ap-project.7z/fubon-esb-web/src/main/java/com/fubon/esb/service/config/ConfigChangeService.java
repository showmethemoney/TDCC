package com.fubon.esb.service.config;

import javax.inject.Inject;

import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.comwave.core.http.HTTPClient;
import com.comwave.core.http.HTTPMethod;
import com.comwave.core.http.HTTPRequest;
import com.comwave.core.util.TimeLength;
import com.fubon.esb.domain.config.ConfigType;


/**
 * @author james
 * @createdDate 2014-11-27
 */
@Service
public class ConfigChangeService
{

	private final Logger logger = LoggerFactory.getLogger( ConfigChangeService.class );
	private static final String SEPERATOR_SERVER = ",";

	@Inject
	private Environment env;

	@Inject
	private HTTPClient httpClient;

	/** 改預約 傳預約ID，改即時傳正本ID */
	public boolean sendChangeEvent(ConfigType configType, String configID) {
		httpClient.setTimeOut( TimeLength.seconds( 10 ) );
		String url = env.getRequiredProperty( "bw.http.url.config.changeevent" );
		boolean send_success=true;
		
		String[] servers = url.split( SEPERATOR_SERVER );
		for(String server : servers) {
			HTTPRequest request = new HTTPRequest( server, HTTPMethod.POST );
			String event = composeChangeEvent( configType, configID );
			request.text( event, ContentType.TEXT_XML );
			
			try {
				httpClient.execute( request );
	            logger.info("http refresh msg receieved by "+server+". Event Message: "+event);
			} catch (Throwable cause) {
				send_success=false;
				logger.error( "http execute error ! " + cause.getMessage(), cause );
			}
		}
		
		return send_success;
	}

	public void sendMailRequest(String subject, String content) {
		String url = env.getRequiredProperty( "bw.http.url.mail.request" ) + "/MailRequest";
		HTTPRequest request = new HTTPRequest( url, HTTPMethod.POST );
		StringBuilder mailInfo = new StringBuilder();
		mailInfo.append( "<MailInfo xmlns = \"http://fubon.com.tw/XSD/ESB/Configuration/Config\">" );
		mailInfo.append( "<Subject>" ).append( subject ).append( "</Subject>" );
		mailInfo.append( "<Content>" ).append( content ).append( "</Content>" );
		mailInfo.append( "</MailInfo>" );
		request.text( mailInfo.toString(), ContentType.APPLICATION_JSON );
		try {
			httpClient.execute( request );
		} catch (Exception e) {
			logger.error( "http execute error! msg:" + mailInfo, e );
		}
	}

	public void cleanEMSQueue(String id) {
		String url = env.getRequiredProperty( "bw.http.url.mail.request" ) + "/cleanQueue";
		HTTPRequest request = new HTTPRequest( url, HTTPMethod.POST );
		String event = composeChangeEvent( ConfigType.CFG_JOB_SYSTEM_SETTING, id );
		request.text( event, ContentType.TEXT_XML );
		try {
			httpClient.execute( request );
		} catch (Exception e) {
			logger.error( "http execute error! msg:" + event, e );
		}
	}

	private String composeChangeEvent(ConfigType configType, String configID) {
		StringBuilder sb = new StringBuilder();
		sb.append( "<ChangeEvent xmlns = \"http://fubon.com.tw/XSD/ESB/Configuration/Config\">" );
		sb.append( "<ConfigType>" ).append( configType ).append( "</ConfigType>" );
		sb.append( "<ConfigID>" ).append( configID ).append( "</ConfigID>" );
		sb.append( "</ChangeEvent>" );
		return sb.toString();
	}

}
