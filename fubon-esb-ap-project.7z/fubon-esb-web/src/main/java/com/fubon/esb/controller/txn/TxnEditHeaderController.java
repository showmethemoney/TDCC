package com.fubon.esb.controller.txn;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.comwave.core.database.Page;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.permission.RequirePermission;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.EditTxn;
import com.fubon.esb.controller.txn.view.TxnHeaderExcelView;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.controller.txn.view.ZipCompressor;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnHeaderExcelReadServcie;
import com.fubon.esb.service.txn.TxnHeaderExcelWriteService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author Qigers
 * @createdDate 2015-03-20
 */
@Controller
@RequestMapping({"/txn/editHeader"})
public class TxnEditHeaderController extends BaseController {
	@Inject
	protected Messages messages;
    @Inject
    private TxnDefinitionService txnDefService;
    @Inject
    private TxnDirectionService txnDirecService;
    @Inject
    private TxnFieldDefinitionService txnFieldService;
    @Inject
    private TxnService txnService;
    @Inject
    private TxnHeaderExcelReadServcie txnHeaderExcelReadServcie;
    @Inject
    private TxnHeaderExcelWriteService txnHeaderExcelWriteService;
    @Inject
    private TimeZoneService timeZoneService;
    private TxnHeaderExcelView txnHeaderExcelView;
    private static final String INCLUDE_BASE_URL = "txn/include/edit";

    @InitBinder
    public void initBinder() {
        txnHeaderExcelView = new TxnHeaderExcelView(txnService, txnHeaderExcelReadServcie, txnHeaderExcelWriteService);
    }

    @RequestMapping({"/list"})
    @RequirePermission(value = "010101")
    public String viewTxnHeaderList(Model model) {
        model.addAttribute("curUser", loginedUser() == null ? new User() : loginedUser());
        return "txn/viewEditTxnHeaderList";
    }

    @RequestMapping({"/search"})
    @RequirePermission(value = "010101")
    public String searchTxnHeaderList(Model model, @RequestParam(required = false) String name, @RequestParam(required = false) String txnHeaderStatus,
            @RequestParam(defaultValue = "1") Integer curPage) {
        Page page = new Page(curPage);
        if (page.getTotalPage() != 0 && curPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
        }
        List<TxnDirection> txnHeads = txnDirecService.findPageByCodeNameAndStatusAddtion(name, txnHeaderStatus, page);
        model.addAttribute("page", page);
        model.addAttribute("txnHeads", txnHeads);
        return INCLUDE_BASE_URL + "/txnHeaders";
    }

    @RequestMapping({"/add"})
    @RequirePermission(value = "010102")
    public String addTxn(Model model) throws Exception {
        TxnVO txnVO = new TxnVO();
        TxnDirection headDirection = new TxnDirection();
        headDirection.setCreateUser(loginedUserId());
        headDirection.setMainId("0");
        headDirection.setCreateTime(new Date());
        txnVO.setHeadDirection(headDirection);
        Boolean tmpEdit = false;
        txnVOModel(model, txnVO, tmpEdit);
        return "txn/viewEditTxnHeader";
    }

    public void txnVOModel(Model model, TxnVO txnVO, Boolean tmpEdit) {
        model.addAttribute("headDirecs", new ArrayList<TxnDirection>());
        model.addAttribute("curUser", loginedUser() == null ? new User() : loginedUser());
        model.addAttribute("tmpEdit", tmpEdit);
        model.addAttribute("txnHeader", txnVO.getHeadDirection() == null ? new TxnDirection() : txnVO.getHeadDirection());
        model.addAttribute("headFields", txnVO.getHeadFields() == null ? new ArrayList<>() : txnVO.getHeadFields());
    }

    @RequestMapping({"/edit/{direcId}"})
    @RequirePermission(value = "010103")
    public String editTxn(Model model, @PathVariable("direcId") String direcId, @RequestParam(required = false, defaultValue = "false") Boolean tmpEdit) throws Exception {
        TxnVO txnVO = new TxnVO();
        TxnDirection headDirection = txnDirecService.findHeadDirByID(direcId);
        if (TxnStatus.M.equals(headDirection.getTxnHeaderStatus())) {
            headDirection = txnDirecService.getOrCreateCopyTxnDirec(headDirection, direcId, loginedUserId());
        }
        txnVO.setHeadFields(txnFieldService.findMainsByDirId(headDirection.getId()));
        txnVO.setHeadDirection(headDirection);

        txnVOModel(model, txnVO, tmpEdit);
        return "txn/viewEditTxnHeader";
    }

    @RequestMapping({"/view/{direcId}"})
    @RequirePermission(value = "010103")
    public String viewTxnHeader(Model model, @PathVariable("direcId") String direcId, @RequestParam(required = false, defaultValue = "false") Boolean tmpEdit) throws Exception {
        TxnVO txnVO = new TxnVO();
        TxnDirection headDirection = txnDirecService.findHeadDirByID(direcId);
        // if (!TxnStatus.M.equals(headDirection.getTxnHeaderStatus())) {
        txnVO.setHeadFields(txnFieldService.findMainsByDirId(headDirection.getId()));
        // } else {
        // headDirection = txnDirecService.getOrCreateCopyTxnDirec(headDirection, direcId, loginedUserId());
        // txnVO.setHeadFields(txnFieldService.findMainsByDirId(direcId));
        // }
        // headDirection.setUpdatedTime(new Date());
        // headDirection.setUpdatedUser(loginedUserId());
        txnVO.setHeadDirection(headDirection);
        txnVOModel(model, txnVO, tmpEdit);
        return "txn/viewTxnHeader";
    }

    @ResponseBody
    @RequestMapping({"/delete/{direcId}"})
    @RequirePermission(value = "010104")
    public Object ajaxDeleteTxn(Model model, @PathVariable("direcId") String direcId) {
        Map<String, Object> msg = new HashMap<String, Object>();
        boolean success=true;
        
        TxnDirection direction = txnDirecService.findHeadDirByID(direcId);
        if (direction != null && TxnStatus.M.equals(direction.getTxnHeaderStatus())) {
        	//check if there's still txn related with this header
        	List<String> defCodes = txnDefService.searchDefinitionCodesByHeadRefId(direcId);
            if(!defCodes.isEmpty()){
            	success=false;
            	msg.put("message", messages.getMessage("config.error.delete") + "<br/>此Header關聯以下電文:" + defCodes.toString());
            }else{
	            direction.setTxnHeaderStatus(TxnStatus.D);
	            txnDirecService.saveOrUpdate(direction);
            }
        } else {
            txnDirecService.removeTxnHeaderById(direcId);
        }
       
        if(success==true)
        	msg.put("success", success);
        return msg;
    }

    @ResponseBody
    @RequestMapping(value = {"/save"}, method = {RequestMethod.POST})
    public Object saveTxnFields(Model model, @RequestBody EditTxn editTxn, @RequestParam Boolean isTemp) throws Exception {
        Map<String, Object> msg = new HashMap<String, Object>();
        msg.put("success", true);
        TxnDirection txnDirec = editTxn.getUpTxnDirec();
        txnDirec.setName(txnDirec.getName().trim());
        txnDirec.setTxnHeaderStatus(isTemp.booleanValue() ? TxnStatus.E : TxnStatus.S);
        txnService.saveOrUpdateEditTxnHeader(txnDirec, editTxn.getEtxnFields());
        return msg;
    }

    @ResponseBody
    @RequestMapping({"/search/names"})
    public Object searchTxnNames(@RequestParam String key) {
        return txnDirecService.searchTxnDefnames(key);
    }

    @ResponseBody
    @RequestMapping({"/removeTmpEditTxn"})
    public Object removeTmpEditTxn(@RequestParam String direcId) {
        txnDirecService.removeTxnHeaderById(direcId);
        return true;
    }

    @RequestMapping({"/reportTxnExcel"})
    @RequirePermission(value = "010105")
    public void writeToExcel(Model model, @RequestParam("defIds[]") String[] defIds, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TxnVO> txnVOs = new ArrayList<TxnVO>();
        if (defIds != null && defIds.length != 0) {
            for (String defId : defIds) {
                txnVOs.add(txnService.findTxnVOForHeaderExcel(defId));
            }
        }
        // one -report as excel file
        if (defIds != null && defIds.length == 1) {
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("txnExcelVO", txnService.findTxnVOForHeaderExcel(defIds[0]));
            txnHeaderExcelView.render(dataMap, request, response);
            return;
        }
        txnHeaderExcelView.writeZipFileToResponse(txnVOs, request, response);
    }

    /** import Excel */
    @RequestMapping({"/readFromExcel"})
    @RequirePermission(value = "010107")
    public void readTxnFromExcel(Model model, MultipartHttpServletRequest request, HttpServletResponse response) throws Exception {
        TxnDirection txnDirec = new TxnDirection();
        txnDirec.setName(request.getParameter("name"));
        txnDirec.setTxnHeaderStatus(TxnStatus.E);
        txnDirec.setCreateUser(loginedUserId());
        txnDirec.setMainId("0");
        txnDirec.setDirection(DirectionType.H);
        txnDirec.setCreateTime(timeZoneService.getTZDateByService(new Date()));
        MultipartFile multipartFile = request.getFile("file_txn_excel");
        File uploadedHeaderFile = new File(ZipCompressor.ZIP_EXCEL_TEMP_DIR + "\\" + System.currentTimeMillis() + "\\" + multipartFile.getOriginalFilename());
        if (uploadedHeaderFile.exists()) {
            uploadedHeaderFile.delete();
        } else {
            uploadedHeaderFile.mkdirs();
        }
        multipartFile.transferTo(uploadedHeaderFile);
        response.setContentType("text/html;charset=utf-8");
        Map<String, Object> result = txnHeaderExcelView.saveTxnHeadsFromUploadedFile(txnDirec, uploadedHeaderFile, Boolean.valueOf(request.getParameter("isCompress")));
        ZipCompressor.clearZipDirection(uploadedHeaderFile.getParent());
        ObjectMapper objectMapper = JSONBinder.objectMapper();
        String jsonResult = objectMapper.writeValueAsString(result);
        response.getWriter().write(jsonResult);
        response.flushBuffer();
        response.getWriter().close();
    }

    @RequestMapping({"/newTr"})
    public String buildNewTrHtml(Model model, @RequestParam String fieldType) {
        TxnFieldDefinition txnField = new TxnFieldDefinition();
        List<TxnFieldDefinition> txnFields = new ArrayList<TxnFieldDefinition>();
        txnField.setFieldType(FieldType.valueOf(fieldType));
        txnFields.add(txnField);
        model.addAttribute("isNewTrHtml", true);
        model.addAttribute("txnFields", txnFields);
        return INCLUDE_BASE_URL + "/txnHeaderFields";
    }

    @ResponseBody
    @RequestMapping({"/isExsitFieldCode"})
    public Map<String, Boolean> checkIsExistByCode(@RequestParam String fieldCode, @RequestParam String dirId) {
        Map<String, Boolean> result = new HashMap<String, Boolean>(1);
        if (txnFieldService.findByTxnCode(fieldCode, dirId) == null) {
            result.put("isExist", Boolean.FALSE);
        } else {
            result.put("isExist", Boolean.TRUE);
        }
        return result;
    }

    @ResponseBody
    @RequestMapping({"/isExsitHeaderCode"})
    public Map<String, Boolean> checkIsExsitHeaderCode(@RequestParam String name, @RequestParam String dirId, @RequestParam String mainId) {
        String trimName = name.trim();
        Map<String, Boolean> result = new HashMap<String, Boolean>(1);
        Boolean flag = txnDirecService.validNameDuplicate(dirId, mainId, trimName);
        result.put("flag", flag);
        return result;
    }
}
