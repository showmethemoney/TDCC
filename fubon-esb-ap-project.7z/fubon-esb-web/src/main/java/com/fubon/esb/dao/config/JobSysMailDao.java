package com.fubon.esb.dao.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.JobSysMail;

/**
 * @author Qigers
 * @createdDate 2014-12-11
 */
@Repository
public class JobSysMailDao extends JPADaoSupport<JobSysMail> {

    public List<JobSysMail> findJobSysMails(String id) {
        Query query = Query.from(JobSysMail.class).where("systemId = :systemId").param("systemId", id);
        return jpaAccess.find(query);
    }

    public void addJobSysMailList(List<JobSysMail> jobSysMails) {
        for (JobSysMail jobSysMail : jobSysMails) {
            jpaAccess.save(jobSysMail);
        }
    }

    public void saveJobSysMails(String id, String[] jobSysMails) {
        if (jobSysMails != null && jobSysMails.length > 0) {
            for (String mail : jobSysMails) {
                JobSysMail jobSysMail = new JobSysMail(id, mail);
                jpaAccess.save(jobSysMail);
            }
        }
    }

    public void removeJobSysMailList(List<JobSysMail> jobSysMails) {
        for (JobSysMail jobSysMail : jobSysMails) {
            jpaAccess.delete(jobSysMail);
        }
    }

    @SuppressWarnings("unchecked")
    public void updateJobSysMailList(String id, String[] mails) {
        List<JobSysMail> newJobSysMailList = createNewJobSysMailsList(id, mails);
        List<JobSysMail> oldJobSysMailList = findJobSysMails(id);
        if (!CollectionUtils.isEqualCollection(oldJobSysMailList, newJobSysMailList)) {
            List<JobSysMail> sameJobSysMailList = (List<JobSysMail>) CollectionUtils.retainAll(oldJobSysMailList, newJobSysMailList);
            newJobSysMailList.removeAll(sameJobSysMailList);
            oldJobSysMailList.removeAll(sameJobSysMailList);
            removeJobSysMailList(oldJobSysMailList);
            addJobSysMailList(newJobSysMailList);
        }

    }

    public List<JobSysMail> createNewJobSysMailsList(String id, String[] mails) {
        List<JobSysMail> jobSysMails = new ArrayList<>();
        if (mails != null && mails.length > 0) {
            for (String mail : mails) {
                jobSysMails.add(new JobSysMail(id, mail));
            }
        }
        return jobSysMails;
    }

    public void removeById(String id) {
        Query query = Query.create("delete from " + JobSysMail.class.getName() + " where systemId = :systemId").param("systemId", id);
        // Query query = Query.create("update " + JobSysMail.class.getName() + " set status='D' where systemId = :systemId").param("systemId", id);
        jpaAccess.update(query);
    }
}
