package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.config.view.TxnGroupView;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnGroup;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-4
 */
@Repository
public class TxnGroupDao extends JPADaoSupport<TxnGroup> {

    public List<TxnGroup> findLatestTxnGroup(TxnGroupView txnGroupView, Page page) {
        Query query = Query.create("select tg from " + TxnGroup.class.getName() + " tg ");
        if (StringUtils.isNotBlank(txnGroupView.getTxnCode())) {
            query.append(" , ").append(Txn.class).append(" t "); // 關聯交易代號
        }
        if (StringUtils.isNoneBlank(txnGroupView.getHostCode())) {
            query.append(" , ").append(Host.class).append(" h "); // 關聯主機代號
        }
        query.append(" where not exists(select tgroup from ").append(TxnGroup.class).append(" tgroup where tgroup.mainId = tg.id)");
        if (StringUtils.isNotBlank(txnGroupView.getTxnCode())) {
            query.append(" and tg.id = t.groupId and t.code = :txnCode and t.mainId is null ");
            query.setParam("txnCode", txnGroupView.getTxnCode().trim());
        }
        if (StringUtils.isNotBlank(txnGroupView.getHostCode())) {
            query.append(" and tg.hostId = h.id and h.code = :hostCode and h.mainId is null ");
            query.setParam("hostCode", txnGroupView.getHostCode().trim());
        }
        if (StringUtils.isNotBlank(txnGroupView.getTxnGroupCode())) {
            query.append(" and tg.code = :txnGroupCode ");
            query.setParam("txnGroupCode", txnGroupView.getTxnGroupCode().trim());
        }
        if (StringUtils.isNotBlank(txnGroupView.getName())) {
            query.append(" and tg.name like :name ");
            query.setParam("name", "%" + txnGroupView.getName() + "%");
        }
        // if (txnGroupView.getStatus() == null) {
        // query.append(" and tg.status != :status ");
        // query.setParam("status", ConfigActiveStatus.D);
        // }
        if (txnGroupView.getStatus() != null) {
            query.append(" and tg.status=:status ");
            query.setParam("status", txnGroupView.getStatus());
        }
        query.orderBy("tg.createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(TxnGroup.class).append(" txnGroup where not exists(select tg from ").append(TxnGroup.class).append(" tg where tg.mainId = txnGroup.id) ").append(" and txnGroup.code=:code")
                        .param("code", code).append(" and txnGroup.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();
    }

    public List<TxnGroup> findTxnGroupByHostId(String hostId) {
        Query query = Query.from(TxnGroup.class).where("hostId = :hostId and (mainId is null or mainId='0')").param("hostId", hostId);
        return jpaAccess.find(query);
    }

    public List<TxnGroup> findMainTxnGroup(String code, Page page) {
        Query query = Query.from(TxnGroup.class).append(" txnGroup where txnGroup.mainId is null and txnGroup.status=:status ").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(code)) {
            query.append(" and txnGroup.code = :code ");
            query.setParam("code", code);
        }
        query.orderBy("txnGroup.code").page(page);
        return jpaAccess.findPage(query);

    }

    public List<String> searchMainTxnGroupCodes(String key) {
        Query query = Query.create("select distinct code from " + TxnGroup.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.append(" and mainId is null");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchTxnGroupCodes(String key) {
        Query query = Query.create("select distinct code from " + TxnGroup.class.getName() + " txnGroup");
        query.append(" where not exists(select tx from ").append(TxnGroup.class).append(" tx where tx.mainId = txnGroup.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        TxnGroup txnGroup = jpaAccess.get(TxnGroup.class, id);
        if (StringUtils.isNotBlank(txnGroup.getMainId()) && !"0".equals(txnGroup.getMainId())) { // 如果是帶有正本的副本
            jpaAccess.delete(txnGroup); // 刪掉副本
            jpaAccess.update(Query.create("update ").append(TxnGroup.class).append(" txnGroup set txnGroup.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", txnGroup.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(TxnGroup.class).append(" txnGroup set txnGroup.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(關聯業務群組、關聯主機)
    public List<Txn> isTxnGroupRelatedTxn(String id) {
        Query relTxn = Query.create("select txn  from " + Txn.class.getName() + " txn");
        relTxn.append(" where txn.groupId = :id ").param("id", id);
        return jpaAccess.find(relTxn);
    }

    public List<Host> isTxnGroupRelateHost(String id) {
        Query relHost = Query.create("select txnGroup  from " + TxnGroup.class.getName() + " txnGroup");
        relHost.append(" where (txnGroup.hostId is not null and txnGroup.hostId != '') and txnGroup.id = :id").param("id", id);
        return jpaAccess.find(relHost);
    }
}
