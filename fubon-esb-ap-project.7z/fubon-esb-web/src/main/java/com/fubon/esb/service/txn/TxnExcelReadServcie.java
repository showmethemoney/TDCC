package com.fubon.esb.service.txn;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.fubon.esb.controller.txn.view.TxnExcelVO;
import com.fubon.esb.domain.txn.DataType;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.FileType;
import com.fubon.esb.domain.txn.JustifyType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;


/**
 * @author nice
 * @createdDate 2014-11-28
 */
@Service
public class TxnExcelReadServcie extends BaseTxnExcelService
{

	public Map<String, Workbook> readWorkbookFromZipFile(File file) throws Exception {
		Map<String, Workbook> workbooks = new HashMap<String, Workbook>();
		ZipFile zipFile = new ZipFile( file );
		Enumeration<? extends ZipEntry> entries = zipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = entries.nextElement();
			if (entry.getName().endsWith( "/" )) {
				continue; // a folder
			}
			InputStream zipInputStream = zipFile.getInputStream( entry );
			Workbook workbook = null;
			if (entry.getName().endsWith( "xlsx" )) {
				workbook = new XSSFWorkbook( zipInputStream );
			} else {
				workbook = new HSSFWorkbook( zipInputStream );
			}
			workbooks.put( entry.getName(), workbook );
			zipInputStream.close();
		}
		zipFile.close();
		return workbooks;
	}

	public Map<String, Workbook> readWorkbooksFromFile(File file, boolean isCompress) throws Exception {
		Map<String, Workbook> workbooks = new HashMap<String, Workbook>();
		if (isCompress) {
			workbooks = readWorkbookFromZipFile( file );
		} else {
			if (file.getName().endsWith( "xlsx" )) {
				workbooks.put( file.getName(), new XSSFWorkbook( new FileInputStream( file ) ) );
			} else {
				workbooks.put( file.getName(), new HSSFWorkbook( new FileInputStream( file ) ) );
			}
		}
		return workbooks;
	}

	public List<TxnExcelVO> readTxnVOsFromExcel(TxnDefinition paramDef, File file, boolean isCompress) throws Exception {
		Map<String, Workbook> workbooks = readWorkbooksFromFile( file, isCompress );
		if (workbooks == null || workbooks.isEmpty())
			return null;
		List<TxnExcelVO> txnVOs = new ArrayList<TxnExcelVO>();
		TxnExcelVO txnVO = null;
		Workbook workbook = null;
		TxnDefinition definition = null;
		int booksSize = workbooks.size();
		for (Entry<String, Workbook> entry : workbooks.entrySet()) {
			workbook = entry.getValue();
			if (workbook != null && workbook.getNumberOfSheets() != 0) {
				txnVO = new TxnExcelVO();
				if (isCompress || booksSize > 1) {
					definition = new TxnDefinition();
					BeanUtils.copyProperties( paramDef, definition );
					readCodeNameToTxnDef( definition, entry.getKey() );
					txnVO.setDefinition( definition );
					txnVO.setExcelName( definition.getTxnCode() + "." + definition.getName() );
				} else {
					txnVO.setDefinition( paramDef );
					txnVO.setExcelName( file.getName() );
				}
				txnVO.setExcelErrors( new ArrayList<String>() );
				txnVO.setUpDirection( new TxnDirection( DirectionType.U ) );
				txnVO.setDownDirection( new TxnDirection( DirectionType.D ) );

				if (!txnDefinitionService.findMainByTxnCode( txnVO.getDefinition().getTxnCode() ).isEmpty()) {
					// 20150807 ADDED
					String keyName = "";
					String keyEName = "";
					// String keyNameforHS="";
					keyName = txnDefinitionService.findMByTxnCode( txnVO.getDefinition().getTxnCode() );
					keyEName = txnDefinitionService.findEByTxnCode( txnVO.getDefinition().getTxnCode() );
					// keyNameforHS=txnDefinitionService.getHeaderStatusByName(txnVO.getDefinition().getTxnCode());

					if (keyEName != null) {
						txnVO.getExcelErrors().add( messages.getMessage( "txn.definition.existed", txnVO.getDefinition().getTxnCode() ) );
						txnVOs.add( txnVO );
						continue;
					} else {
						paramDef.setMainId( txnDefinitionService.findByTxnCode( txnVO.getDefinition().getTxnCode() ) );
						// txnVO.setDefinition(paramDef);

						if (isCompress) {
							BeanUtils.copyProperties( paramDef, definition );
							definition.setName( keyName );
							definition.setTxnCode( keyName );
						}
					}
				}

				/*
				 * else { if(txnDefinitionService.findMainByTxnCode(paramDef.getTxnCode()).isEmpty()==false)
				 * paramDef.setMainId(txnDefinitionService.findMainByTxnCode(paramDef.getTxnCode()).get(0).getId()); txnVO.setDefinition(paramDef); }
				 */

				fillTxnDirectionByHeaderRow( txnVO.getUpDirection(), workbook.getSheetAt( 0 ).getRow( 0 ), txnVO.getExcelErrors() );
				txnVO.setUpFields( sheetToTxnFields( workbook.getSheetAt( 0 ), txnVO.getExcelErrors() ) );
				int upSheetErrorSize = txnVO.getExcelErrors().size();
				fillTxnDirectionByHeaderRow( txnVO.getDownDirection(), workbook.getSheetAt( 1 ).getRow( 0 ), txnVO.getExcelErrors() );
				txnVO.setDownFields( sheetToTxnFields( workbook.getSheetAt( 1 ), txnVO.getExcelErrors() ) );
				List<String> excelErrors = txnVO.getExcelErrors();
				for (int i = 0; i < excelErrors.size(); i++) {
					if (i < upSheetErrorSize) {
						excelErrors.set( i, "上行" + excelErrors.get( i ) );
					} else {
						excelErrors.set( i, "下行" + excelErrors.get( i ) );
					}
				}
				txnVOs.add( txnVO );
			}
		}
		return txnVOs;
	}

	public void readCodeNameToTxnDef(TxnDefinition definition, String fileName) {
		String[] codeName = fileName.split( "\\." );
		if (codeName != null && codeName.length != 0) {
			definition.setTxnCode( codeName[0].substring( codeName[0].lastIndexOf( '/' ) + 1 ) );
			if (codeName.length > 1)
				definition.setName( codeName[1] );
		}
	}

	public List<TxnFieldDefinition> sheetToTxnFields(Sheet sheet, List<String> holdErrors) {
		List<TxnFieldDefinition> txnFields = new ArrayList<TxnFieldDefinition>();
		TxnFieldDefinition field = null;
		for (int i = 0; i <= sheet.getLastRowNum(); i++) {
			field = sheetRowToTxnField( sheet.getRow( i ), holdErrors );
			if (field != null)
				txnFields.add( field );
		}
		return txnFields;
	}

	public void fillTxnDirectionByHeaderRow(TxnDirection direction, Row row, List<String> holdErrors) {
		String erroMsg = "";
		String type = getStringCellValue( row.getCell( 1 ) );
		String outType = getStringCellValue( row.getCell( 3 ) );
		if (type.equals( FileType.T.getDesc() )) {
			direction.setType( FileType.T );
		} else if (type.equals( FileType.X.getDesc() )) {
			direction.setType( FileType.X );
		} else {
			erroMsg += "接收檔案格式無效,";
		}
		if (outType.equals( FileType.T.getDesc() )) {
			direction.setOutType( FileType.T );
		} else if (outType.equals( FileType.X.getDesc() )) {
			direction.setOutType( FileType.X );
		} else {
			erroMsg += "送出檔案格式無效,";
		}
		String headRefName = getStringCellValue( row.getCell( 5 ) );
		if (StringUtils.isNotBlank( headRefName )) {
			TxnDirection headerDir = txnDirectionService.getHeaderDirByName( headRefName );
			if (headerDir == null) {
				erroMsg += "未找到對應名稱[" + headRefName + "]的Header,";
			} else {
				direction.setHeadRefId( headerDir.getId() );
			}
		}
		direction.setEncoding( getStringCellValue( row.getCell( 7 ) ) );
		if (StringUtils.isNoneBlank( erroMsg ))
			holdErrors.add( "第" + (row.getRowNum() + 1) + "行:" + erroMsg );
	}

	public TxnFieldDefinition sheetRowToTxnField(Row row, List<String> holdErrors) {
		if (row.getRowNum() == 0 || row.getRowNum() == 1)
			return null;
		FieldType fieldType = FieldType.F;
		String fieldTypeStr = getStringCellValue( row.getCell( 0 ) );
		if (TAG_TX_REPEAT_END.equals( fieldTypeStr )) {
			return sheetRowToSplitField( row, FieldType.R );
		} else if (TAG_TX_SWITCH_END.equals( fieldTypeStr )) {
			return sheetRowToSplitField( row, FieldType.S );
		} else if (TAG_TX_CASE_END.equals( fieldTypeStr )) {
			return sheetRowToSplitField( row, FieldType.C );
		}
		if (TAG_TX_FIELD.equals( fieldTypeStr )) {
			fieldType = FieldType.F;
		} else if (TAG_TX_REPEAT.equals( fieldTypeStr )) {
			fieldType = FieldType.R;
		} else if (TAG_TX_SWITCH.equals( fieldTypeStr )) {
			fieldType = FieldType.S;
		} else if (TAG_TX_CASE.equals( fieldTypeStr )) {
			fieldType = FieldType.C;
		}
		return sheetRowToDataField( row, fieldType, holdErrors );
	}

	private TxnFieldDefinition sheetRowToSplitField(Row row, FieldType fieldType) {
		TxnFieldDefinition field = new TxnFieldDefinition();
		field.setFieldType( fieldType );
		field.setOrderNo( row.getRowNum() );
		field.setSplitField( true );
		return field;
	}

	private TxnFieldDefinition sheetRowToDataField(Row row, FieldType fieldType, List<String> holdErrors) {
		TxnFieldDefinition field = new TxnFieldDefinition();
		String code = getStringCellValue( row.getCell( 1 ) ).trim();
		field.setDefaultV( getStringCellValue( row.getCell( 2 ) ) );
		field.setName( getStringCellValue( row.getCell( 3 ) ) );
		String dataType = getStringCellValue( row.getCell( 4 ) );
		field.setLength( getIntegerCellValue( row.getCell( 5 ) ) );
		field.setScale( getIntegerCellValue( row.getCell( 6 ) ) );
		field.setPadChar( getStringCellValue( row.getCell( 7 ) ) );
		String justify = getStringCellValue( row.getCell( 8 ) );
		String includeChinese = getStringCellValue( row.getCell( 9 ) );
		String optional = getStringCellValue( row.getCell( 10 ) );
		field.setOrderNo( row.getRowNum() );
		field.setSplitField( false );
		field.setFieldType( fieldType );
		if (FieldType.F.equals( fieldType ))
			field.setCode( code );
		else
			field.setValue( code );
		if (messages.getMessage( DataType.H.getPropKey() ).equals( dataType )) {
			field.setDataType( DataType.H );
		} else if (messages.getMessage( DataType.N.getPropKey() ).equals( dataType )) {
			field.setDataType( DataType.N );
		} else if (messages.getMessage( DataType.X.getPropKey() ).equals( dataType )) {
			field.setDataType( DataType.X );
		}
		if (messages.getMessage( "txn.justifytype.l" ).equals( justify )) {
			field.setJustify( JustifyType.L );
		} else if (messages.getMessage( "txn.justifytype.r" ).equals( justify )) {
			field.setJustify( JustifyType.R );
		}
		if (messages.getMessage( "txn.includechinese.yes" ).equals( includeChinese )) {
			field.setIncludeChinese( 1 );
		} else if (messages.getMessage( "txn.includechinese.no" ).equals( includeChinese )) {
			field.setIncludeChinese( 0 );
		}
		if (messages.getMessage( "txn.required.yes" ).equals( optional )) {
			field.setOptional( 0 );
		} else if (messages.getMessage( "txn.required.no" ).equals( optional )) {
			field.setOptional( 1 );
		}
		String erroMsg = validateTxnField( row.getSheet(), field );
		if (field.getScale() == null && StringUtils.isNoneBlank( getStringCellValue( row.getCell( 6 ) ) )) {
			erroMsg += "欄位小數位數無效,";
		}
		if (StringUtils.isNoneBlank( erroMsg )) {
			holdErrors.add( "第" + (row.getRowNum() + 1) + "行:" + erroMsg );
		}
		return field;
	}

}
