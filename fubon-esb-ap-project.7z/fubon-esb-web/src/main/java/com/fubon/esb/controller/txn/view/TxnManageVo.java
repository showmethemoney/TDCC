package com.fubon.esb.controller.txn.view;

public class TxnManageVo {

    private String accessChannelId;
    private String accessChannelName;
    private Integer accessChannelRows;
    private String channelId;
    private String channelName;
    private Integer channelRows;
    private String hostName;
    private String hostId;
    private Integer hostRows;
    private String txnGroupName;
    private String txnGroupId;
    private Integer txnGroupRows;
    private String serviceName;
    private String serviceId;
    private Integer serviceRows;
    private String serviceVersion;
    private Integer serviceVersionRows;
    private String connectorName;
    private String connectorId;
    private Integer connectorRows;
    private String txnId;
    private String txnName;
    private String txnCode;

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    private Integer txnRows;

    public String getAccessChannelPrefix() {
        return accessChannelId == null ? "null_" : accessChannelId + "_";
    }

    public String getChannelPrefix() {
        return getAccessChannelPrefix() + (channelId == null ? "null_" : channelId + "_");
    }

    public String getHostIdPrefix() {
        return getChannelPrefix() + (hostId == null ? "null_" : hostId + "_");
    }

    public String getTxnGroupIdPrefix() {
        return getHostIdPrefix() + (txnGroupId == null ? "null_" : txnGroupId + "_");
    }

    public String getServiceNamePrefix() {
        return getTxnGroupIdPrefix() + (serviceName == null ? "null_" : serviceName + "_");
    }

    public String getServiceVersionPrefix() {
        return getServiceNamePrefix() + (serviceVersion == null ? "null_" : serviceVersion + "_");
    }

    public String getConnectorIdPrefix() {
        // return getServiceNamePrefix() + (connectorId == null ? "null_" : connectorId + "_");
        return getServiceVersionPrefix() + (connectorId == null ? "null_" : connectorId + "_");
    }

    // ///
    public String getServiceNamePrefix2() {
        return serviceName == null ? "null_" : serviceName + "_";
    }

    public String getServiceVersionPrefix2() {
        return getServiceNamePrefix2() + (serviceVersion == null ? "null_" : serviceVersion + "_");
    }

    // //
    public String getTxnPrefix() {
        return txnId == null ? "null_" : txnId + "_";
    }

    public String getChannelTxnPrefix() {
        return getTxnPrefix() + (channelId == null ? "null_channel_" : channelId + "_");
    }

    public String getAccessChannelTxnPrefix() {
        return getTxnPrefix() + (accessChannelId == null ? "null_accesschannel_" : accessChannelId + "_");
    }

    public String getHostTxnPrefix() {
        return getTxnPrefix() + (hostId == null ? "null_host_" : hostId + "_");
    }

    public String getTxnGroupTxnPrefix() {
        return getTxnPrefix() + (txnGroupId == null ? "null_txngroup_" : txnGroupId + "_");
    }

    public String getServiceTxnPrefix() {
        return getTxnPrefix() + (serviceId == null ? "null_txn_service_" : serviceId + "_");
    }

    public String getServiceVersionTxnPrefix() {
        return getTxnPrefix() + (serviceVersion == null ? "null_serviceversion_" : serviceVersion + "_");
    }

    public String getConnectorTxnPrefix() {
        return getTxnPrefix() + (connectorId == null ? "null_connector_" : connectorId + "_");
    }

    public Integer getAccessChannelRows() {
        return accessChannelRows;
    }

    public void setAccessChannelRows(Integer accessChannelRows) {
        this.accessChannelRows = accessChannelRows;
    }

    public Integer getChannelRows() {
        return channelRows;
    }

    public void setChannelRows(Integer channelRows) {
        this.channelRows = channelRows;
    }

    public Integer getHostRows() {
        return hostRows;
    }

    public void setHostRows(Integer hostRows) {
        this.hostRows = hostRows;
    }

    public Integer getTxnGroupRows() {
        return txnGroupRows;
    }

    public void setTxnGroupRows(Integer txnGroupRows) {
        this.txnGroupRows = txnGroupRows;
    }

    public Integer getServiceRows() {
        return serviceRows;
    }

    public void setServiceRows(Integer serviceRows) {
        this.serviceRows = serviceRows;
    }

    public Integer getServiceVersionRows() {
        return serviceVersionRows;
    }

    public void setServiceVersionRows(Integer serviceVersionRows) {
        this.serviceVersionRows = serviceVersionRows;
    }

    public Integer getConnectorRows() {
        return connectorRows;
    }

    public void setConnectorRows(Integer connectorRows) {
        this.connectorRows = connectorRows;
    }

    public Integer getTxnRows() {
        return txnRows;
    }

    public void setTxnRows(Integer txnRows) {
        this.txnRows = txnRows;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getAccessChannelName() {
        return accessChannelName;
    }

    public void setAccessChannelName(String accessChannelName) {
        this.accessChannelName = accessChannelName;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getTxnGroupName() {
        return txnGroupName;
    }

    public void setTxnGroupName(String txnGroupName) {
        this.txnGroupName = txnGroupName;
    }

    public String getServiceVersion() {
        return serviceVersion;
    }

    public void setServiceVersion(String serviceVersion) {
        this.serviceVersion = serviceVersion;
    }

    public String getConnectorName() {
        return connectorName;
    }

    public void setConnectorName(String connectorName) {
        this.connectorName = connectorName;
    }

    public String getTxnName() {
        return txnName;
    }

    public void setTxnName(String txnName) {
        this.txnName = txnName;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getAccessChannelId() {
        return accessChannelId;
    }

    public void setAccessChannelId(String accessChannelId) {
        this.accessChannelId = accessChannelId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getHostId() {
        return hostId;
    }

    public void setHostId(String hostId) {
        this.hostId = hostId;
    }

    public String getTxnGroupId() {
        return txnGroupId;
    }

    public void setTxnGroupId(String txnGroupId) {
        this.txnGroupId = txnGroupId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }

}
