package com.fubon.esb.controller.common.view;

/**
 * @author nice
 * @createdDate 2014-12-1
 */
public final class History {

    private String url;

    private String html;

    public History() {
    }

    public History(String url, String html) {
        super();
        this.url = url;
        this.html = html;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

}
