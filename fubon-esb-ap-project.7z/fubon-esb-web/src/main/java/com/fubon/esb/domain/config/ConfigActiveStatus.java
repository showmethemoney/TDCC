package com.fubon.esb.domain.config;

public enum ConfigActiveStatus {

    /** Active */
    A("Active"),

    /** Inactive */
    I("Inactive"),

    D("Delete");

    private final String desc;

    private ConfigActiveStatus(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }
}
