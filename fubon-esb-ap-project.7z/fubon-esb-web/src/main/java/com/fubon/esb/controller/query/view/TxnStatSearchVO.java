package com.fubon.esb.controller.query.view;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.fubon.esb.domain.config.TxnStatCategoryType;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-14
 */
public class TxnStatSearchVO {

    /**
     * 統計類別
     * 
     */
    private Integer classification;

    private String startDate;

    private String endDate;

    private TxnStatCategoryType category;

    private Integer type;

    private Integer startYear;

    private Integer endYear;

    private Integer startMonth;

    private Integer endMonth;

    private OrderBy order;

    private Page page;
    
    private String value1;
    
    private String value2e;
    
    private String value2ct;
    
    private String valueD;
    
    private String value3;

    public Integer getClassification() {
        return classification;
    }

    public void setClassification(Integer classification) {
        this.classification = classification;
    }

    public Date getStartDate() {
        if (StringUtils.isBlank(startDate)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(startDate);
        } catch (Exception e) {
            return null;
        }
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        if (StringUtils.isBlank(endDate)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(endDate);
        } catch (Exception e) {
            return null;
        }
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public TxnStatCategoryType getCategory() {
        return category;
    }

    public void setCategory(TxnStatCategoryType category) {
        this.category = category;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getStartYear() {
        return startYear;
    }

    public void setStartYear(Integer startYear) {
        this.startYear = startYear;
    }

    public Integer getEndYear() {
        return endYear;
    }

    public void setEndYear(Integer endYear) {
        this.endYear = endYear;
    }

    public Integer getStartMonth() {
        return startMonth;
    }

    public void setStartMonth(Integer startMonth) {
        this.startMonth = startMonth;
    }

    public Integer getEndMonth() {
        return endMonth;
    }

    public void setEndMonth(Integer endMonth) {
        this.endMonth = endMonth;
    }

    public OrderBy getOrder() {
        return order;
    }

    public void setOrder(OrderBy order) {
        this.order = order;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public String getValue2() {
        if (category == null) {
            return "";
        }

        switch (category) {
            case CT:
                return value2ct;
            case E:
                return value2e;
            default:
                break;
        }
        return "";
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }

    public String getValue2e() {
        return value2e;
    }

    public void setValue2e(String value2e) {
        this.value2e = value2e;
    }

    public String getValue2ct() {
        return value2ct;
    }

    public void setValue2ct(String value2ct) {
        this.value2ct = value2ct;
    }
    
    public String getValueD() {
        return valueD;
    }

    public void setValueD(String valueD) {
        this.valueD = valueD;
    }

    public static TxnStatSearchVO getDefault() {
        TxnStatSearchVO vo = new TxnStatSearchVO();
        vo.setClassification(1);
        vo.setType(1);
        vo.setPage(new Page(1, 50));
        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DAY_OF_YEAR, -1); // 預設昨日
        String yesterdayStr = DateFormatUtils.format(yesterday, "yyyy/MM/dd");
        vo.setEndDate(yesterdayStr);
        vo.setStartDate(yesterdayStr);
        vo.setCategory(TxnStatCategoryType.A);
        return vo;
    }

}
