package com.fubon.esb.domain.log;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Qigers
 * @createdDate 2014-11-14
 */
@Entity(name = "TXN_HIS_RECORD_MSG")
public class TxnHisRecordMsg implements Serializable {
    /** ID **/
    @Id
    @Column(name = "ID")
    private String id;

    /** Tracking ID **/
    @Column(name = "TRACKING_ID")
    private String trackingId;

    /** 創建時間 **/
    @Column(name = "CREATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    /** 交易回應碼 **/
    @Column(name = "RETURN_CODE")
    private String returnCode;

    /** 機器名稱 **/
    @Column(name = "ENGINE_NAME")
    private String engineName;

    /** 上下或下行 **/
    @Column(name = "DIRECTION")
    private String direction;

    /** 所在layer分層 **/
    @Column(name = "LAYER")
    private String layer;

    /** 電文內容 **/
    @Column(name = "MESSAGE")
    private String message;
    
    /** 交易代號 **/
    @Column(name = "TXN_CODE")
    private String txnCode;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getEngineName() {
        return engineName;
    }

    public void setEngineName(String engineName) {
        this.engineName = engineName;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getLayer() {
        return layer;
    }

    public void setLayer(String layer) {
        this.layer = layer;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }
}
