package com.fubon.esb.service.config;

import java.util.ArrayList;
import java.util.List;
 
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.view.EditChannelView;
import com.fubon.esb.dao.config.AccessChannelDao;
import com.fubon.esb.dao.config.BranchIPDao;
import com.fubon.esb.dao.config.WorkstationDao;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;

/**
 * @author Leckie Zhang
 * @createdDate 2014-12-31
 */
@Service
public class ChannelCompareService {

    @Inject
    private AccessChannelCompareService accessChannelCompareService;

    @Inject
    private LoginContext loginContext;

    @Inject
    private AccessChannelDao accessChannelDao;

    @Inject
    private WorkstationDao workstationDao;

    @Inject
    private BranchIPDao branchIPDao;

    @Inject
    private ConfigChangeService configChangeService;

    /**
     * Channel新增或修改發送郵件
     */
    public void sendMail(Channel newChannel, Channel originChannel, EditChannelView view) {
        channelCompare(newChannel, originChannel, view);
    }

    /**
     * Channel修改
     */
    private void channelCompare(Channel newChannel, Channel originChannel, EditChannelView view) {
        if (originChannel == null || "0".equals(originChannel.getMainId())) {
            addChannelMessage(newChannel, originChannel, view);
            return;
        }

        StringBuilder newSb = new StringBuilder();
        StringBuilder oldSb = new StringBuilder();
        String originId = originChannel.getId(); // TODO(1) 可與頁面開發者協調

        channelCompareSub(newChannel, originChannel, newSb, oldSb); // 超過長度，放入子方法中
        if (!accessChannelCompareService.compare(newChannel.getRuleCode(), originChannel.getRuleCode())) {
            newSb.append("驗證模塊參數：").append("").append(newChannel.getRuleCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("驗證模塊參數：").append("").append(originChannel.getRuleCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        List<String> workstationCodeList = workstationDao.findWorkstationCodesByChannelId(originId);
        if (workstationCodeList == null) {
            workstationCodeList = new ArrayList<>();
        }
        String[] workstationCodes = toArray(workstationCodeList);
        String[] newWorkstationCodes = view.getWorkstationCodes();
        if (newWorkstationCodes == null) {
            newWorkstationCodes = new String[]{};
        }

        if (!accessChannelCompareService.compare(workstationCodes, newWorkstationCodes)) {
            newSb.append("Workstation ID：").append("").append(accessChannelCompareService.arrayToString(newWorkstationCodes)).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Workstation ID：").append("").append(accessChannelCompareService.arrayToString(workstationCodes)).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }

        List<String> ipList = branchIPDao.findIPsByChannelId(originId);
        if (ipList == null) {
            ipList = new ArrayList<>();
        }
        String[] ips = toArray(ipList);
        String[] newIps = view.getBranchIps();
        if (newIps == null) {
            newIps = new String[]{};
        }
        if (!accessChannelCompareService.compare(ips, newIps)) {
            newSb.append("Channel連線單位IP：").append("").append(accessChannelCompareService.arrayToString(newIps)).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Channel連線單位IP：").append("").append(accessChannelCompareService.arrayToString(ips)).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        
        if (newSb.length() == 0)
            return;
        
        
        StringBuilder result = new StringBuilder();
        result.append("Channel設定(Channel 代號：").append(newChannel.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append("").append(AccessChannelCompareService.LINEBREACKCODE).append("現形生效內容： ")
                .append(AccessChannelCompareService.LINEBREACKCODE).append(oldSb).append(AccessChannelCompareService.LINEBREACKCODE).append(AccessChannelCompareService.LINEBREACKCODE).append("變更後內容：")
                .append(AccessChannelCompareService.LINEBREACKCODE).append(newSb);
        configChangeService.sendMailRequest("Channel設定變更", result.toString());
    }

    private void channelCompareSub(Channel newChannel, Channel originChannel, StringBuilder newSb, StringBuilder oldSb) {
        if (!accessChannelCompareService.compare(newChannel.getCode(), originChannel.getCode())) {
            newSb.append("Channel代號：").append("").append(newChannel.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Channel代號：").append("").append(originChannel.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getName(), originChannel.getName())) {
            newSb.append("Channel名稱：").append("").append(newChannel.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Channel名稱：").append("").append(originChannel.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getStatus().toString(), originChannel.getStatus().toString())) {
            newSb.append("使用狀態：").append("").append(accessChannelCompareService.getDisplayName(newChannel.getStatus())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("使用狀態：").append("").append(accessChannelCompareService.getDisplayName(originChannel.getStatus())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getEffectType().toString(), originChannel.getEffectType().toString())) {
            newSb.append("生效類型：").append("").append(accessChannelCompareService.getDisplayName(newChannel.getEffectType())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("生效類型：").append("").append(accessChannelCompareService.getDisplayName(originChannel.getEffectType())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getEffectTime(), originChannel.getEffectTime())) {
            if (accessChannelCompareService.isEffectTypeBooked(newChannel.getEffectType())) {
                newSb.append("生效時間：").append("").append(accessChannelCompareService.formatDate(newChannel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            }
            if (accessChannelCompareService.isEffectTypeBooked(originChannel.getEffectType())) {
                oldSb.append("生效時間：").append("").append(accessChannelCompareService.formatDate(originChannel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(AccessChannelCompareService.LINEBREACKCODE);   
            }
        }
        if (!accessChannelCompareService.compare(newChannel.getAccessChannelId(), originChannel.getAccessChannelId())) {
            newSb.append("關聯 Access Channel 代號：").append("").append(getAccessChannelCode(newChannel.getAccessChannelId())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("關聯 Access Channel 代號：").append("").append(getAccessChannelCode(originChannel.getAccessChannelId())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getAppCode(), originChannel.getAppCode())) {
            newSb.append("應用系統代號：").append("").append(newChannel.getAppCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("應用系統代號：").append("").append(originChannel.getAppCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getAppName(), originChannel.getAppName())) {
            newSb.append("應用系統簡稱：").append("").append(newChannel.getAppName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("應用系統簡稱：").append("").append(originChannel.getAppName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getBgGroup(), originChannel.getBgGroup())) {
            newSb.append("BG Group：").append("").append(newChannel.getBgGroup()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("BG Group：").append("").append(originChannel.getBgGroup()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getLoginName(), originChannel.getLoginName())) {
            newSb.append("登入帳號：").append("").append(newChannel.getLoginName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("登入帳號：").append("").append(originChannel.getLoginName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newChannel.getLoginPassWord(), originChannel.getLoginPassWord())) {
            newSb.append("登入密碼：").append("").append(newChannel.getLoginPassWord()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("登入密碼：").append("").append(originChannel.getLoginPassWord()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
    }

    private void addChannelMessage(Channel channel, Channel originChannel, EditChannelView view) {
        StringBuilder result = new StringBuilder();
        String title;
        if (originChannel == null) {
            result.append("Channel設定新增，新增者：").append(loginContext.loginedUserId()).append("").append(AccessChannelCompareService.LINEBREACKCODE).append("新增內容： ").append(AccessChannelCompareService.LINEBREACKCODE);
            title = "Channel設定新增";
        } else {
            result.append("Channel設定(Channel 代號：").append(channel.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append("").append(AccessChannelCompareService.LINEBREACKCODE)
                    .append("現形生效內容： ").append(AccessChannelCompareService.LINEBREACKCODE).append(AccessChannelCompareService.LINEBREACKCODE).append(AccessChannelCompareService.LINEBREACKCODE).append("變更後內容：").append(AccessChannelCompareService.LINEBREACKCODE);
            title = "Channel設定變更";
        }
        
        if (StringUtils.isNotBlank(channel.getCode())) {
            result.append("Channel代號：").append(channel.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getName())) {
            result.append("Channel名稱：").append(channel.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (channel.getStatus() != null) {
            result.append("使用狀態：").append(accessChannelCompareService.getDisplayName(channel.getStatus())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (channel.getEffectType() != null) {
            result.append("生效類型：").append(accessChannelCompareService.getDisplayName(channel.getEffectType())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        addChannelMessageSub(channel, originChannel, view, result);

        configChangeService.sendMailRequest(title, result.toString());
    }
    
    public void addChannelMessageSub(Channel channel, Channel originChannel, EditChannelView view, StringBuilder sb) {
        StringBuilder result = new StringBuilder();
        if (channel.getEffectTime() != null && accessChannelCompareService.isEffectTypeBooked(channel.getEffectType())) {
            result.append("生效時間：").append(accessChannelCompareService.formatDate(channel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getAccessChannelId())) {
            result.append("關聯 Access Channel 代號：").append("").append(accessChannelDao.getAccessChannelById(channel.getAccessChannelId()).getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getAppCode())) {
            result.append("應用系統代號：").append("").append(channel.getAppCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getAppName())) {
            result.append("應用系統簡稱：").append("").append(channel.getAppName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getBgGroup())) {
            result.append("BG Group：").append("").append(channel.getBgGroup()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getLoginName())) {
            result.append("登入帳號：").append("").append(channel.getLoginName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getLoginPassWord())) {
            result.append("登入密碼：").append("").append(channel.getLoginPassWord()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(channel.getRuleCode())) {
            result.append("驗證模塊參數：").append("").append(channel.getRuleCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (view.getWorkstationCodes() != null && view.getWorkstationCodes().length > 0) {
            result.append("Workstation ID：").append("").append(accessChannelCompareService.arrayToString(view.getWorkstationCodes())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (view.getBranchIps() != null && view.getBranchIps().length > 0) {
            result.append("Channel連線單位IP：").append("").append(accessChannelCompareService.arrayToString(view.getBranchIps())).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        
        sb.append(result);
    }

    private String[] toArray(List<String> list) {
        if (list == null || list.isEmpty()) {
            return new String[]{};
        }
        return list.toString().replace("[", "").replace("]", "").split(",");
    }
    
    private String getAccessChannelCode(String id) {
        if (StringUtils.isBlank(id)) {
            return "";
        }
        
        AccessChannel channel = accessChannelDao.getAccessChannelById(id);
        if (channel != null) {
            return channel.getCode();
        }
        
        return "";
    }

}
