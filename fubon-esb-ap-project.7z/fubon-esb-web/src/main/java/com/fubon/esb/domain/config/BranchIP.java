package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Channel 連線單位IP
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_BRANCH_IP")
public class BranchIP implements Serializable {

    /** 所屬Channel */
    @Id
    @Column(name = "CHANNEL_ID")
    private String channelId;

    /** IP地址 */
    @Id
    @Column(name = "IP")
    private String ip;

    public BranchIP() {
        super();
    }

    public BranchIP(String channelId, String ip) {
        super();
        this.channelId = channelId;
        this.ip = ip;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((channelId == null) ? 0 : channelId.hashCode());
        result = prime * result + ((ip == null) ? 0 : ip.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BranchIP other = (BranchIP) obj;
        if (channelId == null) {
            if (other.channelId != null)
                return false;
        } else if (!channelId.equals(other.channelId))
            return false;
        if (ip == null) {
            if (other.ip != null)
                return false;
        } else if (!ip.equals(other.ip))
            return false;
        return true;
    }

}
