package com.fubon.esb.controller.query.view;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.hssf.usermodel.HSSFBorderFormatting;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.config.TxnStat;
import com.fubon.esb.domain.config.TxnStatCategoryType;
import com.fubon.esb.domain.config.TxnStatMon;
import com.fubon.esb.domain.config.TxnStatMonErrorCode;

public class TxnStatsExcelBuilder extends AbstractExcelView {

    @SuppressWarnings("unchecked")
    @Override
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("Sheet1");
        sheet.setDefaultColumnWidth(20);

        HSSFCellStyle simpleStyle = workbook.createCellStyle();
        simpleStyle.setBorderRight(HSSFBorderFormatting.BORDER_THIN);
        simpleStyle.setBorderBottom(HSSFBorderFormatting.BORDER_THIN);
        HSSFFont simpleFont = workbook.createFont();
        simpleFont.setFontHeightInPoints((short) 12);
        simpleFont.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
        simpleFont.setFontName("Calibri");
        simpleStyle.setFont(simpleFont);

        HSSFRow header = sheet.createRow(0);

        TxnStatSearchVO vo = (TxnStatSearchVO) obj.get("vo");
        List<TxnStatMon> txnStatMons = new ArrayList<>();
        List<TxnStat> txnStats = new ArrayList<>();
        List<TxnStatMonErrorCode> txnStatMonErrorCodes = new ArrayList<>();
        if (vo.getClassification() == 2) {
            if (vo.getCategory() != null && vo.getCategory() == TxnStatCategoryType.E) {
                txnStatMonErrorCodes = (List<TxnStatMonErrorCode>) obj.get("txnStats");   
            } else {
                txnStatMons = (List<TxnStatMon>) obj.get("txnStats");
            }
        } else {
            txnStats = (List<TxnStat>) obj.get("txnStats");
        }
        String[] titles = (String[]) obj.get("titles");

        setTitle(titles, header, simpleStyle);

        if (vo.getClassification() == 2) {
            if (vo.getCategory() != null && vo.getCategory() == TxnStatCategoryType.E) {
                fillingForMonthErrorCode(sheet, txnStatMonErrorCodes);
            } else {
                fillingForMonth(sheet, txnStatMons, vo);            
            }
        } else {
            filling(sheet, txnStats, vo);
        }

        String filename = System.currentTimeMillis() + ".xls";
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + filename);
        OutputStream ouputStream = response.getOutputStream();
        workbook.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();
    }
    
    private void setTitle(String[] titles, HSSFRow header, HSSFCellStyle simpleStyle) {
        int index = 0;
        for (String title : titles) {
            if (StringUtils.isNotBlank(title)) {
                header.createCell(index).setCellValue(titles[index]);
                header.getCell(index).setCellStyle(simpleStyle);
                index++;
            } else {
                break;
            }
        }
    }

    private void filling(HSSFSheet sheet, List<TxnStat> txnStats, TxnStatSearchVO vo) {
        int rowCount = 1;

        if (vo.getClassification() == 1) {
            for (TxnStat t : txnStats) {
                int index = 0;
                HSSFRow aRow = sheet.createRow(rowCount++);
                aRow.createCell(index++).setCellValue(formatDate(t.getDay(), "yyyy/MM/dd"));
                index = setCategoryValue(aRow, vo, t, index);
                aRow.createCell(index).setCellValue(checkNull(t.getTotalRecord()));
            }
        } else if (vo.getClassification() == 3) {
            for (TxnStat t : txnStats) {
                int index = 0;
                HSSFRow aRow = sheet.createRow(rowCount++);
                aRow.createCell(index++).setCellValue(formatDate(t.getDay(), "yyyy/MM/dd"));
                aRow.createCell(index++).setCellValue(formatDecimal(t.getHour()));
                index = setCategoryValue(aRow, vo, t, index);
                aRow.createCell(index++).setCellValue(checkNull(t.getTotalRecord()));
                aRow.createCell(index).setCellValue(checkNull(t.getAvgTime()));
            }
        }
    }

    private void fillingForMonth(HSSFSheet sheet, List<TxnStatMon> txnStats, TxnStatSearchVO vo) {
        int rowCount = 1;

        for (TxnStatMon t : txnStats) {
            int index = 0;
            HSSFRow aRow = sheet.createRow(rowCount++);
            aRow.createCell(index++).setCellValue(t.getMonthStr());
            index = setCategoryValue(aRow, vo, t, index);
            aRow.createCell(index).setCellValue(checkNull(t.getTotalRecord()));
        }
    }
    
    private void fillingForMonthErrorCode(HSSFSheet sheet, List<TxnStatMonErrorCode> txnStats) {
        int rowCount = 1;

        for (TxnStatMonErrorCode t : txnStats) {
            int index = 0;
            HSSFRow aRow = sheet.createRow(rowCount++);
            aRow.createCell(index++).setCellValue(t.getMonthStr());
            aRow.createCell(index++).setCellValue(t.getHourRange());
            aRow.createCell(index++).setCellValue(t.getValue());
            aRow.createCell(index++).setCellValue(t.getValue2());
            aRow.createCell(index++).setCellValue(t.getValue3());
            aRow.createCell(index).setCellValue(checkNull(t.getTotalRecord()));
        }
    }

    private int setCategoryValue(HSSFRow aRow, TxnStatSearchVO vo, TxnStat t, int i) {
        int index = i;
        if (vo.getCategory() != TxnStatCategoryType.A) {
            if (vo.getCategory() == TxnStatCategoryType.E && vo.getClassification() == 1) {
                aRow.createCell(index++).setCellValue(t.getHourRange()); // errorcode日查詢  增加時間區間
            }
            if (vo.getCategory() == TxnStatCategoryType.D) {
                aRow.createCell(index++).setCellValue(t.getReturnTime());
            } else {
                aRow.createCell(index++).setCellValue(t.getValue());   
            }
            if (vo.getCategory().equals(TxnStatCategoryType.CT)) {
                aRow.createCell(index++).setCellValue(t.getValue2());
            } else if (vo.getCategory() == TxnStatCategoryType.E) {
                aRow.createCell(index++).setCellValue(t.getValue2());
                aRow.createCell(index++).setCellValue(t.getValue3());
            }
        }
        return index;
    }

    private int setCategoryValue(HSSFRow aRow, TxnStatSearchVO vo, TxnStatMon t, int i) {
        int index = i;
        if (vo.getCategory() != TxnStatCategoryType.A) {
            if (vo.getCategory() == TxnStatCategoryType.D) {
                aRow.createCell(index++).setCellValue(t.getReturnTime());
            } else {
                aRow.createCell(index++).setCellValue(t.getValue());
            }
            if (vo.getCategory() == TxnStatCategoryType.E) {
                aRow.createCell(index++).setCellValue(t.getValue2());
                aRow.createCell(index++).setCellValue(t.getValue3());
            } else if (vo.getCategory().equals(TxnStatCategoryType.CT)) {
                aRow.createCell(index++).setCellValue(t.getValue2());
            }
        }
        return index;
    }

    private String formatDate(Date date, String pattern) {
        if (date == null) {
            return "";
        }

        return DateFormatUtils.format(date, pattern);
    }

    private String checkNull(Object o) {
        if (o == null) {
            return "";
        }

        return String.valueOf(o);
    }
    
    private String formatDecimal(BigDecimal hour) {
        if (hour == null) {
            return "";
        }
        BigDecimal later = hour.add(new BigDecimal("0.5"));
        return fullFillDecimal(hour) + "-" + fullFillDecimal(later);
    }
    
    private String fullFillDecimal(BigDecimal b) {
        int i = b.intValue();
        int j = b.subtract(new BigDecimal(i)).multiply(new BigDecimal("60")).intValue();
        StringBuilder result = new StringBuilder(String.valueOf(i * 100 + j));
        while (result.length() < 4) {
            result.insert(0, "0");
        }
        return result.insert(2, ":").toString();
    }
    
}
