package com.fubon.esb.service.config;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fubon.esb.dao.config.AccessChannelDao;
import com.fubon.esb.dao.config.ChannelDao;
import com.fubon.esb.dao.config.ConnectorDao;
import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.dao.config.ServiceDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnGroupDao;
import com.fubon.esb.dao.config.WorkstationDao;
import com.fubon.esb.dao.system.AdapterDao;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-25
 */
@Service
public class AutoQueryService {

    @Inject
    private TxnDao txnDao;
    @Inject
    private TxnGroupDao txnGroupDao;
    @Inject
    private ServiceDao serviceDao;
    @Inject
    private ChannelDao channelDao;
    @Inject
    private ConnectorDao connectorDao;
    @Inject
    private WorkstationDao workstationDao;
    @Inject
    private AccessChannelDao accessChannelDao;
    @Inject
    private HostDao hostDao;
    @Inject
    private AdapterDao adapterDao;

    public List<String> searchTxnCodes(String code) {
        // if (StringUtils.isBlank(code)) {
        // return null;
        // }
        return txnDao.searchTxnCodes(code);
    }

    public List<String> searchMainTxnGroupCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return txnGroupDao.searchMainTxnGroupCodes(code);
    }

    public List<String> searchMainServiceCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return serviceDao.searchMainServiceCodes(code);
    }

    public List<String> searchMainChannelCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return channelDao.searchMainChannelCodes(code);
    }

    public List<String> searchConnectorCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return connectorDao.searchConnectorCodes(code);
    }

    public List<String> searchChannelCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return channelDao.searchChannelCodes(code);
    }

    public List<String> serchWorkstationCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return workstationDao.searchWorkstationCodes(code);
    }

    public List<String> serchAccessChannelCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return accessChannelDao.searchAccessChannelCodes(code);
    }

    public List<String> serchMainAccessChannelCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return accessChannelDao.searchMainAccessChannelCodes(code);
    }

    public List<String> searchTxnGroupCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return txnGroupDao.searchTxnGroupCodes(code);
    }

    public List<String> searchHostCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return hostDao.searchHostCodes(code);
    }

    public List<String> searchMainHostCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return hostDao.searchMainHostCodes(code);
    }

    public List<String> searchServiceCodes(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return serviceDao.searchServiceCodes(code);
    }

    public List<String> searchRelateTxnCodes(String code, String id) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        return txnDao.searchMainTxnCodes(code, id);
    }

    public List<String> searchAdapterByKey(String key, String connectorId) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return adapterDao.searchAdapterByKey(key, connectorId);
    }
}
