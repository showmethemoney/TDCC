package com.fubon.esb.dao.txn;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.comwave.core.database.Page;
import com.comwave.core.util.StopWatch;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */

public class JDBCAccessSQLPage {

    private final Logger logger = LoggerFactory.getLogger(JDBCAccessSQLPage.class);

    private JdbcTemplate jdbcTemplate;

    /**
     * handle insert/update/delete
     */
    public int execute(String sql, Object... params) {
        StopWatch watch = new StopWatch();
        int updatedRows = 0;
        try {
            updatedRows = jdbcTemplate.update(sql, params);
            return updatedRows;
        } finally {
            logger.debug("execute, sql={}, params={}, updatedRows={}, elapsedTime={}", sql, params, updatedRows, watch.elapsedTime());
        }
    }

    public int[] batchExecute(String sql, List<Object[]> params) {
        StopWatch watch = new StopWatch();
        int totalUpdatedRows = 0;
        try {
            int[] results = jdbcTemplate.batchUpdate(sql, params);
            for (int updatedRows : results) {
                totalUpdatedRows += updatedRows;
            }
            return results;
        } finally {
            logger.debug("batchExecute, sql={}, params={}, totalUpdatedRows={}, elapsedTime={}", sql, params, totalUpdatedRows, watch.elapsedTime());
        }
    }

    public <T> List<T> find(String sql, RowMapper<T> rowMapper, Object... params) {
        StopWatch watch = new StopWatch();
        int returnedRows = 0;
        try {
            List<T> results = jdbcTemplate.query(sql, params, rowMapper);
            returnedRows = results.size();
            return results;
        } finally {
            logger.debug("find, sql={}, params={}, returnedRows={}, elapsedTime={}", sql, params, returnedRows, watch.elapsedTime());
        }
    }

    public <T> List<T> findPage(String sql, final RowMapper<T> rowMapper, final Page page, Object... params) {
        StopWatch watch = new StopWatch();

        Long totalCount = findTotalCount(sql, params);
        if (totalCount == 0) {
            return new ArrayList<>();
        }
        if (page == null) {
            return find(sql, rowMapper, params);
        }
        page.setTotalCount(totalCount.intValue());
        int returnedRows = 0;
        try {
            List<T> results = (List<T>) jdbcTemplate.query(sql, params, new ResultSetExtractor<List<T>>() {

                public List<T> extractData(ResultSet rs) throws SQLException, DataAccessException {
                    List<T> list = new ArrayList<>();
                    int currentRow = 0;
                    while (rs.next() && currentRow < page.getFirstResult() + page.getPageSize()) {
                        if (currentRow >= page.getFirstResult()) {
                            list.add(rowMapper.mapRow(rs, currentRow));
                        }
                        currentRow++;
                    }
                    return list;
                }

            });
            returnedRows = results.size();
            return results;
        } finally {
            logger.debug("find, sql={}, params={}, returnedRows={}, elapsedTime={}", sql, params, returnedRows, watch.elapsedTime());
        }
    }

    public Long findTotalCount(String sql, Object... params) {
        StringBuilder pageQueryString = new StringBuilder("select count(1) count ");
        if (sql.toLowerCase().indexOf("group by") == -1) {
            int start = sql.toLowerCase().indexOf(" from ");
            if (start < 0)
                throw new IllegalStateException("query string is not valid");

            int end = sql.toLowerCase().indexOf(" order by ");
            if (end < 0)
                pageQueryString.append(sql.substring(start));
            else
                pageQueryString.append(sql.substring(start, end));
        } else {
            pageQueryString.append(" from (select count(1) ");
            int start = sql.toLowerCase().indexOf(" from ");
            if (start < 0)
                throw new IllegalStateException("query string is not valid");

            int end = sql.toLowerCase().indexOf(" order by ");
            if (end < 0)
                pageQueryString.append(sql.substring(start));
            else
                pageQueryString.append(sql.substring(start, end));
            pageQueryString.append(" )");

        }
        return findOne(pageQueryString.toString(), new RowMapper<Long>() {
            public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getLong("count");
            }
        }, params);
    }

    public <T> T findOne(String sql, RowMapper<T> rowMapper, Object... params) {
        StopWatch watch = new StopWatch();
        try {
            return jdbcTemplate.queryForObject(sql, params, rowMapper);
        } catch (EmptyResultDataAccessException e) {
            logger.debug("findOne did not find any result", e);
            return null;
        } finally {
            logger.debug("findOne, sql={}, params={}, elapsedTime={}", sql, params, watch.elapsedTime());
        }
    }

    public Integer findInteger(String sql, Object... params) {
        StopWatch watch = new StopWatch();
        try {
            return jdbcTemplate.queryForObject(sql, params, Integer.class);
        } catch (EmptyResultDataAccessException e) {
            logger.debug("findInteger did not find any result", e);
            return null;
        } finally {
            logger.debug("findInteger, sql={}, params={}, elapsedTime={}", sql, params, watch.elapsedTime());
        }
    }

    public String findString(String sql, Object... params) {
        StopWatch watch = new StopWatch();
        try {
            return jdbcTemplate.queryForObject(sql, params, String.class);
        } catch (EmptyResultDataAccessException e) {
            logger.debug("findString did not find any result", e);
            return null;
        } finally {
            logger.debug("findString, sql={}, params={}, elapsedTime={}", sql, params, watch.elapsedTime());
        }
    }

    public void setDataSource(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

}
