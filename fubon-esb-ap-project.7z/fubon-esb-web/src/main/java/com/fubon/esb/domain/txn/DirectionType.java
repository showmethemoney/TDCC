package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum DirectionType {

    U("UP"), D("DOWN"), H("HEAD");

    private String desc;

    DirectionType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

}
