package com.fubon.esb.dao.system;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.Adapter;

@Repository
public class AdapterDao extends JPADaoSupport<Adapter> {

    public List<Adapter> findTxnsByConnectorId(String connectorId) {
        Query query = Query.from(Adapter.class).where("connectorId = :connectorId ").param("connectorId", connectorId);
        return jpaAccess.find(query);
    }

    public List<String> searchAdapterByKey(String key, String connectorId) {
        Query query = Query.create("select distinct adapterName from " + Adapter.class.getName());
        query.where("connectorId = :connectorId ").param("connectorId", connectorId);
        query.append(" and adapterName like :adapterName ").param("adapterName", key + "%");
        query.orderBy("adapterName");
        return jpaAccess.find(query);
    }

    public List<Adapter> findAdapterByName(String adapterName, String connectorId, Page page) {
        Query query = Query.from(Adapter.class);
        query.where("connectorId = :connectorId ").param("connectorId", connectorId);
        if (StringUtils.isNotBlank(adapterName)) {
            query.append(" and adapterName like :adapterName ").param("adapterName", adapterName);
        }
        query.orderBy("adapterName");
        query.page(page);
        return jpaAccess.findPage(query);
    }

    public void updateAdapter(Adapter adapter) {
        Query query = Query.create("update from ").append(Adapter.class).append(" adapter set ");
        if (StringUtils.isNotBlank(adapter.getAdapterName())) {
            query.append(" adapter.adapterName = :adapterName , ");
            query.setParam("adapterName", adapter.getAdapterName());
        }
        if (StringUtils.isNotBlank(adapter.getConnectorId())) {
            query.append(" adapter.connectorId = :connectorId , ");
            query.setParam("connectorId", adapter.getConnectorId());
        }
        if (StringUtils.isNotBlank(adapter.getUrl())) {
            query.append(" adapter.url = :url , ");
            query.setParam("url", adapter.getUrl());
        }

        if (StringUtils.isNoneBlank(adapter.getId())) {
            query.append(" where adapter.id = :id ");
            query.setParam("id", adapter.getId());
        }
        jpaAccess.update(query);
    }

    public void deleteAdapter(Adapter adapter) {
        jpaAccess.delete(adapter);
    }
}
