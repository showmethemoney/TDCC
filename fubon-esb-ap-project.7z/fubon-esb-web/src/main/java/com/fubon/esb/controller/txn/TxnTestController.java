package com.fubon.esb.controller.txn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.TestTxnArray;
import com.fubon.esb.controller.txn.view.TestTxnVO;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;
import com.fubon.esb.service.log.OperationLogService;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnFieldTestValueService;
import com.fubon.esb.service.txn.TxnService;
import com.fubon.esb.service.txn.TxnTestXmlService;

/**
 * @author nice
 * @createdDate 2014-10-23
 * 
 * Modified By Leo@Comwave 2015.08.03
 * edit function viewTxnConten to support changing and testing FMPConnection content
 * edit function txnSendContent to remove getting FMPConnection fields from env
 * 
 */

@Controller
@RequestMapping({"/txn/test"})
@SuppressWarnings({"unchecked"})
public class TxnTestController extends BaseController {
    @Inject
    private Environment env;
    @Inject
    private Messages messsages;

    private HttpSession session;
    @Inject
    private TxnService txnService;
    @Inject
    private TxnDefinitionService txnDefService;
    @Inject
    private TxnDirectionService txnDirecService;
    @Inject
    private TxnFieldDefinitionService txnFieldService;
    @Inject
    protected OperationLogService operationLogService;
    @Inject
    private TxnFieldTestValueService testValueService;
    @Inject
    private TxnTestXmlService txnTestXmlService;

    private static final String INCLUDE_BASE_URL = "txn/include/test";

    private static final String TMP_VALUE_LSIT_KEY = "txn_test_tmp_value_list";

    private static final String PAGE_LINK_LSIT_KEY = "txn_test_page_link_list";

    @InitBinder
    public void initBinder(HttpServletRequest request) {
        session = request.getSession();
    }

    @RequestMapping({"/list"})
    @RequirePermission(value = "010201")
    public String viewTxnTestList(Model model) {
        return "txn/viewTestTxnList";
    }

    @RequestMapping({"/search"})
    public String searchTxnList(Model model, @RequestParam(required = false) String txnCode, @RequestParam(required = false) String txnName, @RequestParam(required = false) String txnStatus,
            @RequestParam Integer curPage) {
        Page page = new Page(curPage);
        model.addAttribute("txnDefis", txnDefService.findTestPageByCodeName(txnCode, txnName, page));
        if (curPage > page.getTotalPage() && page.getTotalPage() != 0) {
            page.setCurrentPage(page.getTotalPage());
            model.addAttribute("txnDefis", txnDefService.findTestPageByCodeName(txnCode, txnName, page));
        }
        model.addAttribute("page", page);
        return INCLUDE_BASE_URL + "/txnDefs";
    }

    @RequestMapping({"/txnContent/{defId}"})
    @RequirePermission({"010202", "010106"})
    public String viewTxnConten(Model model, @PathVariable("defId") String defId) throws Exception {
        session.setAttribute(TMP_VALUE_LSIT_KEY, new ArrayList<TxnFieldTestValue>(1));
        session.setAttribute(PAGE_LINK_LSIT_KEY, new ArrayList<Map<String, Object>>(1));
        model.addAttribute("txnDef", txnDefService.getById(defId));
        model.addAttribute("upDirec", txnDirecService.findByDefIdAndDirection(defId, DirectionType.U));
        TxnDirection upDirection = txnDirecService.findByDefIdAndDirection(defId, DirectionType.U);
        List<TxnFieldDefinition> headFields = txnFieldService.findMainsByDirId(upDirection.getHeadRefId());
        model.addAttribute("upFields", txnFieldService.findMainsByDirId(upDirection.getId()));
        // model.addAttribute("headFields", headFields);
        model.addAttribute("headFields", testValueService.getHeadFields(headFields, upDirection.getId()));
        
        String SPName=env.getProperty("FMP.SPName");
        String LoginID=env.getProperty("FMP.LoginID");
        String Password=env.getProperty("FMP.Password"); 
        model.addAttribute("FMPConnectionFields", testValueService.getFMPConnectionFields(SPName, LoginID, Password));
        
        return "txn/viewTestTxn";
    }

    /**
     * TxnFieldDefinition child
     */
    @RequestMapping({"/goToChildren"})
    public String goToChildren(Model model, @RequestParam String pFieldId, @RequestParam(defaultValue = "1") Integer cycles, @RequestParam(defaultValue = "1") Integer pPageIndex, String caseValue) {
        Map<String, Object> paramsMap = new HashMap<String, Object>(1);
        paramsMap.put("pFieldId", pFieldId);
        paramsMap.put("cycles", cycles);
        paramsMap.put("pPageIndex", pPageIndex);
        model.addAttribute("caseValue", caseValue);
        getPageLinkList(session).add(paramsMap);
        return viewTxnChildContent(model, pFieldId, cycles, pPageIndex);
    }

    /**
     * TxnFieldDefinition child
     */
    @RequestMapping({"/backToParent"})
    public String backToParent(Model model, @RequestParam(required = false) String pFieldId, String caseValue) {
        List<Map<String, Object>> pageLinkList = getPageLinkList(session);
        if (StringUtils.isBlank(pFieldId)) {
            pageLinkList.clear();
            return viewTxnTestList(model);
        }
        model.addAttribute("caseValue", caseValue);
        pageLinkList.remove(pageLinkList.size() - 1);
        Map<String, Object> attributeMap = pageLinkList.get(pageLinkList.size() - 1);
        return viewTxnChildContent(model, pFieldId, (Integer) attributeMap.get("cycles"), (Integer) attributeMap.get("pPageIndex"));
    }

    /**
     * TxnFieldDefinition child
     */
    @RequestMapping({"/testContent"})
    public String viewTxnChildContent(Model model, @RequestParam String pFieldId, @RequestParam(defaultValue = "1") Integer cycles, @RequestParam(defaultValue = "1") Integer pPageIndex) {
        List<TestTxnVO> testTxnVOs = testValueService.findChildrenTestTxnVOs(pFieldId);
        TxnFieldDefinition txnField = txnFieldService.getById(pFieldId);
        int startOrder = testValueService.getStartOrder(pPageIndex);
        for (TestTxnVO txns : testTxnVOs) {
            txns.setTestValues(testValueService.buildTestValueList(txns.getTestValues(), txns.getField().getId(), cycles, startOrder, txnField.getDirectionId()));
            testValueService.fillTmpValuesIfy(getTemValueList(session), txns.getTestValues(), false, startOrder);
        }
        model.addAttribute("cycles", cycles);
        model.addAttribute("parentField", txnField);
        model.addAttribute("testTxnVOs", testTxnVOs);
        model.addAttribute("index", startOrder);
        return INCLUDE_BASE_URL + "/txnTestContentBak";
    }

    /**
     * 保存testValue
     */
    @ResponseBody
    @RequestMapping({"/testSaveValue"})
    public Map<String, String> commitSave(Model model) {
        testValueService.saveOrUpdateTestValues(getTemValueList(session));
        model.addAttribute("txnDefis", txnDefService.findAll());
        return null;
    }

    @RequestMapping("/sendTxn")
    public String txnSendContent(Model model, String headDirId, String bodyDirId, String defId, String spName, String loginId, String password) {
        model.addAttribute("SPName", spName);
        model.addAttribute("LoginID", loginId);
        model.addAttribute("Password", password);
        model.addAttribute("TxnId", env.getProperty("FMP.TxnId"));
        model.addAttribute("deFinition", txnDefService.getById(defId));
        String bodyFieldsXml = testValueService.buildTestFieldsXmlStr(txnFieldService.findMainsByDirId(bodyDirId));
        List<TxnFieldDefinition> headFields = txnService.findAllChildrenAndSplitByField(txnFieldService.findMainsByDirId(headDirId));
        model.addAttribute("headFields", testValueService.getHeadFields(headFields, bodyDirId));
        model.addAttribute("bodyFieldsXml", bodyFieldsXml);
        return INCLUDE_BASE_URL + "/txnSendContent";
    }

    /**
     * 
     * 把頁面傳過來的數據加入testValMap中
     */
    @ResponseBody
    @RequestMapping(value = {"/testPutValue"}, method = RequestMethod.POST)
    public Object putTestValue(Model model, HttpServletRequest request, @RequestBody TestTxnArray testTxn) {
        if (testTxn != null) {
            for (TxnFieldTestValue tValue : testTxn.getTestValues()) {
                testValueService.fillTmepValueIfy(getTemValueList(session), tValue, true, tValue.getOrderNo());
            }
        }
        return true;
    }

    @ResponseBody
    @RequestMapping(value = "/sendTxnData")
    public Map<String, String> sendTxnData(@RequestParam String testData, @RequestParam String txnCode, @RequestParam String txnName) throws Exception {
        Map<String, String> map = new HashMap<String, String>();
        String responseText = txnService.sendTestTxn(testData, 0);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messsages.getMessage("txn.test.send", txnCode, txnName), LogType.TXN_TEST);
        map.put("back", responseText);
        return map;
    }

    @ResponseBody
    @RequestMapping({"/search/defnames"})
    public Object searchTxnTestNames(@RequestParam String key) {
        return txnDefService.searchTxnTestDefnames(key);
    }

    @ResponseBody
    @RequestMapping("/saveFromXml")
    public Object saveTestValuesFromXmlStr(@RequestParam String xmlStr, @RequestParam String dirId) throws Exception {
        Map<String, Object> result = new HashMap<String, Object>(1);
        try {
            txnTestXmlService.saveTxTestValues(xmlStr, dirId);
        } catch (IllegalArgumentException e) {
            result.put("success", false);
            result.put("errorMsg", e.getMessage());
            return result;
        }
        result.put("success", true);
        result.put("errorMsg", null);
        return result;
    }

    private List<TxnFieldTestValue> getTemValueList(HttpSession session) {
        return (List<TxnFieldTestValue>) session.getAttribute(TMP_VALUE_LSIT_KEY);
    }

    private List<Map<String, Object>> getPageLinkList(HttpSession session) {
        return (List<Map<String, Object>>) session.getAttribute(PAGE_LINK_LSIT_KEY);
    }

}
