package com.fubon.esb.domain.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;


/**
 * Access Channel 設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_ACCESS_CHANNEL")
public class AccessChannel extends ConfigBaseEntity {

    /** 代號 */
    @NotEmpty
    @Column(name = "ACCESS_CODE")
    private String code;

    /** 名稱 */
    @Column(name = "ACCESS_NAME")
    @NotEmpty
    private String name;

    /** 使用狀態 **/
    @Column(name = "ACCESS_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private ConfigActiveStatus status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
