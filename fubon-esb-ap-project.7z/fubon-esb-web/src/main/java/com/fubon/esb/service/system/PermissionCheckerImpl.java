package com.fubon.esb.service.system;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.PermissionChecker;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.User;

/**
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Service
public class PermissionCheckerImpl implements PermissionChecker {
    
    @Inject
    private LoginContext loginContext;
    
    @Inject
    private FunctionService functionService;

    @Override
    public boolean checkPermission(String[] permissions) {
        User user = loginContext.loginedUser(User.class);
        if (user == null) {
            return false;
        }
        List<Role> roles = user.getRoleList();
        if (roles == null || roles.isEmpty()) {
            return false;
        }
        List<String> funcCodes = functionService.findFuncCodesFromRoles(roles);
        boolean result = false;
        for (String permission : permissions) {
            result = result || funcCodes.contains(permission); 
        }
        return result;
    }

}
