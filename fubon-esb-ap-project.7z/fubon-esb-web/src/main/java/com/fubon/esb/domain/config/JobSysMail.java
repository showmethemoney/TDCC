package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 排程系統設定Email
 * 
 * @author Qigers
 * @createdDate 2014-12-11
 */
@Entity(name = "CFG_JOB_SYSTEM_MAIL")
public class JobSysMail implements Serializable {

    /** 所屬群組 */
    @Id
    @Column(name = "SYSTEM_ID")
    private String systemId;

    /** mail地址 */
    @Id
    @Column(name = "MAIL")
    private String mail;

    public JobSysMail() {
        super();
    }

    public JobSysMail(String systemId, String mail) {
        super();
        this.systemId = systemId;
        this.mail = mail;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((systemId == null) ? 0 : systemId.hashCode());
        result = prime * result + ((mail == null) ? 0 : mail.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        JobSysMail other = (JobSysMail) obj;
        if (systemId == null) {
            if (other.systemId != null)
                return false;
        } else if (!systemId.equals(other.systemId))
            return false;
        if (mail == null) {
            if (other.mail != null)
                return false;
        } else if (!mail.equals(other.mail))
            return false;
        return true;
    }

}
