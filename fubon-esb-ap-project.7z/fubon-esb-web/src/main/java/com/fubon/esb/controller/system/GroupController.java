package com.fubon.esb.controller.system;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.service.system.GroupService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Controller
@RequestMapping("/system")
public class GroupController extends BaseController {

    private final Log logger = LogFactory.getLog(GroupController.class);

    @Inject
    private GroupService groupService;

    /**
     * 群組角色頁面
     */
    @RequestMapping("viewGroupRoleList")
    @RequirePermission(value = "070101")
    public String viewGroupRoleList(Model model) {
        model.addAttribute("groups", groupService.findAllGroups());
        return "/system/viewGroupRoleList";
    }

    /**
     * 進入群組新增修改頁面
     */
    @RequestMapping("viewGroup")
    @RequirePermission(value = "070101")
    public String viewGroup(Model model, String id) {
        model.addAttribute("group", groupService.getGroupById(id));
        model.addAttribute("STATUS_ACTIVE", ActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ActiveStatus.I);
        model.addAttribute("groupId", id); // 最初的ID
        return "/system/viewGroup";
    }

    /**
     * 根據頁面傳入的Group，新增或修改
     */
    @RequirePermission(value = {"070102", "070103"})
    @RequestMapping("saveOrUpdateGroup")
    @ResponseBody
    public ResultView saveOrUpdateGroup(Group group) {
        Map<String, Object> result = new HashMap<String, Object>();
        try {
            groupService.saveGroup(group);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            addError(e.getMessage());
            validate();
        }
        result.put("groupId", groupService.getGroupOriginId(group)); // 返回最初的GROUP ID

        return ResultView.success(groupService.getGroupOriginId(group));
    }

    /**
     * 查看Group詳細信息
     */
    @RequestMapping("viewGroupInfo")
    @RequirePermission(value = "070101")
    public String viewGroupInfo(Model model, String id) {
        model.addAttribute("group", groupService.getFullGroup(id));
        model.addAttribute("STATUS_ACTIVE", ActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ActiveStatus.I);
        model.addAttribute("groupId", id); // 保持最初的ID
        return "/system/viewGroupInfo";
    }

    /**
     * 刷新左側的Group Role 列表
     */
    @RequestMapping("refreshGroupList")
    @RequirePermission(value = "070101")
    public String refreshGroupList(Model model) {
        model.addAttribute("groups", groupService.findAllGroups());
        return "/system/groupList";
    }

}
