package com.fubon.esb.crypto;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;


/**
 * @author james
 * @createdDate Sep 10, 2014
 */
public final class EncryptionUtils {

    private static final String PRIVATE_KEY =
            "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAkgFDOCEpH3Ii2VEDsjJb+RpK2OAYUCb9ebsh1jCjhBbVOXrmR1pTZW/wf3TroJZo44Zf5N9Twyrna7ZO5gyR4QIDAQABAkEAg3h5k+BgTD2VXcRSpLIuGWfwf8uCeSIy2tuDw4A2rWgZ1Pi808QkZVJgvGDGywldH+RFGW+QwPKEmNzh1VnTwQIhAMMcl7Q2+jQHQDKOywTzWrFU5XPgAFlU6mHizEg6Cp6JAiEAv5GMLhEDZ7lk/bFbS5fQ1Og5eRoEGRFkG8JRM/kQwpkCIFcksyEbmP6Z6nNqUYThiDVB3MW3W5CKm7CikmkD+3A5AiA4hTDexpZCnCh30UQmYXxz1LBgUpSy8LagmgxrUSjowQIgGBSbqvhKjoZewDLbvolIkn8A76IPqHqo0Ly7DNPqe2A=";
    private static final String PUBLIC_KEY = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJIBQzghKR9yItlRA7IyW/kaStjgGFAm/Xm7IdYwo4QW1Tl65kdaU2Vv8H9066CWaOOGX+TfU8Mq52u2TuYMkeECAwEAAQ==";

    public static String getMD5(String pwd, String charSet) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        return new String(Hex.encodeHex(md.digest(pwd.getBytes(charSet)), false));
    }

    public static void main(String[] args) throws Exception {
        String encrypt = encrypt("p@ssw0rd");
        System.out.println(encrypt);
        String decrypt = decrypt(encrypt);
        System.out.println(decrypt);
    }

    /**
     * 加密
     * */
    public static String encrypt(String s) throws Exception {
        return com.comwave.core.crypto.EncryptionUtils.encrypt(s, PUBLIC_KEY);
    }

    /** 解密 */
    public static String decrypt(String s) throws Exception {
        return com.comwave.core.crypto.EncryptionUtils.decrypt(s, PRIVATE_KEY);
    }
}
