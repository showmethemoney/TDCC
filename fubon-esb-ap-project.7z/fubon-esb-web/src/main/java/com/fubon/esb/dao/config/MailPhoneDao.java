package com.fubon.esb.dao.config;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.MailPhone;

/**
 * 
 * @author Shelly
 * @createdDate 2014-12-11
 */
@Repository
public class MailPhoneDao extends JPADaoSupport<MailPhone> {
    public List<MailPhone> findMailPhones(String groupId) {
        Query query = Query.from(MailPhone.class).where("groupId = :groupId").param("groupId", groupId);
        return jpaAccess.find(query);
    }

    public void addMailPhoneList(List<MailPhone> mailPhones) {
        for (MailPhone mailPhone : mailPhones) {
            jpaAccess.save(mailPhone);
        }
    }

    public void removeMailPhoneList(List<MailPhone> mailPhones) {
        for (MailPhone mailPhone : mailPhones) {
            jpaAccess.delete(mailPhone);
        }
    }

    public void saveMailPhones(String groupId, String[] mailPhones) {
        if (mailPhones != null && mailPhones.length > 0) {
            for (String phone : mailPhones) {
                MailPhone mailPhone = new MailPhone(groupId, phone);
                jpaAccess.save(mailPhone);
            }
        }
    }

    public void removeByGroupId(String groupId) {
        Query query = Query.create("delete from " + MailPhone.class.getName() + " where groupId = :groupId").param("groupId", groupId);
        jpaAccess.update(query);
    }
}
