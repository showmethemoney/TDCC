package com.fubon.esb.controller.log.view;

import com.fubon.esb.controller.system.view.ApprovalSearchVO;

/**
 * @author Blue
 * @createdDate 2014-11-10
 */
public class ApprovalLogSearchVO extends ApprovalSearchVO {

    private Integer modifyFlag;

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

}
