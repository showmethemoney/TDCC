package com.fubon.esb.dao.config;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.config.view.ChannelQueryParam;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.Workstation;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Repository
public class ChannelDao extends JPADaoSupport<Channel> {

    @Inject
    private AccessChannelDao accessChannelDao;
    @Inject
    private WorkstationDao workstationDao;
    @Inject
    private BranchIPDao branchIPDao;

    public List<Channel> findChannelsByAccessChannelId(String id) {
        String mainId = null;
        AccessChannel accessChannel = accessChannelDao.get(id);
        if (accessChannel != null)
            mainId = accessChannel.getMainId();
        Query query = Query.from(Channel.class).where("accessChannelId = :id and (mainId is null or mainId = '0') ").param("id", (mainId != null && !"0".equals(mainId)) ? mainId : id);
        return jpaAccess.find(query);
    }

    public List<Channel> findLatestChannels(ChannelQueryParam channelQueryParam, Page page) {
        Query query = Query.create("select c from " + Channel.class.getName() + " c ");
        if (StringUtils.isNotBlank(channelQueryParam.getWorkstationId())) {
            query.append(" , ").append(Workstation.class).append(" w ");
        }
        query.append(" where not exists(select ch from ").append(Channel.class).append(" ch where ch.mainId = c.id)");
        if (StringUtils.isNotBlank(channelQueryParam.getWorkstationId())) {
            query.append(" and c.id=w.channelId and w.code = :workstationId ");
            query.setParam("workstationId", channelQueryParam.getWorkstationId());
        }
        if (StringUtils.isNotBlank(channelQueryParam.getCode())) {
            query.append(" and c.code = :code ");
            query.setParam("code", channelQueryParam.getCode().trim());
        }
        if (StringUtils.isNotBlank(channelQueryParam.getName())) {
            query.append(" and c.name like :name ");
            query.setParam("name", "%" + channelQueryParam.getName() + "%");
        }
        // // 狀態為空時不查詢刪除的
        // if (channelQueryParam.getStatus() == null) {
        // query.append(" and c.status != :status ");
        // query.setParam("status", ConfigActiveStatus.D);
        // }
        if (channelQueryParam.getStatus() != null) {
            query.append(" and c.status=:status ");
            query.setParam("status", channelQueryParam.getStatus());
        }
        query.orderBy("c.createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(Channel.class).append(" channel where not exists(select ch from ").append(Channel.class).append(" ch where ch.mainId=channel.id) ").append(" and channel.code=:code")
                        .param("code", code).append(" and channel.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();

    }

    public List<Channel> findMainChannels(String code, Page page) {
        Query query = Query.from(Channel.class).append(" channel where channel.mainId is null and channel.status=:status ").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(code)) {
            query.append(" and channel.code = :code ");
            query.setParam("code", code);
        }
        query.orderBy("channel.code").page(page);
        return jpaAccess.findPage(query);

    }

    public List<String> searchMainChannelCodes(String key) {
        Query query = Query.create("select distinct code from " + Channel.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.append(" and mainId is null");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchChannelCodes(String key) {
        Query query = Query.create("select distinct code from " + Channel.class.getName() + " channel");
        query.append(" where not exists(select c from ").append(Channel.class).append(" c where c.mainId = channel.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        Channel channel = jpaAccess.get(Channel.class, id);
        if (StringUtils.isNotBlank(channel.getMainId()) && !"0".equals(channel.getMainId())) { // 如果是帶有正本的副本
            jpaAccess.delete(channel); // 刪掉副本
            workstationDao.deleteByChannelId(id); // 刪除副本關聯的Workinstation
            branchIPDao.deleteByChannelId(id); // 刪除副本對應的BranchIp
            jpaAccess.update(Query.create("update ").append(Channel.class).append(" channel set channel.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", channel.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(Channel.class).append(" channel set channel.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(關聯AccessChannel、關聯交易)
    public List<Channel> isChannelRelatedAccessChannel(String id) {
        Query relAc = Query.create("select channel  from " + Channel.class.getName() + " channel");
        relAc.append(" where  (channel.accessChannelId is not null and channel.accessChannelId !='') and id = :id ").param("id", id);
        return jpaAccess.find(relAc);
    }

    public List<TxnChannel> isChannelRelatedTxn(String id) {
        Query relTxn = Query.create("select txnChannel  from " + TxnChannel.class.getName() + " txnChannel");
        relTxn.append(" where txnChannel.channelId  = :id").param("id", id);
        return jpaAccess.find(relTxn);
    }
}
