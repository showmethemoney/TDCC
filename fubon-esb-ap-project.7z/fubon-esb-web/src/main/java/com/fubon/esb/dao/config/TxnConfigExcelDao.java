package com.fubon.esb.dao.config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.CompositeDaoSupport;
import com.fubon.esb.controller.config.view.TxnConfigExcelVO;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.config.PriorityType;
import com.fubon.esb.domain.config.Txn;

/**
 * @author Qigers
 * @createdDate 2014-11-24
 */

@Repository
public class TxnConfigExcelDao extends CompositeDaoSupport<Txn> {
    public List<TxnConfigExcelVO> findTxnConfigDaoList(TxnView txnView) {
        StringBuilder sql = new StringBuilder();
        sql.append("select txn.id as txnId, txn.TXN_CODE as txnCode,txn.TXN_NAME as txnName");
        sql.append(",txnGroup.GROUP_CODE as txnGroupCode");
        sql.append(" , host.HOST_CODE as hostCode , service.SERVICE_CODE as serviceCode,service.VERSION as serviceVerstion ");
        sql.append(",txn.HOST_DRIVE_QUEUE as hostDriveQueue, txn.TRANS_TXN_CODE as transTxnCode,txn.TO_QUEUE as toQueue ");
        sql.append(",txn.TIMEOUT as timeOut ,txn.PRIORITY as priority ");
        sql.append(",connector.CONNECTOR_CODE as connectorCode ");
        sql.append(",adapter.ADAPTER_NAME as adapterName ");
        sql.append(",txn.TXN_STATUS as txnStatus ,txn.MEMO as memo ");
        sql.append(" from CFG_TXN txn ");
        sql.append(" left join CFG_TXN_GROUP txnGroup on txn.GROUP_ID=txnGroup.id");
        sql.append(" left join CFG_HOST host on txnGroup.host_Id=host.id");
        sql.append(" left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" left join CFG_CONNECTOR connector on txn.connector_Id=connector.id");
        sql.append(" left join CFG_ADAPTER adapter on txn.ADAPTER_ID=adapter.id");
        sql.append(" where not exists(select t.id from CFG_TXN t where t.MAIN_ID = txn.id) ");
        sql.append("  order by txn.id ");
        return jdbcAccess.find(sql.toString(), new RowMapper<TxnConfigExcelVO>() {
            public TxnConfigExcelVO mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnConfigExcelVO vo = new TxnConfigExcelVO();
                setTxnConfigExcelVO(vo, rs);
                return vo;
            }
        });
    }

    public TxnConfigExcelVO findTxnConfigDao(String id) {
        StringBuilder sql = new StringBuilder();
        sql.append("select txn.id as txnId, txn.TXN_CODE as txnCode,txn.TXN_NAME as txnName");
        sql.append(",txnGroup.GROUP_CODE as txnGroupCode");
        sql.append(" , host.HOST_CODE as hostCode , service.SERVICE_CODE as serviceCode,service.VERSION as serviceVerstion ");
        sql.append(",txn.APP_CODE as appCode,txn.APP_NAME as appName, txn.BG_GROUP as bgGroup");
        sql.append(",txn.HOST_DRIVE_QUEUE as hostDriveQueue, txn.TRANS_TXN_CODE as transTxnCode,txn.TO_QUEUE as toQueue ");
        sql.append(",txn.TIMEOUT as timeOut ,txn.PRIORITY as priority ");
        sql.append(",connector.CONNECTOR_CODE as connectorCode ");
        sql.append(",adapter.ADAPTER_NAME as adapterName ");
        sql.append(",txn.TXN_STATUS as txnStatus ,txn.EFFECT_TYPE as effctype,txn.EFFECT_TIME as effctime,txn.MEMO as memo ");
        sql.append(",txn.CREATED_USER as createdUser,txn.CREATED_TIME as createdTime");
        sql.append(" from CFG_TXN txn ");
        sql.append(" left join CFG_TXN_GROUP txnGroup on txn.GROUP_ID=txnGroup.id");
        sql.append(" left join CFG_HOST host on txnGroup.host_Id=host.id");
        sql.append(" left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" left join CFG_CONNECTOR connector on txn.connector_Id=connector.id");
        sql.append(" left join CFG_ADAPTER adapter on txn.ADAPTER_ID=adapter.id");
        sql.append(" where not exists(select t.id from CFG_TXN t where t.MAIN_ID = txn.id) and txn.id= '" + id + "'");
        TxnConfigExcelVO txnConfigExcelVO = (TxnConfigExcelVO) jdbcAccess.find(sql.toString(), new RowMapper<TxnConfigExcelVO>() {
            public TxnConfigExcelVO mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnConfigExcelVO vo = new TxnConfigExcelVO();
                setTxnConfigExcelVO(vo, rs);
                return vo;
            }
        }).get(0);
        if (txnConfigExcelVO == null) {
            txnConfigExcelVO = new TxnConfigExcelVO();
        }
        return txnConfigExcelVO;
    }

    private void setTxnConfigExcelVO(TxnConfigExcelVO vo, ResultSet rs) throws SQLException {
        vo.setTxnId(rs.getString("txnId"));
        vo.setTxnCode(rs.getString("txnCode"));
        vo.setTxnName(rs.getString("txnName"));
        vo.setTxnGroupCode(rs.getString("txnGroupCode"));
        vo.setHostCode(rs.getString("hostCode"));
        vo.setServiceCode(rs.getString("serviceCode"));
        vo.setServiceVerstion(rs.getString("serviceVerstion"));
        vo.setAppCode(rs.getString("appCode"));
        vo.setAppName(rs.getString("appName"));
        vo.setBgGroup(rs.getString("bgGroup"));
        vo.setHostDriveQueue(rs.getString("hostDriveQueue"));
        vo.setTransTxnCode(rs.getString("transTxnCode"));
        vo.setToQueue(rs.getString("toQueue"));
        vo.setTimeOut(rs.getInt("timeOut"));
        vo.setPriority(rs.getString("priority"));
        vo.setConnectorCode(rs.getString("connectorCode"));
        vo.setAdapterName(rs.getString("adapterName"));
        vo.setTxnStatus(rs.getString("txnStatus"));
        vo.setEffctype(rs.getString("effctype"));
        vo.setEffctime(rs.getString("effctime"));
        vo.setMemo(rs.getString("memo"));
        vo.setCreatedUser(rs.getString("createdUser"));
        vo.setCreatedTime(rs.getString("createdTime"));

    }

    public PriorityType stoEmum(String s) {
        for (PriorityType pt : PriorityType.values()) {
            if (pt.toString().equals(s)) {
                return pt;
            }
        }
        return null;
    }

    public ActiveStatus stoStatusEmum(String s) {
        for (ActiveStatus as : ActiveStatus.values()) {
            if (as.toString().equals(s)) {
                return as;
            }
        }
        return null;
    }
}
