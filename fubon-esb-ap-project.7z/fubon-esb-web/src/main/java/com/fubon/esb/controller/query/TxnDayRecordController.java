package com.fubon.esb.controller.query;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.query.view.TxnDayRecordsVO;
import com.fubon.esb.controller.query.view.TxnRecordDetailExcel;
import com.fubon.esb.controller.query.view.TxnRecordExcelVO;
import com.fubon.esb.domain.log.TxnRecord;
import com.fubon.esb.domain.log.TxnRecordMsg;
import com.fubon.esb.service.log.TxnDayRecordServive;


/**
 * @author Qigers
 * @createdDate 2014-11-11
 */
@Controller
@RequestMapping(value = "/dayRecord")
public class TxnDayRecordController extends BaseController
{

	@Inject
	private TxnDayRecordServive txnDayRecordServive;

	@RequirePermission(value = "030101")
	@RequestMapping(value = "/viewTxnDayRecordList", method = RequestMethod.GET)
	public String viewTxnDayRecordList(Model model, @RequestParam(required = false) String message, OrderBy orderBy, TxnDayRecordsVO vo) {
		Page page = new Page( 1 );
		page.setCurrentPage( 1 );
		model.addAttribute( "page", page );
		model.addAttribute( "txnDayRecordlist", null ); // 分頁查詢信息
		SimpleDateFormat sdf = new SimpleDateFormat( "yyyy/MM/dd" );
		String today = sdf.format( new Date() );
		vo.setStartDate( today );
		model.addAttribute( "vo", vo );
		model.addAttribute( "txnCodePicUrl", txnCodePicUrl( orderBy ) );
		model.addAttribute( "durationPicUrl", durationPicUrl( orderBy ) );
		model.addAttribute( "startTimePicUrl", startTimePicUrl( orderBy ) );
		model.addAttribute( "orderBy", orderBy );
		return "/query/viewTxnDayRecordList";
	}

	@RequirePermission(value = "030101")
	@RequestMapping(value = "/viewTxnDayRecordList", method = RequestMethod.POST)
	public String viewTxnDayRecordList(Model model, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") Integer currentPage,
	        TxnDayRecordsVO vo, @RequestParam(required = false) Boolean isSearch) {
		String message = vo.getMessage();
		Page page = new Page( currentPage );
		page.setPageSize( 50 );
		@SuppressWarnings("unchecked")
		List<TxnRecord> txnDayRecordlist = (List<TxnRecord>) txnDayRecordServive.findTxnDayRecordPageList( vo, orderBy, page, isSearch );
		
		if (vo.isCalDuration()) {
			if (! txnDayRecordlist.isEmpty()) {
				List<TxnRecord> txnRecords = new ArrayList<TxnRecord>();
				Map<String, String> trackingIdsWithDuration = txnDayRecordServive.findDurationByTrackingIds( txnDayRecordlist );
				
				for(TxnRecord txnRecord : txnDayRecordlist) {
					if (trackingIdsWithDuration.containsKey( txnRecord.getTrackingId() )) {
						txnRecord.setDuration( trackingIdsWithDuration.get( txnRecord.getTrackingId() ) );
					}
					
					txnRecords.add( txnRecord );
				}
				
				txnDayRecordlist.clear();
				txnDayRecordlist.addAll( txnRecords );
			}
		}
		
		model.addAttribute( "txnDayRecordlist", txnDayRecordlist ); // 分頁查詢信息
		model.addAttribute( "page", page );
		vo.setTempCurrentPage( currentPage );
		model.addAttribute( "vo", vo );
		model.addAttribute( "message", message );
		model.addAttribute( "txnCodePicUrl", txnCodePicUrl( orderBy ) );
		model.addAttribute( "durationPicUrl", durationPicUrl( orderBy ) );
		model.addAttribute( "startTimePicUrl", startTimePicUrl( orderBy ) );
		model.addAttribute( "orderBy", orderBy );
		return "/query/viewTxnDayRecordList";
	}

	@RequestMapping(value = "/viewTxnRecordDetailList", method = {RequestMethod.GET, RequestMethod.POST})
	public String viewTxnRecordDetailList(Model model, OrderBy orderby, String recordId,
	        @RequestParam(required = false, defaultValue = "1") Integer currentPage, TxnDayRecordsVO vo) {
		Page page = new Page( currentPage );
		String trackingId = vo.getTrackingId();
		TxnRecord txnRecord = txnDayRecordServive.findTxnRecordDetail( vo, page, recordId );
		if (vo.getSonOrderBy() == null) {
			vo.setSonOrderBy( new OrderBy( "", true ) );
		}

		List<TxnRecordMsg> txnRecordMsgDetailList = (List<TxnRecordMsg>) txnDayRecordServive.findTxnRecordMsgDetailPageList( vo, page, trackingId );
		model.addAttribute( "txnRecord", txnRecord );
		model.addAttribute( "txnRecordMsgDetailList", txnRecordMsgDetailList );
		model.addAttribute( "page", page );

		model.addAttribute( "vo", vo );

		model.addAttribute( "txnCodeDetailPicUrl", txnCodeDetailPicUrl( vo.getSonOrderBy() ) );
		model.addAttribute( "hisLayerImgUrl", hisLayerImgUrl( vo.getSonOrderBy() ) );
		model.addAttribute( "trackingId", trackingId );
		model.addAttribute( "recordId", recordId );
		return "/query/viewTxnRecordDetailList";
	}

	@RequestMapping(value = "/reportTxnRecordDetailExcel", method = RequestMethod.GET)
	public ModelAndView reportTxnRecordDetailExcel(ModelMap model, String trackingId, String recordId, HttpServletRequest request, HttpServletResponse response) {
		TxnRecord txnRecord = txnDayRecordServive.findTxnRecordDetail( recordId );
		List<TxnRecordMsg> txnRecordMsgDetailList = (List<TxnRecordMsg>) txnDayRecordServive.findTxnRecordMsgDetailList( trackingId );
		model.put( "txnRecordMsgDetailList", txnRecordMsgDetailList );
		model.put( "txnRecord", txnRecord );
		TxnRecordDetailExcel txnRecordDetailExcel = new TxnRecordDetailExcel();
		return new ModelAndView( txnRecordDetailExcel, model );
	}

	@RequestMapping(value = "/viewTxnMessageContent", method = RequestMethod.GET)
	public String viewTxnMessageContent(Model model, @RequestParam(required = false) String trackingId, String recordId, String messageId, TxnDayRecordsVO vo)
	        throws DocumentException, IOException {
		TxnRecordMsg txnRecordMsg = txnDayRecordServive.findTxnRecordMsg( messageId );

		String tempStr = txnRecordMsg.getMessage();
		tempStr = tempStr.replaceAll("&", "&amp;");
		if (tempStr.contains( "<?xml" )) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			Document document = DocumentHelper.parseText( tempStr );
			String original_encoding = document.getXMLEncoding();
			XMLWriter writer;
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setTrimText(false);
			writer = new XMLWriter( baos, format );
			writer.write( document );
			writer.close();
			txnRecordMsg.setMessage( baos.toString( "UTF-8" ).replaceAll("&amp;", "&").replaceFirst("UTF-8", original_encoding) );
			baos.close();
		}

		model.addAttribute( "txnRecordMsg", txnRecordMsg );
		model.addAttribute( "vo", vo );
		return "/query/viewTxnMessageContent";
	}

	/**
	 * Export Excel
	 * 
	 * @param model
	 * @param projectId
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequirePermission(value = "030102")
	@RequestMapping(value = "/reportTxnRecordExcel")
	public ModelAndView writeToRecordExcel(ModelMap model, TxnDayRecordsVO vo, HttpServletRequest request, HttpServletResponse response) {
		List<TxnRecord> txnRecordExcelList = (List<TxnRecord>) txnDayRecordServive.findRecords( vo );
		
		if (vo.isCalDuration()) {
			if (! txnRecordExcelList.isEmpty()) {
				List<TxnRecord> txnRecords = new ArrayList<TxnRecord>();
				Map<String, String> trackingIdsWithDuration = txnDayRecordServive.findDurationByTrackingIds( txnRecordExcelList );
				
				for(TxnRecord txnRecord : txnRecordExcelList) {
					if (trackingIdsWithDuration.containsKey( txnRecord.getTrackingId() )) {
						txnRecord.setDuration( trackingIdsWithDuration.get( txnRecord.getTrackingId() ) );
					}
					
					txnRecords.add( txnRecord );
				}
				
				txnRecordExcelList.clear();
				txnRecordExcelList.addAll( txnRecords );
			}
		}
		
		model.put( "txnRecordExcelList", txnRecordExcelList );
		TxnRecordExcelVO txnRecordExcelVO = new TxnRecordExcelVO();
		return new ModelAndView( txnRecordExcelVO, model );
	}

	@ResponseBody
	@RequestMapping({ "/search/txnCodes" })
	public Object searchTxnCodes(@RequestParam String key) {
		return txnDayRecordServive.searchTxnCodes( key );
	}

	@ResponseBody
	@RequestMapping({ "/search/channelCodes" })
	public Object searchChannelCodes(@RequestParam String key) {
		return txnDayRecordServive.searchChannelCodes( key );
	}

	@ResponseBody
	@RequestMapping({ "/search/hostCodes" })
	public Object searchHostCodes(@RequestParam String key) {
		return txnDayRecordServive.searchHostCodes( key );
	}

	@ResponseBody
	@RequestMapping({ "/search/groupCodes" })
	public Object searchGroupCodes(@RequestParam String key) {
		return txnDayRecordServive.searchGroupCodes( key );
	}

	@ResponseBody
	@RequestMapping({ "/search/uuids" })
	public Object searchUUIDs(@RequestParam String key) {
		return txnDayRecordServive.searchUUIDs( key );
	}

	@ResponseBody
	@RequestMapping({ "/search/serviceCodes" })
	public Object searchServiceCodes(@RequestParam String key) {
		return txnDayRecordServive.searchServiceCodes( key );
	}

	public String txnCodePicUrl(OrderBy orderBy) {
		String url = "normal.gif";
		if ((StringUtils.isNotBlank( orderBy.getField() )) && ("txnCode".equals( orderBy.getField() ))) {
			if (!orderBy.isAsc()) {
				url = "down.gif";
			} else {
				url = "up.gif";
			}
		} else {
			url = "normal.gif";
		}
		return url;
	}

	public String durationPicUrl(OrderBy orderBy) {
		String url = "normal.gif";
		if ((StringUtils.isNotBlank( orderBy.getField() )) && ("duration".equals( orderBy.getField() ))) {
			if (!orderBy.isAsc()) {
				url = "down.gif";
			} else {
				url = "up.gif";
			}
		} else {
			url = "normal.gif";
		}
		return url;
	}

	public String txnCodeDetailPicUrl(OrderBy orderBy) {
		String url = "normal.gif";
		// if (orderBy == null) {
		// return url;
		// }
		if ((StringUtils.isNotBlank( orderBy.getField() )) && ("tm.txnCode".equals( orderBy.getField() ))) {
			if (!orderBy.isAsc()) {
				url = "down.gif";
			} else {
				url = "up.gif";
			}
		} else {
			url = "normal.gif";
		}
		return url;
	}

	public String startTimePicUrl(OrderBy orderBy) {
		String url = "normal.gif";
		if ((StringUtils.isNotBlank( orderBy.getField() )) && ("startTime".equals( orderBy.getField() ))) {
			if (!orderBy.isAsc()) {
				url = "down.gif";
			} else {
				url = "up.gif";
			}
		} else {
			url = "normal.gif";
		}
		return url;
	}

	public String hisLayerImgUrl(OrderBy orderBy) {
		String url = "normal.gif";
		if ((StringUtils.isNotBlank( orderBy.getField() )) && ("tm.layer".equals( orderBy.getField() ))) {
			if (orderBy.isAsc()) {
				url = "up.gif";
			} else {
				url = "down.gif";
			}
		} else {
			url = "normal.gif";
		}
		return url;
	}
}
