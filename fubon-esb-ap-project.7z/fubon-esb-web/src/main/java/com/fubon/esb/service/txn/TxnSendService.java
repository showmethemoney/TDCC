package com.fubon.esb.service.txn;

import javax.inject.Inject;

import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.comwave.core.http.HTTPClient;
import com.comwave.core.http.HTTPMethod;
import com.comwave.core.http.HTTPRequest;
import com.comwave.core.http.HTTPResponse;
import com.comwave.core.util.TimeLength;


/**
 * @author james
 * @createdDate 2014-11-27
 */
@Service
public class TxnSendService
{

	private final Logger logger = LoggerFactory.getLogger( TxnSendService.class );
	private static final String SEPERATOR_SERVER = ",";

	
	@Inject
	private Environment env;
	@Inject
	private HTTPClient httpClient;

	public String sendTxn(String txn, int times) {
		String url = env.getRequiredProperty( "bw.http.url.txn.send" );
		HTTPRequest request = new HTTPRequest( url, HTTPMethod.POST );
		request.text( txn, ContentType.TEXT_XML );
		String seconds = env.getRequiredProperty( "bw.http.timeout.seconds" );
		try {
			httpClient.setTimeOut( TimeLength.seconds( Integer.valueOf( seconds ) ) );
			HTTPResponse execute = httpClient.execute( request );
			return execute.responseText();
		} catch (Exception e) {
			if (times > 0) {
				return "";
			} else {
				throw e;
			}
		}
	}

	public boolean sendChangeEvent(String id) {
		httpClient.setTimeOut( TimeLength.seconds( 10 ) );
		String url = env.getRequiredProperty( "bw.http.url.definition.changeevent" );
		boolean send_success=true;
		
		String[] servers = url.split( SEPERATOR_SERVER );
		for (String server : servers) {
			HTTPRequest request = new HTTPRequest( server, HTTPMethod.POST );
			String changeEvent = composeChangeEvent( id );
			request.text( changeEvent, ContentType.TEXT_XML );

			try {
				httpClient.execute( request );
	            logger.info("http refresh msg receieved by "+server+". Event Message: "+changeEvent);
			} catch (Throwable cause) {
				send_success=false;
				logger.error( "http execute error ! " + cause.getMessage(), cause );
			}
		}
		
		return send_success;
	}

	private String composeChangeEvent(String id) {
		StringBuilder sb = new StringBuilder();
		sb.append( "<ChangeEvent xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition\">" );
		sb.append( "<EventType>APPROVE</EventType>" );
		sb.append( "<TxnDefID>" ).append( id ).append( "</TxnDefID>" );
		sb.append( "</ChangeEvent>" );
		return sb.toString();
	}

}
