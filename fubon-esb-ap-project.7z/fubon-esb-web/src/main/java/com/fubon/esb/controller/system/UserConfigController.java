package com.fubon.esb.controller.system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.Page;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.system.view.UserConfigExcelVO;
import com.fubon.esb.controller.system.view.UserConfigVO;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.system.UserConfigService;

/**
 * @author Qigers
 * @createdDate 2015-01-12
 */
@Controller
@RequestMapping("/system")
public class UserConfigController extends BaseController {

    @Inject
    private UserConfigService userConfigService;

    @Inject
    private LoginContext loginContext;

    @ResponseBody
    @RequestMapping({"/search/userIds"})
    public Object searchUserIds(@RequestParam String key) {
        return userConfigService.searchUserIds(key);
    }

    @RequestMapping(value = "/viewUserConfigList", method = RequestMethod.GET)
    public String viewUserList(Model model) {
        UserConfigVO vo = new UserConfigVO();
        Page page = new Page(1);
        // model.addAttribute("userConfigList", null);
        String userId = vo.getUserId();
        String username = vo.getUsername();
        String subject = vo.getSubject();
        model.addAttribute("userConfigList", userConfigService.findAllUsers(userId, username, subject, page));
        model.addAttribute("page", page);
        model.addAttribute("vo", vo);
        return "/system/viewUserConfigList";
    }

    @RequestMapping(value = "/viewUserConfigList", method = RequestMethod.POST)
    @RequirePermission(value = "070301")
    public String viewUserConfigList(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, UserConfigVO vo) {
        String userId = vo.getUserId();
        String username = vo.getUsername();
        String subject = vo.getSubject();
        Page page = new Page(currentPage);
        model.addAttribute("userConfigList", userConfigService.findAllUsers(userId.trim(), username, subject, page));
        model.addAttribute("vo", vo);
        model.addAttribute("page", page);
        return "/system/viewUserConfigList";
    }

    @RequirePermission(value = {"070302", "070303"})
    @RequestMapping(value = "/addOrUpdate", method = RequestMethod.GET)
    public String addOrUpdate(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        UserConfig userConfig;
        boolean editFlag = false;

        if (StringUtils.isNotBlank(id)) {
            isAdd = false;
            if (userConfigService.validMainIdDuplicate(id)) {
                userConfig = userConfigService.getById(id);
                editFlag = flagMainId(userConfig, id);
            } else {
                userConfig = userConfigService.getByMainId(id);
            }
        } else {
            userConfig = new UserConfig();
            userConfig.setMainId("0");
            editFlag = true;
        }
        model.addAttribute("editFlag", editFlag);
        model.addAttribute("userConfig", userConfig);
        model.addAttribute("isAdd", isAdd);
        return "/system/viewUserConfig";
    }

    private boolean flagMainId(UserConfig userConfig, String id) {
        if ("0".equals(userConfig.getMainId())) {
            return false;
        } else {
            userConfig.setMainId(id);
            userConfig.setId(null);
            return true;
        }
    }

    @RequirePermission(value = {"070302", "0070303"})
    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResultView saveOrUpdate(@Valid UserConfig userConfig, String id, String mainId) {
        String currentUser = loginContext.loginedUserId();
        userConfig.setUserId(userConfig.getUserId().trim());
        userConfigService.saveOrUpdate(userConfig, currentUser, id, mainId);
        // configChangeService.sendChangeEvent(ConfigType.SYS_, .getId());
        return ResultView.success("system/viewUserConfigList");
    }

    @RequestMapping("/removeUserConfig")
    @ResponseBody
    @RequirePermission(value = "070304")
    public Map<String, Object> removeUserConfig(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        userConfigService.removeUserConfig(id);
        result.put("flag", true);
        // configChangeService.sendChangeEvent(ConfigType.SYS_, id);
        return result;
    }

    /**
     * Export Excel
     * 
     * @param model
     * @param request
     * @return
     */
    @RequirePermission(value = "070305")
    @RequestMapping(value = "/reportUserConfigExcel")
    public ModelAndView writeToExcel(ModelMap model, UserConfigVO vo, HttpServletRequest request, HttpServletResponse response) {
        String userId = vo.getUserId();
        String username = vo.getUsername();
        String subject = vo.getSubject();
        List<UserConfig> userConfigExcelList = (List<UserConfig>) userConfigService.findUserConfigs(userId.trim(), username, subject);
        model.put("userConfigExcelList", userConfigExcelList);
        UserConfigExcelVO userConfigExcelVO = new UserConfigExcelVO();
        return new ModelAndView(userConfigExcelVO, model);
    }

    @RequestMapping("/validateId")
    @ResponseBody
    public Map<String, Object> validateId(String id, String userId, String mainId) {
        String userId1 = userId.trim();
        Map<String, Object> result = new HashMap<String, Object>();
        Boolean flag = userConfigService.validUserIdDuplicate(userId1);
        if (flag && StringUtils.isBlank(id) && !"0".equals(mainId)) {
            flag = getFlag(userId1, mainId);
        }
        if (flag && StringUtils.isNotBlank(id)) {
            flag = getFlag(userId1, id);
        }
        result.put("flag", flag);
        return result;
    }

    private Boolean getFlag(String userId, String main) {
        Boolean flag = false;
        if (userId.equals(userConfigService.getById(main).getUserId())) {
            flag = false;
        }
        return flag;
    }
}
