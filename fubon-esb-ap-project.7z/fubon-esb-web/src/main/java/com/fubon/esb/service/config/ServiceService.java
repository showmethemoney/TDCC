package com.fubon.esb.service.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.ServiceView;
import com.fubon.esb.dao.config.ServiceDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-3
 */
@Service
public class ServiceService {

    @Inject
    private ServiceDao serviceDao;
    @Inject
    private TxnDao txnDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private AccessChannelCompareService accessChannelCompareService;

    public String nextLine = "\r";

    public List<com.fubon.esb.domain.config.Service> findLatestServices(ServiceView vs, Page page) {
        return serviceDao.findLatestServices(vs, page);
    }

    @Transactional
    public String saveOrUpdateService(com.fubon.esb.domain.config.Service service, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        String serviceId;
        if (StringUtils.isNotBlank(service.getId())) {
            com.fubon.esb.domain.config.Service oldService = getService(service.getId());
            String oldCode = oldService.getCode();
            String oldName = oldService.getName();
            serviceId = updateService(service, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改Service。Service代號：" + oldCode + "，Service名稱：" + oldName, LogType.SYS_CFG_SERVICE);
        } else {
            service.setId(null);
            serviceId = saveService(service, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增Service。Service代號：" + service.getCode() + "，Service名稱：" + service.getName(), LogType.SYS_CFG_SERVICE);
        }
        return serviceId;
    }

    public String saveService(com.fubon.esb.domain.config.Service service, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        if (isCodeDuplicated(service.getCode().trim())) {
            throw new DuplicatedException("已存在相同代號！");
        }
        if (EffectType.B.equals(service.getEffectType())) {
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            service.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            service.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(service.getEffectType())) {
            service.setEffectTime(null);
            service.setMainId(null);
        }
        // 建立者
        service.setCreatedUser(loginContext.loginedUserId());
        service.setCreatedTime(new Date());
        serviceDao.save(service);
        compareAdd(true, service);
        return service.getId();
    }

    public String updateService(com.fubon.esb.domain.config.Service service, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        setProperty(service);
        if (isCodeDuplicated(service)) {
            throw new DuplicatedException("已存在相同代號！");
        }
        if (EffectType.B.equals(service.getEffectType())) {
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            service.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            if (service.getMainId() == null) { // 正本生效-->復制修改後的對象作為副本，正本保持不變
                com.fubon.esb.domain.config.Service copyService = new com.fubon.esb.domain.config.Service(); // 新建副本
                BeanUtils.copyProperties(service, copyService, "id");
                copyService.setMainId(service.getId());
                compareServiceUpdate(getService(service.getId()), copyService);
                serviceDao.save(copyService);
                return copyService.getId();
            } else { // 副本預約生效-->直接修改
                compareServiceUpdate("0".equals(service.getMainId()) ? getService(service.getId()) : getService(service.getMainId()), service);
                serviceDao.update(service);
                return service.getId();
            }
        } else if (EffectType.I.equals(service.getEffectType())) {
            service.setEffectTime(null);
            if (service.getMainId() == null || "0".equals(service.getMainId())) { // 正本立即生效-->直接修改
                service.setMainId(null);
                compareServiceUpdate(getService(service.getId()), service);
                serviceDao.update(service);
                return service.getId();
            } else { // 副本有指向的正本
                com.fubon.esb.domain.config.Service mainService = getService(service.getMainId());
                com.fubon.esb.domain.config.Service originService = new com.fubon.esb.domain.config.Service();
                BeanUtils.copyProperties(mainService, originService);
                BeanUtils.copyProperties(service, mainService, "id");
                mainService.setMainId(null);
                compareServiceUpdate(originService, mainService);
                serviceDao.update(mainService);
                serviceDao.delete(serviceDao.get(service.getId())); // 刪除副本
                return mainService.getId();
            }
        } else
            return null;
    }

    public void setProperty(com.fubon.esb.domain.config.Service service) {
        com.fubon.esb.domain.config.Service persiService = getService(service.getId());
        service.setCreatedTime(persiService.getCreatedTime());
        service.setCreatedUser(persiService.getCreatedUser());
        service.setMainId(persiService.getMainId());
        service.setUpdatedUser(loginContext.loginedUserId());
        service.setUpdatedTime(new Date());
    }

    public com.fubon.esb.domain.config.Service getService(String id) {
        return serviceDao.get(id);
    }

    public String getTxnCodes(String serviceId) {
        List<Txn> txns = txnDao.findTxnsByServceId(serviceId);
        StringBuilder txnCodeBuffer = new StringBuilder();
        String txnCodes = "";
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                txnCodeBuffer.append(txn.getCode() + ",");
            }
            txnCodes = txnCodeBuffer.toString().substring(0, txnCodeBuffer.toString().length() - 1);
        }
        return txnCodes;
    }

    public List<Txn> findTxns(String id) {
        String mainId = getService(id).getMainId();
        return txnDao.findTxnsByServceId((mainId != null && !"0".equals(mainId)) ? mainId : id);
    }

    public Date stringToDate(String effectDate, String effectHour, String effectMinute) {
        Date effectTime = null;
        try {
            effectTime = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(effectDate + " " + effectHour + ":" + effectMinute);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return effectTime;
    }

    public boolean isCodeDuplicated(String code) {
        return serviceDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(com.fubon.esb.domain.config.Service service) {
        com.fubon.esb.domain.config.Service updateService = null;
        updateService = getService(service.getId());
        String oldCode = updateService.getCode();
        return serviceDao.isDuplicatedByCode(service.getCode().trim()) && !oldCode.equals(service.getCode());
    }

    public List<com.fubon.esb.domain.config.Service> findMainService(String code, Page page) {
        return serviceDao.findMainService(code, page);
    }

    public void compareServiceUpdate(com.fubon.esb.domain.config.Service originService, com.fubon.esb.domain.config.Service newService) {
        StringBuilder messageOrigin = new StringBuilder();
        StringBuilder messageNew = new StringBuilder();
        StringBuilder message = new StringBuilder();
        message.append("Service設定").append("(Service代號：").append(newService.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append(nextLine);
        if ((originService == null) || "0".equals(originService.getMainId())) { // 只有副本
            compareAdd(false, newService);
            return;
        }
        if (!accessChannelCompareService.compare(newService.getCode(), originService.getCode())) {
            messageOrigin.append("Service代號：").append(originService.getCode()).append(nextLine);
            messageNew.append("Service代號：").append(newService.getCode()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newService.getName(), originService.getName())) {
            messageOrigin.append("Service名稱：").append(originService.getName()).append(nextLine);
            messageNew.append("Service名稱：").append(newService.getName()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newService.getVersion(), originService.getVersion())) {
            messageOrigin.append("Service版本號：").append(originService.getVersion()).append(nextLine);
            messageNew.append("Service版本號：").append(newService.getVersion()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newService.getStatus().toString(), originService.getStatus().toString())) {
            messageOrigin.append("使用狀態：").append(accessChannelCompareService.getDisplayName(originService.getStatus())).append(nextLine);
            messageNew.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newService.getStatus())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newService.getEffectType().toString(), originService.getEffectType().toString())) {
            messageOrigin.append("生效類型：").append(accessChannelCompareService.getDisplayName(originService.getEffectType())).append(nextLine);
            messageNew.append("生效類型：").append(accessChannelCompareService.getDisplayName(newService.getEffectType())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newService.getEffectTime(), originService.getEffectTime())) {
            if (accessChannelCompareService.isEffectTypeBooked(originService.getEffectType())) {
                messageOrigin.append("生效時間：").append(DateFormatUtils.format(originService.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
            if (accessChannelCompareService.isEffectTypeBooked(newService.getEffectType())) {
                messageNew.append("生效時間：").append(DateFormatUtils.format(newService.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
        }
        if (messageNew.length() == 0) {
            return;
        }
        message.append("現形生效內容：").append(nextLine).append(messageOrigin).append(nextLine).append("變更後內容：").append(nextLine).append(messageNew);
        configChangeService.sendMailRequest("Service設定變更", message.toString());
    }

    public void compareAdd(boolean isAdd, com.fubon.esb.domain.config.Service newService) {
        StringBuilder message = new StringBuilder();
        if (!isAdd) {
            message.append("Service設定").append("(Service代號：").append(newService.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append(nextLine).append("現形生效內容：").append(nextLine)
                    .append(nextLine).append("變更後內容：").append(nextLine);
        } else
            message.append("Service設定新增，新增者：").append(loginContext.loginedUserId()).append(nextLine).append("新增內容：").append(nextLine);
        if (StringUtils.isNotBlank(newService.getCode())) {
            message.append("Service代號：").append(newService.getCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newService.getName())) {
            message.append("Service名稱：").append(newService.getName()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newService.getVersion())) {
            message.append("Service版本號：").append(newService.getVersion()).append(nextLine);
        }
        if (newService.getStatus() != null) {
            message.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newService.getStatus())).append(nextLine);
        }
        if (newService.getEffectType() != null) {
            message.append("生效類型：").append(accessChannelCompareService.getDisplayName(newService.getEffectType())).append(nextLine);
        }
        if (newService.getEffectTime() != null && accessChannelCompareService.isEffectTypeBooked(newService.getEffectType())) {
            message.append("生效時間： ").append(DateFormatUtils.format(newService.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
        }
        configChangeService.sendMailRequest(isAdd ? "Service設定新增" : "Service設定變更", message.toString());
    }

    @Transactional
    public void deleteService(String id) {
        serviceDao.updateStatus(id);
    }

    // 是否有关联Host
    public boolean isRelatedService(String id, StringBuilder message) {
        List<Txn> txns = serviceDao.isRelatedService(id);
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                message.append(txn.getCode()).append(",");
            }
        }
        return !txns.isEmpty();
    }
}
