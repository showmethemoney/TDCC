package com.fubon.esb.service.config;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.domain.config.Connector;

/**
 * @author Leckie Zhang
 * @createdDate 2014-12-31
 */
@Service
public class ConnectorCompareService {

    @Inject
    private AccessChannelCompareService accessChannelCompareService;

    @Inject
    private LoginContext loginContext;

    @Inject
    private ConfigChangeService configChangeService;
    
    /**
     * connector新增或修改發送郵件
     */
    public void sendMail(Connector newConnector, Connector originConnector) {
        channelCompare(newConnector, originConnector);
    }

    /**
     * Channel修改
     */
    private void channelCompare(Connector newConnector, Connector originConnector) {
        if (originConnector == null) {
            addChannelMessage(newConnector);
            return;
        }

        StringBuilder newSb = new StringBuilder();
        StringBuilder oldSb = new StringBuilder();

        if (!accessChannelCompareService.compare(newConnector.getCode(), originConnector.getCode())) {
            newSb.append("Connector代號：").append("").append(newConnector.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Connector代號：").append("").append(originConnector.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (!accessChannelCompareService.compare(newConnector.getName(), originConnector.getName())) {
            newSb.append("Connector名稱：").append("").append(newConnector.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
            oldSb.append("Connector名稱：").append("").append(originConnector.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        
        if (newSb.length() == 0) {
            return;
        }

        StringBuilder result = new StringBuilder();
        result.append("Connector設定(Connector 代號：").append(newConnector.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append("").append(AccessChannelCompareService.LINEBREACKCODE).append("現形生效內容： ")
                .append(AccessChannelCompareService.LINEBREACKCODE).append(oldSb).append(AccessChannelCompareService.LINEBREACKCODE).append(AccessChannelCompareService.LINEBREACKCODE).append("變更後內容：")
                .append(AccessChannelCompareService.LINEBREACKCODE).append(newSb);
        configChangeService.sendMailRequest("Connector設定變更", result.toString());
    }

    private void addChannelMessage(Connector connector) {
        StringBuilder result = new StringBuilder();
        result.append("Connector設定新增，新增者：").append(loginContext.loginedUserId()).append("").append(AccessChannelCompareService.LINEBREACKCODE).append("新增內容： ").append(AccessChannelCompareService.LINEBREACKCODE);

        if (StringUtils.isNotBlank(connector.getCode())) {
            result.append("Connector代號：").append(connector.getCode()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(connector.getName())) {
            result.append("Connector名稱：").append(connector.getName()).append("").append(AccessChannelCompareService.LINEBREACKCODE);
        }

        configChangeService.sendMailRequest("Connector設定新增", result.toString());
    }
}
