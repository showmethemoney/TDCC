package com.fubon.esb.controller.txn;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnSendService;

/**
 * @author Qigers
 * @createdDate 2015-03-20
 */
@Controller
@RequestMapping({"/txn/checkHeader"})
public class TxnCheckHeaderContorller extends BaseController {
    @Inject
    protected TxnSendService txnSendService;

    @Inject
    private TxnDirectionService txnDirectionService;

    @Inject
    private TxnFieldDefinitionService txnFieldService;

    private static final String INCLUDE_BASE_URL = "txn/include/check";

    @RequestMapping({"/list"})
    @RequirePermission(value = "010301")
    public String viewCheckTxnHeaderList(Model model) {
        return "txn/viewCheckTxnHeaderList";
    }

    @RequestMapping({"/search"})
    public String searchTxnHeaderList(Model model, HttpServletRequest request) throws Exception {
        String name = request.getParameter("name");
        Integer curPage = 1;
        try {
            curPage = Integer.parseInt(request.getParameter("curPage"));
        } catch (Exception e) {
            curPage = 1;
        }
        // Assert.notNull(curPage, "request parameter curPage not present !");
        Page page = new Page(curPage);
        if (page.getTotalPage() != 0 && curPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
        }
        List<TxnDirection> txnDirecs = txnDirectionService.searchWaitToCheckTxnDirecs(name, page);
        model.addAttribute("page", page);
        model.addAttribute("txnDirecs", txnDirecs);
        return INCLUDE_BASE_URL + "/txnHeaders";
    }

    @RequestMapping({"/txnContent/{direcId}"})
    @RequirePermission(value = "010302")
    public String viewTxnContent(Model model, @PathVariable("direcId") String direcId, @RequestParam(defaultValue = "true") Boolean isCheck) throws Exception {
        TxnDirection headDirection = txnDirectionService.findHeadDirByID(direcId);
        TxnVO txnVO = new TxnVO();
        if (headDirection != null) {
            txnVO.setHeadFields(txnFieldService.findMainsByDirId(headDirection.getId()));
        }
        txnVO.setHeadDirection(headDirection);
        model.addAttribute("headDirecs", new ArrayList<TxnDirection>());
        model.addAttribute("curUser", loginedUser() == null ? new User() : loginedUser());
        model.addAttribute("isCheck", isCheck);
        model.addAttribute("txnHeader", txnVO.getHeadDirection() == null ? new TxnDirection() : txnVO.getHeadDirection());
        model.addAttribute("headFields", txnVO.getHeadFields() == null ? new ArrayList<>() : txnVO.getHeadFields());
        return "txn/viewCheckTxnHeader";
    }

    // @RequestMapping({"/childContent"})
    // public String viewTxnChildContent(Model model, @RequestParam String pFieldId) {
    // txnEditController.getChildrenFields(model, null, pFieldId, null);
    // model.addAttribute("parentField", txnFieldService.getById(pFieldId));
    // return INCLUDE_BASE_URL + "/txnChildContent";
    // }
    //
    @RequestMapping({"/commit/{direcId}"})
    public String commitCheck(Model model, @PathVariable("direcId") String direcId) {
       // txnDirectionService.approveTxnHeader(direcId, loginedUserId());
        String mainId = txnDirectionService.approveTxnHeader(direcId, loginedUserId());
        List<String> definitionIds = txnDirectionService.searchDefinitionIdByHeadRefId(mainId);
        for (String defid : definitionIds) {
      	  try {
                txnSendService.sendChangeEvent(defid);
            } catch (Exception e) {
                e.printStackTrace();
            }
      }
        return "redirect:/history/goHistory";
    }

    @RequestMapping({"/back/{defId}"})
    public String backCheck(Model model, @PathVariable("defId") String defId) {
        TxnDirection definition = txnDirectionService.getById(defId);
        if (definition != null) {
            if (TxnStatus.D.equals(definition.getTxnHeaderStatus())) {
                definition.setTxnHeaderStatus(TxnStatus.M);
            } else if (TxnStatus.S.equals(definition.getTxnHeaderStatus())) {
                definition.setTxnHeaderStatus(TxnStatus.E);
            }
            definition.setUpdatedTime(new Date());
            definition.setUpdatedUser(loginedUserId());
            txnDirectionService.saveOrUpdate(definition);
        }
        return "redirect:/history/goHistory";
    }

    @ResponseBody
    @RequestMapping({"/mutipleCheck"})
    public Object mutipleReCheck(Model model, @RequestParam("defIds[]") String[] defIds) {
        //txnDirectionService.approveTxnHeaders(defIds, loginedUserId());
        List<String> mainDefIds = txnDirectionService.approveTxnHeaders(defIds, loginedUserId());
        try {
            for (String mainDefId : mainDefIds) {
                List<String> definitionIds = txnDirectionService.searchDefinitionIdByHeadRefId(mainDefId);
                for (String defid : definitionIds) {
                    txnSendService.sendChangeEvent(defid);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @ResponseBody
    @RequestMapping({"/search/direcNames"})
    public Object searchTxnCheckNames(@RequestParam String key) {
        return txnDirectionService.searchWaitApproveNames(key);
    }

    
    @RequestMapping({"/refresh/{direcId}"})
    @ResponseBody
    public Object refreshTxnHeader(Model model, @PathVariable("direcId") String direcId) {
       // txnDirectionService.approveTxnHeader(direcId, loginedUserId());
        String mainId = direcId;
        boolean send_status=true;
        
        List<String> definitionIds = txnDirectionService.searchDefinitionIdByHeadRefId(mainId);
        for(int i=0;i< definitionIds.size(); i++){
        	String defid=definitionIds.get(i).toString();
            try {
                boolean tmpStatus=txnSendService.sendChangeEvent(defid);
                if(tmpStatus!=true)
                	send_status=false;
            } catch (Exception e) {
            	send_status=false;
                e.printStackTrace();
            }
        }
        
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("flag", send_status);
        return result;
    }    
    
    
}
