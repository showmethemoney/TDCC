package com.fubon.esb.controller.config.view;

import com.fubon.esb.domain.config.ConfigActiveStatus;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-6
 */
public class TxnGroupView {
    private String txnGroupCode;
    private String name;
    private String hostCode;
    private String txnCode;
    private ConfigActiveStatus status;

    public String getTxnGroupCode() {
        return txnGroupCode;
    }

    public void setTxnGroupCode(String txnGroupCode) {
        this.txnGroupCode = txnGroupCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHostCode() {
        return hostCode;
    }

    public void setHostCode(String hostCode) {
        this.hostCode = hostCode;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
