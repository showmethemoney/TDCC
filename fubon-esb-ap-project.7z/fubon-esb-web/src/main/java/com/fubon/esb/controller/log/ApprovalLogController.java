package com.fubon.esb.controller.log;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.log.view.ApprovalLogSearchVO;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.service.log.ApprovalLogService;

/**
 * @author Blue
 * @createdDate 2014-11-10
 */
@Controller
@RequestMapping("approvalLog")
public class ApprovalLogController extends BaseController {

    @Inject
    private ApprovalLogService approvalLogService;

    @RequestMapping("viewApprovalLog")
    @RequirePermission(value = "060301")
    public String approvalLog() {
        return "/log/viewApprovalLog";
    }

    /**
     * 查詢ApprovalLogList集合
     * */
    @RequestMapping("viewApprovalLogList")
    public String checkApprovalLog(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, ApprovalLogSearchVO vo, Boolean isSearch, Boolean isAddLog) {
        Page page = new Page(currentPage);
        if (isSearch != null && isSearch) {
            model.addAttribute("approvalLogs", approvalLogService.findAllApprovalLogList(vo, page, isAddLog));
            if (currentPage > page.getTotalPage() && page.getTotalPage() != 0) {
                page.setCurrentPage(page.getTotalPage());
                model.addAttribute("approvalLogs", approvalLogService.findAllApprovalLogList(vo, page, isAddLog));
            }
            if (vo.getModifyFlag() == null) {
                vo.setModifyFlag(0);
            }
            model.addAttribute("vo", vo);
            model.addAttribute("isSearch", isSearch);
            model.addAttribute("page", page);
        }
        return "/log/viewApprovalLog";
    }

    /**
     * 查詢ApprovalLog明細
     * */
    @RequestMapping("viewApprovalLogDetail")
    public String approvalLogDetail(Model model, String id) {
        ApprovalLog approvalLogDetail = approvalLogService.getApprovalLogDetail(id);
        model.addAttribute("approvalLog", approvalLogDetail);
        return "/log/viewApprovalLogDetail";
    }
}
