package com.fubon.esb.service.config;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.database.OrderBy;
import com.fubon.esb.controller.config.view.TxnConfigExcelVO;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.dao.config.TxnConfigExcelDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnGroupDao;
import com.fubon.esb.dao.config.TxnRelatedDao;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnRelated;

/**
 * 
 * @author Qigers
 * @createdDate 2014-11-25
 */

@Service
public class TxnConfigExcelService {

    @Inject
    private HostDao hostDao;

    @Inject
    private TxnGroupDao txnGroupDao;

    @Inject
    private TxnDao txnDao;

    @Inject
    private TxnRelatedDao txnRelatedDao;

    @Inject
    private TxnConfigExcelDao txnConfigExcelDao;

    public List<Txn> findTxns(TxnView txnView, OrderBy orderBy) {
        return txnDao.findTxnConfigDaoList(txnView, orderBy);
    }

    public List<TxnConfigExcelVO> findTxnConfigExcelList(TxnView txnView) {
        return txnConfigExcelDao.findTxnConfigDaoList(txnView);
    }

    public TxnConfigExcelVO findTxnConfigExcel(String id) {
        return txnConfigExcelDao.findTxnConfigDao(id);
    }

    public Host getHostCodeByTxn(Txn txn) {
        Host host = null;
        String groupId = txn.getGroupId();
        if (StringUtils.isNotBlank(groupId)) {
            String hostId = txnGroupDao.get(groupId).getHostId();
            if (hostId != null) {
                host = hostDao.getById(hostId);
            }
        }
        return host;
    }

    public List<String> getRelatedTxnCodes(String id) {
        List<String> relatedTxnCodes = new ArrayList<String>();
        List<TxnRelated> txnRelateds = txnRelatedDao.findByTxnId(id);
        StringBuilder txnRelatedIdsBuilder = new StringBuilder();
        String txnRelatedIds = "";
        StringBuilder txnRelatedCodesBuilder = new StringBuilder();
        String txnRelatedCodes = "";
        if (!txnRelateds.isEmpty()) {
            for (TxnRelated txnRelated : txnRelateds) {
                txnRelatedIdsBuilder.append(txnRelated.getRelatedTxnId() + ",");
                Txn txn = txnDao.get(txnRelated.getRelatedTxnId());
                if (txn != null) {
                    txnRelatedCodesBuilder.append(txn.getCode() + ",");
                }
            }
            txnRelatedIds = !txnRelatedIdsBuilder.toString().isEmpty() ? txnRelatedIdsBuilder.toString().substring(0, txnRelatedIdsBuilder.toString().length() - 1) : "";
            txnRelatedCodes = !txnRelatedCodesBuilder.toString().isEmpty() ? txnRelatedCodesBuilder.toString().substring(0, txnRelatedCodesBuilder.toString().length() - 1) : "";
        }
        relatedTxnCodes.add(txnRelatedIds);
        relatedTxnCodes.add(txnRelatedCodes);
        return relatedTxnCodes;
    }

}
