package com.fubon.esb.service.log;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.query.view.TxnHisRecordsVO;
import com.fubon.esb.dao.log.TxnHisRecordDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.log.TxnHisRecord;
import com.fubon.esb.domain.log.TxnHisRecordMsg;

/**
 * @author Qigers
 * @createdDate 2014-11-14
 */
@Service(value = "txnHisRecordServive")
public class TxnHisRecordServive {

    @Inject
    private TxnHisRecordDao txnHisRecordDao;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;

    public Object findTxnHisRecordPageList(TxnHisRecordsVO vo, OrderBy orderBy, Page page, Boolean isSearch) {
        if (isSearch) {
            String time = vo.getStartHour() + ":" + vo.getStartMinute() + " ~ " + vo.getEndHour() + ":" + vo.getEndMinute();
            time = vo.getStartDate() + " " + time;
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.hisrecord.search") + "   ");
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createShowMessage(vo, time, messageStr), LogType.SEARCH_TXN_HIS_RECORD);
        }
        return txnHisRecordDao.findTxnHisRecordDaoList(vo, orderBy, page);
    }

    private String createShowMessage(TxnHisRecordsVO hisRecordVO, String time, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(hisRecordVO.getStartDate())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.time") + time);
        }
        if (StringUtils.isNotBlank(hisRecordVO.getTxnCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnCode") + hisRecordVO.getTxnCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getChannelCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnChannelCode") + hisRecordVO.getChannelCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getSequence())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnSequence") + hisRecordVO.getSequence());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getReturnCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnReturnCode") + hisRecordVO.getReturnCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getHostCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnHostCode") + hisRecordVO.getHostCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getGroupCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnGroupCode") + hisRecordVO.getGroupCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getServiceCode())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnServiceCode") + hisRecordVO.getServiceCode());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getDuration())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txn.timeout") + hisRecordVO.getDuration());
        }
        if (StringUtils.isNotBlank(hisRecordVO.getMessage())) {
            messageStr.append("  " + messages.getMessage("log.hisrecord.txnMsg.message") + hisRecordVO.getMessage());
        }
        return messageStr.toString();
    }

    public TxnHisRecord findTxnHisRecordDetail(String hisRecordId) {
        return txnHisRecordDao.findTxnHisRecordDetailDao(hisRecordId);
    }

    public Object findTxnRecordDetailPageList(TxnHisRecordsVO vo, Page page, String trackingId) {
        return txnHisRecordDao.findTxnRecordDetailDaoList(vo, page, trackingId);
    }

    public Object findTxnRecordDetailList(String trackingId) {
        return txnHisRecordDao.findTxnRecordDetailExcelDaoList(trackingId);
    }

    public TxnHisRecordMsg findTxnHisRecordMsg(String messageId) {
        return txnHisRecordDao.findTxnHisRecordMsg(messageId);
    }

    public Object findHisRecords(TxnHisRecordsVO vo) {
        String time = vo.getStartHour() + ":" + vo.getStartMinute() + " ~ " + vo.getEndHour() + ":" + vo.getEndMinute();
        time = vo.getStartDate() + " " + time;
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.hisrecord.export.excel") + "    ");
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createShowMessage(vo, time, messageStr), LogType.SEARCH_TXN_HIS_RECORD);
        vo.setSequence(vo.getSequence().replaceAll("^(0+)", ""));
        return txnHisRecordDao.findTxnHisRecordDaoList(vo);
    }

    public List<String> searchServiceCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchServiceCodes(key);
    }

    public List<String> searchGroupCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchGroupCodes(key);
    }

    public List<String> searchHostCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchHostCodes(key);
    }

    public List<String> searchChannelCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchChannelCodes(key);
    }

    public List<String> searchTxnCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchTxnCodes(key);
    }

    public List<String> searchUUIDs(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnHisRecordDao.searchUUIDs(key);
    }
}
