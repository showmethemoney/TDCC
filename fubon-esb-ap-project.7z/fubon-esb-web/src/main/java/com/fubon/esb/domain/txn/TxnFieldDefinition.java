package com.fubon.esb.domain.txn;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

/**
 * 欄位定義
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "TXN_FIELD_DEFINITION")
public class TxnFieldDefinition implements Serializable {

    /** ID **/
    @Id
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    @Column(name = "ID")
    private String id;

    /** 所屬上行或下行電文 **/
    @Column(name = "DIRECTION_ID")
    private String directionId;

    /** 欄位類型 {F:FIELD普通欄位,S:SWITCH判斷欄位,C:CASE判斷欄位,R:REPEAT重復欄位} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "FIELD_TYPE")
    private FieldType fieldType;

    /** 所屬父節點 **/
    @Column(name = "PARENT_ID")
    private String parentId;

    /** Tag ID **/
    @Column(name = "DEF_CODE")
    private String code;

    /** 欄位值 **/
    @Column(name = "VALUE")
    private String value;

    /** 名稱 **/
    @Column(name = "DEF_NAME")
    private String name;

    /** 序號 **/
    @Column(name = "ORDER_NO")
    private Integer orderNo;

    /** 資料類型{ X:字符,N:數字,H:十六進制值} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "DATA_TYPE")
    private DataType dataType;

    /** 長度 **/
    @Column(name = "LENGTH")
    private Integer length;

    /** 小數位數 **/
    @Column(name = "SCALE")
    private Integer scale;

    /** 預設值 **/
    @Column(name = "DEFAULT_VALUE")
    private String defaultV;

    /** 補充字符 默認值為空格 **/
    @Column(name = "PAD_CHAR")
    private String padChar;

    /** 對齊方式{L:LEFT,R:RIGHT} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "JUSTIFY")
    private JustifyType justify;

    /** 是否包含中文0/1 **/
    @Column(name = "INCLUDE_CHINESE")
    private Integer includeChinese;

    /** 是否必填0/1 **/
    @Column(name = "OPTIONAL")
    private Integer optional;

    /** 測試值 **/
    @Column(name = "TEST_VALUE")
    private String testValue;

    /** 是否作為分割的field */
    @Transient
    private boolean isSplitField = false;

    public TxnFieldDefinition() {

    }

    public TxnFieldDefinition(FieldType fieldType) {
        this.fieldType = fieldType;
    }

    /******* page inject enum ********/

    public void setFieldTypeP(String fieldType) {
        this.fieldType = FieldType.valueOf(fieldType);
    }

    public void setDataTypeP(String dataType) {
        this.dataType = DataType.valueOf(dataType);
    }

    public void setJustifyP(String justify) {
    	this.justify = JustifyType.valueOf(justify);
    }
    
    /***************/

    /** 重復欄位依欄位類型{9:數字,C:欄位名} **/
    public String getRepeatType() {
        try {
            Integer.parseInt(value);
            return "9";
        } catch (NumberFormatException e) {
            return "C";
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDirectionId() {
        return directionId;
    }

    public void setDirectionId(String directionId) {
        this.directionId = directionId;
    }

    public FieldType getFieldType() {
        return fieldType;
    }

    public void setFieldType(FieldType fieldType) {
        this.fieldType = fieldType;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getScale() {
        return scale;
    }

    public void setScale(Integer scale) {
        this.scale = scale;
    }

    public String getDefaultV() {
        return defaultV;
    }

    public void setDefaultV(String defaultV) {
        this.defaultV = defaultV;
    }

    public String getPadChar() {
        return padChar;
    }

    public void setPadChar(String padChar) {
        this.padChar = padChar;
    }

    public JustifyType getJustify() {
        return justify;
    }

    public void setJustify(JustifyType justify) {
        this.justify = justify;
    }

    public Integer getIncludeChinese() {
        return includeChinese;
    }

    public void setIncludeChinese(Integer includeChinese) {
        this.includeChinese = includeChinese;
    }

    public Integer getOptional() {
        return optional;
    }

    public void setOptional(Integer optional) {
        this.optional = optional;
    }

    public boolean isSplitField() {
        return isSplitField;
    }

    public void setSplitField(boolean isSplitField) {
        this.isSplitField = isSplitField;
    }

    public String getTestValue() {
        return testValue;
    }

    public void setTestValue(String testValue) {
        this.testValue = testValue;
    }

}
