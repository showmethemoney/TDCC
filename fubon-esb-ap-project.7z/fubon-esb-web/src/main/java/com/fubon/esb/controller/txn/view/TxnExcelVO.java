package com.fubon.esb.controller.txn.view;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nice
 * @createdDate 2014-12-6
 */
public class TxnExcelVO extends TxnVO {

    private String excelName;

    private List<String> excelErrors;

    public TxnExcelVO() {

    }

    public TxnExcelVO(String excelName) {
        this.excelName = excelName;
    }

    public TxnExcelVO(String excelName, List<String> excelErrors) {
        this.excelName = excelName;
        this.excelErrors = excelErrors;
    }

    public void addError(String errorMsg) {
        if (excelErrors == null) {
            excelErrors = new ArrayList<String>();
        }
        excelErrors.add(errorMsg);
    }

    public String getExcelName() {
        return excelName;
    }

    public void setExcelName(String excelName) {
        this.excelName = excelName;
    }

    public List<String> getExcelErrors() {
        return excelErrors;
    }

    public void setExcelErrors(List<String> excelErrors) {
        this.excelErrors = excelErrors;
    }

    @Override
    public boolean isValid() {
        if (excelErrors == null || excelErrors.isEmpty())
            return true;
        return false;
    }

}
