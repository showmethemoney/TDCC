package com.fubon.esb.controller.query;

import java.util.Calendar;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.query.view.TxnStatSearchVO;
import com.fubon.esb.controller.query.view.TxnStatsExcelBuilder;
import com.fubon.esb.domain.config.TxnStatCategoryType;
import com.fubon.esb.service.query.TxnStatService;

/**
 * 統計資料查詢
 * @author Leckie Zhang
 * @createdDate 2014-11-14
 */
@Controller
@RequestMapping("query")
public class TxnStatController extends BaseController {
    
    @Inject
    private TxnStatService txnStatService;
    
    @RequestMapping("viewTxnStats")
    @RequirePermission("030301")
    public String viewTxnStats(Model model, TxnStatSearchVO vo, Boolean isSearch, Integer currentPage) {
        if (isSearch != null && isSearch) {
            Page page = null;
            if (currentPage == null) {
                page  = new Page(1, 50);
                txnStatService.addLog(vo, true);
            } else {
                page = new Page(currentPage, 50);
            }
            vo.setPage(page);
            if (vo.getClassification() == 2) { // 月統計
                setTxnStatMon(vo, model);
            } else {
                model.addAttribute("txnStats", txnStatService.findTxnStats(vo));
            }
            model.addAttribute("vo", vo);
            model.addAttribute("page", page);
        } else {
            // 進入頁面顯示默認數據
            TxnStatSearchVO defaultVo = TxnStatSearchVO.getDefault();
            model.addAttribute("txnStats", txnStatService.findTxnStats(defaultVo));
            model.addAttribute("vo", defaultVo);
            model.addAttribute("page", defaultVo.getPage());
        }
        model.addAttribute("isSearch", true);
        txnStatService.setCategories(model);
        model.addAttribute("categories", txnStatService.findAllCategory());
        Calendar cal = Calendar.getInstance();
        model.addAttribute("currentYear", cal.get(Calendar.YEAR));
        model.addAttribute("currentMonth", cal.get(Calendar.MONTH) + 1);
        model.addAttribute("returnTimeTypes", txnStatService.getReturnTimeTypes());
        return "/query/viewTxnStats";
    }
    
    private void setTxnStatMon(TxnStatSearchVO vo, Model model) {
        if (vo.getCategory() == TxnStatCategoryType.E) { // error code
            model.addAttribute("txnStats", txnStatService.findTxnStatMonErrorCodes(vo));
        } else {
            model.addAttribute("txnStats", txnStatService.findTxnStatMons(vo));
        }
    }
    
    @RequestMapping("exportTxnStats")
    @RequirePermission("030302")
    public ModelAndView exportTxnStats(ModelMap model, TxnStatSearchVO vo) {
        if (vo.getClassification() == 2) {
            if (vo.getCategory() != null && vo.getCategory() == TxnStatCategoryType.E) {
                model.put("txnStats", txnStatService.findTxnStatMonErrorCodes(vo));
            } else {
                model.put("txnStats", txnStatService.findTxnStatMons(vo));                
            }
        } else {
            model.put("txnStats", txnStatService.findTxnStats(vo));
        }
        model.put("vo", vo);
        model.put("titles", txnStatService.getTitles(vo));
        TxnStatsExcelBuilder txnStatsExcelBuilder = new TxnStatsExcelBuilder();
        txnStatService.addLog(vo, null);
        return new ModelAndView(txnStatsExcelBuilder, model);
    }

}
