package com.fubon.esb.controller.txn;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnSendService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Controller
@RequestMapping({"/txn/check"})
public class TxnCheckContorller extends BaseController {
    @Inject
    private TxnService txnService;
    @Inject
    protected TxnSendService txnSendService;
    @Inject
    private TxnDefinitionService txnDefService;
    @Inject
    private TxnEditController txnEditController;
    @Inject
    private TxnFieldDefinitionService txnFieldService;
    private static final String INCLUDE_BASE_URL = "txn/include/check";

    @RequestMapping({"/list"})
    @RequirePermission(value = "010301")
    public String viewCheckList(Model model) {
        return "txn/viewCheckTxnList";
    }

    @RequestMapping({"/search"})
    public String searchTxnList(Model model, HttpServletRequest request) throws Exception {
        String asc = request.getParameter("asc");
        String txnCode = request.getParameter("txnCode");
        String txnName = request.getParameter("txnName");
        String group = request.getParameter("group");
        Integer curPage = 1;
        try {
            curPage = Integer.parseInt(request.getParameter("curPage"));
        } catch (Exception e) {
            curPage = 1;
        }
        Assert.notNull(curPage, "request parameter curPage not present !");
        Page page = new Page(curPage);
        OrderBy orderBy = null;
        if (StringUtils.isNotBlank(asc)) {
            orderBy = new OrderBy();
            orderBy.setField("group");
            orderBy.setAsc(Boolean.valueOf(asc));
        }
        List<TxnDefinition> txnDefs = txnDefService.searchWaitToCheckTxnDefs(orderBy, txnCode, txnName, group, page);
        if (page.getTotalPage() != 0 && curPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            txnDefs = txnDefService.searchWaitToCheckTxnDefs(orderBy, txnCode, txnName, group, page);
        }
        model.addAttribute("txnDefis", txnDefs);
        model.addAttribute("page", page);
        return INCLUDE_BASE_URL + "/txnDefs";
    }

    @RequestMapping({"/txnContent/{defId}"})
    @RequirePermission(value = "010101")
    public String viewTxnContent(Model model, @PathVariable("defId") String defId, @RequestParam(defaultValue = "true") Boolean isCheck) throws Exception {
        TxnVO txnVO = txnService.findTxnVO(defId);
        txnEditController.txnVOModel(model, txnVO);
        model.addAttribute("isCheck", isCheck);
        return "txn/viewCheckTxn";
    }

    @RequestMapping({"/childContent"})
    public String viewTxnChildContent(Model model, @RequestParam String pFieldId) {
        txnEditController.getChildrenFields(model, null, pFieldId, null);
        model.addAttribute("parentField", txnFieldService.getById(pFieldId));
        return INCLUDE_BASE_URL + "/txnChildContent";
    }

    @RequestMapping({"/commit/{defId}"})
    public String commitCheck(Model model, @PathVariable("defId") String defId) {
        String mainId = txnService.approveTxn(defId, loginedUserId());
        try {
            txnSendService.sendChangeEvent(mainId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/history/goHistory";
    }

    @RequestMapping({"/back/{defId}"})
    public String backCheck(Model model, @PathVariable("defId") String defId) {
        TxnDefinition definition = txnDefService.getById(defId);
        if (definition != null) {
            if (TxnStatus.D.equals(definition.getStatus())) {
                definition.setStatus(TxnStatus.M);
            } else if (TxnStatus.S.equals(definition.getStatus())) {
                definition.setStatus(TxnStatus.E);
            }
            definition.setUpdatedTime(new Date());
            definition.setUpdatedUser(loginedUserId());
            txnDefService.saveOrUpdate(definition);
        }
        return "redirect:/history/goHistory";
    }

    @ResponseBody
    @RequestMapping({"/mutipleCheck"})
    public Object mutipleReCheck(Model model, @RequestParam("defIds[]") String[] defIds) {
        List<String> mainDefIds = txnService.approveTxns(defIds, loginedUserId());
        try {
            for (String mainDefId : mainDefIds) {
                txnSendService.sendChangeEvent(mainDefId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @ResponseBody
    @RequestMapping({"/search/defnames"})
    public Object searchTxnCheckNames(@RequestParam String key) {
        return txnDefService.searchTxnCheckDefnames(key);
    }

    
    @RequestMapping({"/refresh/{defId}"})
    @ResponseBody
    public Object refreshTxn(Model model, @PathVariable("defId") String defId) {
        String mainId = defId;
        boolean send_status=true;
        
        send_status=txnSendService.sendChangeEvent(mainId);

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("flag", send_status);
        return result;
    }    
    
    
}
