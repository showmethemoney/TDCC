package com.fubon.esb.dao.config;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.Holiday;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-12
 */
@Repository
public class HolidayDao extends JPADaoSupport<Holiday> {
    
    public List<Holiday> findHolidysByYear(Integer year) {
        return jpaAccess.find(Query.create("select new " + Holiday.class.getName() + "(h) from " + Holiday.class.getName() + " h where YEAR(h.day)=:year order by h.id").param("year", year));
    }
    
}
