package com.fubon.esb.domain.job;

public enum JobRecordStatusType {

    SUCCESS("SUCCESS"), ACTIVE("ACTIVE"), SENDING("SENDING"), ERROR("ERROR");

    private final String desc;

    private JobRecordStatusType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
