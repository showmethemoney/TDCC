package com.fubon.esb.domain.log;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-23
 */
public enum LogType {

    /** 系統  */
    SYS("SYS", null),
    
    /** 電文工具-電文編輯 */
    TXN_EDIT("TXN_TOOL", "TXN_EDIT"),

    /** 電文工具-電文覆核 */
    TXN_APPROVE("TXN_TOOL", "TXN_APPROVE"),

    /** 電文工具-電文測試 */
    TXN_TEST("TXN_TOOL", "TXN_TEST"),

    /** 電文管理 */
    TXN_MANAGE("TXN_MANAGE", null),

    /** 查詢-當日交易紀錄查詢 */
    SEARCH_TXN_RECORD("SEARCH", "SEARCH_TXN_RECORD"),

    /** 查詢-歷史交易紀錄查詢 */
    SEARCH_TXN_HIS_RECORD("SEARCH", "SEARCH_TXN_HIS_RECORD"),

    /** 查詢-統計資料查詢 */
    SEARCH_DAILY_STATISTIC("SEARCH", "SEARCH_DAILY_STATISTIC"),

    /** 查詢-假日檔查詢 */
    SEARCH_HOLIDAY("SEARCH", "SEARCH_HOLIDAY"),

    /** 排程管理-排程設定 */
    JOB_MANAGE_CONFIG("JOB_MANAGE", "JOB_MANAGE_CONFIG"),

    /** 排程管理-排程查詢 */
    JOB_MANAGE_SEARCH("JOB_MANAGE", "JOB_MANAGE_SEARCH"),

    /** 排程管理 - 排程系統設定 */
    JOB_SYSTEM_SETTING("JOB_MANAGE", "JOB_SYSTEM_SETTING"),
    
    /** 系統管理 -交易設定 */
    SYS_CFG_TXN("SYS_CFG", "SYS_CFG_TXN"),

    /** 系統管理 -Channel 設定 */
    SYS_CFG_CHANNEL("SYS_CFG", "SYS_CFG_CHANNEL"),

    /** 系統管理 -Access Channel 設定 */
    SYS_CFG_ACCESS_CHANNEL("SYS_CFG", "SYS_CFG_ACCESS_CHANNEL"),

    /** 系統管理 -業務群組設定 */
    SYS_CFG_TXN_GROUP("SYS_CFG", "SYS_CFG_TXN_GROUP"),

    /** 系統管理 -主機設定 */
    SYS_CFG_HOST("SYS_CFG", "SYS_CFG_HOST"),

    /** 系統管理 -Service 設定 */
    SYS_CFG_SERVICE("SYS_CFG", "SYS_CFG_SERVICE"),

    /** 系統管理 -Connector 設定 */
    SYS_CFG_CONNECTOR("SYS_CFG", "SYS_CFG_CONNECTOR"),

    /** 系統管理 - 交易回覆代碼對應設定 */
    SYS_CFG_RETURN_CODE("SYS_CFG", "SYS_CFG_RETURN_CODE"),

    /** 系統管理 - Email 通知群組管理 */
    SYS_CFG_MAIL_GROUP("SYS_CFG", "SYS_CFG_MAIL_GROUP"),

    /** 系統日誌-系統紀錄查詢 */
    SYS_LOG_QUERY("SYS_LOG", "SYS_LOG_QUERY"),

    /** 系統日誌-系統狀態查詢 */
    SYS_STATUS_QUERY("SYS_LOG", "SYS_STATUS_QUERY"),

    /** 系統日誌-權限覆核日誌 */
    SYS_APPROVAL_LOG("SYS_LOG", "SYS_APPROVAL_LOG"),

    /** 系統權限管理-角色權限設定 */
    SYS_FUNC_MANAGE("SYS_FUNC", "SYS_FUNC_MANAGE"),

    /** 系統權限管理-系統權限覆核 */
    SYS_FUNC_APPROVAL("SYS_FUNC", "SYS_FUNC_APPROVAL"),
    
    /** 系統權限管理-系統帳號設定 */
    SYS_USER_CONFIG("SYS_FUNC", "SYS_USER_CONFIG"),
    
    /** 系統權限管理-系統帳號覆核 */
    SYS_USER_APPROVAL("SYS_FUNC", "SYS_USER_APPROVAL"),
    
    /** 系統登入 */
    SYS_LOGIN("SYS_LOGIN", null),

    /** 系統登出 */
    SYS_LOGOUT("SYS_LOGOUT", null);

    private String module;

    private String function;

    private LogType(String module, String function) {
        this.module = module;
        this.function = function;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }

}
