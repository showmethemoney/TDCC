package com.fubon.esb.service.config;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.config.ReturnCodeDao;
import com.fubon.esb.domain.config.ReturnCode;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Qigers
 * @createdDate 2014-11-17
 */

@Service
public class ReturnCodeService {

    @Inject
    private ReturnCodeDao returnCodeDao;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;

    @Inject
    private ConfigChangeService configChangeService;

    public List<ReturnCode> findReturnCodes(String groupCode, String returnCode, Page page) {
        return returnCodeDao.findReturnCodes(groupCode, returnCode, page);
    }

    public ReturnCode getById(String id) {
        return returnCodeDao.getlById(id);
    }

    @Transactional
    public void removeReturnCode(String id) {
        ReturnCode rc = getById(id);
        returnCodeDao.removeReturnCode(id);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.returncode.delete"));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(rc, messageStr), LogType.SYS_CFG_RETURN_CODE);
    }

    @Transactional
    public void saveOrUpdate(ReturnCode returnCode, String currentUser) {
        String returnCodeId = returnCode.getId();
        if (StringUtils.isNotBlank(returnCodeId)) {
            ReturnCode oldReturnCode = getById(returnCodeId);
            returnCode.setCreatedTime(oldReturnCode.getCreatedTime());
            returnCode.setUpdatedTime(new Date());
            returnCode.setUpdatedUser(currentUser);
            Boolean flagGroupCode = oldReturnCode.getGroupCode().equals(returnCode.getGroupCode());
            Boolean flagReturnCode = oldReturnCode.getReturnCode().equals(returnCode.getReturnCode());
            Boolean flagDescz = oldReturnCode.getDescz().equals(returnCode.getDescz());
            Boolean updateFlag = flagGroupCode && flagReturnCode && flagDescz;
            if (!updateFlag) {
                configChangeService.sendMailRequest("交易回應代碼對應設定更變", createUpdateStr(currentUser, returnCode, oldReturnCode));
            }
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.returncode.update"));
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(oldReturnCode, messageStr), LogType.SYS_CFG_RETURN_CODE);
            returnCodeDao.updateReturnCode(returnCode);
        } else {
            if (validCodeDuplicate(returnCode.getId())) {
                throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
            }
            returnCode.setCreatedTime(new Date());

            String addStr = "交易回應代碼對應設定新增，新增者：" + currentUser + "\r";
            addStr += "新增內容：\r";
            addStr += "業務群組代號：" + returnCode.getGroupCode() + "\r";
            addStr += "交易回應代碼：" + returnCode.getReturnCode() + "\r";
            addStr += "交易回應代碼說明：" + returnCode.getDescz() + "\r";
            configChangeService.sendMailRequest("交易回應代碼對應設定新增", addStr);
            returnCodeDao.addReturnCode(returnCode);
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.returncode.add"));
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(returnCode, messageStr), LogType.SYS_CFG_RETURN_CODE);
        }
    }

    private String createUpdateStr(String currentUser, ReturnCode returnCode, ReturnCode oldReturnCode) {
        String updateStr = "交易回應代碼對應設定(交易回應代碼：" + returnCode.getReturnCode() + ")變更，變更者：" + currentUser + "\r";
        updateStr += "現形生效內容：\r";
        Boolean flagGroupCode = oldReturnCode.getGroupCode().equals(returnCode.getGroupCode());
        Boolean flagReturnCode = oldReturnCode.getReturnCode().equals(returnCode.getReturnCode());
        Boolean flagDescz = oldReturnCode.getDescz().equals(returnCode.getDescz());
        if (!flagGroupCode) {
            updateStr += "業務群組代號：" + oldReturnCode.getGroupCode() + "\r";
        }
        if (!flagReturnCode) {
            updateStr += "交易回應代碼：" + oldReturnCode.getReturnCode() + "\r";
        }
        if (!flagDescz) {
            updateStr += "交易回應代碼說明：" + oldReturnCode.getDescz() + "\r";
        }
        updateStr += "\r變更後內容：\r";
        if (!flagGroupCode) {
            updateStr += "業務群組代號：" + returnCode.getGroupCode() + "\r";
        }
        if (!flagReturnCode) {
            updateStr += "交易回應代碼：" + returnCode.getReturnCode() + "\r";
        }
        if (!flagDescz) {
            updateStr += "交易回應代碼說明：" + returnCode.getDescz() + "\r";
        }
        return updateStr;
    }

    private String createStr(ReturnCode returnCode, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(returnCode.getGroupCode())) {
            messageStr.append(messages.getMessage("log.returncode.groupcode") + returnCode.getGroupCode());
        }

        if (StringUtils.isNotBlank(returnCode.getReturnCode())) {
            messageStr.append(messages.getMessage("log.returncode.returncode") + returnCode.getReturnCode());
        }
        return messageStr.toString();
    }

    public boolean validCodeDuplicate(String id) {
        return returnCodeDao.idDuplicate(id);
    }

    public boolean validCodeDuplicate(String groupCode, String returnCode) {
        return returnCodeDao.codeDuplicate(groupCode, returnCode);
    }

    public List<String> searchReturnCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return returnCodeDao.searchReturnCodes(key);
    }
}
