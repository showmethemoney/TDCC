package com.fubon.esb.controller.common;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fubon.esb.exception.ValidationException;

/**
 * @author james
 * @createdDate 2014-11-6
 */
@ControllerAdvice
public class ControllerExceptionAdvice {

    @ExceptionHandler
    @ResponseBody
    public ResultView controllerExceptionHandler(ValidationException exception) {
        return ResultView.error(exception.getErrorMessages());
    }

}
