package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.txn.view.TxnManageVo;
import com.fubon.esb.dao.txn.TxnManageDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.txn.TxnManageCategoryType;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-18
 */
@Service
public class TxnManageService {

    @Inject
    private TxnManageDao txnManageDao;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private Messages messages;
    @Inject
    private TxnManageFormatService txnManageFormatService;

    public List<TxnManageVo> findTxnAll(Page page, Boolean isSearch) {
        List<TxnManageVo> txnManages = txnManageDao.findAllTxn(page);
        // Collections.sort(txnManages, comparator);
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "全部"), LogType.TXN_MANAGE);
        }
        txnManageFormatService.formatQueryByAll(txnManages);

        return txnManages;
    }

    public List<TxnManageVo> findTxnByTxn(Page page, Boolean isSearch) {
        List<TxnManageVo> txnManages = txnManageDao.findTxnByTxn(page);
        // Collections.sort(txnManages,comparator);
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "交易代號"), LogType.TXN_MANAGE);
        }
        txnManageFormatService.formatQueryByTxn(txnManages);
        return txnManages;
    }

    public Map<String, List<TxnManageVo>> findTxnByChannel(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByChannel(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryChannelList(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "Channel"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> findTxnByAccessChannel(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByAccessChannel(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryAccessChannel(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "Access Channel"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> findTxnByHost(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByHost(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryHostList(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "主機"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> findTxnByTxnGroup(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByTxnGroup(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryTxnGroupList(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "業務群組"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> findTxnByService(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByService(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryServiceList(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "Service"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public List<TxnManageVo> findTxnByServiceVersion(Page page, Boolean isSearch) {
        List<TxnManageVo> txnManages = txnManageDao.findTxnByServiceVersion(page);
        // Collections.sort(txnManages, comparator);
        txnManageFormatService.formatQueryByVersion(txnManages);

        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "Service 版本"), LogType.TXN_MANAGE);
        }
        return txnManages;
    }

    public Map<String, List<TxnManageVo>> findTxnByConnector(Page page, Boolean isSearch) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        List<TxnManageVo> txnManageVos = txnManageDao.findTxnByConnector(page);
        // Collections.sort(txnManageVos, comparator);
        if (!txnManageVos.isEmpty()) {
            txnManageMap = txnManageFormatService.formatQueryConnectorList(txnManageVos);
        }
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manager.log.query"), "Connector"), LogType.TXN_MANAGE);
        }
        return txnManageMap;
    }

    public List<TxnManageVo> findTxnByType(TxnManageCategoryType queryType) {
        if (queryType == TxnManageCategoryType.ALL) {
            List<TxnManageVo> txnManages = txnManageDao.findAllTxn(null);
            txnManageFormatService.formatQueryByAll(txnManages);
            return txnManages;
        } else if (queryType == TxnManageCategoryType.TXN) {
            List<TxnManageVo> txnManageVos = txnManageDao.findTxnByTxn(null);
            txnManageFormatService.formatQueryByTxn(txnManageVos);
            return txnManageVos;
        } else if (queryType == TxnManageCategoryType.CHANNEL) {
            return txnManageDao.findTxnByChannel(null);
        } else if (queryType == TxnManageCategoryType.ACCESSCHANNEL) {
            return txnManageDao.findTxnByAccessChannel(null);
        } else if (queryType == TxnManageCategoryType.HOST) {
            return txnManageDao.findTxnByHost(null);
        } else if (queryType == TxnManageCategoryType.TXNGROUP) {
            return txnManageDao.findTxnByTxnGroup(null);
        } else if (queryType == TxnManageCategoryType.SERVICE) {
            return txnManageDao.findTxnByService(null);
        } else if (queryType == TxnManageCategoryType.SERVICEVERSION) {
            return txnManageDao.findTxnByServiceVersion(null);
        } else if (queryType == TxnManageCategoryType.CONNECTOR) {
            return txnManageDao.findTxnByConnector(null);
        } else
            return new ArrayList<TxnManageVo>();
    }

    public int compareTo(String s1, String s2) {
        if (StringUtils.isBlank(s1) && StringUtils.isBlank(s2)) {
            return 0;
        } else if (StringUtils.isBlank(s1) && StringUtils.isNotBlank(s2)) {
            return -1;
        } else if (StringUtils.isNotBlank(s1) && StringUtils.isBlank(s2)) {
            return 1;
        } else
            return s1.toLowerCase().compareTo(s2.toLowerCase());
    }

}
