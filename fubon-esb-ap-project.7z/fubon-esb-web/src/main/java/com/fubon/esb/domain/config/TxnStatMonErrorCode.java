package com.fubon.esb.domain.config;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * 交易月統計(ERRORCODE)
 * 
 * @author Leckie Zhang
 * @createdDate 2014-12-15
 */
@Entity(name = "TXN_STAT_MON_ERROR_CODE")
public class TxnStatMonErrorCode {
    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "paymentableGenerator")
    @GenericGenerator(name = "paymentableGenerator", strategy = "identity")
    private BigInteger id;

    /** 統計日期 */
    @Column(name = "DAY")
    private Date day;

    /** 統計月份 */
    @Column(name = "MONTH")
    private Integer month;

    /** 統計月份 */
    @Column(name = "HOUR")
    private BigDecimal hour;

    /** 電文統計方式 */
    @Column(name = "TYPE")
    private Integer type;

    /** 資料類別 */
    @Enumerated(EnumType.STRING)
    @Column(name = "CATEGORY")
    private TxnStatCategoryType category;

    /** 類別值 */
    @Column(name = "VALUE")
    private String value;

    /** 附加類別值 */
    @Column(name = "VALUE2")
    private String value2;

    /** 附加類別值 */
    @Column(name = "VALUE3")
    private String value3;

    /** 電文筆數 */
    @Column(name = "TOTAL_RECORD")
    private BigInteger totalRecord;

    public TxnStatMonErrorCode() {
    }

    public TxnStatMonErrorCode(Integer month, BigInteger totalRecord) {
        this.month = month;
        this.totalRecord = totalRecord;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    public BigDecimal getHour() {
        return hour;
    }

    public void setHour(BigDecimal hour) {
        this.hour = hour;
    }

    public String getMonthStr() {
        if (month == null) {
            return "";
        }

        String monthStr = String.valueOf(month);
        return monthStr.substring(0, 4) + "/" + monthStr.subSequence(4, 6);
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public void setTotalRecord(BigInteger totalRecord) {
        this.totalRecord = totalRecord;
    }

    public BigInteger getTotalRecord() {
        return totalRecord;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public void setCategory(TxnStatCategoryType category) {
        this.category = category;
    }

    public TxnStatCategoryType getCategory() {
        return category;
    }

    public String getValue() {
        return value;
    }

    private String fullFillDecimal(BigDecimal b) {
        int i = b.intValue();
        int j = b.subtract(new BigDecimal(i)).multiply(new BigDecimal("60")).intValue();
        StringBuilder result = new StringBuilder(String.valueOf(i * 100 + j));
        while (result.length() < 4) {
            result.insert(0, "0");
        }
        return result.insert(2, ":").toString();
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }

    /** 時間區間 格式00:30 */
    public String getHourRange() {
        if (hour == null) {
            return "";
        }
        BigDecimal later = hour.add(new BigDecimal("0.5"));
        return fullFillDecimal(hour) + "-" + fullFillDecimal(later);
    }

}
