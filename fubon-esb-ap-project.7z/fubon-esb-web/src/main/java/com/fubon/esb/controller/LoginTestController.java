package com.fubon.esb.controller;

import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comwave.core.platform.cookie.RequireCookie;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.session.RequireSession;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.User;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
@Controller
@RequireCookie
@RequireSession
public class LoginTestController {

    @Inject
    private LoginContext loginContext;
    
    @Inject
    private RoleDao roleDao;

    @RequestMapping(value = "/viewLoginTest", method = RequestMethod.GET)
    public String viewLoginTest() {
        return "viewLoginTest";
    }

    @RequestMapping(value = "/loginTest", method = RequestMethod.POST)
    public String loginTest(@Valid String userId, @Valid String password, String timeZone) {
        User user = new User();
        user.setUserId(userId);
        user.setTimeZone(timeZone);
//        user.setBranch(branchDao.get("B1400"));
//        List<Group> groups = new ArrayList<Group>();
//        groups.add(groupService.getGroupByAdGroup("FAdmin"));
//        user.setGroups(groups);
//        user.setRoleList(roleService.findRolesByGroupBranch(user.getGroups(), user.getBranch()));
        List<Role> roleList = roleDao.findRoleByUserId(user.getUserId());
        if (roleList == null || roleList.isEmpty()) {
            roleList = roleDao.findRoleByADGroup(Group.DEFAULTADGROUP);
        }
        user.setRoleList(roleList);
        loginContext.login(user.getUserId());
        loginContext.login(user);
        return "redirect:/home";
    }

}
