package com.fubon.esb.service.log;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.LogDBConfig;
import com.fubon.esb.controller.log.view.OperationLogSearchVO;
import com.fubon.esb.dao.log.OperationLogDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;


/**
 * @author Leckie Zhang
 * @createdDate 2014-10-23
 */
@Service(value = "operationLogService")
public class OperationLogService
{

	@Inject
	private OperationLogDao operationLogDao;

	@Inject
	private LoginContext loginContext;

	@Inject
	private Messages messages;

	/**
	 * Create Log
	 * 
	 * @param level
	 *            : OperationLog {@link OperationLog}
	 * @param message
	 * @param user
	 *            {@link User}
	 * @param type
	 *            {@link LogType}
	 */
	@Transactional(LogDBConfig.LOG_DB_JPA_TXN)
	public void addOperationLog(String level, String message, LogType type) {
		OperationLog log = new OperationLog();
		log.setModule( type.getModule() );
		log.setFunction( type.getFunction() );
		log.setLevel( level );
		log.setMessage( message );
		log.setOpUser( loginContext.loginedUserId() );
		log.setOpTime( new Date() );
		operationLogDao.save( log );
	}

	public List<OperationLog> getFuncList() {
		List<OperationLog> logs = new ArrayList<>();
		for (LogType type : LogType.values()) {
			OperationLog log = new OperationLog();
			log.setModule( type.getModule() );
			log.setFunction( type.getFunction() );
			logs.add( log );
		}
		return logs;
	}

	@Transactional(LogDBConfig.LOG_DB_JPA_TXN)
	public Object findOperationLogPageList(OperationLogSearchVO vo, OrderBy orderBy, Page page, String message, Boolean isSearch) {
		String starTime = vo.getStartDate() + " " + vo.getStartHour() + ":" + vo.getStartMinute();
		String endTime = vo.getEndDate() + " " + vo.getEndHour() + ":" + vo.getEndMinute();
		String module = operationLogDao.getModule( vo );
		String function = operationLogDao.getFunction( vo );
		StringBuilder showMessage = new StringBuilder();
		showMessage.append( messages.getMessage( "look.for.system.log" ) + "   " );
		if (StringUtils.isNotBlank( vo.getStartDate() )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.starttime" ) + starTime );
		}
		if (StringUtils.isNotBlank( vo.getEndDate() )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.endtime" ) + endTime );
		}
		if (StringUtils.isNotBlank( vo.getLevel() )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.level" ) + vo.getLevel() );
		}
		if (StringUtils.isNotBlank( vo.getOpUser() )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.opUser" ) + vo.getOpUser() );
		}
		if (StringUtils.isNotBlank( module ) || StringUtils.isNotBlank( function )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.function" ) + messages.getMessage( module ) + "-" + messages.getMessage( function ) );
		}
		if (StringUtils.isNotBlank( message )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.message" ) + message );
		}
		if (StringUtils.isNoneBlank( vo.getExcludeMessage() )) {
			showMessage.append( " " + messages.getMessage( "look.for.system.excludeMessage" ) + vo.getExcludeMessage() );
		}
		if (isSearch) {
			addOperationLog( OperationLog.LEVEL_INFO, showMessage.toString(), LogType.SYS_LOG_QUERY );
		}
		return operationLogDao.findOperationLogDaoList( vo, orderBy, page, message );
	}
}
