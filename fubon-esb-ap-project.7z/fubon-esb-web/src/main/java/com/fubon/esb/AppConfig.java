package com.fubon.esb;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.comwave.core.http.HTTPClient;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.model.ExtraModelBuilder;
import com.fubon.esb.service.ExtraModelBuilderExt;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
@Configuration
public class AppConfig {

    @Bean
    public LoginContext loginContext() {
        return new LoginContext();
    }

    @Bean
    public ExtraModelBuilder extraModelBuilder() {
        return new ExtraModelBuilderExt();
    }

    @Bean
    public HTTPClient httpClient() {
        return new HTTPClient();
    }
}
