package com.fubon.esb.controller.txn.view;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFBorderFormatting;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.txn.TxnManageCategoryType;

/**
 * 
 * @author Shelly
 * @createdDate 2015-1-14
 */
public class TxnManageExcelView extends AbstractExcelView {

    @Override
    @SuppressWarnings("unchecked")
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("sheet1");
        sheet.setDefaultColumnWidth(20);
        HSSFCellStyle simpleStyle = workbook.createCellStyle();
        simpleStyle.setBorderRight(HSSFBorderFormatting.BORDER_THIN);
        simpleStyle.setBorderBottom(HSSFBorderFormatting.BORDER_THIN);
        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 13);
        font.setColor(HSSFFont.COLOR_NORMAL);
        font.setFontName("宋體");
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        simpleStyle.setFont(font);
        HSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        TxnManageCategoryType queryType = (TxnManageCategoryType) obj.get("queryType");
        String titles[] = getTitle(queryType);
        HSSFRow header = sheet.createRow(0);
        int index = 0;
        for (int i = 0; i < titles.length; i++) {
            if (StringUtils.isNotBlank(titles[i])) {
                header.createCell(index).setCellValue(titles[i]);
                header.getCell(index).setCellStyle(simpleStyle);
                index++;
            } else
                break;
        }
        List<TxnManageVo> txnManageVos = (List<TxnManageVo>) obj.get("txnManageVos");
        setExcelContentByType(sheet, txnManageVos, queryType);
        String filename = System.currentTimeMillis() + ".xls";
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + filename);
        OutputStream ouputStream = response.getOutputStream();
        workbook.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();
    }

    private String[] getTitle(TxnManageCategoryType queryType) {
        String[] titles = new String[8];
        if (queryType == TxnManageCategoryType.ALL) {
            titles[0] = "Access Channel";
            titles[1] = "Channel";
            titles[2] = "主機";
            titles[3] = "業務群組";
            titles[4] = "Service";
            titles[5] = "Service版本";
            titles[6] = "Connector";
            titles[7] = "交易";
        } else if (queryType == TxnManageCategoryType.TXN) {
            titles[0] = "交易代號";
            titles[1] = "Channel";
            titles[2] = "Access Channel";
            titles[3] = "主機";
            titles[4] = "業務群組";
            titles[5] = "Service";
            titles[6] = "Service版本";
            titles[7] = "Connector";

        } else if (queryType == TxnManageCategoryType.CHANNEL) {
            titles[0] = "Channel";
            titles[1] = "交易";
        } else if (queryType == TxnManageCategoryType.ACCESSCHANNEL) {
            titles[0] = "Access Channel";
            titles[1] = "交易";
        } else if (queryType == TxnManageCategoryType.HOST) {
            titles[0] = "主機";
            titles[1] = "交易";
        } else if (queryType == TxnManageCategoryType.TXNGROUP) {
            titles[0] = "業務群組";
            titles[1] = "交易";
        } else if (queryType == TxnManageCategoryType.SERVICE) {
            titles[0] = "Service";
            titles[1] = "交易";
        } else if (queryType == TxnManageCategoryType.SERVICEVERSION) {
            titles[0] = "Service";
            titles[1] = "Service版本";
            titles[2] = "交易";
        } else if (queryType == TxnManageCategoryType.CONNECTOR) {
            titles[0] = "Connector";
            titles[1] = "交易";
        }
        return titles;
    }

    private void setExcelContentByType(HSSFSheet sheet, List<TxnManageVo> txnManageList, TxnManageCategoryType queryType) {
        if (queryType == TxnManageCategoryType.ALL) {
            createExcelforAll(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.TXN) {
            createExcelforTxn(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.CHANNEL) {
            createExcelforChannel(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.ACCESSCHANNEL) {
            createExcelforAccessChannel(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.HOST) {
            createExcelforHost(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.TXNGROUP) {
            createExcelforTxnGroup(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.SERVICE) {
            createExcelforService(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.SERVICEVERSION) {
            createExcelforServiceVersion(sheet, txnManageList);
        } else if (queryType == TxnManageCategoryType.CONNECTOR) {
            createExcelforConnector(sheet, txnManageList);
        }
    }

    private void createExcelforTxn(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            setCellContentForTxn(row, vo);
        }
    }

    public void setCellContentForTxn(HSSFRow row, TxnManageVo vo) {
        row.createCell(0).setCellValue(vo.getTxnCode());
        row.createCell(1).setCellValue(vo.getChannelName());
        row.createCell(2).setCellValue(vo.getAccessChannelName());
        row.createCell(3).setCellValue(vo.getHostName());
        row.createCell(4).setCellValue(vo.getTxnGroupName());
        row.createCell(5).setCellValue(vo.getServiceName());
        row.createCell(6).setCellValue(vo.getServiceVersion());
        row.createCell(7).setCellValue(vo.getConnectorName());

    }

    private void createExcelforAll(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getAccessChannelName());
            row.createCell(1).setCellValue(vo.getChannelName());
            row.createCell(2).setCellValue(vo.getHostName());
            row.createCell(3).setCellValue(vo.getTxnGroupName());
            row.createCell(4).setCellValue(vo.getServiceName());
            row.createCell(5).setCellValue(vo.getServiceVersion());
            row.createCell(6).setCellValue(vo.getConnectorName());
            row.createCell(7).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforChannel(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getChannelName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforAccessChannel(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getAccessChannelName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforHost(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getHostName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforTxnGroup(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getTxnGroupName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforService(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getServiceName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforServiceVersion(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getServiceName());
            row.createCell(1).setCellValue(vo.getServiceVersion());
            row.createCell(2).setCellValue(vo.getTxnCode());
        }
    }

    private void createExcelforConnector(HSSFSheet sheet, List<TxnManageVo> txnManageList) {
        for (int i = 1; i <= txnManageList.size(); i++) {
            TxnManageVo vo = txnManageList.get(i - 1);
            HSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue(vo.getConnectorName());
            row.createCell(1).setCellValue(vo.getTxnCode());
        }
    }
}
