package com.fubon.esb.domain.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 
 * Channel設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */

@Entity(name = "CFG_CHANNEL")
public class Channel extends ConfigBaseEntity {

    /** 代號 */
    @NotEmpty
    @Column(name = "CHANNEL_CODE")
    private String code;

    /** 名稱 */
    @Column(name = "CHANNEL_NAME")
    @NotEmpty
    private String name;

    /** 使用狀態 **/
    @Column(name = "CHANNEL_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private ConfigActiveStatus status;

    /** 所屬Access Channel */
    @Column(name = "ACCESS_CHANNEL_ID")
    private String accessChannelId;

    /** 應用系統代號 */
    @Column(name = "APP_CODE")
    private String appCode;

    /** 應用系統簡稱 */
    @Column(name = "APP_NAME")
    private String appName;

    /** BG Group */
    @Column(name = "BG_GROUP")
    private String bgGroup;

    /** 登陸賬號 **/
    @Column(name = "LOGIN_NAME")
    private String loginName;

    /** 登錄密碼 */
    @Column(name = "LOGIN_PASSWORD")
    private String loginPassWord;

    @Column(name = "RULE_CODE")
    private String ruleCode;

    public String getAccessChannelId() {
        return accessChannelId;
    }

    public void setAccessChannelId(String accessChannelId) {
        this.accessChannelId = accessChannelId;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getBgGroup() {
        return bgGroup;
    }

    public void setBgGroup(String bgGroup) {
        this.bgGroup = bgGroup;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getLoginPassWord() {
        return loginPassWord;
    }

    public void setLoginPassWord(String loginPassWord) {
        this.loginPassWord = loginPassWord;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

    public String getRuleCode() {
        return ruleCode;
    }

    public void setRuleCode(String ruleCode) {
        this.ruleCode = ruleCode;
    }

}
