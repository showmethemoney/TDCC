package com.fubon.esb.domain.system;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

/**
 * 權限種類
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_FUNCTION")
public class Function {

    /** 權限代號 */
    @Id
    @Column(name = "FUNCTION_CODE")
    private String code;

    /** 權限名稱 */
    @Column(name = "FUNCTION_NAME")
    private String name;

    /**
     * 權限層級 一般的三層結構:
     * 
     * 1:功能模塊 2:功能菜單(可嵌套) 3:功能按鈕(葉節點)
     */
    @Column(name = "LEVEL")
    private Integer level;

    /** 父權限 */
    @Column(name = "PARENT_CODE")
    private String parentCode;

    /** 依賴節點 */
    @Column(name = "DEPEND_CODE")
    private String dependCode;

    /** 是否葉節點 */
    @Column(name = "IS_LEAF")
    private Boolean isLeaf;

    /** 序號 */
    @Column(name = "ORDER_NO")
    private Integer orderNo;

    /** 子權限列表 */
    @Transient
    private List<Function> children = new ArrayList<>();

    /** 用於判斷Level 1 是否 具有 三層 */
    @Transient
    private Boolean hasThirdLevel;

    /** 是否選中 */
    @Transient
    private Boolean checked;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

    public String getDependCode() {
        return dependCode;
    }

    public void setDependCode(String dependCode) {
        this.dependCode = dependCode;
    }

    public Boolean getIsLeaf() {
        return isLeaf;
    }

    public void setIsLeaf(Boolean isLeaf) {
        this.isLeaf = isLeaf;
    }

    public List<Function> getChildren() {
        return children;
    }

    public void setChildren(List<Function> children) {
        this.children = children;
    }

    public Boolean getHasThirdLevel() {
        return hasThirdLevel;
    }

    public void setHasThirdLevel(Boolean hasThirdLevel) {
        this.hasThirdLevel = hasThirdLevel;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Function other = (Function) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

}
