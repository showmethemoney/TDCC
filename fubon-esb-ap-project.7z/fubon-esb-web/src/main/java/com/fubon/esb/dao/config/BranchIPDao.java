package com.fubon.esb.dao.config;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.BranchIP;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Repository
public class BranchIPDao extends JPADaoSupport<BranchIP> {

    public void saveBranchIP(String channelId, String[] ips) {
        if (ips != null && ips.length > 0) {
            for (String ip : ips) {
                BranchIP newBranchIP = new BranchIP(channelId, ip);
                jpaAccess.save(newBranchIP);
            }
        }
    }

    public List<BranchIP> findByChanelId(String channelId) {
        Query query = Query.from(BranchIP.class).where("channelId=:channelId").param("channelId", channelId);
        return jpaAccess.find(query);
    }

    public void addBranchIPList(List<BranchIP> bips) {
        for (BranchIP bp : bips) {
            jpaAccess.save(bp);
        }
    }

    public void removeBranchIPList(List<BranchIP> bips) {
        for (BranchIP bp : bips) {
            jpaAccess.delete(bp);
        }
    }

    public void deleteByChannelId(String id) {
        jpaAccess.update(Query.create("delete " + BranchIP.class.getName() + " where channelId=:channelId").param("channelId", id));
    }

    public List<BranchIP> findByIP(String ip) {
        Query query = Query.from(BranchIP.class).where("ip=:ip").param("ip", ip);
        return jpaAccess.find(query);
    }
    
    public List<String> findIPsByChannelId(String channelId) {
        StringBuilder jql = new StringBuilder().append("select ip from ").append(BranchIP.class.getName())
                .append(" where channelId = :channelId");
        Query query = Query.create(jql.toString());
        query.param("channelId", channelId);
        return jpaAccess.find(query);
    }
    
}
