package com.fubon.esb.domain.txn;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * 電文定義
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "TXN_DEFINITION")
public class TxnDefinition {

    public static final String INIT_MAIN_ID = "0";

    /** ID **/
    @Id
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    @Column(name = "ID")
    private String id;

    /** 交易代號 **/
    @Column(name = "TXN_DEF_CODE")
    private String txnCode;

    /** 格式名稱 **/
    @Column(name = "TXN_DEF_NAME")
    private String name;

    /** 分類編號 **/
    @Column(name = "GROUPZ")
    private String group;

    /** 單位代碼 **/
    @Column(name = "BRANCH_CODE")
    private String branchCode;

    /** 狀態{M:Main正式版本,E:Edited編輯版本(暫存),S:Saved存儲版本(待復核)} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "TXN_DEF_STATUS")
    private TxnStatus status;

    /** 對應正本 **/
    @Column(name = "MAIN_ID")
    private String mainId;

    /** 創建/更新者 **/
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 創建/更新時間 **/
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTime;

    /** 復核者 **/
    @Column(name = "APPROVED_USER")
    private String approvedUser;

    /** 復核時間 **/
    @Column(name = "APPROVED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date approvedTime;

    /******* page inject enum ********/
    public void setStatusP(String status) {
        for (TxnStatus ts : TxnStatus.values()) {
            if (ts.toString().equals(status)) {
                this.status = ts;
                break;
            }
        }
    }

    /***************/

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public TxnStatus getStatus() {
        return status;
    }

    public void setStatus(TxnStatus status) {
        this.status = status;
    }

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getApprovedUser() {
        return approvedUser;
    }

    public void setApprovedUser(String approvedUser) {
        this.approvedUser = approvedUser;
    }

    public Date getApprovedTime() {
        return approvedTime;
    }

    public void setApprovedTime(Date approvedTime) {
        this.approvedTime = approvedTime;
    }

}
