package com.fubon.esb.service.config;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.config.MailGroupDao;
import com.fubon.esb.dao.config.MailItemDao;
import com.fubon.esb.dao.config.MailPhoneDao;
import com.fubon.esb.domain.config.MailGroup;
import com.fubon.esb.domain.config.MailItem;
import com.fubon.esb.domain.config.MailPhone;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-11
 */

@Service
public class MailGroupService {

    @Inject
    private MailGroupDao mailGroupDao;
    @Inject
    private MailItemDao mailItemDao;
    @Inject
    private Messages messages;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private MailPhoneDao mailPhoneDao;

    public List<MailGroup> findMailGroups(String code, String name) {
        return mailGroupDao.findMailGroups(code, name);
    }

    public List<MailGroup> findAllMailGroups() {
        return mailGroupDao.findAllMailGroups();
    }

    @Transactional
    public void saveOrUpdate(MailGroup mailGroup, String[] mails, String[] phones) throws DuplicatedException {
        if (StringUtils.isNotBlank(mailGroup.getId())) {
            MailGroup oldMailGroup = getById(mailGroup.getId());
            String oldCode = oldMailGroup.getCode();
            String oldName = oldMailGroup.getName();
            updateMailGroup(mailGroup, mails, phones);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改 Email 通知群組管理。群組代號：" + oldCode + "，群組名稱：" + oldName, LogType.SYS_CFG_MAIL_GROUP);
        } else {
            mailGroup.setId(null);
            saveMailGroup(mailGroup, mails, phones);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增Email 通知群組管理。群組代號：" + mailGroup.getCode() + "，群組名稱：" + mailGroup.getName(), LogType.SYS_CFG_MAIL_GROUP);
        }
    }

    public void saveMailGroup(MailGroup mailGroup, String[] mails, String[] phones) throws DuplicatedException {
        if (validMailCodeDuplicate(mailGroup.getCode())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        mailGroupDao.save(mailGroup);
        mailItemDao.saveMailItems(mailGroup.getId(), mails);
        mailPhoneDao.saveMailPhones(mailGroup.getId(), phones);
    }

    public void updateMailGroup(MailGroup mailGroup, String[] mails, String[] phones) throws DuplicatedException {
        if (validMailCodeDuplicate(mailGroup)) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        mailGroupDao.update(mailGroup);
        updateMailItemList(mailGroup.getId(), mails);
        updateMialPhoneList(mailGroup.getId(), phones);

    }

    @Transactional
    public void removeMailGroup(String id) {
        MailGroup mailGroup = getById(id);
        String code = mailGroup.getCode();
        String name = mailGroup.getName();
        mailGroupDao.removeMailGroup(id);
        mailItemDao.removeByGroupId(id);
        mailPhoneDao.removeByGroupId(id);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "刪除Email 通知群組管理，群組代號：" + code + "，群組名稱：" + name, LogType.SYS_CFG_MAIL_GROUP);

    }

    public List<MailItem> createNewMailGroupList(String groupId, String[] mails) {
        List<MailItem> mailItems = new ArrayList<>();
        if (mails != null && mails.length > 0) {
            for (String mail : mails) {
                mailItems.add(new MailItem(groupId, mail));
            }
        }
        return mailItems;
    }

    @SuppressWarnings("unchecked")
    public void updateMailItemList(String groupId, String[] mails) {
        List<MailItem> newMailItemList = createNewMailGroupList(groupId, mails);
        List<MailItem> oldMailItemList = mailItemDao.findMailItems(groupId);
        if (!CollectionUtils.isEqualCollection(oldMailItemList, newMailItemList)) {
            List<MailItem> sameMailItemList = (List<MailItem>) CollectionUtils.retainAll(oldMailItemList, newMailItemList);
            newMailItemList.removeAll(sameMailItemList);
            oldMailItemList.removeAll(sameMailItemList);
            mailItemDao.removeMailItemList(oldMailItemList);
            mailItemDao.addMailItemList(newMailItemList);
        }

    }

    public List<MailPhone> createNewMailPhoneList(String groupId, String[] phones) {
        List<MailPhone> mailPhones = new ArrayList<>();
        if (phones != null && phones.length > 0) {
            for (String phone : phones) {
                mailPhones.add(new MailPhone(groupId, phone));
            }
        }
        return mailPhones;
    }

    @SuppressWarnings("unchecked")
    public void updateMialPhoneList(String groupId, String[] phones) {
        List<MailPhone> newMailPhoneList = createNewMailPhoneList(groupId, phones);
        List<MailPhone> oldMailPhoneList = mailPhoneDao.findMailPhones(groupId);
        if (!CollectionUtils.isEqualCollection(oldMailPhoneList, newMailPhoneList)) {
            List<MailPhone> sameMailPhoneList = (List<MailPhone>) CollectionUtils.retainAll(oldMailPhoneList, newMailPhoneList);
            newMailPhoneList.removeAll(sameMailPhoneList);
            oldMailPhoneList.removeAll(sameMailPhoneList);
            mailPhoneDao.removeMailPhoneList(oldMailPhoneList);
            mailPhoneDao.addMailPhoneList(newMailPhoneList);
        }

    }

    public List<MailItem> findMailItems(String groupId) {
        return mailItemDao.findMailItems(groupId);
    }

    public List<MailPhone> fndMailPhones(String groupId) {
        return mailPhoneDao.findMailPhones(groupId);
    }

    public MailGroup getById(String id) {
        return mailGroupDao.getlById(id);
    }

    public boolean validMailCodeDuplicate(String code) {
        return mailGroupDao.codeDuplicate(code);
    }

    public boolean validMailCodeDuplicate(MailGroup mailGroup) {
        MailGroup updateMailGroup = getById(mailGroup.getId());
        String oldCode = updateMailGroup.getCode();
        return !oldCode.equals(mailGroup.getCode()) && mailGroupDao.codeDuplicate(mailGroup.getCode());
    }

    public String findMailsByGroupId(String groupId) {
        List<MailItem> mailItemList = mailItemDao.findMailItems(groupId);
        String mails = "";
        StringBuilder mailsBuilder = new StringBuilder();
        if (!mailItemList.isEmpty()) {
            for (MailItem mailItem : mailItemList) {
                mailsBuilder.append(mailItem.getMail()).append(",");
            }
        }
        mails = mailsBuilder.toString();
        if (!mails.isEmpty()) {
            mails = mails.substring(0, mails.length() - 1);
        }
        return mails;
    }

    public String findPhonesByGroupId(String groupId) {
        List<MailPhone> mailPhoneList = mailPhoneDao.findMailPhones(groupId);
        String phones = "";
        StringBuilder phonesBuilder = new StringBuilder();
        if (!mailPhoneList.isEmpty()) {
            for (MailPhone mailPhone : mailPhoneList) {
                phonesBuilder.append(mailPhone.getPhone()).append(",");
            }
        }
        phones = phonesBuilder.toString();
        if (!phones.isEmpty()) {
            phones = phones.substring(0, phones.length() - 1);
        }
        return phones;
    }
}
