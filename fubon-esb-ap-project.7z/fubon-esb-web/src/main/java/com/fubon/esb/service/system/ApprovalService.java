package com.fubon.esb.service.system;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.system.view.ApprovalSearchVO;
import com.fubon.esb.dao.system.FunctionDao;
import com.fubon.esb.dao.system.GroupDao;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.dao.system.UserConfigDao;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Function;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.log.ApprovalLogService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-6
 */
@Service
public class ApprovalService {

    @Inject
    private GroupDao groupDao;

    @Inject
    private RoleDao roleDao;

    @Inject
    private UserConfigDao userConfigDao;

    @Inject
    private FunctionDao functionDao;

    @Inject
    private RoleService roleService;

    @Inject
    private Messages messages;

    @Inject
    private GroupService groupService;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private ApprovalLogService approvalLogService;

    @Inject
    private LoginContext loginContext;

    public List<ApprovalLog> findAllGroupRoleForApproval(ApprovalSearchVO vo) {
        List<ApprovalLog> approvalLogs = new ArrayList<>();
        approvalLogs.addAll(groupDao.findGroupsToAppoval(vo));
        approvalLogs.addAll(roleDao.findRolesToAppoval(vo));

        for (ApprovalLog approvalLog : approvalLogs) {
            setUpForApproval(approvalLog); // 填充頁面需要的數據
        }

        return approvalLogs;
    }

    /**
     * 為覆核Log裝配信息
     */
    public void setUpForApproval(ApprovalLog approvalLog) {
        approvalLog.setGroup(groupDao.getGroupById(approvalLog.getGroupId()));
        if (StringUtils.isNotBlank(approvalLog.getRoleId())) {
            // 角色修改
            approvalLog.setRole(roleDao.getRoleById(approvalLog.getRoleId()));
        }
    }

    /**
     * 獲取具體覆核信息
     */
    public ApprovalLog getApprovalLog(String groupId, String roleId) {
        if (StringUtils.isBlank(roleId)) {
            // 群組覆核
            return groupService.getGroupApprovalLogByGroupId(groupId);
        } else {
            // 角色覆核
            return getRoleApprovalLogByRoleId(roleId);
        }
    }

    private ApprovalLog getRoleApprovalLogByRoleId(String roleId) {
        ApprovalLog approvalLog = new ApprovalLog();

        Role role = roleDao.get(roleId);
        Role oldRole = null;
        if (!"0".equals(role.getMainId())) {
            oldRole = roleDao.get(role.getMainId());
        }

        Group group = groupDao.get(role.getGroupId());
        approvalLog.setGroup(group);
        approvalLog.setRole(role);
        approvalLog.setModifyFlag(role.getModifyFlag());
        approvalLog.setUpdatedUser(role.getUpdatedUser());
        approvalLog.setUpdatedTime(role.getUpdatedTime());
        approvalLog.setModifyContent(getRoleModifyContent(role, oldRole));

        return approvalLog;
    }

    private String getRoleModifyContent(Role newRole, Role oldRole) {
        if (oldRole == null) {
            return getRoleModifyContentForNew(newRole);
        }

        StringBuilder content = new StringBuilder();

        if (roleService.isModifyFlagMatch(newRole, 1)) {
            if (!newRole.getName().equals(oldRole.getName())) {
                content.append(getMessage("system.approval.role.name")).append("-").append(newRole.getName()).append("\r\n");
            }
            if (!newRole.getStatus().equals(oldRole.getStatus())) {
                content.append(getMessage("system.approval.role.status")).append("-").append(groupService.getStatus(newRole.getStatus())).append("\r\n");
            }
            if (!newRole.getDesc().equals(oldRole.getDesc())) {
                content.append(getMessage("system.approval.role.desc")).append("-").append(newRole.getDesc()).append("\r\n");
            }
            content.append(compareRelativeUsers(newRole, oldRole));
        }
        if (roleService.isModifyFlagMatch(newRole, 2)) {
            content.append(compareRelativeFuncs(newRole, oldRole));
        }
        return content.toString();
    }

    private String getRoleModifyContentForNew(Role newRole) {
        StringBuilder content = new StringBuilder();
        if (roleService.isModifyFlagMatch(newRole, 1)) {
            if (StringUtils.isNotBlank(newRole.getName())) {
                content.append(getMessage("system.approval.role.name")).append("-").append(newRole.getName()).append("\r\n");
            }
            if (newRole.getStatus() != null) {
                content.append(getMessage("system.approval.role.status")).append("-").append(groupService.getStatus(newRole.getStatus())).append("\r\n");
            }
            if (StringUtils.isNotBlank(newRole.getDesc())) {
                content.append(getMessage("system.approval.role.desc")).append("-").append(newRole.getDesc()).append("\r\n");
            }
            content.append(compareRelativeUsers(newRole, null));
        }
        if (roleService.isModifyFlagMatch(newRole, 2)) {
            content.append(compareRelativeFuncs(newRole, null));
        }
        return content.toString();
    }
    
    private String compareRelativeUsers(Role newRole, Role oldRole) {
        StringBuilder sb = new StringBuilder();

        List<UserConfig> newUsers = userConfigDao.findUserListByRole(newRole.getId());
        List<UserConfig> oldUsers = null;
        if (oldRole != null) {
            oldUsers = userConfigDao.findUserListByRole(oldRole.getId());
        }
        if (newUsers == null) {
            newUsers = new ArrayList<>();
        }
        if (oldUsers == null) {
            oldUsers = new ArrayList<>();
        }

        if (!CollectionUtils.isEqualCollection(newUsers, oldUsers)) {
            @SuppressWarnings("unchecked")
            List<UserConfig> sameUsers = (List<UserConfig>) CollectionUtils.retainAll(newUsers, oldUsers);
            newUsers.removeAll(sameUsers);
            oldUsers.removeAll(sameUsers);
            for (UserConfig user : newUsers) {
                sb.append(getMessage("system.approval.role.branch.add")).append(" ").append(user.getUserId()).append(";");
            }
            sb.append("\r\n");
            for (UserConfig user : oldUsers) {
                sb.append(getMessage("system.approval.role.branch.del")).append(" ").append(user.getUserId()).append(";");
            }
            sb.append("\r\n");
        }

        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private String compareRelativeFuncs(Role newRole, Role oldRole) {
        StringBuilder sb = new StringBuilder();

        List<Function> newFunctions = functionDao.findFunctionByRole(newRole.getId());
        List<Function> oldFunctions = null;
        if (oldRole != null) {
            oldFunctions = functionDao.findFunctionByRole(oldRole.getId());
        }
        if (newFunctions == null) {
            newFunctions = new ArrayList<>();
        }
        if (oldFunctions == null) {
            oldFunctions = new ArrayList<>();
        }

        if (!CollectionUtils.isEqualCollection(newFunctions, oldFunctions)) {
            List<Function> sameFunctions = (List<Function>) CollectionUtils.retainAll(newFunctions, oldFunctions);
            newFunctions.removeAll(sameFunctions);
            oldFunctions.removeAll(sameFunctions);
            for (Function function : newFunctions) {
                sb.append(getMessage("system.approval.role.func.add")).append(" ").append(getFuncFullName(function)).append(";"); // TODO(func full name)
            }
            sb.append("\r\n");
            for (Function function : oldFunctions) {
                sb.append(getMessage("system.approval.role.func.del")).append(" ").append(getFuncFullName(function)).append(";");
            }
            sb.append("\r\n");
        }

        return sb.toString();
    }

    private String getFuncFullName(Function function) {
        Function tmpFunc = function;
        String funcName = tmpFunc.getName();
        while (StringUtils.isNotBlank(tmpFunc.getParentCode())) {
            tmpFunc = functionDao.get(tmpFunc.getParentCode());
            funcName = tmpFunc.getName() + "-" + funcName;
        }
        return funcName;
    }

    @Transactional
    public void runApproval(String groupId, String roleId, String modifyContent) throws Exception {
        Integer modifyFlag = 0;
        if (StringUtils.isBlank(roleId)) {
            // 群組覆核 TODO(生成log)
            Group group = groupDao.getGroupById(groupId);
            if (group.getUpdatedUser().equals(loginContext.loginedUserId())) {
                throw new Exception(getMessage("system.approval.disabled"));
            }
            modifyFlag = group.getModifyFlag();
            if ("0".equals(group.getMainId())) {
                group.setMainId(null);
                group.setModifyFlag(null);
                groupDao.update(group);
            } else {
                Group origin = new Group();
                BeanUtils.copyProperties(group, origin, "id", "mainId", "modifyFlag");
                origin.setId(group.getMainId());
                groupDao.update(origin);
                groupDao.delete(group);
            }
            String message = getMessage("system_log_group_approval") + ": " + group.getName();
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message, LogType.SYS_FUNC_APPROVAL); // log
            approvalLogService.addGroupApprovalLog(group, modifyContent, modifyFlag); // 覆核日誌

        } else {
            // 角色覆核
            Role role = roleDao.get(roleId);
            if (role.getUpdatedUser().equals(loginContext.loginedUserId())) {
                throw new Exception(getMessage("system.approval.disabled"));
            }
            modifyFlag = role.getModifyFlag();
            if ("0".equals(role.getMainId())) {
                role.setMainId(null);
                role.setModifyFlag(null);
                roleDao.update(role);
            } else {
                Role origin = new Role();
                BeanUtils.copyProperties(role, origin, "id", "mainId", "modifyFlag");
                origin.setId(role.getMainId());
                roleService.approvalRole(origin, role);
            }
            String message = getMessage("system_log_role_approval") + ": " + role.getName();
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message, LogType.SYS_FUNC_APPROVAL);
            approvalLogService.addRoleApprovalLog(role, modifyContent, modifyFlag); // 覆核日誌
        }
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

}
