package com.fubon.esb.controller.config.view;

import java.util.List;

import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Service;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.TxnGroup;

/**
 * @author Qigers
 * @createdDate 2014-11-24
 */
public class TxnExportExcelVO {
    private Txn txn;
    private TxnGroup txnGroup;
    private Service service;
    private Channel channel;
    private TxnChannel txnChannel;
    private Connector connector;
    private Host host;
    private TxnConfigExcelVO txnConfigExcelVO;

    private List<String> channelCodes;
    private List<String> relatedTxnCodes;

    public TxnExportExcelVO(Txn txn, TxnGroup txnGroup, Service service, Channel channel, TxnChannel txnChannel) {
        super();
        this.txn = txn;
        this.txnGroup = txnGroup;
        this.service = service;
        this.channel = channel;
        this.txnChannel = txnChannel;

    }

    public TxnExportExcelVO(TxnExportExcelVO txnvo, Connector connector, Host host) {
        super();
        this.txn = txnvo.getTxn();
        this.txnGroup = txnvo.getTxnGroup();
        this.service = txnvo.getService();
        this.channel = txnvo.getChannel();
        this.txnChannel = txnvo.getTxnChannel();
        this.connector = connector;
        this.host = host;
    }

    public TxnExportExcelVO() {

    }

    public Txn getTxn() {
        return txn;
    }

    public void setTxn(Txn txn) {
        this.txn = txn;
    }

    public TxnGroup getTxnGroup() {
        return txnGroup;
    }

    public void setTxnGroup(TxnGroup txnGroup) {
        this.txnGroup = txnGroup;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public Connector getConnector() {
        return connector;
    }

    public void setConnector(Connector connector) {
        this.connector = connector;
    }

    public Host getHost() {
        return host;
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public TxnChannel getTxnChannel() {
        return txnChannel;
    }

    public void setTxnChannel(TxnChannel txnChannel) {
        this.txnChannel = txnChannel;
    }

    public List<String> getChannelCodes() {
        return channelCodes;
    }

    public void setChannelCodes(List<String> channelCodes) {
        this.channelCodes = channelCodes;
    }

    public List<String> getRelatedTxnCodes() {
        return relatedTxnCodes;
    }

    public void setRelatedTxnCodes(List<String> relatedTxnCodes) {
        this.relatedTxnCodes = relatedTxnCodes;
    }

    public TxnConfigExcelVO getTxnConfigExcelVO() {
        return txnConfigExcelVO;
    }

    public void setTxnConfigExcelVO(TxnConfigExcelVO txnConfigExcelVO) {
        this.txnConfigExcelVO = txnConfigExcelVO;
    }
}
