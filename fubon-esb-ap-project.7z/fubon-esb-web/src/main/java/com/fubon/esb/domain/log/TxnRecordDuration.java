package com.fubon.esb.domain.log;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Ethan Lee 
 */
@Entity(name = "TXN_RECORD_DURATION")
public class TxnRecordDuration implements Serializable 
{
    /** ID **/
    @Id
    @Column(name = "ID")
    private String id;
    
	/** Tracking ID **/
    @Column(name = "TRACKING_ID")
    private String trackingId;

    /** 處理時間 **/
    @Column(name = "DURATION")
    private String duration;

    /** 創建時間 **/
    @Column(name = "CREATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

	public String getId() {
		return id;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public String getDuration() {
		return duration;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
}
