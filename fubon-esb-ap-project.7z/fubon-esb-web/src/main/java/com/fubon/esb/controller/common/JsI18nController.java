package com.fubon.esb.controller.common;

import java.io.IOException;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.comwave.core.platform.i18n.Messages;

@Controller
public class JsI18nController {

    private final Logger logger = LoggerFactory.getLogger(JsI18nController.class);

    @Inject
    private Messages message;

    @RequestMapping(value = "/js/resource")
    public void getMessages(@RequestParam(value = "key[]") String[] keys, HttpServletRequest request, HttpServletResponse response, Locale locale) {
        response.setCharacterEncoding("utf-8");
        response.setContentType("application/javascript");
        StringBuilder contents = new StringBuilder("if(!window.i18n){var i18n = window.i18n = {}}");
        if (keys != null && keys.length > 0) {

            for (String key : keys) {
                String value = message.getMessage(key);
                contents.append("i18n['" + key + "']=\"" + value + "\";");
            }
        }
        try {
            response.getWriter().write(contents.toString());
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }
}
