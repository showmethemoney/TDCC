package com.fubon.esb.controller.config.view;

import com.fubon.esb.domain.config.ConfigActiveStatus;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
public class ChannelQueryParam {

    private String code;
    private String name;
    private String workstationId;
    private ConfigActiveStatus status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkstationId() {
        return workstationId;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

    public void setWorkstationId(String workstationId) {
        this.workstationId = workstationId;
    }

}
