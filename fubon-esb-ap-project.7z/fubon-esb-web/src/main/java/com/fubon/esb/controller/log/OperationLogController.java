package com.fubon.esb.controller.log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.log.view.OperationLogSearchVO;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Qigers
 * @createdDate 2014-11-10
 */
@Controller
@RequestMapping(value = "/operationLog")
public class OperationLogController extends BaseController {

    @Inject
    private OperationLogService operationLogService;

    @RequestMapping(value = "/viewOperationLogList", method = RequestMethod.GET)
    @RequirePermission(value = "060101")
    public String viewOperationLogList(Model model, @RequestParam(required = false) String message, OrderBy orderBy, OperationLogSearchVO vo) {
        Page page = new Page(1);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String today = sdf.format(date);
        vo.setStartDate(today);
        vo.setEndDate(today);
        model.addAttribute("page", page);
        model.addAttribute("operationLoglist", null); // 分頁查詢信息
        model.addAttribute("logs", operationLogService.getFuncList()); // 功能分類
        model.addAttribute("vo", vo);
        model.addAttribute("orderPicUrl", setOrderPicUrl(orderBy));
        model.addAttribute("orderBy", orderBy);
        return "/log/viewOperationLogList";
    }

    @RequestMapping(value = "/viewOperationLogList", method = RequestMethod.POST)
    @RequirePermission(value = "060101")
    public String viewOperationLogList(Model model, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") Integer currentPage, OperationLogSearchVO vo,
            @RequestParam(required = false) Boolean isSearch) {
        String message = vo.getMessage();
        Page page;
        if (vo.getFlag()) {
            page = new Page(1);
        } else {
            page = new Page(currentPage);
        }
        page.setPageSize(50);
        @SuppressWarnings("unchecked")
        List<OperationLog> operationLoglist = (List<OperationLog>) operationLogService.findOperationLogPageList(vo, orderBy, page, message, isSearch);
        model.addAttribute("operationLoglist", operationLoglist); // 分頁查詢信息
        model.addAttribute("page", page);
        model.addAttribute("vo", vo);
        model.addAttribute("message", message);
        model.addAttribute("logs", operationLogService.getFuncList()); // 功能分類
        model.addAttribute("orderPicUrl", setOrderPicUrl(orderBy));
        model.addAttribute("orderBy", orderBy);
        model.addAttribute("page", page);
        return "/log/viewOperationLogList";
    }

    public String setOrderPicUrl(OrderBy orderBy) {
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            return "normal.gif";
        } else if (orderBy.isAsc()) {
            return "up.gif";
        } else {
            return "down.gif";
        }
    }
}
