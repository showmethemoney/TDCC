package com.fubon.esb.dao.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.system.view.ApprovalSearchVO;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.RoleBranch;
import com.fubon.esb.domain.system.RoleUser;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Repository
public class RoleDao extends JPADaoSupport<Role> {
    
    @Inject
    private TimeZoneService timeZoneService;

    public void saveRole(Role role) {
        jpaAccess.save(role);
    }

    public void updateRole(Role role) {
        jpaAccess.update(role);
    }

    /**
     * 根據GroupId查出Group下頂層Role 列表
     */
    public List<Role> findRoleListByGroupId(String groupId) {
        return jpaAccess.find(Query.create(
                "select r from " + Role.class.getName() + " r where r.groupId = :groupId and ( r.mainId is null or r.mainId ='0' ) ")
                .param("groupId", groupId));
    }
    
    public Role getRoleById(String id) {
        return jpaAccess.get(Role.class, id);
    }
    
    public Role getRoleByMainId(String mainId) {
        return jpaAccess.findOne(Query.from(Role.class).where("mainId = :id").param("id", mainId));
    }
    
    public List<ApprovalLog> findRolesToAppoval(ApprovalSearchVO vo) {
        StringBuilder jql = new StringBuilder();
        jql.append("select new ").append(ApprovalLog.class.getName()).append("(r.groupId, r.id, r.modifyFlag, r.updatedUser, r.updatedTime) from ")
        .append(Role.class.getName()).append(" r , ").append(Group.class.getName())
        .append(" g where r.groupId = g.id and  r.mainId is not null  ");
        Map<String, Object> params = new HashMap<String, Object>();
        
        if (StringUtils.isNotBlank(vo.getRoleName())) {
            jql.append(" and r.name like :roleName ");
            params.put("roleName", "%" + vo.getRoleName() + "%");
        }
        if (StringUtils.isNotBlank(vo.getGroupName())) {
            jql.append(" and g.name like :groupName ");
            params.put("groupName", "%" + vo.getGroupName() + "%");
        }
        if (StringUtils.isNotBlank(vo.getUpdatedUser())) {
            jql.append(" and r.updatedUser like :user ");
            params.put("user", "%" + vo.getUpdatedUser() + "%");
        }
        if (vo.getStartDate() != null) {
            jql.append(" and r.updatedTime >= :start");
            params.put("start", timeZoneService.getTZDateByService(vo.getStartDate()));
        }
        if (vo.getEndDate() != null) {
            jql.append(" and r.updatedTime <= :end");
            params.put("end", timeZoneService.getTZDateByService(vo.getEndDate()));
        }
        
        Query query = Query.create(jql.toString());
        query.putParams(params);
        
        List<ApprovalLog> approvalLogs = jpaAccess.find(query);
        if (approvalLogs == null) {
            return new ArrayList<>();
        }
        return approvalLogs;
    }
    
    public List<Role> findRolesByGroupBranch(List<String> groupIds, String branchCode) {
        StringBuilder jql = new StringBuilder();
        jql.append("select r from ").append(Role.class.getName()).append(" r, ").append(RoleBranch.class.getName())
        .append(" rb where r.id=rb.roleId and r.mainId is null and r.status=:active and rb.branchCode=:branchCode and r.groupId in :groupIds ");
        Query query = Query.create(jql.toString());
        query.param("branchCode", branchCode);
        query.param("groupIds", groupIds);
        query.param("active", ActiveStatus.A);
        return jpaAccess.find(query);
    }
    
    public List<Role> findRoleByUserId(String userId) {
        StringBuilder jql = new StringBuilder("select r  from ").append(Role.class.getName())
                .append(" r,  ")
                .append(Group.class.getName())
                .append(" g  where g.id=r.groupId and g.status=:status and g.mainId is null and  r.mainId is null and r.status=:status and exists (")
                .append(" from ")
                .append(RoleUser.class.getName())
                .append(" ru where ru.roleId = r.id and exists ( from ")
                .append(UserConfig.class.getName()).append(" u where u.id = ru.userId and u.userId=:userId")
                .append(")").append(")")
                ;
        return jpaAccess.find(Query.create(jql.toString()).param("userId", userId).param("status", ActiveStatus.A));
    }
    
    public List<Role> findRoleByADGroup(String adGroup) {
        StringBuilder jql = new StringBuilder("from ")
            .append(Role.class.getName())
            .append(" where mainId is null and groupId in ( select g.id  from ")
            .append(Group.class.getName())
            .append(" g where g.adGroup = :adGroup )")
        ;
        return jpaAccess.find(Query.create(jql.toString()).param("adGroup", adGroup));
    }
    
}
