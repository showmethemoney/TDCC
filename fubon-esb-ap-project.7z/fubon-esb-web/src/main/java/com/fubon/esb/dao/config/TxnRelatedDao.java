package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.TxnRelated;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-7
 */
@Repository
public class TxnRelatedDao extends JPADaoSupport<TxnRelated> {

    public void saveTxnRelateds(String txnId, String relatedIds) {
        if (relatedIds != null && !relatedIds.isEmpty()) {
            String ids[] = relatedIds.split(",");
            for (String id : ids) {
                if (StringUtils.isNotBlank(id)) {
                    TxnRelated txnRelated = new TxnRelated(txnId, id);
                    jpaAccess.save(txnRelated);
                }
            }
        }
    }

    public List<TxnRelated> findByTxnId(String txnId) {
        Query query = Query.from(TxnRelated.class).where("txnId = :txnId").param("txnId", txnId);
        return jpaAccess.find(query);
    }

    public void addTxnRelatedList(List<TxnRelated> txnRelateds) {
        for (TxnRelated txnRelated : txnRelateds) {
            jpaAccess.save(txnRelated);
        }
    }

    public void removeTxnRelatedlList(List<TxnRelated> txnRelateds) {
        for (TxnRelated txnRelated : txnRelateds) {
            jpaAccess.delete(txnRelated);
        }
    }

    public void deleteByTxnId(String txnId) {
        jpaAccess.update(Query.create("delete " + TxnRelated.class.getName() + " where txnId=:txnId").param("txnId", txnId));
    }
}
