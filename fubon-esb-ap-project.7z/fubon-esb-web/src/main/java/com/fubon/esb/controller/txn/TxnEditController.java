package com.fubon.esb.controller.txn;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.comwave.core.database.Page;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.permission.RequirePermission;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.EditTxn;
import com.fubon.esb.controller.txn.view.TxnExcelView;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.controller.txn.view.ZipCompressor;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.txn.TxnDefinitionService;
import com.fubon.esb.service.txn.TxnDirectionService;
import com.fubon.esb.service.txn.TxnExcelReadServcie;
import com.fubon.esb.service.txn.TxnExcelWriteService;
import com.fubon.esb.service.txn.TxnFieldDefinitionService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Controller
@RequestMapping({"/txn/edit"})
public class TxnEditController extends BaseController {
    @Inject
    private TxnDefinitionService txnDefService;
    @Inject
    private TxnDirectionService txnDirecService;
    @Inject
    private TxnFieldDefinitionService txnFieldService;
    @Inject
    private TxnService txnService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private TxnExcelReadServcie txnExcelReadServcie;
    @Inject
    private TxnExcelWriteService txnExcelWriteService;
    @Inject
    private Messages messages;
    private TxnExcelView txnExcelView;
    private static final String INCLUDE_BASE_URL = "txn/include/edit";

    @InitBinder
    public void initBinder() {
        txnExcelView = new TxnExcelView(txnService, txnExcelReadServcie, txnExcelWriteService);
    }

    @RequestMapping({"/list"})
    @RequirePermission(value = "010101")
    public String viewTxnList(Model model) {
        model.addAttribute("curUser", loginedUser() == null ? new User() : loginedUser());
        return "txn/viewEditTxnList";
    }

    @RequestMapping({"/search"})
    @RequirePermission(value = "010101")
    public String searchTxnList(Model model, @RequestParam(required = false) String txnCode, @RequestParam(required = false) String txnName, @RequestParam(required = false) String txnStatus,
            @RequestParam(defaultValue = "1") Integer curPage) {
        Page page = new Page(curPage);
        List<TxnDefinition> txnDefs = txnDefService.findPageByCodeNameAndStatusAddtion(txnCode, txnName, txnStatus, page);
        if (page.getTotalPage() != 0 && curPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            txnDefs = txnDefService.findPageByCodeNameAndStatusAddtion(txnCode, txnName, txnStatus, page);
        }
        model.addAttribute("txnDefis", txnDefs);
        model.addAttribute("page", page);
        return INCLUDE_BASE_URL + "/txnDefs";
    }

    @RequestMapping({"/add"})
    @RequirePermission(value = "010102")
    public String addTxn(Model model) throws Exception {
        return editTxn(model, null, false);
    }

    @RequestMapping({"/edit/{defId}"})
    @RequirePermission(value = "010103")
    public String editTxn(Model model, @PathVariable("defId") String defId, @RequestParam(required = false, defaultValue = "false") Boolean tmpEdit) throws Exception {
        TxnVO txnVO = new TxnVO();
        if (StringUtils.isNotBlank(defId)) {
            TxnDefinition dbDef = txnDefService.getById(defId);
            if (TxnStatus.M.equals(dbDef.getStatus())) {
                txnVO = txnService.findTxnVO(txnService.getOrCreateCopyTxnDef(defId, loginedUserId()).getId());
            } else {
                txnVO = txnService.findTxnVO(defId);
            }
        }
        List<TxnDirection> headDirecs = txnDirecService.findHeadDirections();
        model.addAttribute("headDirecs", headDirecs == null ? new ArrayList<>() : headDirecs);
        model.addAttribute("maxOrder", txnFieldService.getMaxOrderByTxn(defId));
        model.addAttribute("curUser", loginedUser() == null ? new User() : loginedUser());
        model.addAttribute("tmpEdit", tmpEdit);
        txnVOModel(model, txnVO);
        return "txn/viewEditTxn";
    }

    public void txnVOModel(Model model, TxnVO txnVO) {
        model.addAttribute("txnDef", txnVO.getDefinition() == null ? new TxnDefinition() : txnVO.getDefinition());
        model.addAttribute("upDirec", txnVO.getUpDirection() == null ? new TxnDirection() : txnVO.getUpDirection());
        model.addAttribute("upFields", txnVO.getUpFields() == null ? new ArrayList<>() : txnVO.getUpFields());
        model.addAttribute("downDirec", txnVO.getDownDirection() == null ? new TxnDefinition() : txnVO.getDownDirection());
        model.addAttribute("downFields", txnVO.getDownFields() == null ? new ArrayList<>() : txnVO.getDownFields());
    }

    @ResponseBody
    @RequestMapping({"/delete/{defId}"})
    @RequirePermission(value = "010104")
    public Object ajaxDeleteTxn(Model model, @PathVariable("defId") String tid) {
        Map<String, Object> msg = new HashMap<String, Object>();
        TxnDefinition definition = txnDefService.getById(tid);
        if (definition != null && TxnStatus.M.equals(definition.getStatus())) {
            definition.setStatus(TxnStatus.D);
            txnDefService.saveOrUpdate(definition);
        } else {
            txnService.removeTxn(tid);
        }
        msg.put("success", true);
        return msg;
    }

    @ResponseBody
    @RequestMapping(value = {"/save"}, method = {RequestMethod.POST})
    public Object saveTxnFields(Model model, @RequestBody EditTxn editTxn, @RequestParam Boolean isTemp) throws Exception {
        Map<String, Object> msg = new HashMap<String, Object>();
        msg.put("success", true);
        TxnDefinition txnDef = editTxn.getTxnDefi();
        Assert.notNull(txnDef, "recieved txn definition can not be null!");
        if (txnDefService.isExistDefCodeButSelf(txnDef.getId(), txnDef.getMainId(), txnDef.getTxnCode())) {
            msg.put("success", false);
            msg.put("errorMsg", messages.getMessage("txn.definition.existed", txnDef.getTxnCode()));
            return msg;
        }
        if (isTemp.booleanValue()) {
            txnDef.setStatus(TxnStatus.E);
        } else {
            txnDef.setStatus(TxnStatus.S);
        }
        txnDef.setUpdatedUser(loginedUserId());
        txnDef.setUpdatedTime(new Date());
        txnService.saveOrUpdateEditTxn(txnDef, editTxn.getUpTxnDirec(), editTxn.getDownTxnDirec(), editTxn.getEtxnFields());
        return msg;
    }

    @RequestMapping({"/children"})
    public String getChildrenFields(Model model, @RequestParam String direction, @RequestParam String parentId, @RequestParam Integer beginIndex) {
        TxnFieldDefinition parentField = txnFieldService.getById(parentId);
        List<TxnFieldDefinition> txnFields = txnFieldService.findChildren(parentId);
        model.addAttribute("txnFields", txnFields);
        model.addAttribute("isChildFields", true);
        model.addAttribute("beginIndex", beginIndex);
        model.addAttribute("direction", direction);
        model.addAttribute("parentField", parentField);
        return INCLUDE_BASE_URL + "/txnFields";
    }

    @RequestMapping({"/newTr"})
    public String buildNewTrHtml(Model model, @RequestParam String fieldType) {
        List<TxnFieldDefinition> txnFields = new ArrayList<TxnFieldDefinition>();
        TxnFieldDefinition txnField = new TxnFieldDefinition();
        txnField.setFieldType(FieldType.valueOf(fieldType));
        txnFields.add(txnField);
        model.addAttribute("txnFields", txnFields);
        model.addAttribute("isNewTrHtml", true);
        return INCLUDE_BASE_URL + "/txnFields";
    }

    @ResponseBody
    @RequestMapping({"/search/defcodes"})
    public Object searchTxnCodes(@RequestParam String key) {
        return txnDefService.searchTxnCodes(key);
    }
    
    @ResponseBody
    @RequestMapping({"/search/defnames"})
    public Object searchTxnNames(@RequestParam String key) {
        return txnDefService.searchTxnDefnames(key);
    }

    @RequestMapping({"/readFromExcel"})
    @RequirePermission(value = "010107")
    public void readTxnFromExcel(Model model, MultipartHttpServletRequest request, HttpServletResponse response) throws Exception {
        TxnDefinition txnDef = new TxnDefinition();
        txnDef.setTxnCode(request.getParameter("txnCode"));
        txnDef.setName(request.getParameter("txnName"));
        txnDef.setGroup(request.getParameter("group"));
        txnDef.setBranchCode(request.getParameter("branchCode"));
        txnDef.setUpdatedUser(loginedUserId());
        txnDef.setUpdatedTime(timeZoneService.getTZDateByService(new Date()));
        txnDef.setMainId(TxnDefinition.INIT_MAIN_ID);
        txnDef.setStatus(TxnStatus.E);
        MultipartFile multipartFile = request.getFile("file_txn_excel");
        File uploadedFile = new File(ZipCompressor.ZIP_EXCEL_TEMP_DIR + "\\" + System.currentTimeMillis() + "\\" + multipartFile.getOriginalFilename());
        if (uploadedFile.exists()) {
            uploadedFile.delete();
        } else {
            uploadedFile.mkdirs();
        }
        multipartFile.transferTo(uploadedFile);
        response.setContentType("text/html;charset=utf-8");
        Map<String, Object> result = txnExcelView.saveTxnsFromUploadedFile(txnDef, uploadedFile, Boolean.valueOf(request.getParameter("isCompress")));
        ZipCompressor.clearZipDirection(uploadedFile.getParent());
        ObjectMapper objectMapper = JSONBinder.objectMapper();
        String jsonResult = objectMapper.writeValueAsString(result);
        response.getWriter().write(jsonResult);
        response.flushBuffer();
        response.getWriter().close();
    }

    @RequestMapping({"/reportTxnExcel"})
    @RequirePermission(value = "010105")
    public void writeToExcel(Model model, @RequestParam("defIds[]") String[] defIds, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TxnVO> txnVOs = new ArrayList<TxnVO>();
        if (defIds != null && defIds.length != 0) {
            for (String defId : defIds) {
                txnVOs.add(txnService.findTxnVOForExcel(defId));
            }
        }
        // one -report as excel file
        if (defIds != null && defIds.length == 1) {
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("txnExcelVO", txnService.findTxnVOForExcel(defIds[0]));
            txnExcelView.render(dataMap, request, response);
            return;
        }
        // mutiple - report as zip file
        txnExcelView.writeZipFileToResponse(txnVOs, request, response);
    }

    @ResponseBody
    @RequestMapping({"/isExsitFieldCode"})
    public Map<String, Boolean> checkIsExistByCode(@RequestParam String fieldCode, @RequestParam String dirId) {
        Map<String, Boolean> result = new HashMap<String, Boolean>(1);
        if (txnFieldService.findByTxnCode(fieldCode, dirId) == null) {
            result.put("isExist", Boolean.FALSE);
        } else {
            result.put("isExist", Boolean.TRUE);
        }
        return result;
    }

    @ResponseBody
    @RequestMapping({"/removeTmpEditTxn"})
    public Object removeTmpEditTxn(@RequestParam String defId) {
        txnService.removeTxn(defId);
        return true;
    }
}
