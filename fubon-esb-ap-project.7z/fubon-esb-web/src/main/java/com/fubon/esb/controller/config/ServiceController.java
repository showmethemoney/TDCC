package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.ServiceView;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Service;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.ServiceService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-3
 */
@Controller
@RequestMapping("/service")
public class ServiceController extends BaseController {

    @Inject
    private ServiceService serviceService;
    @Inject
    private LoginContext loginContext;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSearchService")
    public String viewServiceList(Model model) {
        return "/config/viewServiceList";
    }

    @RequirePermission(value = "050601")
    @RequestMapping("/viewServiceList")
    public String viewServiceList(Model model, ServiceView vs, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Service> services = serviceService.findLatestServices(vs, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            services = serviceService.findLatestServices(vs, page);
        }
        model.addAttribute("services", services);
        model.addAttribute("code", vs.getCode());
        model.addAttribute("name", vs.getName());
        model.addAttribute("status", vs.getStatus());
        model.addAttribute("txnCode", vs.getTxnCode());
        model.addAttribute("version", vs.getVersion());
        model.addAttribute("page", page);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        return "/config/viewServiceList";
    }

    @RequirePermission(value = {"050602", "050603"})
    @RequestMapping("/viewService")
    public String viewService(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) { // 修改
            isAdd = false;
            Service service = serviceService.getService(id);
            String txnCodes = serviceService.getTxnCodes(id);
            model.addAttribute("service", service);
            model.addAttribute("txnCodes", txnCodes);
        }
        model.addAttribute("isAdd", isAdd);
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewService";
    }
    
    
    @RequestMapping("/refreshService")
    @ResponseBody
    public Object refreshService(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
         
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_SERVICE, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    

    @RequestMapping("saveOrUpdateService")
    @ResponseBody
    public ResultView saveOrUpdateService(@Valid Service service, String effectDate, String effectHour, String effectMinute) {
        try {
            String serviceId = serviceService.saveOrUpdateService(service, effectDate, effectHour, effectMinute);
            configChangeService.sendChangeEvent(ConfigType.CFG_SERVICE, serviceId);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/service/viewServiceList");
    }

    @RequestMapping("/findTxns")
    @ResponseBody
    public Map<String, Object> findTxns(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Txn> txns = serviceService.findTxns(id);
        result.put("txns", txns);
        return result;
    }

    @RequestMapping("/findMainService")
    public String findMainService(Model model, String code, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Service> services = serviceService.findMainService(code, page);
        model.addAttribute("code", code);
        model.addAttribute("page", page);
        model.addAttribute("services", services);
        return "/config/include/viewMainServiceList";
    }

    @ResponseBody
    @RequestMapping({"/findMainServiceCodes"})
    public Object findMainServiceCodes(@RequestParam String key) {
        return autoQueryService.searchMainServiceCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findServiceCodes"})
    public Object findServiceCodes(@RequestParam String key) {
        return autoQueryService.searchServiceCodes(key);
    }

    @RequirePermission(value = "050601")
    @RequestMapping("/viewServiceDetail")
    public String viewServiceDetail(Model model, @RequestParam String id) {
        Service service = serviceService.getService(id);
        String txnCodes = serviceService.getTxnCodes(id);
        model.addAttribute("service", service);
        model.addAttribute("txnCodes", txnCodes);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewServiceDetail";
    }

    // 刪除
    @RequestMapping("/deleteService")
    @ResponseBody
    public Object deleteService(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = serviceService.isRelatedService(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + ",與以下交易相關聯" + relateMessage);
        } else {
            serviceService.deleteService(id);
            flag = true;
            result.put("flag", flag);
        }
        return result;
    }
}
