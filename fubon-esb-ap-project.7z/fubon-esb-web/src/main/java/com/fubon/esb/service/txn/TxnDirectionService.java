package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.comwave.core.database.Page;
import com.fubon.esb.controller.txn.view.EditTxnField;
import com.fubon.esb.dao.txn.TxnDirectionDao;
import com.fubon.esb.dao.txn.TxnFieldDefinitionDao;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;


/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Service
public class TxnDirectionService extends TxnLogService
{

	@Inject
	private TxnDirectionDao txnDirDao;

	@Inject
	private TxnFieldDefinitionDao txnFieldDao;

	@Inject
	private TxnFieldDefinitionService txnFieldService;

	public TxnDirection getById(String id) {
		return (TxnDirection) txnDirDao.get( id );
	}

	public TxnDirection getHeaderDirByName(String name) {
		List<TxnDirection> dirs = txnDirDao.findHeadDirsByName( name );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 );
		}
		return null;
	}

	public TxnDirection findByDefIdAndDirection(String defId, DirectionType direction) {
		if (StringUtils.isBlank( defId )) {
			return null;
		}
		Assert.notNull( direction, "search condition direction can not be null!" );
		TxnDirection dir = txnDirDao.findByDefIdAndDirAttachHeadName( defId, direction );
		if (dir == null) {
			dir = txnDirDao.findByDefIdAndDir( defId, direction );
		}
		return dir;
	}

	@Transactional
	public void saveOrUpdate(TxnDirection txnDir) {
		if (txnDir == null) {
			return;
		}
		String directionCN = "";
		if (StringUtils.isBlank( txnDir.getId() )) {
			txnDir.setId( null );
			txnDirDao.save( txnDir );
			if (DirectionType.U.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.up" );
			} else if (DirectionType.D.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.down" );
			}
			logToDB( messages.getMessage( "txn.edit.log.direction.add", directionCN, txnDir.getName() ) );
		} else {
			TxnDirection oldDir = getById( txnDir.getId() );
			if (DirectionType.U.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.up" );
			} else if (DirectionType.D.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.down" );
			}
			logToDB( messages.getMessage( "txn.edit.log.direction.update", directionCN, oldDir.getName() ) );
			BeanUtils.copyProperties( txnDir, oldDir );
			txnDirDao.save( oldDir );
		}
	}

	@Transactional
	public void saveOrUpdateHeader(TxnDirection txnDir) {
		if (txnDir == null) {
			return;
		}
		String directionCN = "";
		if (StringUtils.isBlank( txnDir.getId() )) {
			txnDir.setId( null );
			txnDirDao.save( txnDir );
			if (DirectionType.H.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.head" );
			}
			logToDB( messages.getMessage( "txn.edit.log.direction.add", directionCN, txnDir.getName() ) );
		} else {
			TxnDirection oldDir = getById( txnDir.getId() );
			if (DirectionType.H.equals( txnDir.getDirection() )) {
				directionCN = messages.getMessage( "txn.definition.head" );
			}
			logToDB( messages.getMessage( "txn.edit.log.direction.update", directionCN, oldDir.getName() ) );
			BeanUtils.copyProperties( txnDir, oldDir );
			txnDirDao.update( oldDir );
		}
	}

	public List<TxnDirection> getByTxnDefId(String txnDefId) {
		if (StringUtils.isBlank( txnDefId )) {
			return null;
		}
		return txnDirDao.getByTxnDefId( txnDefId );
	}

	public void removeByTxnDef(String txnDefId) {
		if (StringUtils.isBlank( txnDefId )) {
			return;
		}
		txnDirDao.removeByTxnDef( txnDefId );
	}

	public List<TxnDirection> findHeadDirections() {
		return txnDirDao.findHeadDirections();
	}

	/**
	 * 查询Header List
	 */
	public List<TxnDirection> findPageByCodeNameAndStatusAddtion(String name, String txnHeaderStatus, Page page) {
		TxnStatus txnStatus = null;
		if (StringUtils.isNotBlank( txnHeaderStatus )) {
			txnStatus = TxnStatus.valueOf( txnHeaderStatus );
		}
		return txnDirDao.findPageByCodeNameAndStatusAddtion( name, txnStatus, page );
	}

	public List<String> searchTxnDefnames(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDirDao.searchTxnNames( key );
	}

	public TxnDirection findHeadDirByID(String id) {
		return txnDirDao.findHeadDirByID( id );
	}

	@Transactional
	public void removeTxnHeaderById(String id) {
		if (StringUtils.isBlank( id ))
			return;
		txnFieldDao.removeByTxnDirection( id );
		txnDirDao.removeTxnHeaderById( id );
	}

	/** mainId=null update **/
	@Transactional
	public TxnDirection getOrCreateCopyTxnDirec(TxnDirection direction, String mainId, String userId) {
		if (StringUtils.isBlank( mainId )) {
			return null;
		}
		Assert.notNull( direction, "main direction can not be null!" );
		TxnDirection createDirec = new TxnDirection();
		BeanUtils.copyProperties( direction, createDirec );
		createDirec.setId( null );
		createDirec.setMainId( mainId );
		createDirec.setTxnHeaderStatus( TxnStatus.E );
		createDirec.setUpdatedUser( userId );
		Date currDate = new Date();
		createDirec.setUpdatedTime( currDate );
		createDirec.setCreateTime( currDate );
		saveOrUpdate( createDirec );
		List<TxnFieldDefinition> createFields = txnFieldService.findMainsByDirId( mainId );
		EditTxnField[] eFields = new EditTxnField[createFields.size()];
		for (int index = 0; index < createFields.size(); index++) {
			TxnFieldDefinition tfd = new TxnFieldDefinition();
			BeanUtils.copyProperties( createFields.get( index ), tfd );
			tfd.setDirectionId( createDirec.getId() );
			tfd.setId( null );
			EditTxnField field = new EditTxnField();
			field.setEditType( EditTxnField.EDIT_TYPE_ADD );
			field.setTxnField( tfd );
			eFields[index] = field;
		}
		txnFieldService.batchProcessHeaderFromVOs( eFields, createDirec.getId(), false );
		return createDirec;
	}

	public TxnDirection findHeadDirByMainID(String mainId) {
		return txnDirDao.findHeadDirByMainID( mainId );
	}

	/**
	 * 复核列表List
	 */
	public List<TxnDirection> searchWaitToCheckTxnDirecs(String name, Page page) {
		List<TxnDirection> txnDirections = txnDirDao.searchWaitToCheckTxnDirecs( name, page );
		if (txnDirections == null) {
			return new ArrayList<TxnDirection>();
		} else {
			return txnDirections;
		}
	}

	public List<String> searchWaitApproveNames(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDirDao.searchWaitApproveNames( key );
	}

	public List<String> searchDefinitionIdByHeadRefId(String key) {
		if (StringUtils.isBlank( key )) {
			return null;
		}
		return txnDirDao.searchDefinitionIdByHeadRefId( key );
	}

	/** ifExist **/
	public boolean isExistDefCodeButSelf(String selfId, String mainId, String defCode) {
		List<TxnDirection> result = getByTxnCodeButSelf( selfId, mainId, defCode );
		if (result != null && !result.isEmpty())
			return true;
		return false;
	}

	public List<TxnDirection> getByTxnCodeButSelf(String selfId, String mainId, String name) {
		if (StringUtils.isBlank( name )) {
			return null;
		}
		return txnDirDao.getByTxnCodeButSelf( selfId, mainId, name );
	}

	@Transactional
	public String approveTxnHeader(String direcId, String approveUser) {
		String mainId = direcId;

		TxnDirection direction = findHeadDirByID( direcId );
		String copyMainId = direction.getMainId();
		if (direction != null && TxnStatus.D.equals( direction.getTxnHeaderStatus() )) { // check if it is for deleting
			if (StringUtils.isBlank( direcId ))
				return null;
			removeTxnHeaderById( direcId );

		} else if (copyMainId != null && !"0".equals( copyMainId )) {
			TxnDirection mainDire = findHeadDirByID( copyMainId );
			String id = mainDire.getId();
			if (StringUtils.isNotBlank( id )) {
				BeanUtils.copyProperties( direction, mainDire );
				mainDire.setId( id );
				mainDire.setMainId( null );
				mainDire.setTxnHeaderStatus( TxnStatus.M );
				txnDirDao.update( mainDire );
				List<TxnFieldDefinition> copyFields = txnFieldService.findMainsByDirId( mainId );
				EditTxnField[] eFields = new EditTxnField[copyFields.size()];
				for (int index = 0; index < copyFields.size(); index++) {
					TxnFieldDefinition tfd = new TxnFieldDefinition();
					BeanUtils.copyProperties( copyFields.get( index ), tfd );
					tfd.setDirectionId( id );
					tfd.setId( null );
					EditTxnField field = new EditTxnField();
					field.setEditType( EditTxnField.EDIT_TYPE_ADD );
					field.setTxnField( tfd );
					eFields[index] = field;
				}
				txnFieldDao.removeByTxnDirection( id );
				txnFieldService.batchProcessHeaderFromVOs( eFields, id, false );
			}
			removeTxnHeaderById( direcId );
			mainId = id;
		} else {
			direction.setTxnHeaderStatus( TxnStatus.M );
			direction.setMainId( null );
			txnDirDao.update( direction );
		}
		return mainId;
	}

	@Transactional
	public List<String> approveTxnHeaders(String[] defIds, String approveUser) {
		List<String> mainDefIds = new ArrayList<String>();
		for (String direcId : defIds) {
			mainDefIds.add( approveTxnHeader( direcId, approveUser ) );
		}
		return mainDefIds;
	}

	/** if name exist **/
	public Boolean validHeaderCodeDuplicate(String selfId, String mainId, String name) {
		List<TxnDirection> txnDirection = txnDirDao.getByTxnCodeButSelf( selfId, mainId, name );
		return txnDirection == null ? false : true;
	}

	/** if name exist parameter name **/
	public boolean validNameDuplicate(String selfId, String mainId, String name) {
		return txnDirDao.nameDuplicate( selfId, mainId, name );
	}

	public String getHeaderByName(String name) {
		List<TxnDirection> dirs = txnDirDao.findHeadDirsByName( name );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 ).getName();
		}
		return null;
	}

	public String getMainidByName(String name) {
		List<TxnDirection> dirs = txnDirDao.findHeadDirsByName( name );
		if (dirs != null && !dirs.isEmpty()) {
			return dirs.get( 0 ).getId();
		}
		return null;
	}

	public String getHeaderStatusByName(String name) {

		List<TxnDirection> dirs = txnDirDao.findHeaderStatusByName( name );
		if (dirs != null && !dirs.isEmpty()) {

			return dirs.get( 0 ).getName();
		}
		return null;
	}

}
