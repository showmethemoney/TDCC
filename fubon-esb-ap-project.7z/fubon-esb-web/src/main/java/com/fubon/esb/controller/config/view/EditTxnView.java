package com.fubon.esb.controller.config.view;

public class EditTxnView {
    private String effectDate;
    private String effectHour;
    private String effectMinute;
    private String channelIds;
    private String txnRelatedIds;

    public String getEffectDate() {
        return effectDate;
    }

    public void setEffectDate(String effectDate) {
        this.effectDate = effectDate;
    }

    public String getEffectHour() {
        return effectHour;
    }

    public void setEffectHour(String effectHour) {
        this.effectHour = effectHour;
    }

    public String getEffectMinute() {
        return effectMinute;
    }

    public void setEffectMinute(String effectMinute) {
        this.effectMinute = effectMinute;
    }

    public String getChannelIds() {
        return channelIds;
    }

    public void setChannelIds(String channelIds) {
        this.channelIds = channelIds;
    }

    public String getTxnRelatedIds() {
        return txnRelatedIds;
    }

    public void setTxnRelatedIds(String txnRelatedIds) {
        this.txnRelatedIds = txnRelatedIds;
    }
 

}
