package com.fubon.esb.domain.config;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-6
 */
public enum PriorityType {

    /** High */
    H("High"),

    /** Median */
    M("Median"),

    /** LOW */
    L("Low");

    private String desc;

    private PriorityType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String toString() {
        return desc;
    }

    public String getName() {
        switch (this.name()) {
            case "H":
                return "高";
            case "M":
                return "中";
            case "L":
                return "低";
            default:
                return "";
        }
    }
}
