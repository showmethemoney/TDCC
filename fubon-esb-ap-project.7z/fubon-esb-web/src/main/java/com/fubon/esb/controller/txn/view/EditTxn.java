package com.fubon.esb.controller.txn.view;

import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
public class EditTxn {

    private TxnDefinition txnDefi;

    private TxnDirection upTxnDirec;
    
    private TxnDirection headTxnDirec;
    
    private TxnDirection downTxnDirec;

    private EditTxnField[] etxnFields;

    public TxnDefinition getTxnDefi() {
        return this.txnDefi;
    }

    public void setTxnDefi(TxnDefinition txnDefi) {
        this.txnDefi = txnDefi;
    }

    public TxnDirection getUpTxnDirec() {
        return this.upTxnDirec;
    }

    public void setUpTxnDirec(TxnDirection upTxnDirec) {
        this.upTxnDirec = upTxnDirec;
    }

    public TxnDirection getDownTxnDirec() {
        return this.downTxnDirec;
    }

    public void setDownTxnDirec(TxnDirection downTxnDirec) {
        this.downTxnDirec = downTxnDirec;
    }

    public EditTxnField[] getEtxnFields() {
        return this.etxnFields;
    }

    public void setEtxnFields(EditTxnField[] etxnFields) {
        this.etxnFields = etxnFields;
    }

    public TxnDirection getHeadTxnDirec() {
        return headTxnDirec;
    }

    public void setHeadTxnDirec(TxnDirection headTxnDirec) {
        this.headTxnDirec = headTxnDirec;
    }
}
