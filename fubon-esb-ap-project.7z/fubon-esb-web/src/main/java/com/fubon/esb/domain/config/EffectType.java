package com.fubon.esb.domain.config;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
public enum EffectType {

    /** Immediate */
    I("Immediate"),

    /** Booked */
    B("Booked");

    private String desc;

    private EffectType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String toString() {
        return desc;
    }
}
