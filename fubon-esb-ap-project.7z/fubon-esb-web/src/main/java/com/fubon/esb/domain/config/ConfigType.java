package com.fubon.esb.domain.config;

/**
 * @author james
 * @createdDate 2014-11-27
 */
public enum ConfigType {

    CFG_ACCESS_CHANNEL, CFG_CHANNEL, CFG_CONNECTOR, CFG_HOST, CFG_RETURN_CODE, CFG_SERVICE, CFG_TXN_GROUP, CFG_TXN, CFG_MAIL_GROUP, CFG_JOB_SYSTEM_SETTING

}
