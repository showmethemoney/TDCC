package com.fubon.esb.service.log;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.fubon.esb.dao.log.HostServerDao;

/**
 * @author Qigers
 * @createdDate 2014-11-21
 */
@Service(value = "hostServerService")
public class HostServerService {
    @Inject
    private HostServerDao hostServerDao;
    public Object findHostList() {
        return hostServerDao.findHostStatusList();
    }

    public Object findServerList() {
        return hostServerDao.findServerStatusList();
    }
}
