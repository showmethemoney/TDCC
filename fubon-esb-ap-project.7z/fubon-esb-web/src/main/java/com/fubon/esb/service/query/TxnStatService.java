package com.fubon.esb.service.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.query.view.TxnStatCategory;
import com.fubon.esb.controller.query.view.TxnStatSearchVO;
import com.fubon.esb.dao.config.TxnStatDao;
import com.fubon.esb.dao.config.TxnStatMonDao;
import com.fubon.esb.dao.config.TxnStatMonErrorCodeDao;
import com.fubon.esb.domain.config.TxnStat;
import com.fubon.esb.domain.config.TxnStatCategoryType;
import com.fubon.esb.domain.config.TxnStatMon;
import com.fubon.esb.domain.config.TxnStatMonErrorCode;
import com.fubon.esb.domain.config.TxnStatReturnTimeType;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-17
 */
@Service
public class TxnStatService {
    
    private Map<TxnStatCategoryType, Object> logTitles;

    @Inject
    private TxnStatDao txnStatDao;

    @Inject
    private TxnStatMonDao txnStatMonDao;
    
    @Inject
    private TxnStatMonErrorCodeDao txnStatMonErrorCodeDao;

    @Inject
    private Messages messages;

    @Inject
    private OperationLogService operationLogService;
    
    @PostConstruct
    public void init() {
        logTitles = new HashMap<TxnStatCategoryType, Object>();
        for (TxnStatCategoryType type : TxnStatCategoryType.values()) {
            if (type != TxnStatCategoryType.E && type != TxnStatCategoryType.CT) {
                logTitles.put(type, getMessage("excel_" + type.getName()));
            } else if (type == TxnStatCategoryType.E) {
                List<String> titles = new ArrayList<>();
                titles.add(getMessage("excel_" + type.getName()));
                titles.add(getMessage("excel_txnStat_category_e_txncode"));
                titles.add(getMessage("excel_txnStat_category_e_errorcode"));
                logTitles.put(type, titles);
            } else { // CT
                List<String> titles = new ArrayList<>();
                titles.add(getMessage("excel_" + type.getName()));
                titles.add(getMessage("excel_txnStat_category_ct_code"));
                logTitles.put(type, titles);
            }
        }
    }
    
    public List<TxnStat> findTxnStats(TxnStatSearchVO vo) {
        return txnStatDao.findTxnStats(vo);
    }

    public List<TxnStatMon> findTxnStatMons(TxnStatSearchVO vo) {
        return txnStatMonDao.findTxnStats(vo);
    }
    
    public List<TxnStatMonErrorCode> findTxnStatMonErrorCodes(TxnStatSearchVO vo) {
        return txnStatMonErrorCodeDao.findTxnStats(vo);
    }

    public List<TxnStatCategory> findAllCategory() {
        List<TxnStatCategory> categories = new ArrayList<>();
        for (TxnStatCategoryType type : TxnStatCategoryType.values()) {
            categories.add(new TxnStatCategory(type.getCategory(), type.getName()));
        }
        return categories;
    }

    public String[] getTitles(TxnStatSearchVO vo) {
        Integer classification = vo.getClassification();
        String[] titles = new String[10];
        int i = 0;
        if (1 == classification) { // 日
            titles[i++] = getMessage("title_query_txnstat_day");
            i = setCategoryTitle(titles, vo, i);
            titles[i] = getMessage("title_query_txnstat_totalRecord");

        } else if (2 == classification) { // 月
            titles[i++] = getMessage("title_query_txnstat_day");
            i = setCategoryTitle(titles, vo, i);
            titles[i] = getMessage("title_query_txnstat_totalRecord");
        } else { // 區段
            titles[i++] = getMessage("title_query_txnstat_day");
            titles[i++] = getMessage("title_query_txnstat_hour");
            i = setCategoryTitle(titles, vo, i);
            titles[i++] = getMessage("title_query_txnstat_totalRecord");
            titles[i] = getMessage("title_query_txnstat_avgTime");
        }

        return titles;
    }

    private int setCategoryTitle(String[] titles, TxnStatSearchVO vo, int i) {
        int index = i;
        if (vo.getCategory() != TxnStatCategoryType.A) {
            if (vo.getCategory() == TxnStatCategoryType.E && vo.getClassification() != 3) {
                titles[index++] = getMessage("title_query_txnstat_hour"); // errorcode日查詢 月  增加時間區間
            }
            titles[index++] = getMessage("excel_" + vo.getCategory().getName());
            if (vo.getCategory().equals(TxnStatCategoryType.CT)) {
                titles[index++] = getMessage("excel_txnStat_category_ct_code");
            } else if (vo.getCategory() == TxnStatCategoryType.E) {
                titles[index++] = getMessage("excel_txnStat_category_e_txncode");
                titles[index++] = getMessage("excel_txnStat_category_e_errorcode");
            }
        }

        return index;
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

    public void addLog(TxnStatSearchVO vo, Boolean isSearch) {
        StringBuilder message = new StringBuilder();
        if (isSearch != null && isSearch) {
            message.append(getMessage("log_message_txnstat_search")).append(".");
        } else {
            message.append(getMessage("log_message_txnstat_export")).append(".");
        }
        message.append(getMessage("log_message_txnstat_class")).append(":");
        if (Integer.valueOf(2).equals(vo.getClassification())) {
            message.append(getMessage("log_message_txnstat_class_month")).append(";").append(getMessage("log_message_txnstat_range")).append(":").append(vo.getStartYear()).append("/")
                    .append(vo.getStartMonth()).append("~").append(vo.getEndYear()).append("/").append(vo.getEndMonth()).append(";");
        } else {
            if (Integer.valueOf(1).equals(vo.getClassification())) {
                message.append(getMessage("log_message_txnstat_class_day")).append(";");
            } else {
                message.append(getMessage("log_message_txnstat_class_range")).append(";");
            }
            if (vo.getStartDate() != null) {
                message.append(getMessage("log_message_txnstat_startDate")).append(":").append(DateFormatUtils.format(vo.getStartDate(), "yyyy/MM/dd")).append(";");
            }
            if (vo.getEndDate() != null) {
                message.append(getMessage("log_message_txnstat_endDate")).append(":").append(DateFormatUtils.format(vo.getEndDate(), "yyyy/MM/dd")).append(";");
            }
        }
        if (vo.getCategory() != null) {
            message.append(getMessage("log_message_txnstat_category")).append(":").append(getMessage(vo.getCategory().getName())).append(";");
        }
        message.append(getMessage("log_message_txnstat_type")).append(":")
                .append(Integer.valueOf(1).equals(vo.getType()) ? getMessage("log_message_txnstat_type_1") : getMessage("log_message_txnstat_type_2")).append(";");
        fullfillMessage(message, vo); // 新增模糊查詢,填充log信息
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message.toString(), LogType.SEARCH_DAILY_STATISTIC);
    }
    
    @SuppressWarnings("unchecked")
    private void fullfillMessage(StringBuilder message, TxnStatSearchVO vo) {
        TxnStatCategoryType type = vo.getCategory();
        if (type == null) {
            return;
        }

        if (type != TxnStatCategoryType.E && type != TxnStatCategoryType.CT && StringUtils.isNotBlank(vo.getValue1())) {
            message.append(logTitles.get(type)).append(":").append(vo.getValue1()).append(";");
            return;
        }
        if (type != TxnStatCategoryType.E && type != TxnStatCategoryType.CT && StringUtils.isBlank(vo.getValue1())) {
            return;
        }
        List<String> titles = (List<String>) logTitles.get(type);
        if (StringUtils.isNotBlank(vo.getValue1())) {
            message.append(titles.get(0)).append(":").append(vo.getValue1()).append(";");
        }
        if (StringUtils.isNotBlank(vo.getValue2())) {
            message.append(titles.get(1)).append(":").append(vo.getValue2()).append(";");
        }
        if (StringUtils.isNotBlank(vo.getValue3()) && type == TxnStatCategoryType.E) {
            message.append(titles.get(2)).append(":").append(vo.getValue3()).append(";");
        }
    }

    public void setCategories(Model model) {
        for (TxnStatCategoryType type : TxnStatCategoryType.values()) {
            model.addAttribute("category_" + type.toString(), type);
        }
    }
    
    public List<String[]> getReturnTimeTypes() {
        List<String[]> list = new ArrayList<>();
        for (TxnStatReturnTimeType type : TxnStatReturnTimeType.values()) {
            String[] arr = new String[2];
            arr[0] = type.name();
            arr[1] = type.getValue();
            list.add(arr);
        }
        return list;
    }

}
