package com.fubon.esb.domain.config;

/**
 * @author Leckie Zhang
 * @createdDate 2015-2-9
 */
public enum TxnStatReturnTimeType {
    
    D0("100以下"),
    D100("100~200"),
    D200("200~300"),
    D300("300~400"),
    D400("400~500"),
    D500("500~600"),
    D600("600~700"),
    D700("700~800"),
    D800("800~900"),
    D900("900~1000"),
    D1000("1000~2000"),
    D2000("2000~3000"),
    D3000("3000~4000"),
    D4000("4000~5000"),
    D5000("5000~10000"),
    D10000("10000~15000"),
    D15000("15000~20000"),
    D20000("20000~25000"),
    D25000("25000~30000"),
    D30000("30000~40000"),
    D40000("40000~50000"),
    D50000("50000~60000"),
    D60000("60000以上");
    
    private String value;

    private TxnStatReturnTimeType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
