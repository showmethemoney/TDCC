package com.fubon.esb.service.config;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.EditTxnView;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.dao.config.TxnChannelDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnRelatedDao;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.TxnRelated;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

@Service
public class TxnConfigEditService extends TxnConfigService {

    @Inject
    private TxnDao txnDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private TxnChannelDao txnChannelDao;
    @Inject
    private TxnRelatedDao txnRelatedDao;
    @Inject
    private ChannelService channelService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private Messages messages;
    @Inject
    private TxnGroupConfigChangeMail txnGroupConfigChangeMail;

    @Transactional
    public String saveOrUpdateTxn(Txn txn, EditTxnView editTxnView) throws DuplicatedException {
        String result;
        if (StringUtils.isNotBlank(txn.getId())) {
            Txn oldTxn = getTxnById(txn.getId());
            String code = oldTxn.getCode();
            String name = oldTxn.getName();
            result = updateTxn(txn, editTxnView);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改交易設定。交易代號：" + code + "，交易名稱：" + name, LogType.SYS_CFG_TXN);
            return result;
        } else {
            txn.setId(null);
            result = saveTxn(txn, editTxnView);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增交易設定。交易代號：" + txn.getCode() + "，交易名稱：" + txn.getName(), LogType.SYS_CFG_TXN);
            return result;
        }
    }

    public String saveTxn(Txn txn, EditTxnView editTxnView) throws DuplicatedException {
        if (isCodeDuplicated(txn.getCode().trim())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(txn.getEffectType())) {
            Date effectTime = timeZoneService.getTZDateByService(channelService.stringToDate(editTxnView.getEffectDate(), editTxnView.getEffectHour(), editTxnView.getEffectMinute()));
            txn.setEffectTime(effectTime);
            txn.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(txn.getEffectType())) {
            txn.setEffectTime(null);
            txn.setMainId(null);
        }
        txn.setCreatedUser(loginContext.loginedUserId());
        txn.setCreatedTime(new Date());
        txnDao.save(txn);
        if (StringUtils.isNotBlank(txn.getId())) {
            txnChannelDao.saveTxnChannels(txn.getId(), editTxnView.getChannelIds());
            txnRelatedDao.saveTxnRelateds(txn.getId(), editTxnView.getTxnRelatedIds());
        }
        txnGroupConfigChangeMail.compareAdd(true, txn, editTxnView);
        return txn.getId();
    }

    public String updateTxn(Txn txn, EditTxnView editTxnView) throws DuplicatedException {
        setProperty(txn);
        if (isCodeDuplicated(txn)) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(txn.getEffectType())) { // 預約生效
            txn.setEffectTime(timeZoneService.getTZDateByService(channelService.stringToDate(editTxnView.getEffectDate(), editTxnView.getEffectHour(), editTxnView.getEffectMinute())));
            if (txn.getMainId() == null) { // 正本，新建副本(新建關聯的txnchannel和txnrelated)
                Txn newTxn = new Txn();
                BeanUtils.copyProperties(txn, newTxn, "id");
                newTxn.setMainId(txn.getId());
                txnGroupConfigChangeMail.compareUpdate(getTxnById(txn.getId()), newTxn, editTxnView);
                txnDao.save(newTxn);
                txnChannelDao.saveTxnChannels(newTxn.getId(), editTxnView.getChannelIds());
                txnRelatedDao.saveTxnRelateds(newTxn.getId(), editTxnView.getTxnRelatedIds());
                return newTxn.getId();
            } else { // 副本-直接修改
                txnGroupConfigChangeMail.compareUpdate("0".equals(txn.getMainId()) ? getTxnById(txn.getId()) : getTxnById(txn.getMainId()), txn, editTxnView);
                txnDao.update(txn);
                updateTxnChannelAndTxnRelated(txn.getId(), editTxnView);
                return txn.getId();
            }
        } else if (EffectType.I.equals(txn.getEffectType())) { // 立即預約
            txn.setEffectTime(null);
            if (txn.getMainId() == null || "0".equals(txn.getMainId())) { // 正本-直接修改
                txn.setMainId(null);
                txnGroupConfigChangeMail.compareUpdate(getTxnById(txn.getId()), txn, editTxnView);
                txnDao.update(txn);
                updateTxnChannelAndTxnRelated(txn.getId(), editTxnView);
                return txn.getId();
            } else {
                Txn mainTxn = txnDao.get(txn.getMainId()); // 副本，找到正本復制屬性
                Txn originTxn = new Txn(); //
                BeanUtils.copyProperties(mainTxn, originTxn); //
                BeanUtils.copyProperties(txn, mainTxn, "id");
                mainTxn.setMainId(null);
                txnGroupConfigChangeMail.compareUpdate(originTxn, mainTxn, editTxnView);
                txnDao.update(mainTxn);
                updateTxnChannelAndTxnRelated(mainTxn.getId(), editTxnView); // 更新正本的txnchannel和txnrelated
                txnChannelDao.deleteByTxnId(txn.getId()); // 刪除副本關聯的TxnChannel
                txnRelatedDao.deleteByTxnId(txn.getId()); // 刪除副本對應的Txnrelated
                txnDao.delete(txnDao.get(txn.getId())); // 刪除副本
                return mainTxn.getId();
            }
        } else
            return null;
    }

    public void setProperty(Txn txn) {
        Txn persiTxn = getTxnById(txn.getId());
        txn.setCreatedTime(persiTxn.getCreatedTime());
        txn.setCreatedUser(persiTxn.getCreatedUser());
        txn.setMainId(persiTxn.getMainId());
        txn.setUpdatedUser(loginContext.loginedUserId());
        txn.setUpdatedTime(new Date());
    }

    @Transactional
    public void deleteTxn(String id) {
        txnDao.updateStatus(id);
    }

    // 是否有关联交易
    public boolean isRelatedTxn(String id, StringBuilder message) {
        List<TxnRelated> txnRelateds = txnDao.isTxnRelatedTxn(id);
        List<Txn> txns = txnDao.isTxnRelated(id);
        List<TxnChannel> txnChannels = txnDao.isTxnRelatedChannel(id);
        if (!txnRelateds.isEmpty()) {
            for (TxnRelated txnRelated : txnRelateds) {
                if (!id.equals(txnRelated.getTxnId())) {
                    message.append(getTxnById(txnRelated.getTxnId()).getCode()).append(",");
                }
            }
        }
        return !txnRelateds.isEmpty() || !txns.isEmpty() || !txnChannels.isEmpty();
    }

    public String createStr(TxnView txnView, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(txnView.getTxnCode())) {
            messageStr.append(messages.getMessage("log.TxnConfig.configcode") + txnView.getTxnCode());
        }
        if (StringUtils.isNotBlank(txnView.getTxnName())) {
            messageStr.append(messages.getMessage("log.TxnConfig.configname") + txnView.getTxnName());
        }
        if (StringUtils.isNotBlank(txnView.getTxnGroupCode())) {
            messageStr.append(messages.getMessage("log.TxnConfig.groupcode") + txnView.getTxnGroupCode());
        }
        if (StringUtils.isNotBlank(txnView.getServiceCode())) {
            messageStr.append(messages.getMessage("log.TxnConfig.service") + txnView.getServiceCode());
        }
        if (StringUtils.isNotBlank(txnView.getChannelCode())) {
            messageStr.append(messages.getMessage("log.TxnConfig.channelcode") + txnView.getChannelCode());
        }
        if (StringUtils.isNotBlank(txnView.getConnectorCode())) {
            messageStr.append(messages.getMessage("log.TxnConfig.connector") + txnView.getConnectorCode());
        }
        if (txnView.getStatus() != null) {
            messageStr.append(messages.getMessage("log.TxnConfig.status") + txnView.getStatus());
        }
        return messageStr.toString();
    }

    public String setOrderPicUrl(OrderBy orderBy) {
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            return "normal.gif";
        } else if (orderBy.isAsc()) {
            return "up.gif";
        } else {
            return "down.gif";
        }
    }

}
