package com.fubon.esb.service.log;

import java.util.Date;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.fubon.esb.dao.log.TxnRecordDurationDao;


/**
 * @author Ethan Lee
 */
@Service(value = "txnRecordDurationService")
public class TxnRecordDurationService
{
	@Inject
	private TxnRecordDurationDao txnRecordDurationDao;

	public int deleteTxnRecordTime(Date dateTime) {
		return txnRecordDurationDao.deleteTxnRecordTimeByTime( dateTime );
	}

	public int deleteTxnRecordDuration(Date dateTime) {
		return txnRecordDurationDao.deleteTxnRecordDurationByTime( dateTime );
	}
}
