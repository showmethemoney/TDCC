package com.fubon.esb.dao.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.Query;
import com.fubon.esb.controller.query.view.TxnStatSearchVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.config.TxnStat;
import com.fubon.esb.domain.config.TxnStatCategoryType;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-14
 */
@Repository
public class TxnStatDao extends LogDBJPADaoSupport<TxnStat> {

    @Inject
    private TimeZoneService timeZoneService;

    public List<TxnStat> findTxnStats(TxnStatSearchVO vo) {

        StringBuilder jql = new StringBuilder();
        StringBuilder countJql = new StringBuilder("select 1 ");
        Map<String, Object> params = new HashMap<String, Object>();

        jql.append("  select new ").append(TxnStat.class.getName()).append("(");
        if (vo.getClassification() == 1) { // 日統計
            jql.append("day, max(hour), max(value), max(value2), max(value3), sum(totalRecord) )  ");
        } else { // 區間統計 3
            jql.append("   day, hour, max(value),max(value2),max(value3), sum(totalRecord), sum(avgTime) )  ");
        }

        String commonJql = getCommonJql(vo, params);

        jql.append(commonJql);
        if (vo.getOrder() != null) {
            jql.append(" order  by ").append(vo.getOrder().getClause());
        } else {
            if (vo.getCategory() == TxnStatCategoryType.D) {
                jql.append(" order by  CAST(max(value) as int) ");
            } else {
                jql.append(" order by day");  
            }
        }
        Query query = Query.create(jql.toString());
        query.putParams(params);

        if (vo.getPage() != null) {
            Query countQuery = Query.create(countJql.append(commonJql).toString());
            countQuery.putParams(params);
            List<Long> countResult = jpaAccess.find(countQuery);
            if (countResult == null || countResult.isEmpty()) {
                return new ArrayList<>();
            }

            vo.getPage().setTotalCount(countResult.size()); // TODO(待改進)
            query.fetch(vo.getPage().getPageSize());
            query.from(vo.getPage().getFirstResult());
        }
        return jpaAccess.find(query);
    }

    private String getCommonJql(TxnStatSearchVO vo, Map<String, Object> params) {
        StringBuilder commonJql = new StringBuilder();
        commonJql.append("  from ").append(TxnStat.class.getName()).append(" where 1=1 ");
        if (vo.getStartDate() != null) {
            commonJql.append(" and day >= :start ");
            params.put("start", timeZoneService.getTZDateByService(vo.getStartDate()));
        }
        if (vo.getEndDate() != null) {
            commonJql.append(" and day <= :end ");
            params.put("end", timeZoneService.getTZDateByService(vo.getEndDate()));
        }

        commonJql.append(" and type = :type ");
        params.put("type", vo.getType());
        
        commonJql.append(" and category = :category ");
        params.put("category", vo.getCategory());
            
        if (vo.getCategory() == TxnStatCategoryType.D && StringUtils.isNotBlank(vo.getValueD())) {
            commonJql.append(" and value = :value1 ");
            params.put("value1", vo.getValueD().replace("D", ""));
        } else if (vo.getCategory() != TxnStatCategoryType.A && StringUtils.isNotBlank(vo.getValue1())) {
            commonJql.append(" and value like :value1 ");
            params.put("value1", "%" + vo.getValue1() + "%");
        }
        if ((vo.getCategory() == TxnStatCategoryType.CT || vo.getCategory() == TxnStatCategoryType.E) && StringUtils.isNotBlank(vo.getValue2())) {
            commonJql.append(" and value2 like :value2 ");
            params.put("value2", "%" + vo.getValue2() + "%");
        }
        if (vo.getCategory() == TxnStatCategoryType.E && StringUtils.isNotBlank(vo.getValue3())) {
            commonJql.append(" and value3 like :value3 ");
            params.put("value3", "%" + vo.getValue3() + "%");
        }

        if (vo.getClassification() == 1 && vo.getCategory() != TxnStatCategoryType.E) { // 日統計,非ErrorCode別
            commonJql.append(" group by day ");
        } else {
            commonJql.append(" group by  day , hour ");
        }
        if (vo.getCategory() != TxnStatCategoryType.A) {
            commonJql.append(" , value ");
            if (vo.getCategory() == TxnStatCategoryType.CT) {
                commonJql.append(" , value2 ");
            } else if (vo.getCategory() == TxnStatCategoryType.E) {
                commonJql.append(" , value2, value3 ");
            }
        }

        return commonJql.toString();
    }

}
