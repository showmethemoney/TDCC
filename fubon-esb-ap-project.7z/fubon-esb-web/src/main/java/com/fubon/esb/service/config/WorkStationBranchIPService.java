package com.fubon.esb.service.config;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.EditChannelView;
import com.fubon.esb.dao.config.BranchIPDao;
import com.fubon.esb.dao.config.ChannelDao;
import com.fubon.esb.dao.config.WorkstationDao;
import com.fubon.esb.domain.config.BranchIP;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.Workstation;

@Service
public class WorkStationBranchIPService {

    @Inject
    private WorkstationDao workstationDao;
    @Inject
    private BranchIPDao branchIPDao;

    @Inject
    private Messages messages;

    @Inject
    private ChannelDao channelDao;

    public List<Workstation> findWorkstationByChannelId(String channelId) {
        return workstationDao.findBychannelId(channelId);
    }

    public List<BranchIP> findBranchIPByChanelId(String channelId) {
        return branchIPDao.findByChanelId(channelId);
    }

    @SuppressWarnings("unchecked")
    private void compareBranchIpCodeList(List<BranchIP> newList, List<BranchIP> oldList) {
        if (!CollectionUtils.isEqualCollection(oldList, newList)) {
            List<BranchIP> sameList = (List<BranchIP>) CollectionUtils.retainAll(oldList, newList);
            newList.removeAll(sameList);
            oldList.removeAll(sameList);
            branchIPDao.removeBranchIPList(oldList); // 刪除刪除的BranchIP
            // checkIPDuplicated(flag, newList, channelId);
            branchIPDao.addBranchIPList(newList); // 保存新增的BranchIp
        }
    }

    /** 修改worksttaionList和branchIpList的差異 */
    @SuppressWarnings("unchecked")
    private void compareWorkstatioCodeList(boolean flag, List<Workstation> newList, List<Workstation> oldList, String channelId) {
        if (!CollectionUtils.isEqualCollection(oldList, newList)) {
            List<Workstation> sameList = (List<Workstation>) CollectionUtils.retainAll(oldList, newList);
            newList.removeAll(sameList);
            oldList.removeAll(sameList);
            workstationDao.removeWorkstationList(oldList); // 刪除刪除的workstation
            //checkWorksttaionDuplicate(flag, newList, channelId);
            workstationDao.addWorkstationList(newList); // 插入新增workstation
        }
    }

    /** 對比worksttaionList和branchIpList的差異 並修改 **/
    public void updateWorkstationAndBranchIp(boolean flag, String channelId, EditChannelView editChannel) throws DuplicatedException {
        List<BranchIP> newBranchIPList = createNewBranchIPList(channelId, editChannel);
        List<BranchIP> oldBranchIPList = branchIPDao.findByChanelId(channelId);
        compareBranchIpCodeList(newBranchIPList, oldBranchIPList);

        List<Workstation> newWorkstationList = createNewWorkstationList(channelId, editChannel);
        List<Workstation> oldWorkstationList = workstationDao.findBychannelId(channelId);
        compareWorkstatioCodeList(flag, newWorkstationList, oldWorkstationList, channelId);
    }

    public List<BranchIP> createNewBranchIPList(String channelId, EditChannelView editChannel) {
        List<BranchIP> newBranchIPList = new ArrayList<>();
        if (editChannel.getBranchIps() != null && editChannel.getBranchIps().length > 0) {
            for (String ip : editChannel.getBranchIps()) {
                newBranchIPList.add(new BranchIP(channelId, ip));
            }
        }
        return newBranchIPList;
    }

    public List<Workstation> createNewWorkstationList(String channelId, EditChannelView editChannel) {
        List<Workstation> newWorkstationList = new ArrayList<>();
        if (editChannel.getWorkstationCodes() != null && editChannel.getWorkstationCodes().length > 0) {
            for (String wk : editChannel.getWorkstationCodes()) {
                newWorkstationList.add(new Workstation(channelId, wk));
            }
        }
        return newWorkstationList;
    }

    public void saveBranchIPAndWorkStation(boolean flag, String[] ips, String[] workstationCodes, String channelId) throws DuplicatedException {
        
    	// if (workstationCodes != null && workstationCodes.length > 0) {
        //    for (String code : workstationCodes) {
        //        if (StringUtils.isNotBlank(code) && isWorkstationCodeDuplicate(flag, code, channelId)) {
        //            throw new DuplicatedException(messages.getMessage("config_valid_workstationcode_exist", code));
        //        }
        //    }
        // }
        
        workstationDao.saveWorkstation(channelId, workstationCodes);
        // if (ips != null && ips.length > 0) {
        // for (String ip : ips) {
        // if (StringUtils.isNotBlank(ip) && isIPDuplicate(flag, ip, channelId)) {
        // throw new DuplicatedException(messages.getMessage("config_valid_branchip_exist", ip));
        // }
        // }
        // }
        branchIPDao.saveBranchIP(channelId, ips);
    }

    // private void checkIPDuplicated(boolean flag, List<BranchIP> newList, String channelId) {
    // for (BranchIP branchIP : newList) {
    // List<BranchIP> branchIPs = branchIPDao.findByIP(branchIP.getIp());
    // if (!branchIPs.isEmpty()) {
    // if (flag) {
    // throw new DuplicatedException(messages.getMessage("config_valid_branchip_exist", branchIP.getIp()));
    // }
    // for (BranchIP br : branchIPs) {
    // Channel channel2 = channelDao.get(br.getChannelId());
    // if (StringUtils.isNotBlank(channel2.getMainId()) && (!channel2.getMainId().equals(channelId))) {
    // throw new DuplicatedException(messages.getMessage("config_valid_branchip_exist", branchIP.getIp()));
    // }
    // }
    // }
    // }
    //
    // }

    public void checkWorksttaionDuplicate(boolean flag, List<Workstation> newList, String channelId) {
        for (Workstation workstation : newList) {
            List<Workstation> workstations = workstationDao.findByWorkstationCode(workstation.getCode());
            if (!workstations.isEmpty()) {
                if (flag) {
                    throw new DuplicatedException(messages.getMessage("config_valid_workstationcode_exist", workstation.getCode()));
                }
                for (Workstation wk : workstations) {
                    Channel channel2 = channelDao.get(wk.getChannelId());
                    if (StringUtils.isNotBlank(channel2.getMainId()) && (!channel2.getMainId().equals(channelId))) {
                        throw new DuplicatedException(messages.getMessage("config_valid_workstationcode_exist", workstation.getCode()));
                    }
                }
            }
        }
    }

    public boolean isWorkstationCodeDuplicate(boolean flag, String workstationCode, String channelId) {
        boolean isExist = false;
        List<Workstation> workstations = workstationDao.findByWorkstationCode(workstationCode);
        Channel channel = channelDao.get(channelId);
        if (!workstations.isEmpty()) { // 新增channel驗證是否重復
            if (flag) {
                return true;
            }
            for (Workstation workstation : workstations) { // 新增副本是否有重復
                if (StringUtils.isNotBlank(channel.getMainId()) && (!channel.getMainId().equals(workstation.getChannelId()))) {
                    isExist = true;
                }
            }
        }
        return isExist;
    }

    public boolean isIPDuplicate(boolean flag, String ip, String channelId) {
        boolean isExist = false;
        List<BranchIP> branchIPs = branchIPDao.findByIP(ip);
        Channel channel = channelDao.get(channelId);
        if (!branchIPs.isEmpty()) {
            if (flag) {
                return true;
            }
            for (BranchIP branchIP : branchIPs) {
                if (StringUtils.isNotBlank(channel.getMainId()) && (!channel.getMainId().equals(branchIP.getChannelId()))) {
                    isExist = true;
                }
            }
        }
        return isExist;
    }

}
