package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum FieldType {

    /** 欄位類型 {F:FIELD普通欄位,S:SWITCH判斷欄位,C:CASE判斷欄位,R:REPEAT重復欄位} **/
    F("txn.fieldtype.f"), S("txn.fieldtype.s"), C("txn.fieldtype.c"), R("txn.fieldtype.r");

    private String propKey;

    FieldType(String propKey) {
        this.propKey = propKey;
    }

    public String getPropKey() {
        return propKey;
    }
}
