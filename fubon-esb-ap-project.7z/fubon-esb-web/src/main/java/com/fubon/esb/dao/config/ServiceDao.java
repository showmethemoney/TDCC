package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.config.view.ServiceView;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.Service;
import com.fubon.esb.domain.config.Txn;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-3
 */
@Repository
public class ServiceDao extends JPADaoSupport<Service> {

    public List<Service> findLatestServices(ServiceView service, Page page) {
        Query query = Query.create("select service from " + Service.class.getName() + " service ");
        if (StringUtils.isNotBlank(service.getTxnCode())) {
            query.append(" , ").append(Txn.class).append(" t ");
        }
        query.append(" where not exists(select s from ").append(Service.class).append(" s where s.mainId = service.id)");
        if (StringUtils.isNotBlank(service.getTxnCode())) {
            query.append(" and service.id = t.serviceId and t.code = :txnCode and t.mainId is null ");
            query.setParam("txnCode", service.getTxnCode().trim());
        }
        if (StringUtils.isNotBlank(service.getCode())) {
            query.append(" and service.code = :code ");
            query.setParam("code", service.getCode().trim());
        }
        if (StringUtils.isNotBlank(service.getName())) {
            query.append(" and service.name like :name ");
            query.setParam("name", "%" + service.getName() + "%");
        }
        if (StringUtils.isNotBlank(service.getVersion())) {
            query.append(" and service.version like :version ");
            query.setParam("version", "%" + service.getVersion() + "%");
        }

        if (service.getStatus() != null) {
            query.append(" and service.status = :status ");
            query.setParam("status", service.getStatus());
        }
        query.orderBy("service.createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public void addService(Service service) {
        jpaAccess.save(service);
    }

    public void update(Service service) {
        jpaAccess.update(service);
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(Service.class).append(" service where not exists(select se from ").append(Service.class).append(" se where se.mainId = service.id) ").append(" and service.code=:code")
                        .param("code", code);
        query.append(" and service.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();

    }

    public List<Service> findMainService(String code, Page page) {
        Query query = Query.from(Service.class).append(" service where service.mainId is null and service.status=:status ").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(code)) {
            query.append(" and service.code = :code ");
            query.setParam("code", code);
        }
        query.orderBy("service.code").page(page);
        return jpaAccess.findPage(query);

    }

    public List<String> searchMainServiceCodes(String key) {
        Query query = Query.create("select distinct code from " + Service.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.append(" and mainId is null");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchServiceCodes(String key) {
        Query query = Query.create("select distinct code from " + Service.class.getName() + " service");
        query.append(" where not exists(select s from ").append(Service.class).append(" s where s.mainId = service.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        Service service = jpaAccess.get(Service.class, id);
        if (StringUtils.isNotBlank(service.getMainId()) && !"0".equals(service.getMainId())) { // 如果是帶有正本的副本
            jpaAccess.delete(service); // 刪掉副本
            jpaAccess.update(Query.create("update ").append(Service.class).append(" service set service.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", service.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(Service.class).append(" service set service.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(txn關聯Service)
    public List<Txn> isRelatedService(String id) {
        Query relTxn = Query.create("select txn  from " + Txn.class.getName() + " txn");
        relTxn.append(" where txn.serviceId = :id ").param("id", id);
        return jpaAccess.find(relTxn);
    }

}
