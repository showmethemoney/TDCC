package com.fubon.esb.controller.common;

import java.util.List;

import javax.inject.Inject;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.cookie.RequireCookie;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.session.RequireSession;
import com.fubon.esb.controller.common.view.TimeZone;
import com.fubon.esb.controller.common.view.TimeZoneSet;
import com.fubon.esb.domain.system.User;

/**
 * @author james
 * @createdDate 2014-11-28
 */
@RequireCookie
@RequireSession
@Controller
public class TimeZoneController {

    @Inject
    private Environment env;

    @Inject
    private LoginContext loginContext;


    @RequestMapping(value = "/timeZoneSet")
    @ResponseBody
    public List<TimeZone> timeZoneSet() {
        String gmt = env.getRequiredProperty("gmt.time.zone");
        List<TimeZone> list = JSONBinder.fromJSON(TimeZoneSet.class, gmt).getTimezones();
        User user = loginContext.loginedUser(User.class);
        if (user != null && user.getTimeZone() != null) {
            for (TimeZone timeZone : list) {
                if (timeZone.getZone().equals(user.getTimeZone())) {
                    timeZone.setSelect("true");
                } else {
                    timeZone.setSelect("false");
                }
            }
        }
        return list;
    }

    @RequestMapping(value = "/changeTimeZone")
    @ResponseBody
    public void changeTimeZone(String timeZone) {
        User user = loginContext.loginedUser(User.class);
        if (user != null) {
            user.setTimeZone(timeZone);
            loginContext.login(user);
        }
    }
}
