package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 交易關聯Channel
 * 
 * @author Shelly
 * @createdDate 2014-10-31
 */
@Entity(name = "CFG_TXN_CHANNEL")
public class TxnChannel implements Serializable {

    /** 交易ID **/
    @Id
    @Column(name = "TXN_ID")
    private String txnId;

    /** channel_id **/
    @Id
    @Column(name = "CHANNEL_ID")
    private String channelId;

    public TxnChannel() {
        super();
    }

    public TxnChannel(String txnId, String channelId) {
        super();
        this.txnId = txnId;
        this.channelId = channelId;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((channelId == null) ? 0 : channelId.hashCode());
        result = prime * result + ((txnId == null) ? 0 : txnId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TxnChannel other = (TxnChannel) obj;
        if (channelId == null) {
            if (other.channelId != null)
                return false;
        } else if (!channelId.equals(other.channelId))
            return false;
        if (txnId == null) {
            if (other.txnId != null)
                return false;
        } else if (!txnId.equals(other.txnId))
            return false;
        return true;
    }

}
