package com.fubon.esb.controller.system.view;

/**
 * @author Qigers
 * @createdDate 2015-1-15
 */
public class UserConfigVO {

    private String userId;

    private String username;

    private String subject;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

}
