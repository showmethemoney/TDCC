package com.fubon.esb.domain.config;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * 交易月統計
 * 
 * @author Leckie Zhang
 * @createdDate 2014-12-1
 */
@Entity(name = "TXN_STAT_MON")
public class TxnStatMon {
    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "paymentableGenerator")
    @GenericGenerator(name = "paymentableGenerator", strategy = "identity")
    private BigInteger id;

    /** 統計日期 */
    @Column(name = "DAY")
    private Date day;

    /** 統計月份 */
    @Column(name = "MONTH")
    private Integer month;

    /** 電文統計方式 */
    @Column(name = "TYPE")
    private Integer type;

    /** 資料類別 */
    @Enumerated(EnumType.STRING)
    @Column(name = "CATEGORY")
    private TxnStatCategoryType category;

    /** 類別值 */
    @Column(name = "VALUE")
    private String value;

    /** 附加類別值 */
    @Column(name = "VALUE2")
    private String value2;
    
    /** 附加類別值 */
    @Column(name = "VALUE3")
    private String value3;

    /** 電文筆數 */
    @Column(name = "TOTAL_RECORD")
    private BigInteger totalRecord;

    public TxnStatMon() {
    }

    public TxnStatMon(Integer month, BigInteger totalRecord) {
        this.month = month;
        this.totalRecord = totalRecord;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public String getMonthStr() {
        if (month == null) {
            return "";
        }

        String monthStr = String.valueOf(month);
        return monthStr.substring(0, 4) + "/" + monthStr.subSequence(4, 6);
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public BigInteger getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(BigInteger totalRecord) {
        this.totalRecord = totalRecord;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public TxnStatCategoryType getCategory() {
        return category;
    }

    public void setCategory(TxnStatCategoryType category) {
        this.category = category;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }
    
    public String getReturnTime() {
        String returnTime = "D" + value;
        for (TxnStatReturnTimeType type : TxnStatReturnTimeType.values()) {
            if (returnTime.equals(type.name())) {
                return type.getValue();
            }
        }
        
        return "";
    }

}
