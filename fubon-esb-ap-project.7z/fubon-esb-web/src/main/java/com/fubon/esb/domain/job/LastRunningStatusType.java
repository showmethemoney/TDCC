package com.fubon.esb.domain.job;

public enum LastRunningStatusType {

    S("success"), F("fail"), R("running");

    private final String desc;

    private LastRunningStatusType(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }

}
