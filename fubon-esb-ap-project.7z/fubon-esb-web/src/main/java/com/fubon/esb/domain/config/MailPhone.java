package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 
 * @author Shelly
 * @createdDate 2014-12-11
 */
@Entity(name = "CFG_MAIL_PHONE")
public class MailPhone implements Serializable {

    /** 所屬群組 */
    @Id
    @Column(name = "GROUP_ID")
    private String groupId;

    /** 手機號碼 */
    @Id
    @Column(name = "PHONE")
    private String phone;

    public MailPhone(String groupId, String phone) {
        super();
        this.groupId = groupId;
        this.phone = phone;
    }

    public MailPhone() {
        super();
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
