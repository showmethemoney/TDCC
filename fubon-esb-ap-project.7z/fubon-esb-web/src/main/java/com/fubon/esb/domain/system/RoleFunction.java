package com.fubon.esb.domain.system;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 角色權限
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_ROLE_FUNCTION")
public class RoleFunction implements Serializable {

    /** 所屬角色 */
    @Id
    @Column(name = "ROLE_ID")
    private String roleId;

    /** 權限ID */
    @Id
    @Column(name = "FUNCTION_ID")
    private String funcCode;

    public RoleFunction() {
    }

    public RoleFunction(String roleId, String funcCode) {
        this.roleId = roleId;
        this.funcCode = funcCode;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getFuncCode() {
        return funcCode;
    }

    public void setFuncCode(String funcCode) {
        this.funcCode = funcCode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((funcCode == null) ? 0 : funcCode.hashCode());
        result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RoleFunction other = (RoleFunction) obj;
        if (funcCode == null) {
            if (other.funcCode != null)
                return false;
        } else if (!funcCode.equals(other.funcCode))
            return false;
        if (roleId == null) {
            if (other.roleId != null)
                return false;
        } else if (!roleId.equals(other.roleId))
            return false;
        return true;
    }

}
