package com.fubon.esb.domain.txn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author nice
 * @createdDate 2015-1-8
 */
@Entity(name = "TXN_FIELD_TESTVALUE")
public class TxnFieldTestValue {

    /** ID **/
    @Id
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    @Column(name = "ID")
    private String id;

    /** 欄位ID **/
    @Column(name = "FIELD_ID")
    private String fieldId;

    /** REf_DIR_ID **/
    @Column(name = "REF_DIR_ID")
    private String refDirectionId;

    /** 測試值 **/
    @Column(name = "TEST_VALUE")
    private String testValue;

    /** 測試值序號 **/
    @Column(name = "ORDER_NO")
    private Integer orderNo;

    public TxnFieldTestValue() {
    }

    public TxnFieldTestValue(String id, String fieldId, String refDirectionId, String testValue, Integer orderNo) {
        this.id = id;
        this.fieldId = fieldId;
        this.refDirectionId = refDirectionId;
        this.testValue = testValue;
        this.orderNo = orderNo;
    }

    public TxnFieldTestValueKey getKey() {
        return new TxnFieldTestValueKey(fieldId, orderNo, refDirectionId);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getRefDirectionId() {
        return refDirectionId;
    }

    public void setRefDirectionId(String refDirectionId) {
        this.refDirectionId = refDirectionId;
    }

    public String getTestValue() {
        return testValue;
    }

    public void setTestValue(String testValue) {
        this.testValue = testValue;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

}
