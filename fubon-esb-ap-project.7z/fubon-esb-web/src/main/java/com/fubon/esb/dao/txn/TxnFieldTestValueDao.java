package com.fubon.esb.dao.txn;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.txn.TxnFieldTestValue;

@Repository
public class TxnFieldTestValueDao extends JPADaoSupport<TxnFieldTestValue> {

    public List<TxnFieldTestValue> findTestValuesByFieldId(String fid) {
        Query query = Query.from(TxnFieldTestValue.class).append(" where fieldId=:fid").param("fid", fid).orderBy("orderNo");
        return jpaAccess.find(query);
    }

    public List<TxnFieldTestValue> getTestValue(String fid, int orderNo, String refDirId) {
        Query query = Query.from(TxnFieldTestValue.class).append(" where fieldId=:fid and orderNo=:orderNo and refDirectionId=:refDirId");
        query.param("fid", fid).param("orderNo", orderNo).param("refDirId", refDirId);
        return jpaAccess.find(query);
    }
    
    public List<TxnFieldTestValue> getTestValue(String fid, int orderNo) {
        Query query = Query.from(TxnFieldTestValue.class).append(" where fieldId=:fid and orderNo=:orderNo ");
        query.param("fid", fid).param("orderNo", orderNo);
        return jpaAccess.find(query);
    }

    public List<TxnFieldTestValue> getHeadTestValue(String fid, String refDirectionId) {
        Query query = Query.from(TxnFieldTestValue.class).append(" where fieldId=:fid and refDirectionId=:refDirectionId").param("fid", fid).param("refDirectionId", refDirectionId);
        return jpaAccess.find(query);
    }
}
