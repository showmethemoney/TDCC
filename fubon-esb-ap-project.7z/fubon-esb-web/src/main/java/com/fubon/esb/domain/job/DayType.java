package com.fubon.esb.domain.job;


public enum DayType {


   D("Day"),
   W("Week"),
    M("Month");

    private final String desc;

    private DayType(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }

}
