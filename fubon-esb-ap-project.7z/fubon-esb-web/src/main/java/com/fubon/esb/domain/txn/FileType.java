package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum FileType {

    /** 文件格式{T:TXT,X:XML} **/
    T("TXT"), X("XML");

    private String desc;

    FileType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

}
