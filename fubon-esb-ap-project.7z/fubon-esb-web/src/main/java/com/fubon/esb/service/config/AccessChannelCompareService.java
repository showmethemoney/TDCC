package com.fubon.esb.service.config;

import java.util.Arrays;
import java.util.Date;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.TxnGroup;

/**
 * @author Leckie Zhang
 * @createdDate 2014-12-31
 */
@Service
public class AccessChannelCompareService {

    public static final String LINEBREACKCODE = "\r";

    @Inject
    private LoginContext loginContext;

    @Inject
    private ConfigChangeService configChangeService;

    /**
     * AccessChannel新增或修改發送郵件
     */
    public void sendMail(AccessChannel newChannel, AccessChannel originChannel) {
        accessChannelCompare(newChannel, originChannel);
    }

    /**
     * AccessChannel修改
     */
    private void accessChannelCompare(AccessChannel newChannel, AccessChannel originChannel) {
        if (originChannel == null || "0".equals(originChannel.getMainId())) {
            addAccessChannelMessage(newChannel, originChannel);
            return;
        }

        StringBuilder newSb = new StringBuilder();
        StringBuilder oldSb = new StringBuilder();

        if (!compare(newChannel.getCode(), originChannel.getCode())) {
            newSb.append("Access Channel代號：").append("").append(newChannel.getCode()).append("").append(LINEBREACKCODE);
            oldSb.append("Access Channel代號：").append("").append(originChannel.getCode()).append("").append(LINEBREACKCODE);
        }
        if (!compare(newChannel.getName(), originChannel.getName())) {
            newSb.append("Access Channel名稱：").append("").append(newChannel.getName()).append("").append(LINEBREACKCODE);
            oldSb.append("Access Channel名稱：").append("").append(originChannel.getName()).append("").append(LINEBREACKCODE);
        }
        if (!compare(newChannel.getStatus().toString(), originChannel.getStatus().toString())) {
            newSb.append("使用狀態：").append("").append(getDisplayName(newChannel.getStatus())).append("").append(LINEBREACKCODE);
            oldSb.append("使用狀態：").append("").append(getDisplayName(originChannel.getStatus())).append("").append(LINEBREACKCODE);
        }
        if (!compare(newChannel.getEffectType().toString(), originChannel.getEffectType().toString())) {
            newSb.append("生效類型：").append("").append(getDisplayName(newChannel.getEffectType())).append("").append(LINEBREACKCODE);
            oldSb.append("生效類型：").append("").append(getDisplayName(originChannel.getEffectType())).append("").append(LINEBREACKCODE);
        }
        if (!compare(newChannel.getEffectTime(), originChannel.getEffectTime())) {
            if (isEffectTypeBooked(newChannel.getEffectType())) {
                newSb.append("生效時間：").append("").append(formatDate(newChannel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(LINEBREACKCODE);
            }
            if (isEffectTypeBooked(originChannel.getEffectType())) {
                oldSb.append("生效時間：").append("").append(formatDate(originChannel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(LINEBREACKCODE);
            }
        }

        if (newSb.length() == 0) {
            return;
        }

        StringBuilder result = new StringBuilder();
        result.append("Access Channel設定(Access Channel 代號：").append(newChannel.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append("").append(LINEBREACKCODE).append("現形生效內容：")
                .append(LINEBREACKCODE).append(oldSb).append(LINEBREACKCODE).append(LINEBREACKCODE).append("變更後內容：").append(LINEBREACKCODE).append(newSb);
        configChangeService.sendMailRequest("Access Channel設定變更", result.toString());
    }

    private void addAccessChannelMessage(AccessChannel accessChannel, AccessChannel originChannel) {
        StringBuilder result = new StringBuilder();
        String title;
        if (originChannel == null) {
            result.append("Access Channel設定新增，新增者：").append(loginContext.loginedUserId()).append("").append(LINEBREACKCODE).append("新增內容： ").append(LINEBREACKCODE);
            title = "Access Channel設定新增";
        } else {
            result.append("Access Channel設定(Access Channel 代號：").append(accessChannel.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append("").append(LINEBREACKCODE)
                    .append("現形生效內容：").append(LINEBREACKCODE).append(LINEBREACKCODE).append(LINEBREACKCODE).append("變更後內容：").append(LINEBREACKCODE);
            title = "Access Channel設定變更";
        }

        if (StringUtils.isNotBlank(accessChannel.getCode())) {
            result.append("Access Channel代號：").append(accessChannel.getCode()).append("").append(LINEBREACKCODE);
        }
        if (StringUtils.isNotBlank(accessChannel.getName())) {
            result.append("Access Channel名稱：").append(accessChannel.getName()).append("").append(LINEBREACKCODE);
        }
        if (accessChannel.getStatus() != null) {
            result.append("使用狀態：").append(getDisplayName(accessChannel.getStatus())).append("").append(LINEBREACKCODE);
        }
        if (accessChannel.getEffectType() != null) {
            result.append("生效類型：").append(getDisplayName(accessChannel.getEffectType())).append("").append(LINEBREACKCODE);
        }
        if (accessChannel.getEffectTime() != null && isEffectTypeBooked(accessChannel.getEffectType())) {
            result.append("生效時間：").append(formatDate(accessChannel.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append("").append(LINEBREACKCODE);
        }

        configChangeService.sendMailRequest(title, result.toString());
    }

    /**
     * 判斷兩個字符串是否相等 相等：true 不相等：false
     */
    public boolean compare(String newStr, String oldStr) {
        if (newStr != null) {
            return newStr.equals(oldStr);
        }
        if (oldStr != null) {
            return false;
        }
        return true;
    }

    /**
     * 判斷兩個日期是否相等 相等：true 不相等：false
     */
    public boolean compare(Date newDate, Date oldDate) {
        if (newDate != null) {
            return newDate.equals(oldDate);
        }
        if (oldDate != null) {
            return false;
        }
        return true;
    }

    /**
     * 判斷兩個數組是否相等 相等：true 不相等：false
     */
    public boolean compare(String[] newArray, String[] oldArray) {
        if (newArray != null) {
            if (oldArray != null) {
                return compareArray(newArray, oldArray);
            } else {
                return false;
            }
        } else {
            if (oldArray != null) {
                return false;
            }
            return true;
        }
    }

    private boolean compareArray(String[] newArray, String[] oldArray) {
        if (newArray.length != oldArray.length) {
            return false;
        } else {
            Arrays.sort(newArray);
            Arrays.sort(oldArray);
            return Arrays.equals(newArray, newArray);
        }
    }

    public String formatDate(Object... obj) {
        Date date = (Date) obj[0];
        String pattern = "yyyy/MM/dd HH:mm:ss";
        if (obj.length == 2) {
            pattern = obj[1].toString();
        }
        if (date == null) {
            return "";
        }
        return DateFormatUtils.format(date, pattern);
    }

    public String arrayToString(Object[] array) {
        if (array == null || array.length == 0) {
            return "";
        }
        return Arrays.toString(array).replace("[", "").replace("]", "");
    }

    public String getDisplayName(ConfigActiveStatus status) {
        if (status == null) {
            return "";
        }
        if ("A".equals(status.name())) {
            return "啟用";
        }

        return "停用";
    }

    public String getDisplayName(EffectType type) {
        if (type == null) {
            return "";
        }

        if ("I".equals(type.name())) {
            return "即時";
        }

        return "預約生效";
    }

    /** 判斷生效時間是否是預約生效 */
    public boolean isEffectTypeBooked(EffectType type) {
        return "B".equals(type.name());
    }

    //
    public boolean compare(com.fubon.esb.domain.config.Service newService, com.fubon.esb.domain.config.Service originService) {
        if (newService != null) {
            if (originService != null) {
                return compare(newService.getId(), originService.getId());
            } else {
                return false;
            }
        } else {
            if (originService != null) {
                return false;
            }
        }
        return true;
    }

    public boolean compare(TxnGroup newTxnGroup, TxnGroup originTxnGroup) {
        if (newTxnGroup != null) {
            if (originTxnGroup != null) {
                return compare(newTxnGroup.getId(), originTxnGroup.getId());
            } else {
                return false;
            }
        } else {
            if (originTxnGroup != null) {
                return false;
            }
        }
        return true;
    }

    public boolean compare(Connector newConnector, Connector originConnector) {
        if (newConnector != null) {
            if (originConnector != null) {
                return compare(newConnector.getId(), originConnector.getId());
            } else {
                return false;
            }
        } else {
            if (originConnector != null) {
                return false;
            }
        }
        return true;
    }

    public boolean compare(Integer newInteger, Integer originInteger) {
        if (newInteger != null) {
            return newInteger.equals(originInteger);
        }
        if (originInteger != null) {
            return false;
        }
        return true;
    }
}
