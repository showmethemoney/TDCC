package com.fubon.esb.domain.config;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * 交易統計
 * 
 * @author Leckie Zhang
 * @createdDate 2014-11-14
 */
@Entity(name = "TXN_STAT")
public class TxnStat {

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "paymentableGenerator")
    @GenericGenerator(name = "paymentableGenerator", strategy = "identity")
    private BigInteger id;

    /** 統計日期 */
    @Column(name = "DAY")
    private Date day;

    /** 統計小時 */
    @Column(name = "HOUR")
    private BigDecimal hour;

    /** 電文統計方式 */
    @Column(name = "TYPE")
    private Integer type;

    /** 資料類別 */
    @Enumerated(EnumType.STRING)
    @Column(name = "CATEGORY")
    private TxnStatCategoryType category;

    /** 類別值 */
    @Column(name = "VALUE")
    private String value;

    /** 附加類別值 */
    @Column(name = "VALUE2")
    private String value2;
    
    /** 附加類別值 */
    @Column(name = "VALUE3")
    private String value3;

    /** 電文筆數 */
    @Column(name = "TOTAL_RECORD")
    private BigInteger totalRecord;

    /** 平均回應時間 */
    @Column(name = "AVG_TIME")
    private BigInteger avgTime;
    
    public TxnStat() {
    }

    public TxnStat(Date day, BigDecimal hour, String value, String value2, String value3, BigInteger totalRecord) {
        this.day = day;
        this.hour = hour;
        this.value = value;
        this.value2 = value2;
        this.value3 = value3;
        this.totalRecord = totalRecord;
    }

    public TxnStat(Date day, BigDecimal hour, String value, String value2, String value3, BigInteger totalRecord, BigInteger avgTime) {
        this(day, hour, value, value2, value3, totalRecord);
        this.avgTime = avgTime;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    public BigDecimal getHour() {
        return hour;
    }

    public void setHour(BigDecimal hour) {
        this.hour = hour;
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public TxnStatCategoryType getCategory() {
        return category;
    }

    public void setCategory(TxnStatCategoryType category) {
        this.category = category;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public BigInteger getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(BigInteger totalRecord) {
        this.totalRecord = totalRecord;
    }

    public BigInteger getAvgTime() {
        return avgTime;
    }

    public void setAvgTime(BigInteger avgTime) {
        this.avgTime = avgTime;
    }
    
    private String fullFillDecimal(BigDecimal b) {
        int i = b.intValue();
        int j = b.subtract(new BigDecimal(i)).multiply(new BigDecimal("60")).intValue();
        StringBuilder result = new StringBuilder(String.valueOf(i * 100 + j));
        while (result.length() < 4) {
            result.insert(0, "0");
        }
        return result.insert(2, ":").toString();
    }
    
    /**時間區間 格式00:30*/
    public String getHourRange() {
        if (hour == null) {
            return "";
        }
        BigDecimal later = hour.add(new BigDecimal("0.5"));
        return fullFillDecimal(hour) + "-" + fullFillDecimal(later);
    }
    
    public String getReturnTime() {
        String returnTime = "D" + value;
        for (TxnStatReturnTimeType type : TxnStatReturnTimeType.values()) {
            if (returnTime.equals(type.name())) {
                return type.getValue();
            }
        }
        
        return "";
    }

}
