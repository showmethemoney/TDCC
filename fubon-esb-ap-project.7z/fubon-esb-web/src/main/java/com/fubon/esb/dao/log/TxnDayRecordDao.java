package com.fubon.esb.dao.log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.query.view.TxnDayRecordsVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.log.TxnRecord;
import com.fubon.esb.domain.log.TxnRecordMsg;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Qigers
 * @createdDate 2014-11-12
 */
@Repository
public class TxnDayRecordDao extends LogDBJPADaoSupport<TxnRecordMsg> {

    @Inject
    private TimeZoneService timeZoneService;
    
    /**
     * 根據日期、時、分組合Date
     */
    private Date getFullTime(String today, String theHour, String theMinute, String theSecond, String theMillisecond) {
        if (StringUtils.isNotBlank(today) && StringUtils.isNotBlank(theHour) && StringUtils.isNotBlank(theMinute)) {
            try {
                return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").parse(today + " " + theHour + ":" + theMinute + ":" + theSecond + "." + theMillisecond);
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
                return null;
            }
        }
        return null;
    }

    /**
     * 根據日期、時、分構建當日Date中的startTime
     */
    private Date getStartTime(TxnDayRecordsVO vo) {
        // String today = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
        String today = vo.getStartDate();
        Date startTime = getFullTime(today, "00", "00", "00", "000");
        if (StringUtils.isNotBlank(vo.getStartHour()) || StringUtils.isNotBlank(vo.getStartMinute())) {
            startTime = getFullTime(today, vo.getStartHour(), vo.getStartMinute(), "00", "000");
        }
        return startTime;
    }

    /**
     * 根據日期、時、分構建當日Date中的endTime
     */
    private Date getEndTime(TxnDayRecordsVO vo) {
        // String today = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
        String today = vo.getStartDate();
        Date endTime = getFullTime(today, "23", "59", "59", "999");
        if (StringUtils.isNotBlank(vo.getEndHour()) || StringUtils.isNotBlank(vo.getEndMinute())) {
            endTime = getFullTime(today, vo.getEndHour(), vo.getEndMinute(), "59", "999");
        }
        return endTime;
    }

    /**
     * 構建查詢條件
     */
    private StringBuilder getSqlCondition(TxnDayRecordsVO vo, StringBuilder jql, Map<String, Object> params) {
        Date startTime = getStartTime(vo);
        Date endTime = getEndTime(vo);
        if (startTime != null) {
            jql.append(" and t.startTime >= :startTime ");
            params.put("startTime", timeZoneService.getTZDateByService(startTime));
        }
        if (endTime != null) {
            jql.append(" and t.startTime <= :endTime ");
            params.put("endTime", timeZoneService.getTZDateByService(endTime));
        }
        if (StringUtils.isNotBlank(vo.getSequence())) {
            jql.append(" and t.sequence = :sequence ");
            params.put("sequence", vo.getSequence().replaceAll("^(0+)", ""));
        }
        if (StringUtils.isNotBlank(vo.getReturnCode())) {
            jql.append(" and t.returnCode like :returnCode ");
            params.put("returnCode", "%" + vo.getReturnCode() + "%");
        }
        if (StringUtils.isNotBlank(vo.getTxnCode())) {
            jql.append(" and t.txnCode = :txnCode ");
            params.put("txnCode", vo.getTxnCode());
        }
        if (StringUtils.isNotBlank(vo.getChannelCode())) {
            jql.append(" and t.channelCode = :channelCode ");
            params.put("channelCode", vo.getChannelCode());
        }
        // if (StringUtils.isNotBlank(vo.getDuration())) {
        // jql.append(" and t.duration >= :duration ");
        // params.put("duration", vo.getDuration());
        // }
        if (StringUtils.isNotBlank(vo.getUuid())) {
            jql.append(" and t.uuid = :uuid ");
            params.put("uuid", vo.getUuid());
        }
        return jql;
    }
    
    @Transactional(propagation=Propagation.NEVER, readOnly=true)
    public Map<String, Long> findDurationByTrackingIds(List<String> trackingIds) {
    	Map<String, Long> result = new HashMap<String, Long>();
    	Query query = null;
    	
    	for(String trackingId : trackingIds) {
    		query  = Query.create( "SELECT o.createTime FROM " + TxnRecordMsg.class.getName() + " o WHERE o.trackingId = :trackingId AND o.layer = 'ListenerLayer' ORDER BY o.direction ASC" );
        	query.param( "trackingId", trackingId );
        	
        	List<Date> txnRecordCreateTimes = jpaAccess.find( query );
        	
        	if (! txnRecordCreateTimes.isEmpty()) {
        		// sql order by direction ASC (D, U)，所以第一筆放入map 的都會是 D，如果出現重複，就是 U
        		for (Date txnRecordCreateTime : txnRecordCreateTimes) {
    				
    				if (result.containsKey( trackingId )) {
    					result.put( trackingId, (long) result.get( trackingId ) - txnRecordCreateTime.getTime() );					 
    				} else {
    					result.put( trackingId, txnRecordCreateTime.getTime() );
    				}
    			}
        	}
    	}
    	
    	return result;
    }
    
    /**
     * 查詢當日交易記錄
     */
    public Object findTxnDayRecordDaoList(TxnDayRecordsVO vo, OrderBy orderBy, Page page) {
        StringBuilder jql = new StringBuilder();
        jql.append("select t from " + TxnRecord.class.getName() + " t where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        jql = getSqlCondition(vo, jql, params);

        // TODO(11) 用分頁的方式完成查詢
        Query query = Query.create(jql.toString());
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            query.orderBy(" startTime desc ");
        } else {
            query.orderBy(orderBy.getClause());
        }
        query.page(page).putParams(params);
        List<TxnRecord> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    /**
     * 查詢交易記錄
     */
    public TxnRecord findTxnRecordDetailDao(TxnDayRecordsVO vo, Page page, String id) {
        StringBuilder jql = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(id)) {
            jql.append(" from " + TxnRecord.class.getName()).append(" where 1=1 " + " and id=:id ");
            params.put("id", id);
        }
        Query query = Query.create(jql.toString());
        query.putParams(params);
        TxnRecord txnRecord = (TxnRecord) jpaAccess.find(query).get(0);
        if (txnRecord == null) {
            return new TxnRecord();
        }
        return txnRecord;
    }

    public TxnRecord findTxnRecordExcelDetailDao(String id) {
        StringBuilder jqlString = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(id)) {
            jqlString.append(" from " + TxnRecord.class.getName()).append(" where 1=1 " + " and id=:id ");
            params.put("id", id);
        }
        Query query = Query.create(jqlString.toString());
        query.putParams(params);
        TxnRecord txnRecord = (TxnRecord) jpaAccess.find(query).get(0);
        if (txnRecord == null) {
            return new TxnRecord();
        }
        return txnRecord;
    }

    /**
     * 查詢交易記錄詳情
     */
    @Transactional(readOnly = true)
    public Object findTxnRecordMsgDetailDaoList(TxnDayRecordsVO vo, Page page, String trackingId) {
        StringBuilder jql = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(trackingId)) {
            jql.append(" select tm from " + TxnRecordMsg.class.getName() + " tm ").append(" , ").append(TxnRecord.class.getName()).append(" t ")
                    .append(" where 1=1 " + " and t.trackingId=tm.trackingId and tm.trackingId=:trackingId ");
            params.put("trackingId", trackingId);
        }
        
        if (vo.getSonOrderBy() != null && StringUtils.isNotBlank(vo.getSonOrderBy().getField())) {
//            query.orderBy(" tm.txnCode ");
            jql.append(" order by ").append(vo.getSonOrderBy().getClause());
        } else {
            jql.append(" order by tm.createTime ");
//            query.orderBy(" tm.createTime ");
        }
        Query query = Query.create(jql.toString());
        query.page(page).putParams(params);
        List<TxnRecordMsg> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    public Object findTxnRecordMsgDetailExcelDaoList(String trackingId) {
        StringBuilder jqlString = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(trackingId)) {
            jqlString.append(" select tm from " + TxnRecordMsg.class.getName() + " tm ").append(" , ").append(TxnRecord.class.getName()).append(" t ")
                    .append(" where 1=1 " + " and t.trackingId=tm.trackingId and tm.trackingId=:trackingId ");
            params.put("trackingId", trackingId);
        }
        Query query = Query.create(jqlString.toString());
        query.orderBy(" tm.createTime ");
        query.putParams(params);
        List<TxnRecordMsg> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    /**
     * 查看電文內容詳情
     */
    public TxnRecordMsg findTxnRecordMsg(String id) {
        StringBuilder jql = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        jql.append(" from " + TxnRecordMsg.class.getName());
        jql.append(" where 1=1 ");
        jql.append(" and id= :id");
        params.put("id", id);
        Query query = Query.create(jql.toString());
        query.putParams(params);
        TxnRecordMsg txnRecordMsg = (TxnRecordMsg) jpaAccess.find(query).get(0);
        if (txnRecordMsg == null) {
            return new TxnRecordMsg();
        }
        return txnRecordMsg;
    }

    /**
     * 查詢滿足搜索條件當日交易記錄 導出EXCEL
     */
    public Object findTxnRecordDaoList(TxnDayRecordsVO vo) {
        StringBuilder jql = new StringBuilder();
        jql.append("select t from " + TxnRecord.class.getName() + " t where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        jql = getSqlCondition(vo, jql, params);
        Query query = Query.create(jql.toString());
        query.orderBy("  startTime desc ");
        query.putParams(params);
        List<TxnRecord> txnRecords = jpaAccess.find(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    public List<String> searchTxnCodes(String key) {
        Query query = Query.create("select distinct txnCode from " + TxnRecord.class.getName());
        query.where(" txnCode like :txnCode").param("txnCode", key + "%");
        query.orderBy("txnCode");
        return jpaAccess.find(query);
    }

    public List<String> searchChannelCodes(String key) {
        Query query = Query.create("select distinct channelCode from " + TxnRecord.class.getName());
        query.where(" channelCode like :channelCode").param("channelCode", key + "%");
        query.orderBy("channelCode");
        return jpaAccess.find(query);
    }

    public List<String> searchHostCodes(String key) {
        Query query = Query.create("select distinct hostCode from " + TxnRecord.class.getName());
        query.where(" hostCode like :hostCode").param("hostCode", key + "%");
        query.orderBy("hostCode");
        return jpaAccess.find(query);
    }

    public List<String> searchGroupCodes(String key) {
        Query query = Query.create("select distinct groupCode from " + TxnRecord.class.getName());
        query.where(" groupCode like :groupCode").param("groupCode", key + "%");
        query.orderBy("groupCode");
        return jpaAccess.find(query);
    }

    public List<String> searchUUIDs(String key) {
        Query query = Query.create("select distinct uuid from " + TxnRecord.class.getName());
        query.where(" uuid like :uuid").param("uuid", key + "%");
        query.orderBy("uuid");
        return jpaAccess.find(query);
    }

    public List<String> searchServiceCodes(String key) {
        Query query = Query.create("select distinct serviceCode from " + TxnRecord.class.getName());
        query.where(" serviceCode like :serviceCode").param("serviceCode", key + "%");
        query.orderBy("serviceCode");
        return jpaAccess.find(query);
    }
}
