package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.service.config.AccessChannelService;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ChannelService;
import com.fubon.esb.service.config.ConfigChangeService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Controller
@RequestMapping("/accessChannel")
public class AccessChannelController extends BaseController {

    @Inject
    private AccessChannelService accessChannelService;
    @Inject
    private ChannelService channelService;
    @Inject
    private LoginContext loginContext;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSearchAccessChannelList")
    public String viewSearchAccessChannel(Model model) {
        return "/config/viewAccessChannelList";
    }

    @RequestMapping("/viewAccessChannelList")
    @RequirePermission(value = "050301")
    public String viewAccessChannel(Model model, String code, String name, ConfigActiveStatus status, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<AccessChannel> accessChannelList = accessChannelService.findLatestAccessChannels(code, name, status, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            accessChannelList = accessChannelService.findLatestAccessChannels(code, name, status, page);
        }
        model.addAttribute("accessChannelList", accessChannelList);
        model.addAttribute("code", code);
        model.addAttribute("name", name);
        model.addAttribute("status", status);
        model.addAttribute("page", page);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        return "/config/viewAccessChannelList";

    }

    @RequestMapping("/viewChannelByAcId")
    public String viewChannelByAcId(Model model, String accessChannelId) {
        List<Channel> channelList = channelService.findChannelsByAccessChannelId(accessChannelId);
        model.addAttribute("channelList", channelList);
        return "/config/viewRelateChannel";
    }

    @RequestMapping("/viewAddAccessChannel")
    @RequirePermission(value = "050302")
    public String viewAddAccessChannel(Model model) {
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        return "/config/viewAddAccessChannel";
    }
    
    
    @RequestMapping("/refreshAccessChannel")
    @ResponseBody
    public Object refreshAccessChannel(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_ACCESS_CHANNEL, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    

    @RequestMapping("/saveAccessChannel")
    @ResponseBody
    public ResultView saveAccessChannel(@Valid AccessChannel accessChannel, String effectDate, String effectHour, String effectMinute) {
        try {
            String accessChannelId = accessChannelService.saveAccessChannel(accessChannel, effectDate, effectHour, effectMinute);
            configChangeService.sendChangeEvent(ConfigType.CFG_ACCESS_CHANNEL, accessChannelId);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/accessChannel/viewAccessChannelList");
    }

    @RequestMapping("/viewUpdateAccessChannel")
    @RequirePermission(value = "050303")
    public String viewUpdateAccessChannel(Model model, String id) {
        AccessChannel accessChannel = null;
        List<Channel> channelList = null;
        accessChannel = accessChannelService.getAccessChannelById(id);
        channelList = channelService.findChannelsByAccessChannelId(id);
        String channels = "";
        String txnCodes = "";
        if (channelList != null && !channelList.isEmpty()) {
            channels = accessChannelService.getChannelCodes(channelList);
            txnCodes = accessChannelService.getTxnCodes(channelList);
        }
        model.addAttribute("accessChannel", accessChannel);
        model.addAttribute("channels", channels);
        model.addAttribute("txnCodes", txnCodes);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewUpdateAccessChannel";
    }

    @RequestMapping("/updateAccessChannel")
    @ResponseBody
    public ResultView updateAccessChannel(@Valid AccessChannel accessChannel, String effectDate, String effectHour, String effectMinute) {
        try {
            String accessChannelId = accessChannelService.updateAccessChannel(accessChannel, effectDate, effectHour, effectMinute);
            configChangeService.sendChangeEvent(ConfigType.CFG_ACCESS_CHANNEL, accessChannelId);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/accessChannel/viewAccessChannelList");
    }

    @RequestMapping("/viewMainAccessChannel")
    public String findMainAccessChannel(Model model, @RequestParam(required = false, defaultValue = "1") int currentPage, @RequestParam(required = false) String accessChannelCode) {
        Page page = new Page(currentPage);
        List<AccessChannel> achannel = accessChannelService.findMainAccessChannels(accessChannelCode, page);
        model.addAttribute("achannel", achannel);
        model.addAttribute("accessChannelCode", accessChannelCode);
        model.addAttribute("page", page);
        return "/config/viewAllAccessChannel";
    }

    @ResponseBody
    @RequestMapping({"/findAccessChannelCodes"})
    public Object findAccessChannelCodes(@RequestParam String key) {
        return autoQueryService.serchAccessChannelCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findMainAccessChannelCodes"})
    public Object findMainAccessChannelCodes(@RequestParam String key) {
        return autoQueryService.serchMainAccessChannelCodes(key);
    }

    @RequestMapping("/viewAccessChannelDetail")
    @RequirePermission(value = "050301")
    public String viewAccessChannelDetail(Model model, String id) {
        AccessChannel accessChannel = null;
        List<Channel> channelList = null;
        String channels = "";
        String txnCodes = "";
        accessChannel = accessChannelService.getAccessChannelById(id);
        channelList = channelService.findChannelsByAccessChannelId(id);
        if (channelList != null && !channelList.isEmpty()) {
            channels = accessChannelService.getChannelCodes(channelList);
            txnCodes = accessChannelService.getTxnCodes(channelList);
        }
        model.addAttribute("accessChannel", accessChannel);

        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        model.addAttribute("channels", channels);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("txnCodes", txnCodes);
        return "/config/viewAccessChannelDetail";
    }

    // 刪除
    @RequestMapping("/deleteAccessChannel")
    @ResponseBody
    public Object deleteAccessChannel(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = accessChannelService.isRelatedAccessChannel(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + "關聯以下channel" + relateMessage);
        } else {
            accessChannelService.deleteAccessChannel(id);
            flag = true;
            result.put("flag", flag);
        }
        return result;
    }
    
    
}
