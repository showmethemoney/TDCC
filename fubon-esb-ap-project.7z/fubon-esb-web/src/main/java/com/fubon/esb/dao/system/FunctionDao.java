package com.fubon.esb.dao.system;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.Function;
import com.fubon.esb.domain.system.RoleFunction;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-3
 */
@Repository
public class FunctionDao extends JPADaoSupport<Function> {
    
    public List<Function> findFunctionByLevel(Integer level) {
        return jpaAccess.find(Query.from(Function.class).where("level = :level").param("level", level).orderBy("orderNo"));
    }
    
    public List<Function> findFunctionByRole(String roleId) {
        return jpaAccess.find(Query.create("from " + Function.class.getName() + " where code in( select funcCode from "
            + RoleFunction.class.getName() + " where roleId = :roleId )").param("roleId", roleId));
    }
    
    public List<String> findFuncCodesByRole(String roleId) {
        return jpaAccess.find(Query.create("select code from " + Function.class.getName() + " where code in( select funcCode from "
                + RoleFunction.class.getName() + " where roleId = :roleId )").param("roleId", roleId));
    }
    
    public List<String> findFuncCodesFromRoles(List<String> roleIds) { // TODO(可以優化)
        return jpaAccess.find(Query.create("select distinct code from " + Function.class.getName() + " where code in( select distinct funcCode from "
                + RoleFunction.class.getName() + " where roleId in (:roleId) )").param("roleId", roleIds));
    }

}
