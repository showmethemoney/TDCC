package com.fubon.esb.controller.config.view;

import com.fubon.esb.domain.config.ConfigActiveStatus;

/**
 * Service查詢參數
 * 
 * @author Shelly
 * @createdDate 2014-11-3
 */
public class ServiceView {

    private String code;
    private String name;
    private String version;
    private String txnCode;
    private ConfigActiveStatus status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
