package com.fubon.esb.service.txn;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.comwave.core.database.OrderBy;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;

/**
 * @author nice
 * @createdDate 2014-11-24
 */
@Service
public class BaseTxnService extends TxnLogService {

    @Inject
    protected TxnDefinitionService txnDefinitionService;

    @Inject
    protected TxnDirectionService txnDirectionService;

    @Inject
    protected TxnFieldDefinitionService txnFieldService;

    private final Logger logger = LoggerFactory.getLogger(BaseTxnService.class);

    @Transactional
    public void removeTxn(String txnDefId) {
        if (StringUtils.isBlank(txnDefId))
            return;
        removeDirectionAndFields(txnDefId);
        txnDefinitionService.removeById(txnDefId);
    }

    @Transactional
    public void removeDirectionAndFields(String txnDefId) {
        List<TxnDirection> txnDirs = txnDirectionService.getByTxnDefId(txnDefId);
        if ((txnDirs != null) && (!txnDirs.isEmpty()))
            for (TxnDirection td : txnDirs) {
                txnFieldService.removeByTxnDirection(td.getId());
            }
        txnDirectionService.removeByTxnDef(txnDefId);
    }

    @Transactional
    public TxnDefinition getOrCreateCopyTxnDef(String mainId, String userId) {
        if (StringUtils.isBlank(mainId)) {
            return null;
        }
        TxnDefinition mainDef = txnDefinitionService.getById(mainId);
        Assert.notNull(mainDef, "main definition can not be null!");
        if (!TxnStatus.M.equals(mainDef.getStatus()))
            return mainDef;
        List<TxnDefinition> copys = txnDefinitionService.getCopyTxnDefinition(mainId);
        if ((copys != null) && (!copys.isEmpty())) {
            return (TxnDefinition) copys.get(0);
        }
        TxnDefinition copy = new TxnDefinition();
        BeanUtils.copyProperties(mainDef, copy, "id");
        copy.setId(null);
        copy.setMainId(mainId);
        copy.setStatus(TxnStatus.E);
        copy.setUpdatedTime(new Date());
        copy.setUpdatedUser(userId);
        txnDefinitionService.saveOrUpdate(copy);
        createTxnDirCopyByDefId(mainId, copy.getId());
        return copy;
    }

    @Transactional
    public void createTxnDirCopyByDefId(String mainDefId, String copyDefId) {
        TxnDirection direction = null;
        List<TxnDirection> dirs = txnDirectionService.getByTxnDefId(mainDefId);
        if ((dirs != null) && (!dirs.isEmpty())) {
            for (TxnDirection td : dirs) {
                direction = new TxnDirection();
                BeanUtils.copyProperties(td, direction);
                direction.setId(null);
                direction.setDefinitionId(copyDefId);
                txnDirectionService.saveOrUpdate(direction);
                createTxnFieldCopyByDirId(td.getId(), direction.getId());
            }
        }
    }

    @Transactional
    public void createTxnFieldCopyByDirId(String mainDirId, String copyDirId) {
        Map<String, String> historys = new HashMap<String, String>(0);
        TxnFieldDefinition field = null;
        OrderBy orderBy = new OrderBy("orderNo");
        orderBy.and("parentId");
        List<TxnFieldDefinition> fields = txnFieldService.findByTxnDirId(mainDirId, orderBy);
        if ((fields != null) && (!fields.isEmpty())) {
            for (TxnFieldDefinition tfd : fields) {
                field = new TxnFieldDefinition();
                BeanUtils.copyProperties(tfd, field);
                field.setId(null);
                field.setDirectionId(copyDirId);
                if (StringUtils.isNoneBlank(new CharSequence[] {tfd.getParentId()})) {
                    field.setParentId((String) historys.get(tfd.getParentId()));
                }
                txnFieldService.save(field);
                historys.put(tfd.getId(), field.getId());
            }
        }
    }

    @Transactional
    public void mutipleCopyDefsToMainDefs(String[] copyDefIds, String updateUser) {
        if (copyDefIds != null && copyDefIds.length != 0) {
            for (String copDefId : copyDefIds) {
                copyDefToMainDef(copDefId, updateUser);
            }
        }
    }

    @Transactional
    public void copyDefToMainDef(String copyDefId, String updateUser) {
        // find copy definition
        TxnDefinition copyDef = txnDefinitionService.getById(copyDefId);
        if (copyDef == null) {
            logger.info("can not find copy definition object with id[" + copyDefId + "]!");
            return;
        }
        boolean isMain = TxnDefinition.INIT_MAIN_ID.equals(copyDef.getMainId()) || StringUtils.isBlank(copyDef.getMainId());
        if (isMain || becomeMainDef(copyDef, updateUser) == null) {
            copyDef.setStatus(TxnStatus.M);
            copyDef.setUpdatedTime(new Date());
            copyDef.setMainId(null);
            copyDef.setUpdatedUser(updateUser);
            copyDef.setApprovedUser(updateUser);
            copyDef.setApprovedTime(new Date());
            logToDB(messages.getMessage("txn.check.log.check", copyDef.getTxnCode(), copyDef.getName(), copyDef.getTxnCode(), copyDef.getName()), LogType.TXN_APPROVE);
            txnDefinitionService.saveOrUpdate(copyDef);
        }
    }

    @Transactional
    public TxnDefinition becomeMainDef(TxnDefinition copyDef, String updateUser) {
        if (copyDef == null)
            return null;
        TxnDefinition mainDef = txnDefinitionService.getById(copyDef.getMainId());
        if (mainDef != null) {
            Assert.isTrue(TxnStatus.M.equals(mainDef.getStatus()), "[copy to main] main definition is not status of M!");
            removeDirectionAndFields(mainDef.getId());
            List<TxnDirection> latestDirs = txnDirectionService.getByTxnDefId(copyDef.getId());
            if (latestDirs != null && !latestDirs.isEmpty())
                for (TxnDirection dir : latestDirs) {
                    dir.setDefinitionId(mainDef.getId());
                    txnDirectionService.saveOrUpdate(dir);
                }
            BeanUtils.copyProperties(copyDef, mainDef, "id", "status", "mainId");
            mainDef.setUpdatedTime(new Date());
            mainDef.setMainId(null);
            mainDef.setUpdatedUser(updateUser);
            mainDef.setApprovedUser(updateUser);
            mainDef.setApprovedTime(new Date());
            logToDB(messages.getMessage("txn.check.log.check", copyDef.getTxnCode(), copyDef.getName(), mainDef.getTxnCode(), mainDef.getName()), LogType.TXN_APPROVE);
            txnDefinitionService.removeById(copyDef.getId());
            txnDefinitionService.saveOrUpdate(mainDef);
        }
        return mainDef;
    }
}
