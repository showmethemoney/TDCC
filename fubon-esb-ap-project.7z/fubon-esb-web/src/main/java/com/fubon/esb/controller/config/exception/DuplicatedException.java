package com.fubon.esb.controller.config.exception;

public class DuplicatedException extends RuntimeException {

    public DuplicatedException() {
        super();
    }

    public DuplicatedException(String message, Throwable throwable) {
        super(message, throwable);
    }

    public DuplicatedException(String message) {
        super(message);
    }

    public DuplicatedException(Throwable throwable) {
        super(throwable);
    }
}
