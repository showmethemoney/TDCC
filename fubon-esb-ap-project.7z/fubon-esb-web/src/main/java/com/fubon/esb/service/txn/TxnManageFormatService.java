package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.fubon.esb.controller.txn.view.TxnManageVo;

/**
 * 
 * @author Shelly
 * @createdDate 2015-1-14
 */
@Service
public class TxnManageFormatService {

    private void updateMap(Map<String, List<TxnManageVo>> txnManageMap, String keys, TxnManageVo txnManageVo) {
        if (txnManageMap.get(keys) == null) {
            List<TxnManageVo> txnManageList = new ArrayList<>();
            txnManageList.add(txnManageVo);
            txnManageMap.put(keys, txnManageList);
        } else {
            txnManageMap.get(keys).add(txnManageVo);
        }

    }

    public Map<String, List<TxnManageVo>> formatQueryConnectorList(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getConnectorId()).append("#").append(txnManageVo.getConnectorName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> formatQueryTxnGroupList(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getTxnGroupId()).append("#").append(txnManageVo.getTxnGroupName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);

        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> formatQueryServiceList(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getServiceId()).append("#").append(txnManageVo.getServiceName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);

        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> formatQueryChannelList(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getChannelId()).append("#").append(txnManageVo.getChannelName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> formatQueryHostList(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getHostId()).append("#").append(txnManageVo.getHostName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);
        }
        return txnManageMap;
    }

    public Map<String, List<TxnManageVo>> formatQueryAccessChannel(List<TxnManageVo> txnManages) {
        Map<String, List<TxnManageVo>> txnManageMap = new LinkedHashMap<String, List<TxnManageVo>>();
        for (TxnManageVo txnManageVo : txnManages) {
            StringBuilder idNameBuilder = new StringBuilder();
            idNameBuilder.append(txnManageVo.getAccessChannelId()).append("#").append(txnManageVo.getAccessChannelName());
            updateMap(txnManageMap, idNameBuilder.toString(), txnManageVo);
        }
        return txnManageMap;
    }

    public void formatQueryByAll(List<TxnManageVo> txnManages) {
        Map<String, Integer> temp = new HashMap<String, Integer>();
        for (TxnManageVo txnManageVo : txnManages) {
            setRows(txnManageVo.getAccessChannelPrefix(), temp);
            setRows(txnManageVo.getChannelPrefix(), temp);
            setRows(txnManageVo.getHostIdPrefix(), temp);
            setRows(txnManageVo.getTxnGroupIdPrefix(), temp);
            setRows(txnManageVo.getServiceNamePrefix(), temp);
            setRows(txnManageVo.getServiceVersionPrefix(), temp);
            setRows(txnManageVo.getConnectorIdPrefix(), temp);
        }
        setRowsValue(txnManages, temp);
    }

    public void setRowsValue(List<TxnManageVo> txnManages, Map<String, Integer> temp) {
        for (TxnManageVo txnManageVo : txnManages) {
            txnManageVo.setAccessChannelRows(temp.get(txnManageVo.getAccessChannelPrefix()));
            txnManageVo.setChannelRows(temp.get(txnManageVo.getChannelPrefix()));
            txnManageVo.setHostRows(temp.get(txnManageVo.getHostIdPrefix()));
            txnManageVo.setTxnGroupRows(temp.get(txnManageVo.getTxnGroupIdPrefix()));
            txnManageVo.setServiceRows(temp.get(txnManageVo.getServiceNamePrefix()));
            txnManageVo.setServiceVersionRows(temp.get(txnManageVo.getServiceVersionPrefix()));
            txnManageVo.setConnectorRows(temp.get(txnManageVo.getConnectorIdPrefix()));
            temp.put(txnManageVo.getAccessChannelPrefix(), -1);
            temp.put(txnManageVo.getChannelPrefix(), -1);
            temp.put(txnManageVo.getHostIdPrefix(), -1);
            temp.put(txnManageVo.getTxnGroupIdPrefix(), -1);
            temp.put(txnManageVo.getServiceNamePrefix(), -1);
            temp.put(txnManageVo.getServiceVersionPrefix(), -1);
            temp.put(txnManageVo.getConnectorIdPrefix(), -1);
        }
    }

    public void setRows(String id, Map<String, Integer> temp) {
        if (temp.get(id) == null) {
            temp.put(id, 1);
        } else {
            Set<String> s = temp.keySet();
            for (String str : s) {
                if (id.equals(str)) {
                    temp.put(id, (int) (temp.get(id) + 1));
                }
            }
        }
    }

    public void formatQueryByVersion(List<TxnManageVo> txnManages) {
        Map<String, Integer> temp = new HashMap<String, Integer>();
        for (TxnManageVo txnManageVo : txnManages) {
            setRows(txnManageVo.getServiceNamePrefix2(), temp);
            setRows(txnManageVo.getServiceVersionPrefix2(), temp);
        }
        setRowsValueForVersion(txnManages, temp);
    }

    public void setRowsValueForVersion(List<TxnManageVo> txnManages, Map<String, Integer> temp) {
        for (TxnManageVo txnManageVo : txnManages) {
            txnManageVo.setServiceRows(temp.get(txnManageVo.getServiceNamePrefix2()));
            txnManageVo.setServiceVersionRows(temp.get(txnManageVo.getServiceVersionPrefix2()));
            temp.put(txnManageVo.getServiceNamePrefix2(), -1);
            temp.put(txnManageVo.getServiceVersionPrefix2(), -1);
        }
    }

    public void formatQueryByTxn(List<TxnManageVo> txnManages) {
        Map<String, Integer> temp = new HashMap<String, Integer>();
        for (TxnManageVo txnManageVo : txnManages) {
            setRows(txnManageVo.getTxnId(), temp);
            setRows(txnManageVo.getChannelTxnPrefix(), temp);
            setRows(txnManageVo.getAccessChannelTxnPrefix(), temp);
            setRows(txnManageVo.getHostTxnPrefix(), temp);
            setRows(txnManageVo.getTxnGroupTxnPrefix(), temp);
            setRows(txnManageVo.getServiceTxnPrefix(), temp);
            setRows(txnManageVo.getServiceVersionTxnPrefix(), temp);
            setRows(txnManageVo.getConnectorTxnPrefix(), temp);
        }
        setRowsValueForTxn(txnManages, temp);
    }

    public void setRowsValueForTxn(List<TxnManageVo> txnManages, Map<String, Integer> temp) {
        for (TxnManageVo txnManageVo : txnManages) {
            txnManageVo.setTxnRows(temp.get(txnManageVo.getTxnId()));
            txnManageVo.setChannelRows(temp.get(txnManageVo.getChannelTxnPrefix()));
            txnManageVo.setAccessChannelRows(temp.get(txnManageVo.getAccessChannelTxnPrefix()));
            txnManageVo.setHostRows(temp.get(txnManageVo.getHostTxnPrefix()));
            txnManageVo.setTxnGroupRows(temp.get(txnManageVo.getTxnGroupTxnPrefix()));
            txnManageVo.setServiceRows(temp.get(txnManageVo.getServiceTxnPrefix()));
            txnManageVo.setServiceVersionRows(temp.get(txnManageVo.getServiceVersionTxnPrefix()));
            txnManageVo.setConnectorRows(temp.get(txnManageVo.getConnectorTxnPrefix()));
            temp.put(txnManageVo.getTxnId(), -1);
            temp.put(txnManageVo.getChannelTxnPrefix(), -1);
            temp.put(txnManageVo.getAccessChannelTxnPrefix(), -1);
            temp.put(txnManageVo.getHostTxnPrefix(), -1);
            temp.put(txnManageVo.getTxnGroupTxnPrefix(), -1);
            temp.put(txnManageVo.getServiceTxnPrefix(), -1);
            temp.put(txnManageVo.getServiceVersionTxnPrefix(), -1);
            temp.put(txnManageVo.getConnectorTxnPrefix(), -1);
        }
    }

}
