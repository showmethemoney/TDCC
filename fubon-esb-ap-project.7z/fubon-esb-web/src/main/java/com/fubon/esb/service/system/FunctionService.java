package com.fubon.esb.service.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.dao.system.FunctionDao;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.dao.system.RoleFunctionDao;
import com.fubon.esb.dao.system.RoleUserDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Function;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.RoleFunction;
import com.fubon.esb.domain.system.RoleUser;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-5
 */
@Service
public class FunctionService {

    @Inject
    private RoleDao roleDao;

    @Inject
    private FunctionDao functionDao;

    @Inject
    private RoleFunctionDao roleFunctionDao;

    @Inject
    private LoginContext loginContext;

    @Inject
    private Messages messages;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private RoleUserDao roleUserDao;

    /**
     * 查出所有權限，按照level組好
     */
    public List<Function> findAllFunctions(String roleId) {
        List<Function> functions = functionDao.findFunctionByLevel(1);
        List<Function> children = functionDao.findFunctionByLevel(2);
        List<Function> grandsons = functionDao.findFunctionByLevel(3);

        List<RoleFunction> rfs = roleFunctionDao.findRoleFuncListByRoleId(roleId);
        if (rfs != null && !rfs.isEmpty()) {
            List<String> funcCodes = new ArrayList<>();
            for (RoleFunction rf : rfs) {
                funcCodes.add(rf.getFuncCode());
            }
            for (Function function : children) {
                function.setChecked(isFuncChecked(funcCodes, function));
            }
            for (Function function : grandsons) {
                function.setChecked(isFuncChecked(funcCodes, function));
            }
        }

        setSons(children, grandsons);
        setSons(functions, children);

        for (Function func : functions) {
            func.setHasThirdLevel(checkLevel(func));
        }

        return functions;
    }

    private Boolean isFuncChecked(List<String> funcCodes, Function function) {
        return function.getIsLeaf() && funcCodes.contains(function.getCode());
    }

    /**
     * 把子權限放入父權限準哦功能
     */
    private void setSons(List<Function> parents, List<Function> sons) {
        for (Function son : sons) {
            for (Function parent : parents) {
                if (parent.getCode().equals(son.getParentCode())) {
                    parent.getChildren().add(son);
                    break;
                }
            }
        }
    }

    /**
     * 檢查權限的深度，如果為3層返回true，否則返回false
     */
    private Boolean checkLevel(Function func) {
        if (func.getChildren() != null && func.getChildren().size() != 0) {
            return !func.getChildren().get(0).getIsLeaf();
        }

        return false;
    }

    /**
     * 保存權限<br />
     * 1. 覆核後第一次修改：複製一個副本，rolefunction 對應的id為副本的id，modify flag 為8（ 1<<3）,直接存入所有權限 <br />
     * 2.尚處在修改狀態：roleId即為副本ID，對Rolefunction進行新增和刪除，modify flag | 8.
     * 
     * @throws Exception
     */
    @Transactional
    public void updateRoleFuncList(String roleId, String[] funcCodes) throws Exception {
        if (StringUtils.isBlank(roleId)) {
            throw new Exception(getMessage("function.message.error.rolenotsaved"));
        }
        Role role = roleDao.getRoleById(roleId);
        if (!isRoleChanged(role)) { // 還沒修改過
            Role newRole = new Role();
            BeanUtils.copyProperties(role, newRole, "id"); // 複製副本
            newRole.setMainId(roleId);
            newRole.setModifyFlag(setModifyFlagForFuncChange(newRole));
            setUpdateInfoForRole(newRole);
            roleDao.saveRole(newRole);
            String newId = newRole.getId();
            // 關聯的分行關聯到新的id
            List<String> userIds = roleUserDao.findUserIdsByRole(newRole.getMainId());
            for (String userId : userIds) {
                roleUserDao.save(new RoleUser(newId, userId));
            }
            // 直接新增
            if (funcCodes != null) {
                List<RoleFunction> newList = new ArrayList<>();
                for (String funcCode : funcCodes) {
                    RoleFunction rf = new RoleFunction(newId, funcCode);
                    newList.add(rf);
                }
                roleFunctionDao.saveRoleFunctionList(newList);
            }
        } else {
            role.setModifyFlag(setModifyFlagForFuncChange(role));
            setUpdateInfoForRole(role);
            roleDao.updateRole(role);

            String[] tmpCodes;
            if (funcCodes == null) {
                tmpCodes = new String[]{};
            } else {
                tmpCodes = funcCodes;
            }
            List<RoleFunction> newList = new ArrayList<>();
            for (String funcCode : tmpCodes) {
                RoleFunction rf = new RoleFunction(roleId, funcCode);
                newList.add(rf);
            }

            List<RoleFunction> oldList = roleFunctionDao.findRoleFuncListByRoleId(roleId);

            compareRoleFuncList(newList, oldList);
        }

        String message = getMessage("system_log_role_edit") + ": " + role.getName();
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message, LogType.SYS_FUNC_MANAGE); // log
    }

    @SuppressWarnings("unchecked")
    private void compareRoleFuncList(List<RoleFunction> newList, List<RoleFunction> oldList) {
        if (!CollectionUtils.isEqualCollection(newList, oldList)) {
            List<RoleFunction> sameList = (List<RoleFunction>) CollectionUtils.retainAll(newList, oldList);

            newList.removeAll(sameList);
            oldList.removeAll(sameList);

            roleFunctionDao.removeRoleFunctionList(oldList); //
            roleFunctionDao.saveRoleFunctionList(newList);
        }
    }

    /**
     * maiId不為空：role已被修改過
     */
    private Boolean isRoleChanged(Role role) {
        return StringUtils.isNotBlank(role.getMainId());
    }

    private Integer setModifyFlagForFuncChange(Role role) { // 沒有進行比較 TODO(是否需要比較)
        if (role.getModifyFlag() == null) {
            return 1 << 1;
        }

        return role.getModifyFlag() | (1 << 1);
    }

    /**
     * 更新Role更新信息
     */
    private void setUpdateInfoForRole(Role role) {
        role.setUpdatedTime(new Date());
        role.setUpdatedUser(loginContext.loginedUserId());
    }

    public List<String> findFuncCodesFromRoles(List<Role> roles) {
        List<String> roleIds = new ArrayList<>();
        for (Role role : roles) {
            roleIds.add(role.getId());
        }
        return functionDao.findFuncCodesFromRoles(roleIds);
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

}
