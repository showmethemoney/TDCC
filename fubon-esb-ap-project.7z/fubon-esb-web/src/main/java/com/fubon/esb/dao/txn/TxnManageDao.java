package com.fubon.esb.dao.txn;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import org.springframework.jdbc.core.RowMapper;

import com.comwave.core.database.CompositeDaoSupport;
import com.comwave.core.database.Page;
import com.fubon.esb.controller.txn.view.TxnManageVo;
import com.fubon.esb.domain.config.Txn;

@Repository
public class TxnManageDao extends CompositeDaoSupport<Txn> {

    @Inject
    private JDBCAccessSQLPage jdbcAccess;

    public List<TxnManageVo> findAllTxn(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select accessChannel.ACCESS_NAME as accessChannelName,accessChannel.id as accessChannelId,");
        sql.append("channel.CHANNEL_NAME as channelName,channel.id as channelId,host.HOST_NAME as hostName,host.id as hostId,txnGroup.GROUP_NAME as txnGroupName,txnGroup.id as txnGroupId,service.SERVICE_NAME as serviceName,service.id as serviceId,");
        sql.append("service.VERSION as serviceVerstion,connector.CONNECTOR_NAME as connectorName,connector.id as connectorId,txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_CHANNEL txnChannel on txn.id = txnChannel.TXN_ID");
        sql.append(" left join CFG_CHANNEL channel on txnChannel.channel_Id=channel.id");
        sql.append(" left join CFG_TXN_GROUP txnGroup on txn.group_Id=txnGroup.id");
        sql.append(" left join CFG_HOST host on txnGroup.host_Id=host.id");
        sql.append(" left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" left join CFG_CONNECTOR connector on txn.connector_Id=connector.id");
        sql.append(" left join CFG_ACCESS_CHANNEL accessChannel on channel.access_Channel_Id=accessChannel.id");
        sql.append(" where accessChannel.main_Id is null and txn.main_Id is null and channel.main_Id is null and host.main_Id is null and txnGroup.main_Id is null and service.main_Id is null and host.main_Id is null");
       // sql.append(" order by accessChannel.id desc,channel.Id desc,host.Id desc,txnGroup.Id desc,service.SERVICE_NAME desc,connector.id desc,service.VERSION ");
        sql.append(" order by accessChannel.ACCESS_NAME ,channel.CHANNEL_NAME ,host.HOST_NAME ,txnGroup.GROUP_NAME,service.SERVICE_NAME ,service.VERSION,connector.CONNECTOR_NAME,txn.TXN_CODE ");
        List<TxnManageVo> txnManages = jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo vo = new TxnManageVo();
                setTxnManageVo(vo, rs);
                return vo;
            }
        }, page);
        return txnManages;
    }

    public List<TxnManageVo> findTxnByTxn(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select accessChannel.ACCESS_NAME as accessChannelName,accessChannel.id as accessChannelId,");
        sql.append("channel.CHANNEL_NAME as channelName,channel.id as channelId,host.HOST_NAME as hostName,host.id as hostId,txnGroup.GROUP_NAME as txnGroupName,txnGroup.id as txnGroupId,service.SERVICE_NAME as serviceName,service.id as serviceId,");
        sql.append("service.VERSION as serviceVerstion,connector.CONNECTOR_NAME as connectorName,connector.id as connectorId,txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_CHANNEL txnChannel on txn.id = txnChannel.TXN_ID");
        sql.append(" left join CFG_CHANNEL channel on txnChannel.channel_Id=channel.id");
        sql.append(" left join CFG_TXN_GROUP txnGroup on txn.group_Id=txnGroup.id");
        sql.append(" left join CFG_HOST host on txnGroup.host_Id=host.id");
        sql.append(" left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" left join CFG_CONNECTOR connector on txn.connector_Id=connector.id");
        sql.append(" left join CFG_ACCESS_CHANNEL accessChannel on channel.access_Channel_Id=accessChannel.id");
        sql.append(" where accessChannel.main_Id is null and txn.main_Id is null and channel.main_Id is null and host.main_Id is null and txnGroup.main_Id is null and service.main_Id is null and host.main_Id is null");
      //  sql.append(" order by txn.id desc,accessChannel.id desc,channel.Id desc,host.Id desc,txnGroup.Id desc,service.SERVICE_NAME desc,connector.id desc,service.VERSION ");
       
        sql.append(" order by txn.TXN_CODE,accessChannel.ACCESS_NAME ,channel.CHANNEL_NAME ,host.HOST_NAME ,txnGroup.GROUP_NAME,service.SERVICE_NAME ,service.VERSION,connector.CONNECTOR_NAME ");
        List<TxnManageVo> txnManages = jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo vo = new TxnManageVo();
                setTxnManageVo(vo, rs);
                return vo;
            }
        }, page);
        return txnManages;
    }

    private void setTxnManageVo(TxnManageVo vo, ResultSet rs) throws SQLException {
        vo.setAccessChannelId(rs.getString("accessChannelId"));
        vo.setAccessChannelName(rs.getString("accessChannelName"));
        vo.setChannelName(rs.getString("channelName"));
        vo.setChannelId(rs.getString("channelId"));
        vo.setHostName(rs.getString("hostName"));
        vo.setHostId(rs.getString("hostId"));
        vo.setTxnGroupName(rs.getString("txnGroupName"));
        vo.setTxnGroupId(rs.getString("txnGroupId"));
        vo.setServiceName(rs.getString("serviceName"));
        vo.setServiceId(rs.getString("serviceId"));
        vo.setServiceVersion(rs.getString("serviceVerstion"));
        vo.setConnectorName(rs.getString("connectorName"));
        vo.setConnectorId(rs.getString("connectorId"));
        vo.setTxnCode(rs.getString("txnCode"));
        vo.setTxnId(rs.getString("txnId"));
    }

    public List<TxnManageVo> findTxnByChannel(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select channel.CHANNEL_NAME as channelName,");
        sql.append("txn.TXN_CODE as txnCode,channel.id as channelId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_CHANNEL txnChannel on txn.id = txnChannel.TXN_ID");
        sql.append(" left join CFG_CHANNEL channel on txnChannel.channel_Id=channel.id");
      //  sql.append(" where txn.main_Id is null and channel.main_Id is null order by channel.id desc");
        sql.append(" where txn.main_Id is null and channel.main_Id is null order by channel.CHANNEL_NAME,txn.txn_code");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setChannelId(rs.getString("channelId"));
                txnManageVo.setChannelName(rs.getString("channelName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

    public List<TxnManageVo> findTxnByAccessChannel(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from (select distinct * from (select accessChannel.ACCESS_NAME as accessChannelName,accessChannel.id as accessChannelId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_CHANNEL txnChannel on txn.id = txnChannel.TXN_ID ");
        sql.append(" left join CFG_CHANNEL channel on txnChannel.channel_Id=channel.id");
        sql.append(" left join CFG_ACCESS_CHANNEL accessChannel on channel.access_Channel_Id=accessChannel.id ");
        sql.append(" where txn.main_Id is null and channel.main_Id is null and accessChannel.main_Id is null) as temp1) as temp");
        //sql.append(" order by temp.accessChannelId desc,temp.txnCode");
        sql.append(" order by temp.accessChannelName,temp.txnCode");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setAccessChannelId(rs.getString("accessChannelId"));
                txnManageVo.setAccessChannelName(rs.getString("accessChannelName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);

    }

    public List<TxnManageVo> findTxnByHost(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select host.HOST_NAME as hostName,host.id as hostId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_GROUP txnGroup on txn.group_Id=txnGroup.id");
        sql.append(" left join CFG_HOST host on txnGroup.host_Id=host.id");
        sql.append(" where txn.main_Id is null and host.main_Id is null and txnGroup.main_Id is null");
      //  sql.append(" order by host.id desc");
        sql.append(" order by host.HOST_NAME,txn.txn_code");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setHostId(rs.getString("hostId"));
                txnManageVo.setHostName(rs.getString("hostName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

    public List<TxnManageVo> findTxnByTxnGroup(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select txnGroup.GROUP_NAME as txnGroupName,txnGroup.id as txnGroupId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_TXN_GROUP txnGroup on txn.group_Id=txnGroup.id");
        sql.append(" where txn.main_Id is null and  txnGroup.main_Id is null");
        //sql.append(" order by txnGroup.id desc");
        sql.append(" order by txnGroup.GROUP_NAME,txn.txn_code");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setTxnGroupId(rs.getString("txnGroupId"));
                txnManageVo.setTxnGroupName(rs.getString("txnGroupName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

    public List<TxnManageVo> findTxnByService(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select service.SERVICE_NAME as serviceName,service.id as serviceId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" where txn.main_Id is null and  service.main_Id is null");
       // sql.append(" order by service.id desc");
        sql.append(" order by service.SERVICE_NAME ,txn.txn_code");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setServiceId(rs.getString("serviceId"));
                txnManageVo.setServiceName(rs.getString("serviceName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

    public List<TxnManageVo> findTxnByServiceVersion(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select service.SERVICE_NAME as serviceName,service.VERSION as serviceVersion,service.id as serviceId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_SERVICE service on txn.service_Id=service.id");
        sql.append(" where txn.main_Id is null and  service.main_Id is null");
       // sql.append(" order by service.SERVICE_NAME desc,service.VERSION ");
        sql.append(" order by service.SERVICE_NAME ,service.VERSION, txn.TXN_CODE");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setServiceId(rs.getString("serviceId"));
                txnManageVo.setServiceName(rs.getString("serviceName"));
                txnManageVo.setServiceVersion(rs.getString("serviceVersion"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

    public List<TxnManageVo> findTxnByConnector(Page page) {
        StringBuilder sql = new StringBuilder();
        sql.append("select connector.CONNECTOR_NAME as connectorName,connector.id as connectorId,");
        sql.append("txn.TXN_CODE as txnCode,txn.id as txnId ");
        sql.append(" from CFG_Txn txn left join CFG_CONNECTOR connector on txn.connector_Id=connector.id");
        sql.append(" where txn.main_Id is null");
       // sql.append(" order by connector.id desc");
        sql.append(" order by connector.CONNECTOR_NAME,txn.TXN_CODE");
        return jdbcAccess.findPage(sql.toString(), new RowMapper<TxnManageVo>() {
            public TxnManageVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                TxnManageVo txnManageVo = new TxnManageVo();
                txnManageVo.setTxnId(rs.getString("txnId"));
                txnManageVo.setConnectorId(rs.getString("connectorId"));
                txnManageVo.setConnectorName(rs.getString("connectorName"));
                txnManageVo.setTxnCode(rs.getString("txnCode"));
                return txnManageVo;
            }
        }, page);
    }

}
