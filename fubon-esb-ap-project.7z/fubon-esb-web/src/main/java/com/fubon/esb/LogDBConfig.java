package com.fubon.esb;

import javax.inject.Inject;
import javax.inject.Named;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.comwave.core.database.JPAAccess;

/**
 * @author Robin
 * @createdDate Nov 17, 2014
 */
@Configuration
public class LogDBConfig {

    public static final String LOG_DB = "UserDB";
    public static final String LOG_DB_JPA_TXN = "logDbTransactionManager";
    public static final String LOG_DB_JPA_ACCESS = "logDbJpaAccess";

    @Inject
    private Environment env;

    @Bean
    public DataSource logDbDataSource() {
    	String jndi_name=env.getRequiredProperty("log.db.jndi");
        DataSource ds=null;
        try{
        	InitialContext ic=new InitialContext();
        	ds = (DataSource) ic.lookup(jndi_name);
        }catch(Exception e){
        }
        
        return ds;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean logDbEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setDataSource(logDbDataSource());
        factoryBean.setPackagesToScan(LogDBConfig.class.getPackage().getName() + ".domain");
        factoryBean.setPersistenceUnitName(LOG_DB);

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabasePlatform(env.getRequiredProperty("log.jdbc.dialect"));
        vendorAdapter.setShowSql(false);
        vendorAdapter.setGenerateDdl(false);
        factoryBean.setJpaVendorAdapter(vendorAdapter);
        return factoryBean;
    }

    @Bean
    @Qualifier(LOG_DB_JPA_TXN)
    public PlatformTransactionManager logDbTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setDataSource(logDbDataSource());
        transactionManager.setPersistenceUnitName(LOG_DB);
        return transactionManager;
    }

    @Bean
    @Named(LOG_DB_JPA_ACCESS)
    public JPAAccess logDbJpaAccess() {
        return new JPAAccess() {
            @Override
            @PersistenceContext(unitName = LOG_DB)
            public void setEntityManager(EntityManager entityManager) {
                super.setEntityManager(entityManager);
            }
        };
    }

}
