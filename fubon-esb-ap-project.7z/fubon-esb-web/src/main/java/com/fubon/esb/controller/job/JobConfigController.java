package com.fubon.esb.controller.job;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.job.view.JobConfigView;
import com.fubon.esb.controller.job.view.JobRecordlView;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.domain.config.MailGroup;
import com.fubon.esb.domain.job.DayType;
import com.fubon.esb.domain.job.JobConfig;
import com.fubon.esb.domain.job.JobRecord;
import com.fubon.esb.domain.job.JobStatus;
import com.fubon.esb.domain.job.LastRunningStatusType;
import com.fubon.esb.domain.job.RunType;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.config.JobSystemSettingService;
import com.fubon.esb.service.config.MailGroupService;
import com.fubon.esb.service.job.JobConfigService;
import com.fubon.esb.service.job.JobExecuteService;
import com.fubon.esb.service.job.JobRecordService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-13
 */
@Controller
@RequestMapping("/jobConfig")
public class JobConfigController extends BaseController {

    @Inject
    private JobConfigService jobConfigService;
    @Inject
    private JobExecuteService jobExecuteService;
    @Inject
    private MailGroupService mailGroupService;
    @Inject
    private JobSystemSettingService jobSystemSettingService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private Messages messages;
    @Inject
    private JobRecordService jobRecordService;
    @Inject
    private Environment env;

    @RequestMapping("/viewSearchJobConfig")
    public String viewSearchJobConfig(Model model) {
        return "/job/viewJobConfigList";
    }

    @RequirePermission(value = "040101")
    @RequestMapping("/viewJobConfigList")
    public String viewJobConfigList(Model model, JobConfigView jobConfigView, String status, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<JobConfig> jobConfigs = jobConfigService.findJobConfigList(jobConfigView, status, jobRecordService.isAdminGroup() ? null : jobRecordService.findUserBranchCodeList(), orderBy, page);
        model.addAttribute("jobConfigs", jobConfigs);
        model.addAttribute("jobConfigView", jobConfigView);
        model.addAttribute("page", page);
        model.addAttribute("status", status);
        model.addAttribute("STATUS_ACTIVE", JobStatus.A);
        model.addAttribute("STATUS_INACTIVE", JobStatus.I);
        model.addAttribute("STATUS_DELETE", JobStatus.D);
        model.addAttribute("DAYTYPE_D", DayType.D);
        model.addAttribute("DAYTYPE_W", DayType.W);
        model.addAttribute("DAYTYPE_M", DayType.M);
        return "/job/viewJobConfigList";

    }

    @RequirePermission(value = {"040102", "040103"})
    @RequestMapping("/viewJobConfig")
    public String viewJobConfig(Model model, String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) {
            isAdd = false;
            JobConfig jobConfig = jobConfigService.getById(id);
            model.addAttribute("jobConfig", jobConfig);
        }
        List<MailGroup> mailGroups = mailGroupService.findAllMailGroups();
        List<JobSystemSetting> jobSystemSettings = jobSystemSettingService.findJobSystemSettings(null, null, null, null);
        model.addAttribute("isAdd", isAdd);
        model.addAttribute("STATUS_ACTIVE", JobStatus.A);
        model.addAttribute("STATUS_INACTIVE", JobStatus.I);
        model.addAttribute("STATUS_DELETE", JobStatus.D);
        model.addAttribute("DAYTYPE_D", DayType.D);
        model.addAttribute("DAYTYPE_W", DayType.W);
        model.addAttribute("DAYTYPE_M", DayType.M);
        model.addAttribute("mailGroups", mailGroups);
        model.addAttribute("jobSystemSettings", jobSystemSettings);
        return "/job/viewJobConfig";
    }

    @RequirePermission(value = {"040102", "040103"})
    @RequestMapping("/saveOrUpdateJobConfig")
    @ResponseBody
    public ResultView saveOrUpdateJobConfig(@Valid JobConfig jobConfig) {
        try {
            jobConfigService.saveOrUpdate(jobConfig);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/jobConfig/viewJobConfigList");

    }

    @RequirePermission(value = "040105")
    @RequestMapping("/removeJobConfig")
    @ResponseBody
    public Map<String, Object> removeJobConfig(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        jobConfigService.removeJobConfig(id);
        result.put("flag", true);
        return result;
    }

    @RequirePermission(value = {"040101", "040201"})
    @RequestMapping("/viewJobConfigDetail")
    public String viewJobConfigDetail(@RequestParam(required = true) String id, Model model, @RequestParam(required = false) String runningDate) {
        model.addAttribute("jobConfig", jobConfigService.setJobSysCode(jobConfigService.getById(id)));
        model.addAttribute("jobRecords", jobConfigService.findDayJobRecords(id, runningDate));
        model.addAttribute("RUNTYPE_A", RunType.A);
        model.addAttribute("RUNTYPE_M", RunType.M);
        model.addAttribute("STATUS_S", LastRunningStatusType.S);
        model.addAttribute("STATUS_F", LastRunningStatusType.F);
        model.addAttribute("STATUS_R", LastRunningStatusType.R);
        model.addAttribute("DAYTYPE_D", DayType.D);
        model.addAttribute("DAYTYPE_W", DayType.W);
        model.addAttribute("DAYTYPE_M", DayType.M);
        return "/job/viewJobConfigDetail";
    }

    @RequestMapping("/viewJobConfigRecord")
    public String viewJobConfigRecord(@RequestParam(required = true) String id, Model model) {
        model.addAttribute("jobConfig", jobConfigService.setJobSysCode(jobConfigService.getById(id)));
        model.addAttribute("jobRecords", jobRecordService.findJobRecords(id));
        model.addAttribute("RUNTYPE_A", RunType.A);
        model.addAttribute("RUNTYPE_M", RunType.M);
        model.addAttribute("STATUS_S", LastRunningStatusType.S);
        model.addAttribute("STATUS_F", LastRunningStatusType.F);
        model.addAttribute("STATUS_R", LastRunningStatusType.R);
        model.addAttribute("DAYTYPE_D", DayType.D);
        model.addAttribute("DAYTYPE_W", DayType.W);
        model.addAttribute("DAYTYPE_M", DayType.M);
        return "/job/viewJobConfigDetail";
    }

    @RequirePermission(value = "040201")
    @RequestMapping("/viewJobRecordList")
    public String viewJobRecordList(Model model, JobRecordlView jobRecordView, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") int currentPage,
            @RequestParam(required = false, defaultValue = "false") Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        List<JobConfig> jobConfigs = jobRecordService.findJobRecords(jobRecordView, jobRecordService.isAdminGroup() ? null : jobRecordService.findUserBranchCodeList(), orderBy, page);
        if (isSearch) {
            jobRecordService.jobQueryLog(jobRecordView);
        }
        model.addAttribute("isPlay", jobConfigService.hasRunningJob(jobConfigService.findAllJobConfig(jobRecordService.isAdminGroup() ? null : jobRecordService.findUserBranchCodeList())));
        model.addAttribute("jobConfigs", jobConfigs);
        model.addAttribute("page", page);
        model.addAttribute("jobRecordView", jobRecordView);
        model.addAttribute("STATUS_S", LastRunningStatusType.S);
        model.addAttribute("STATUS_F", LastRunningStatusType.F);
        model.addAttribute("STATUS_R", LastRunningStatusType.R);
        model.addAttribute("DAYTYPE_D", DayType.D);
        model.addAttribute("DAYTYPE_W", DayType.W);
        model.addAttribute("DAYTYPE_M", DayType.M);
        model.addAttribute("SOUND_SRC", env.getProperty("jobrecord.sound.src"));
        model.addAttribute("REFRESH_TIMEOUT", env.getProperty("jobrecord.refresh.timeout"));
        return "/job/viewJobRecordList";
    }

    @RequestMapping("/getJobConfig")
    @ResponseBody
    public Map<String, Object> getJobConfig(String id, String searchRunningTime) {
        Map<String, Object> result = new HashMap<String, Object>();
        JobRecord jobRecord = jobConfigService.getLatestJobRecord(id, searchRunningTime);
        result.put("jobRecord", jobRecord);
        return result;
    }

    @RequestMapping("/saveMemo")
    @ResponseBody
    public ResultView saveMemo(String jobRecordId, String memo) {
        jobConfigService.saveMemo(jobRecordId, memo);
        return ResultView.success("/jobConfig/viewJobRecordList");

    }

    @RequestMapping("/jobExecute")
    @ResponseBody
    @RequirePermission(value = "040104")
    public Map<String, Object> jobExecute(String jobConfigId, String jobParam) {
        Map<String, Object> result = new HashMap<>();
        JobConfig jobConfig = jobConfigService.getById(jobConfigId);
        String retuenMessage = null;
        try {
            retuenMessage = jobExecuteService.jobExecute(jobConfig, jobParam);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (StringUtils.isNotBlank(retuenMessage)) {
            result.put("flag", false);
            result.put("message", retuenMessage);
        } else {
            result.put("flag", true);
        }
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("job.config.log.run"), jobConfig.getCode(), jobConfig.getName()), LogType.JOB_MANAGE_CONFIG);
        return result;

    }

    @ResponseBody
    @RequestMapping("/isJobSysStop")
    public Object isJobSysStop(String jobConfigId) {
        Map<String, Object> result = new HashMap<>();
        JobConfig jobConfig = jobConfigService.getById(jobConfigId);
        if (jobConfig != null && jobConfig.getStatus() == JobStatus.D) {
            result.put("flag", false);
            result.put("message", messages.getMessage("job.execute.alert.delete"));
            return result;
        }
        result.put("flag", true);
        return result;
    }

    @ResponseBody
    @RequestMapping("/checkDate")
    public Object checkDate(String runningDate) {
        Map<String, Object> result = new HashMap<>();
        boolean flag = jobConfigService.checkDatePreMonth(runningDate);
        result.put("flag", flag);
        return result;
    }
}
