package com.fubon.esb;

import javax.inject.Inject;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.comwave.core.database.JDBCAccess;
import com.comwave.core.database.JPAAccess;
import com.fubon.esb.dao.txn.JDBCAccessSQLPage;

/**
 * @author Robin
 * @createdDate Oct 5, 2014
 */
@Configuration
@EnableTransactionManagement(proxyTargetClass = true)
public class DefaultDBConfig {

    public static final String DEFAULT_DB = "DefaultDB";

    @Inject
    private Environment env;

    @Bean
    public DataSource dataSource() {
    	String jndi_name=env.getRequiredProperty("default.db.jndi");
        DataSource ds=null;
        try{
        	InitialContext ic=new InitialContext();
        	ds = (DataSource) ic.lookup(jndi_name);
        }catch(Exception e){
        }
        
        return ds;
    }


    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setDataSource(dataSource());
        factoryBean.setPackagesToScan(DefaultDBConfig.class.getPackage().getName() + ".domain");
        factoryBean.setPersistenceUnitName(DEFAULT_DB);

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabasePlatform(env.getRequiredProperty("default.jdbc.dialect"));
        vendorAdapter.setShowSql(false);
        vendorAdapter.setGenerateDdl(false);
        factoryBean.setJpaVendorAdapter(vendorAdapter);
        return factoryBean;
    }

    @Bean
    @Primary
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setDataSource(dataSource());
        transactionManager.setPersistenceUnitName(DEFAULT_DB);
        return transactionManager;
    }

    @Bean
    @Primary
    public JPAAccess jpaAccess() {
        return new JPAAccess() {
            @Override
            @PersistenceContext(unitName = DEFAULT_DB)
            public void setEntityManager(EntityManager entityManager) {
                super.setEntityManager(entityManager);
            }
        };
    }

    @Bean
    @Primary
    public JDBCAccess jdbcAccess() {
        JDBCAccess jdbcAccess = new JDBCAccess();
        jdbcAccess.setDataSource(dataSource());
        return jdbcAccess;
    }
    
    @Bean
    @Primary
    public JDBCAccessSQLPage jdbcAccessSQLPage() {
        JDBCAccessSQLPage jdbcAccess = new JDBCAccessSQLPage();
        jdbcAccess.setDataSource(dataSource());
        return jdbcAccess;
    }

}
