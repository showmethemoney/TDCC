package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.ReturnCode;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.ReturnCodeService;

/**
 * @author Qigers
 * @createdDate 2014-11-17
 */

@Controller
@RequestMapping("returnCode")
public class ReturnCodeController extends BaseController {

    @Inject
    private ReturnCodeService returnCodeService;

    @Inject
    private LoginContext loginContext;

    @Inject
    private ConfigChangeService configChangeService;

    @RequirePermission(value = "050801")
    @RequestMapping(value = "/viewReturnCodeList", method = RequestMethod.GET)
    public String findReturnCodes(Model model, String groupCode, String returnCode) {
        Page page = new Page(1);
        model.addAttribute("page", page);
        model.addAttribute("groupCode", groupCode);
        model.addAttribute("returnCode", returnCode);
        List<ReturnCode> returnCodeList = returnCodeService.findReturnCodes(groupCode, returnCode, page);
        model.addAttribute("returnCodeList", returnCodeList);
        // model.addAttribute("returnCodeList", null);
        return "/config/viewReturnCodeList";

    }

    @RequestMapping(value = "/viewSearchReturnCode", method = RequestMethod.POST)
    @RequirePermission(value = "050801")
    public String viewSearchReturnCode(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, String groupCode, String returnCode) {
        Page page = new Page(currentPage);
        List<ReturnCode> returnCodeList = returnCodeService.findReturnCodes(groupCode.trim(), returnCode.trim(), page);
        model.addAttribute("page", page);
        model.addAttribute("groupCode", groupCode.trim());
        model.addAttribute("returnCode", returnCode.trim());
        model.addAttribute("returnCodeList", returnCodeList);
        return "/config/viewReturnCodeList";
    }
    
    
    @RequestMapping("/refreshReturnCode")
    @ResponseBody
    public Object refreshReturnCode(Model model, @RequestParam(required = true) String id){	
        boolean send_status=true;
    	
    	if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_RETURN_CODE, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    

    @RequirePermission(value = {"050802", "050803"})
    @RequestMapping(value = "/addOrUpdate", method = RequestMethod.GET)
    public String addOrUpdate(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        ReturnCode returnCode;
        if (StringUtils.isNotBlank(id)) {
            isAdd = false;
            returnCode = returnCodeService.getById(id);
        } else {
            returnCode = new ReturnCode();
            returnCode.setCreatedUser(loginContext.loginedUserId());
            returnCode.setCreatedTime(new Date());
        }
        model.addAttribute("returnCode", returnCode);
        model.addAttribute("isAdd", isAdd);
        return "/config/viewReturnCode";
    }

    @RequirePermission(value = "050801")
    @RequestMapping(value = "/view", method = RequestMethod.GET)
    public String view(Model model, @RequestParam(required = false) String id) {
        ReturnCode returnCode;
        returnCode = returnCodeService.getById(id);
        model.addAttribute("returnCode", returnCode);
        return "/config/viewReturnCodeDetails";
    }

    @RequirePermission(value = {"050802", "050803"})
    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResultView saveOrUpdate(@Valid ReturnCode returnCode) {
        String currentUser = loginContext.loginedUserId();
        returnCode.setGroupCode(returnCode.getGroupCode().trim());
        returnCode.setReturnCode(returnCode.getReturnCode().trim());
        returnCodeService.saveOrUpdate(returnCode, currentUser);
        configChangeService.sendChangeEvent(ConfigType.CFG_RETURN_CODE, returnCode.getId());
        return ResultView.success("returnCode/viewReturnCodeList");
    }

    @RequestMapping("/removeReturnCode")
    @ResponseBody
    @RequirePermission(value = "050804")
    public Map<String, Object> removeReturnCode(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        returnCodeService.removeReturnCode(id);
        result.put("flag", true);
        configChangeService.sendChangeEvent(ConfigType.CFG_RETURN_CODE, id);
        return result;
    }

    @RequestMapping("/validateCode")
    @ResponseBody
    public Map<String, Object> validateCode(String groupCode, String returnCode, String id) {
        String groupCode1 = groupCode.trim();
        String returnCode1 = returnCode.trim();
        Map<String, Object> result = new HashMap<String, Object>();
        Boolean flag = returnCodeService.validCodeDuplicate(groupCode1, returnCode1);
        if (flag && StringUtils.isNotBlank(id)) {
            ReturnCode rc = returnCodeService.getById(id);
            if (returnCode1.equals(rc.getReturnCode()) && groupCode1.equals(rc.getGroupCode())) {
                flag = false;
            }
        }
        result.put("flag", flag);
        return result;
    }

    @ResponseBody
    @RequestMapping({"/search/returnCodes"})
    public Object searchReturnCodes(@RequestParam String key) {
        return returnCodeService.searchReturnCodes(key);
    }

}
