package com.fubon.esb.domain.config;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

/**
 * 排程系統設定
 * 
 * @author Qigers
 * @createdDate 2014-12-11
 */
@Entity(name = "CFG_JOB_SYSTEM_SETTING")
public class JobSystemSetting implements Serializable {

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 系統代號 */
    @Column(name = "SYSTEM_CODE")
    private String systemCode;

    /** 系統名稱 */
    @Column(name = "SYSTEM_NAME")
    private String systemName;

    /** 送出報表時間-時 */
    @Column(name = "SEND_HOUR")
    private String sendHour;

    /** 送出報表時間-分 */
    @Column(name = "SEND_MINUTE")
    private String sendMinute;

    /** 備註 */
    @Column(name = "MEMO")
    private String memo;

    /** 狀態 **/
    @Column(name = "SYSTEM_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private JobSystemSettingStatus status;

    /** 建立者 */
    @Column(name = "CREATED_USER")
    private String createdUser;

    /** 建立時間 */
    @Column(name = "CREATED_TIME")
    private Date createdTime;

    /** 更新者 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    /** 使用單位代號 */
    @Column(name = "BRANCH_CODE")
    private String branchCode;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSystemCode() {
        return systemCode;
    }

    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public String getSendHour() {
        return sendHour;
    }

    public void setSendHour(String sendHour) {
        this.sendHour = sendHour;
    }

    public String getSendMinute() {
        return sendMinute;
    }

    public void setSendMinute(String sendMinute) {
        this.sendMinute = sendMinute;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public JobSystemSettingStatus getStatus() {
        return status;
    }

    public void setStatus(JobSystemSettingStatus status) {
        this.status = status;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

}
