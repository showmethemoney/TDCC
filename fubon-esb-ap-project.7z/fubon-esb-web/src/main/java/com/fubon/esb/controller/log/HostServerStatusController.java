package com.fubon.esb.controller.log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import com.comwave.core.database.OrderBy;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.domain.log.HostStatus;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.log.ServerStatus;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.log.HostServerService;
import com.fubon.esb.service.log.OperationLogService;

import com.fubon.esb.service.TimeZoneService;



/**
 * @author Qigers
 * @createdDate 2014-11-21
 */
@Controller
@RequestMapping(value = "/hostServer")
public class HostServerStatusController extends BaseController {
    
    @Inject
    private LoginContext loginContext;
	
	@Inject
    private TimeZoneService timeZoneService;
	
    @Inject
    private HostServerService hostServerService;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;
    
    private final Logger logger = LoggerFactory.getLogger(HostServerStatusController.class);
    
    @RequestMapping(value = "/viewHostServerStatusList", method = RequestMethod.GET)
    @RequirePermission(value = "060201")
    public String viewHostServerStatusList(Model model, OrderBy orderBy) {
        List<ServerStatus> serverStatusList = (List<ServerStatus>) hostServerService.findServerList();
        model.addAttribute("serverStatusList", serverStatusList);
        List<HostStatus> hostStatusList = (List<HostStatus>) hostServerService.findHostList();
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("log.system.status.search"), LogType.SYS_STATUS_QUERY);
        model.addAttribute("hostStatusList", hostStatusList);
        return "/log/viewHostServerStatusList";
    }

    
    
    @ResponseBody  
    @RequestMapping(value = "/updateHostServerStatusList", method = RequestMethod.GET)
    @RequirePermission(value = "060201")
    public String updateHostServerStatusList(Model model, OrderBy orderBy) {
    	Map info=new HashMap();
    	
    	List<HostStatus> hostStatusList = (List<HostStatus>) hostServerService.findHostList();
    	List<ServerStatus> serverStatusList = (List<ServerStatus>) hostServerService.findServerList();
    	
    	//transform the date format accroding to the user timezone
    	User user = loginContext.loginedUser(User.class);
    	for(int i=0;i<hostStatusList.size();i++){
    		Date tmpdt=hostStatusList.get(i).getUpdatedTime();
    		tmpdt=timeZoneService.getDateByTimeZone(tmpdt,user.getTimeZone());
    		hostStatusList.get(i).setUpdatedTime(tmpdt);
    	}
    	
    	if(!hostStatusList.isEmpty())
    		info.put("hostInfo", hostStatusList);
    	if(!serverStatusList.isEmpty())
    		info.put("serverInfo", serverStatusList);
    	
    	
        ObjectMapper objectMapper = JSONBinder.objectMapper();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        objectMapper.setDateFormat(df);
        String jsonResult=null;
        try{
        	jsonResult = objectMapper.writeValueAsString(info);
        	//logger.info(jsonResult);
        }catch(Exception e){
        	System.out.println("Error while generating json string for host stuats list, caused by:"+e.toString());
        }
        return jsonResult;
    }
    
    
    
    
}
