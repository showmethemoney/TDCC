package com.fubon.esb.service.txn;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.fubon.esb.controller.txn.view.TxnExcelVO;
import com.fubon.esb.dao.txn.TxnDirectionDao;
import com.fubon.esb.domain.txn.DataType;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.JustifyType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;


/**
 * @author Qigers
 * @createdDate 2015-03-27
 */

@Service
public class TxnHeaderExcelReadServcie extends BaseTxnExcelService
{

	@Inject
	private TxnDirectionDao search;

	public Map<String, Workbook> readWorkbookFromZipFile(File sourceZip) throws Exception {
		Map<String, Workbook> workbooksMap = new HashMap<String, Workbook>();
		ZipFile sourceZipFile = new ZipFile( sourceZip );
		Enumeration<? extends ZipEntry> entries = sourceZipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = entries.nextElement();
			if (entry.getName().endsWith( "/" )) {
				continue; // a folder
			}
			InputStream zipInputStream = sourceZipFile.getInputStream( entry );
			Workbook workbook = null;
			if (entry.getName().endsWith( "xlsx" )) {
				workbook = new XSSFWorkbook( zipInputStream );
			} else {
				workbook = new HSSFWorkbook( zipInputStream );
			}
			workbooksMap.put( entry.getName(), workbook );
			zipInputStream.close();
		}
		sourceZipFile.close();
		return workbooksMap;
	}

	public Map<String, Workbook> readWorkbooksFromFile(File file, boolean isCompress) throws Exception {
		Map<String, Workbook> workbooksMap = new HashMap<String, Workbook>();
		if (isCompress) {
			workbooksMap = readWorkbookFromZipFile( file );
		} else {
			if (file.getName().endsWith( "xlsx" )) {
				workbooksMap.put( file.getName(), new XSSFWorkbook( new FileInputStream( file ) ) );
			} else {
				workbooksMap.put( file.getName(), new HSSFWorkbook( new FileInputStream( file ) ) );
			}
		}
		return workbooksMap;
	}

	public void readCodeNameToTxnDef(TxnDirection direction, String fileName) {
		String[] codeName = fileName.split( "\\." );
		if (codeName != null && codeName.length != 0) {
			direction.setName( codeName[0].substring( codeName[0].lastIndexOf( '/' ) + 1 ) );
		}
	}

	public void readCodeNameToTxnDirec(TxnDirection direction, String fileName) {
		String[] codeName = fileName.split( "\\." );
		if (codeName != null && codeName.length != 0) {
			direction.setName( codeName[0].substring( codeName[0].lastIndexOf( '/' ) + 1 ) );
		}
	}

	/** import **/
	public List<TxnExcelVO> readTxnHeaderVOsFromExcel(TxnDirection paramDirec, File file, boolean isCompress) throws Exception {
		Map<String, Workbook> workbooks = readWorkbooksFromFile( file, isCompress );
		if (workbooks == null || workbooks.isEmpty())
			return null;
		List<TxnExcelVO> txnExcelVOList = new ArrayList<TxnExcelVO>();
		TxnExcelVO txnVO = null;
		Workbook workbook = null;
		TxnDirection direction = null;
		int a = 0;
		int b = 0;
		int booksSize = workbooks.size();
		for (Entry<String, Workbook> entry : workbooks.entrySet()) {
			workbook = entry.getValue();
			if (workbook != null && workbook.getNumberOfSheets() != 0) {
				txnVO = new TxnExcelVO();
				if (isCompress || booksSize > 1) {
					direction = new TxnDirection();
					BeanUtils.copyProperties( paramDirec, direction );
					readCodeNameToTxnDirec( direction, entry.getKey() );
					txnVO.setHeadDirection( direction );
					txnVO.setExcelName( direction.getName() );
				} else {
					paramDirec.setDirection( DirectionType.H );
					txnVO.setHeadDirection( paramDirec );
					txnVO.setExcelName( file.getName() );
				}
				txnVO.setExcelErrors( new ArrayList<String>() );

				if (txnDirectionService.isExistDefCodeButSelf( null, null, txnVO.getHeadDirection().getName() )) {
					// 20150806 ADDED
					String keyName = "";
					String keyNameforHS = "";
					keyName = txnDirectionService.getHeaderByName( txnVO.getHeadDirection().getName() );
					keyNameforHS = txnDirectionService.getHeaderStatusByName( txnVO.getHeadDirection().getName() );

					if (keyNameforHS != null) {

						txnVO.getExcelErrors().add( messages.getMessage( "txn.direction.existed", txnVO.getHeadDirection().getName() ) );

						txnExcelVOList.add( txnVO );
						continue;

					} else {

						paramDirec.setMainId( txnDirectionService.getMainidByName( keyName ) );

						if (isCompress) {
							BeanUtils.copyProperties( paramDirec, direction );
							direction.setName( keyName );

						}

					}
				}

				// fillTxnHeaderDirectionByHeaderRow(txnVO.getHeadDirection(), workbook.getSheetAt(0).getRow(0), txnVO.getExcelErrors());
				txnVO.setHeadFields( sheetToTxnFields( workbook.getSheetAt( 0 ), txnVO.getExcelErrors() ) );
				int headSheetErrorSize = txnVO.getExcelErrors().size();
				List<String> excelErrors = txnVO.getExcelErrors();
				for (int i = 0; i < excelErrors.size(); i++) {
					if (i < headSheetErrorSize) {
						excelErrors.set( i, "Header" + excelErrors.get( i ) );
					}
				}

				txnExcelVOList.add( txnVO );

			}
		}

		return txnExcelVOList;
	}

	public List<TxnFieldDefinition> sheetToTxnFields(Sheet sheet, List<String> holdErrors) {
		List<TxnFieldDefinition> txnFieldDefinitionList = new ArrayList<TxnFieldDefinition>();
		TxnFieldDefinition field = null;
		for (int i = 0; i <= sheet.getLastRowNum(); i++) {
			field = sheetRowToTxnField( sheet.getRow( i ), holdErrors );
			if (field != null)
				txnFieldDefinitionList.add( field );
		}
		return txnFieldDefinitionList;
	}

	public void fillTxnDirectionByHeaderRow(TxnDirection direction, Row row, List<String> holdErrors) {
		String erroMsg = "";
		// String type = getStringCellValue(row.getCell(1));
		// String outType = getStringCellValue(row.getCell(3));
		// if (type.equals(FileType.T.getDesc())) {
		// direction.setType(FileType.T);
		// } else if (type.equals(FileType.X.getDesc())) {
		// direction.setType(FileType.X);
		// } else {
		// erroMsg += "接收檔案格式無效,";
		// }
		// if (outType.equals(FileType.T.getDesc())) {
		// direction.setOutType(FileType.T);
		// } else if (outType.equals(FileType.X.getDesc())) {
		// direction.setOutType(FileType.X);
		// } else {
		// erroMsg += "送出檔案格式無效,";
		// }
		// String headRefName = getStringCellValue(row.getCell(5));
		// if (StringUtils.isNotBlank(headRefName)) {
		// TxnDirection headerDir = txnDirectionService.getHeaderDirByName(headRefName);
		// if (headerDir == null) {
		// erroMsg += "未找到對應名稱[" + headRefName + "]的Header,";
		// } else {
		// direction.setHeadRefId(headerDir.getId());
		// }
		// }
		// direction.setEncoding(getStringCellValue(row.getCell(7)));
		if (StringUtils.isNoneBlank( erroMsg ))
			holdErrors.add( "第" + (row.getRowNum() + 1) + "行:" + erroMsg );
	}

	public void fillTxnHeaderDirectionByHeaderRow(TxnDirection direction, Row row, List<String> holdErrors) {
		String erroMsg = "";
		// String type = getStringCellValue(row.getCell(1));
		// String outType = getStringCellValue(row.getCell(3));
		// if (type.equals(FileType.T.getDesc())) {
		// direction.setType(FileType.T);
		// } else if (type.equals(FileType.X.getDesc())) {
		// direction.setType(FileType.X);
		// } else {
		// erroMsg += "接收檔案格式無效,";
		// }
		// if (outType.equals(FileType.T.getDesc())) {
		// direction.setOutType(FileType.T);
		// } else if (outType.equals(FileType.X.getDesc())) {
		// direction.setOutType(FileType.X);
		// } else {
		// erroMsg += "送出檔案格式無效,";
		// }
		// String headRefName = getStringCellValue(row.getCell(5));
		// if (StringUtils.isNotBlank(headRefName)) {
		// TxnDirection headerDir = txnDirectionService.getHeaderDirByName(headRefName);
		// if (headerDir == null) {
		// erroMsg += "未找到對應名稱[" + headRefName + "]的Header,";
		// } else {
		// direction.setHeadRefId(headerDir.getId());
		// }
		// }
		// direction.setEncoding(getStringCellValue(row.getCell(7)));
		if (StringUtils.isNoneBlank( erroMsg ))
			holdErrors.add( "第" + (row.getRowNum() + 1) + "行:" + erroMsg );
	}

	public TxnFieldDefinition sheetRowToTxnField(Row row, List<String> holdErrors) {
		if (row.getRowNum() == 0)
			return null;
		FieldType type = FieldType.F;
		String typeStr = getStringCellValue( row.getCell( 0 ) );
		if (TAG_TX_REPEAT_END.equals( typeStr )) {
			return sheetRowToSplitField( row, FieldType.R );
		} else if (TAG_TX_SWITCH_END.equals( typeStr )) {
			return sheetRowToSplitField( row, FieldType.S );
		} else if (TAG_TX_CASE_END.equals( typeStr )) {
			return sheetRowToSplitField( row, FieldType.C );
		}
		if (TAG_TX_FIELD.equals( typeStr )) {
			type = FieldType.F;
		} else if (TAG_TX_REPEAT.equals( typeStr )) {
			type = FieldType.R;
		} else if (TAG_TX_SWITCH.equals( typeStr )) {
			type = FieldType.S;
		} else if (TAG_TX_CASE.equals( typeStr )) {
			type = FieldType.C;
		}
		return sheetRowToDataField( row, type, holdErrors );
	}

	private TxnFieldDefinition sheetRowToSplitField(Row row, FieldType fieldType) {
		TxnFieldDefinition txnFieldDefinition = new TxnFieldDefinition();
		txnFieldDefinition.setFieldType( fieldType );
		txnFieldDefinition.setOrderNo( row.getRowNum() );
		txnFieldDefinition.setSplitField( true );
		return txnFieldDefinition;
	}

	private TxnFieldDefinition sheetRowToDataField(Row row, FieldType fieldType, List<String> holdErrors) {
		TxnFieldDefinition txnFieldDefinition = new TxnFieldDefinition();
		txnFieldDefinition.setDefaultV( getStringCellValue( row.getCell( 1 ) ) );
		txnFieldDefinition.setName( getStringCellValue( row.getCell( 2 ) ) );
		String dataType = getStringCellValue( row.getCell( 3 ) );
		txnFieldDefinition.setLength( getIntegerCellValue( row.getCell( 4 ) ) );
		txnFieldDefinition.setScale( getIntegerCellValue( row.getCell( 5 ) ) );
		txnFieldDefinition.setPadChar( getStringCellValue( row.getCell( 6 ) ) );
		String justify = getStringCellValue( row.getCell( 7 ) );
		String includeChinese = getStringCellValue( row.getCell( 8 ) );
		String optional = getStringCellValue( row.getCell( 9 ) );
		txnFieldDefinition.setOrderNo( row.getRowNum() );
		txnFieldDefinition.setSplitField( false );
		txnFieldDefinition.setFieldType( fieldType );
		if (FieldType.F.equals( fieldType )) {
			txnFieldDefinition.setCode( getStringCellValue( row.getCell( 0 ) ).trim() );
		} else {
			txnFieldDefinition.setValue( getStringCellValue( row.getCell( 0 ) ).trim() );
		}
		if (messages.getMessage( DataType.H.getPropKey() ).equals( dataType )) {
			txnFieldDefinition.setDataType( DataType.H );
		} else if (messages.getMessage( DataType.N.getPropKey() ).equals( dataType )) {
			txnFieldDefinition.setDataType( DataType.N );
		} else if (messages.getMessage( DataType.X.getPropKey() ).equals( dataType )) {
			txnFieldDefinition.setDataType( DataType.X );
		}
		if (messages.getMessage( "txn.justifytype.l" ).equals( justify )) {
			txnFieldDefinition.setJustify( JustifyType.L );
		} else if (messages.getMessage( "txn.justifytype.r" ).equals( justify )) {
			txnFieldDefinition.setJustify( JustifyType.R );
		}
		if (messages.getMessage( "txn.includechinese.yes" ).equals( includeChinese )) {
			txnFieldDefinition.setIncludeChinese( 1 );
		} else if (messages.getMessage( "txn.includechinese.no" ).equals( includeChinese )) {
			txnFieldDefinition.setIncludeChinese( 0 );
		}
		if (messages.getMessage( "txn.required.yes" ).equals( optional )) {
			txnFieldDefinition.setOptional( 0 );
		} else if (messages.getMessage( "txn.required.no" ).equals( optional )) {
			txnFieldDefinition.setOptional( 1 );
		}
		String erroMsg = validateTxnField( row.getSheet(), txnFieldDefinition );
		if (txnFieldDefinition.getScale() == null && StringUtils.isNoneBlank( getStringCellValue( row.getCell( 6 ) ) )) {
			erroMsg += "欄位小數位數無效,";
		}
		if (StringUtils.isNoneBlank( erroMsg )) {
			holdErrors.add( "第" + (row.getRowNum() + 1) + "行:" + erroMsg );
		}
		return txnFieldDefinition;
	}
}
