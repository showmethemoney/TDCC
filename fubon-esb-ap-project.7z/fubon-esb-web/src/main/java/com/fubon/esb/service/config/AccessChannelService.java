package com.fubon.esb.service.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.config.AccessChannelDao;
import com.fubon.esb.dao.config.TxnChannelDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Service
public class AccessChannelService {

    @Inject
    private AccessChannelDao accessChannelDao;
    @Inject
    private TxnDao txnDao;
    @Inject
    private TxnChannelDao txnChannelDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private Messages messages;
    @Inject
    private AccessChannelCompareService accessChannelCompareService;

    public List<AccessChannel> findLatestAccessChannels(String code, String name, ConfigActiveStatus status, Page page) {
        return accessChannelDao.findLatestAccessChannels(code, name, status, page);
    }

    @Transactional
    public String saveAccessChannel(AccessChannel accessChannel, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        if (isCodeDuplicated(accessChannel.getCode().trim())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(accessChannel.getEffectType())) {
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            accessChannel.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            accessChannel.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(accessChannel.getEffectType())) {
            accessChannel.setEffectTime(null);
            accessChannel.setMainId(null);
        }
        // 建立者
        accessChannel.setCreatedUser(loginContext.loginedUserId());
        accessChannel.setCreatedTime(new Date());
        accessChannelDao.save(accessChannel);
        accessChannelCompareService.sendMail(accessChannel, null);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增AccessChannel,Access Channel代號：" + accessChannel.getCode() + "，Access Channel名稱：" + accessChannel.getName(),
                LogType.SYS_CFG_ACCESS_CHANNEL);
        return accessChannel.getId();

    }

    public AccessChannel getAccessChannelById(String id) {
        return accessChannelDao.getAccessChannelById(id);
    }

    @Transactional
    public String updateAccessChannel(AccessChannel accessChannel, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        setProperty(accessChannel);
        AccessChannel oldAccessChannel = getAccessChannelById(accessChannel.getId());
        String oldCode = oldAccessChannel.getCode();
        String oldName = oldAccessChannel.getName();
        if (isCodeDuplicated(accessChannel)) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(accessChannel.getEffectType())) {
            Date effectTime = timeZoneService.getTZDateByService(stringToDate(effectDate, effectHour, effectMinute));
            accessChannel.setEffectTime(effectTime);
            if (accessChannel.getMainId() == null) { // 正本生效-->復制修改後的對象作為副本，正本保持不變
                AccessChannel copyAc = new AccessChannel(); // 新建副本
                BeanUtils.copyProperties(accessChannel, copyAc, "id");
                copyAc.setMainId(accessChannel.getId());
                accessChannelCompareService.sendMail(copyAc, getAccessChannelById(accessChannel.getId()));
                accessChannelDao.save(copyAc);
                operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改AccessChannel,Access Channel代號：" + oldCode + "，Access Channel名稱：" + oldName, LogType.SYS_CFG_ACCESS_CHANNEL);
                return copyAc.getId();
            } else { // 副本預約生效-->直接修改
                accessChannelCompareService.sendMail(accessChannel, getAccessChannelById("0".equals(accessChannel.getMainId()) ? accessChannel.getId() : accessChannel.getMainId()));
                accessChannelDao.update(accessChannel);
                operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改AccessChannel,Access Channel代號：" + oldCode + "，Access Channel名稱：" + oldName, LogType.SYS_CFG_ACCESS_CHANNEL);
                return accessChannel.getId();
            }
        } else if (EffectType.I.equals(accessChannel.getEffectType())) {
            accessChannel.setEffectTime(null);
            if (accessChannel.getMainId() == null || "0".equals(accessChannel.getMainId())) { // 正本立即生效-->直接修改
                accessChannel.setMainId(null);
                accessChannelCompareService.sendMail(accessChannel, getAccessChannelById(accessChannel.getId()));
                accessChannelDao.update(accessChannel);
                operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改AccessChannel,Access Channel代號：" + oldCode + "，Access Channel名稱：" + oldName, LogType.SYS_CFG_ACCESS_CHANNEL);
                return accessChannel.getId();
            } else { // 副本有指向的正本
                AccessChannel mainAccessChannel = getAccessChannelById(accessChannel.getMainId());
                AccessChannel originAccessChannel = new AccessChannel();
                BeanUtils.copyProperties(mainAccessChannel, originAccessChannel);
                BeanUtils.copyProperties(accessChannel, mainAccessChannel, "id");
                mainAccessChannel.setMainId(null); //
                accessChannelCompareService.sendMail(mainAccessChannel, originAccessChannel); //
                accessChannelDao.deleteAccessChannelById(accessChannel.getId()); // 刪除副本
                accessChannelDao.update(mainAccessChannel);
                operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改AccessChannel,Access Channel代號：" + oldCode + "，Access Channel名稱：" + oldName, LogType.SYS_CFG_ACCESS_CHANNEL);
                return mainAccessChannel.getId();
            }
        } else
            return null;
    }

    public void setProperty(AccessChannel accessChannel) {
        accessChannel.setUpdatedTime(new Date());
        accessChannel.setUpdatedUser(loginContext.loginedUserId());
        AccessChannel persiAccessChannel = getAccessChannelById(accessChannel.getId());
        accessChannel.setMainId(persiAccessChannel.getMainId());
        accessChannel.setCreatedTime(persiAccessChannel.getCreatedTime());
        accessChannel.setCreatedUser(persiAccessChannel.getCreatedUser());
    }

    public String getChannelCodes(List<Channel> channelList) {

        String channels = "";
        StringBuilder channelBuffer = new StringBuilder();
        for (Channel channel : channelList) {
            channelBuffer.append(channel.getCode() + ",");
        }
        if (channelBuffer.length() > 0) {
            channels = channelBuffer.toString();
            channels = channels.substring(0, channels.length() - 1);
        }
        return channels;
    }

    public String getTxnCodes(List<Channel> channelList) {

        List<String> channelIds = new ArrayList<String>();
        List<TxnChannel> txnChannelList = new ArrayList<TxnChannel>();
        StringBuilder txnCodeBuffer = new StringBuilder();
        String txnCodes = "";
        for (Channel channel : channelList) {
            channelIds.add(channel.getId());
        }
        if (!channelIds.isEmpty()) {
            txnChannelList = txnChannelDao.findByChannelIds(channelIds);
        }
        if (!txnChannelList.isEmpty()) {
            for (TxnChannel txnChannel : txnChannelList) {

                Txn txn = txnDao.getTxnById(txnChannel.getTxnId());
                if (txn != null) {
                    txnCodeBuffer.append(txn.getCode() + ",");
                }
            }
        }
        if (txnCodeBuffer.length() > 0) {
            txnCodes = txnCodeBuffer.toString();
            txnCodes = txnCodes.substring(0, txnCodes.length() - 1);
        }
        return txnCodes;
    }

    public List<AccessChannel> findMainAccessChannels(String accessChannelCode, Page page) {
        return accessChannelDao.findMainAccessChannels(accessChannelCode, page);
    }

    public Date stringToDate(String effectDate, String effectHour, String effectMinute) {
        Date effectTime = null;
        try {
            effectTime = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(effectDate + " " + effectHour + ":" + effectMinute);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return effectTime;
    }

    public boolean isCodeDuplicated(String code) {
        return accessChannelDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(AccessChannel accessChannel) {
        AccessChannel updatedAccessChannel = null;
        String oldCode = "";
        updatedAccessChannel = getAccessChannelById(accessChannel.getId());
        if (updatedAccessChannel != null) {
            oldCode = updatedAccessChannel.getCode();
        }
        return accessChannelDao.isDuplicatedByCode(accessChannel.getCode().trim()) && !oldCode.equals(accessChannel.getCode());
    }

    @Transactional
    public void deleteAccessChannel(String id) {
        accessChannelDao.updateStatus(id);
    }

    // 是否有关联Channel
    public boolean isRelatedAccessChannel(String id, StringBuilder message) {
        List<Channel> channels = accessChannelDao.isRelatedAccessChannel(id);
        if (!channels.isEmpty()) {
            for (Channel channel : channels) {
                if (id.equals(channel.getAccessChannelId())) {
                    message.append(channel.getCode()).append(",");
                }
            }
        }
        return !channels.isEmpty();
    }

}
