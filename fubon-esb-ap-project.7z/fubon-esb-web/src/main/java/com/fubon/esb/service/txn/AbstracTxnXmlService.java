package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

/**
 * @author nice
 * @createdDate 2015-1-23
 */
@Service
public abstract class AbstracTxnXmlService {
    @Inject
    protected TxnFieldTestValueService testValueService;
    @Inject
    protected TxnFieldDefinitionService txnFieldService;
    @Inject
    protected TxnDirectionService txnDirectionService;
    protected static final String TAG_NAME_BODY = "TxBody";
    protected static final String TAG_NAME_HEADER = "TxHead";
    protected static final String TAG_NAME_FMPCONN = "FMPConnectionString";
    protected final ThreadLocal<Document> document = new ThreadLocal<Document>();
    protected final ThreadLocal<List<NormalFieldValue>> normalFieldValues = new ThreadLocal<List<NormalFieldValue>>();
    private final ThreadLocal<String> tlCurDirectionId = new ThreadLocal<String>();

    public String getCurDirectionId() {
        return tlCurDirectionId.get();
    }

    public void setCurDirectionId(String dirId) {
        tlCurDirectionId.set(dirId);
    }

    abstract void prepareXml(String xmlStr, String dirId) throws Exception;

    abstract void saveTxTestValues(String xmlStr, String dirId) throws Exception;

    public Document getDocument() {
        return document.get();
    }

    public void setDocument(Document doc) {
        document.set(doc);
    }

    public List<NormalFieldValue> getNormalFieldValues() {
        if (normalFieldValues.get() == null) {
            normalFieldValues.set(new ArrayList<NormalFieldValue>(1));
        }
        return normalFieldValues.get();
    }

    public void addNormalFieldValue(NormalFieldValue normalFieldValue) {
        for (NormalFieldValue nfv : getNormalFieldValues()) {
            if (nfv.getFieldCode().equals(normalFieldValue.getFieldCode())) {
                nfv.setTestValue(normalFieldValue.getTestValue());
                return;
            }
        }
        getNormalFieldValues().add(normalFieldValue);
    }

    public String findNormalFieldValue(String fieldCode) {
        for (NormalFieldValue mainFFieldData : getNormalFieldValues()) {
            if (mainFFieldData.getFieldCode().equals(fieldCode)) {
                return mainFFieldData.getTestValue();
            }
        }
        return null;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void fillMainNormalFieldValues() throws Exception {
        Element txBody = visitBodyElement();
        for (Iterator<Element> it = txBody.elementIterator(); it.hasNext();) {
            Element next = it.next();
            List cElems = next.elements();
            if (cElems == null || cElems.isEmpty()) {
                addNormalFieldValue(new NormalFieldValue(next.getName(), next.getText()));
            }
        }
    }

    public Element visitFMPConnElement() throws Exception {
        return getDocument().getRootElement().element(TAG_NAME_FMPCONN);
    }

    public Element visitHeaderElement() throws Exception {
        return getDocument().getRootElement().element(TAG_NAME_HEADER);
    }

    public Element visitBodyElement() throws Exception {
        return getDocument().getRootElement().element(TAG_NAME_BODY);
    }

    /** 一層層剝，到最後一層查找到對應的則意味著成功 **/
    public Element getElementByDegree(String searchQname, Element root, List<Integer> degree) {
        int level = degree == null ? 0 : degree.size();
        if (root == null || level == 0)
            return root;
        if (level == 1) {
            return root.element(searchQname);
        }
        List<Integer> mapDegree = new ArrayList<Integer>(degree);
        int select = mapDegree.remove(0);
        if (root.elements() != null && !root.elements().isEmpty()) {
            try {
                return getElementByDegree(searchQname, (Element) root.elements().get(select - 1), mapDegree);
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        } else {
            return null;
        }
    }

    public List<Integer> increaseDegree(final List<Integer> provDegree, final boolean insertBefore, final Integer... increments) {
        List<Integer> newDegree = provDegree == null ? new ArrayList<Integer>(1) : new ArrayList<Integer>(provDegree);
        if (increments != null && increments.length != 0) {
            List<Integer> adds = Arrays.asList(increments);
            if (insertBefore) {
                newDegree.addAll(0, adds);
            } else {
                newDegree.addAll(adds);
            }
        }
        return newDegree;
    }

    protected int converToOrderNo(List<Integer> degree) {
        StringBuffer orderNo = new StringBuffer(degree.size());
        degree.set(0, 1);
        for (Integer deg : degree) {
            orderNo.append(deg);
        }
        return Integer.parseInt(orderNo.toString());
    }

    static class NormalFieldValue {
        private String fieldCode;
        private String testValue;

        public NormalFieldValue(String fieldCode, String testValue) {
            this.fieldCode = fieldCode;
            this.testValue = testValue;
        }

        public String getFieldCode() {
            return fieldCode;
        }

        public void setFieldCode(String fieldCode) {
            this.fieldCode = fieldCode;
        }

        public String getTestValue() {
            return testValue;
        }

        public void setTestValue(String testValue) {
            this.testValue = testValue;
        }
    }

    static class Link {
        private Integer curIndex;
        private List<Integer> degree;
        private List<Integer> pIndex;

        public Link(Integer curIndex, List<Integer> degree, List<Integer> pIndex) {
            this.curIndex = curIndex;
            this.degree = degree;
            this.pIndex = pIndex;
        }

        public Integer getCurIndex() {
            return curIndex;
        }

        public void setCurIndex(Integer curIndex) {
            this.curIndex = curIndex;
        }

        public List<Integer> getDegree() {
            return degree;
        }

        public void setDegree(List<Integer> degree) {
            this.degree = degree;
        }

        public List<Integer> getpIndex() {
            return pIndex;
        }

        public void setpIndex(List<Integer> pIndex) {
            this.pIndex = pIndex;
        }

    }

}
