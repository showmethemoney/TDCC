package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.fubon.esb.controller.txn.view.EditTxnField;
import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnStatus;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Service
public class TxnService extends BaseTxnService {

    @Inject
    private TxnSendService txnSendService;
    @Inject
    private TxnDirectionService txnDirecService;

    @Transactional
    public void saveFromTxnExcelVO(TxnVO txnVO) {
        TxnDefinition definition = txnVO.getDefinition();
        Assert.notNull(definition, "TxnDefinition can not be null");
        TxnDirection upDirection = txnVO.getUpDirection();
        TxnDirection downDirection = txnVO.getDownDirection();
        txnDefinitionService.saveOrUpdate(definition);
        upDirection.setDefinitionId(definition.getId());
        downDirection.setDefinitionId(definition.getId());
        txnDirectionService.saveOrUpdate(upDirection);
        txnDirectionService.saveOrUpdate(downDirection);
        EditTxnField[] upFields = covertContainsSplitFieldToEditTxnFields(txnVO.getUpFields(), DirectionType.U.toString());
        EditTxnField[] downFields = covertContainsSplitFieldToEditTxnFields(txnVO.getDownFields(), DirectionType.D.toString());
        EditTxnField[] allFields = ArrayUtils.addAll(upFields, downFields);
        saveOrUpdateEditTxn(definition, upDirection, downDirection, allFields);
        logToDB(messages.getMessage("txn.edit.log.read.txn", definition.getTxnCode(), definition.getName()));
    }

    @Transactional
    public void saveOrUpdateEditTxn(TxnDefinition txnDef, TxnDirection upTxnDirec, TxnDirection downTxnDirec, EditTxnField[] eTxnFields) {
        txnDefinitionService.saveOrUpdate(txnDef);
        upTxnDirec.setDefinitionId(txnDef.getId());
        downTxnDirec.setDefinitionId(txnDef.getId());
        txnDirectionService.saveOrUpdate(upTxnDirec);
        txnDirectionService.saveOrUpdate(downTxnDirec);
        txnFieldService.batchProcessFromVOs(txnDef, eTxnFields, upTxnDirec.getId(), downTxnDirec.getId());
    }

    public TxnVO findTxnVO(String defId) {
        TxnVO txnVO = new TxnVO();
        TxnDefinition definition = txnDefinitionService.getById(defId);
        TxnDirection upDirection = txnDirectionService.findByDefIdAndDirection(defId, DirectionType.U);
        TxnDirection downDirection = txnDirectionService.findByDefIdAndDirection(defId, DirectionType.D);
        txnVO.setDefinition(definition);
        txnVO.setUpDirection(upDirection);
        txnVO.setDownDirection(downDirection);
        if (upDirection != null)
            txnVO.setUpFields(txnFieldService.findMainsByDirId(upDirection.getId()));
        if (downDirection != null)
            txnVO.setDownFields(txnFieldService.findMainsByDirId(downDirection.getId()));
        return txnVO;
    }

    public TxnVO findTxnVOForExcel(String defId) {
        TxnDefinition definition = txnDefinitionService.getById(defId);
        TxnDirection upDirection = txnDirectionService.findByDefIdAndDirection(defId, DirectionType.U);
        TxnDirection downDirection = txnDirectionService.findByDefIdAndDirection(defId, DirectionType.D);
        List<TxnFieldDefinition> upFields = new ArrayList<TxnFieldDefinition>();
        List<TxnFieldDefinition> downFields = new ArrayList<TxnFieldDefinition>();
        if (upDirection != null)
            upFields = findAllChildrenAndSplitByField(txnFieldService.findMainsByDirId(upDirection.getId()));
        if (downDirection != null)
            downFields = findAllChildrenAndSplitByField(txnFieldService.findMainsByDirId(downDirection.getId()));
        return new TxnVO(definition, upDirection, downDirection, upFields, downFields);
    }

    /** Header export Excel **/
    public TxnVO findTxnVOForHeaderExcel(String defId) {
        TxnDirection headDirection = txnDirecService.findHeadDirByID(defId);
        List<TxnFieldDefinition> headFields = new ArrayList<TxnFieldDefinition>();
        if (headDirection != null)
            headFields = txnFieldService.findMainsByDirId(headDirection.getId());
        return new TxnVO(headDirection, headFields);
    }

    /** save update **/
    @Transactional
    public void saveOrUpdateEditTxnHeader(TxnDirection headTxnDirec, EditTxnField[] eTxnFields) {
        txnDirectionService.saveOrUpdateHeader(headTxnDirec);
        txnFieldService.batchProcessHeaderFromVOs(eTxnFields, headTxnDirec.getId(), true);
    }

    /** import save **/
    @Transactional
    public void saveFromTxnHeaderExcelVO(TxnVO txnVO) {
        TxnDirection direction = txnVO.getHeadDirection();
        Assert.notNull(direction, "TxnDirection can not be null");
        TxnDirection headDirection = txnVO.getHeadDirection();
        // txnDirectionService.saveOrUpdate(headDirection);
        EditTxnField[] headFields = covertContainsSplitFieldToEditTxnFields(txnVO.getHeadFields(), DirectionType.H.toString());
        saveOrUpdateEditTxnHeader(headDirection, headFields);
        logToDB(messages.getMessage("txn.edit.log.read.txn", direction.getName()));
    }

    /** 通過不同的filedtype以新的TxnFieldDefinition對象添加到list上達到分割效果 **/
    public List<TxnFieldDefinition> findAllChildrenAndSplitByField(List<TxnFieldDefinition> parents) {
        List<TxnFieldDefinition> result = new ArrayList<TxnFieldDefinition>();
        if (parents != null && !parents.isEmpty())
            for (TxnFieldDefinition field : parents) {
                result.add(field);
                List<TxnFieldDefinition> children = findChildrenAndSplitByField(field.getId());
                if (children != null && !children.isEmpty())
                    result.addAll(findAllChildrenAndSplitByField(children));
            }
        return result;
    }

    /** 通過不同的filedtype以新的TxnFieldDefinition對象添加到list上達到分割效果 **/
    public List<TxnFieldDefinition> findChildrenAndSplitByField(String parentId) {
        TxnFieldDefinition parentField = txnFieldService.getById(parentId);
        if (parentField == null)
            return null;
        List<TxnFieldDefinition> result = new ArrayList<TxnFieldDefinition>();
        TxnFieldDefinition splitFieldE = null;
        if (FieldType.F.equals(parentField.getFieldType())) {
            splitFieldE = new TxnFieldDefinition(FieldType.F);
            splitFieldE.setSplitField(true);
            splitFieldE.setName(BaseTxnExcelService.TAG_TX_FIELD);
            splitFieldE.setValue(parentField.getValue());
        } else if (FieldType.R.equals(parentField.getFieldType())) {
            splitFieldE = new TxnFieldDefinition(FieldType.R);
            splitFieldE.setSplitField(true);
            splitFieldE.setName(BaseTxnExcelService.TAG_TX_REPEAT_END);
            splitFieldE.setValue(parentField.getValue());
        } else if (FieldType.S.equals(parentField.getFieldType())) {
            splitFieldE = new TxnFieldDefinition(FieldType.S);
            splitFieldE.setSplitField(true);
            splitFieldE.setName(BaseTxnExcelService.TAG_TX_SWITCH_END);
            splitFieldE.setValue(parentField.getValue());
        } else if (FieldType.C.equals(parentField.getFieldType())) {
            splitFieldE = new TxnFieldDefinition(FieldType.C);
            splitFieldE.setSplitField(true);
            splitFieldE.setName(BaseTxnExcelService.TAG_TX_CASE_END);
            splitFieldE.setValue(parentField.getValue());
        }
        result.addAll(txnFieldService.findChildren(parentId));
        result.add(splitFieldE);
        return result;
    }

    /** 通過excel中獲取的field列表（解析excel時碰到類似Tx Repeat-End,Tx Switch-End,Tx Case-End行將轉換成作為分割的TxnFieldDefinition）轉換成Tr-ParentTr關係對象 EditTxnField數組 **/
    public EditTxnField[] covertContainsSplitFieldToEditTxnFields(List<TxnFieldDefinition> fields, String direction) {
        if (fields == null || fields.isEmpty())
            return null;
        Map<Integer, String> history = new HashMap<>();
        EditTxnField[] eFields = new EditTxnField[fields.size()];
        List<EditTxnField> parentOrder = new ArrayList<EditTxnField>();
        EditTxnField eField = null;
        TxnFieldDefinition field = null;
        for (int i = 0; i < fields.size(); i++) {
            field = fields.get(i);
            Assert.notNull(field.getOrderNo());
            Assert.notNull(field.getFieldType());
            String trId = "TR_" + field.getOrderNo();
            history.put(field.getOrderNo(), trId);
            eField = new EditTxnField();
            eField.setEditType(EditTxnField.EDIT_TYPE_ADD);
            eField.setTrid(trId);
            eField.setTxnField(field);
            eField.setBlongDirec(direction);
            EditTxnField curParent = null;
            if (parentOrder != null && !parentOrder.isEmpty())
                curParent = parentOrder.get(parentOrder.size() - 1);
            if (!FieldType.F.equals(field.getFieldType()) && !field.isSplitField()) {
                parentOrder.add(eField);
            }
            if (curParent != null && field.isSplitField() && field.getFieldType().equals(curParent.getTxnField().getFieldType())) {
                parentOrder.remove(parentOrder.size() - 1);
            }
            eField.setParentTrid(curParent == null ? null : curParent.getTrid());
            if (!field.isSplitField())
                eFields[i] = eField;
        }
        return eFields;
    }

    @Transactional
    public String approveTxn(String defId, String approveUser) {
        String mainId = defId;
        TxnDefinition definition = txnDefinitionService.getById(defId);
        // delete txn
        if (definition != null && TxnStatus.D.equals(definition.getStatus())) {
            removeTxn(defId);
        } else { // check txn
            mainId = txnDefinitionService.getMainDefIdByCopyDefId(defId);
            copyDefToMainDef(defId, approveUser);
        }
        return mainId;
    }

    @Transactional
    public List<String> approveTxns(String[] defIds, String approveUser) {
        List<String> mainIds = new ArrayList<String>();
        for (String defId : defIds) {
            String mainId = approveTxn(defId, approveUser);
            mainIds.add(mainId);
        }
        return mainIds;
    }

    public String sendTestTxn(String requestData, int times) {
        int repeat = times;
        String newRequestDate = requestData;
        String responseText = txnSendService.sendTxn(newRequestDate, repeat);
        if (StringUtils.isNotBlank(responseText) && responseText.indexOf("<HRETRN>C</HRETRN>") != -1) {
            if (newRequestDate.indexOf("<HRETRN>") > -1) {
                String hretrn = newRequestDate.substring(newRequestDate.indexOf("<HRETRN>"), newRequestDate.indexOf("</HRETRN>") + 9);
                newRequestDate = newRequestDate.replace(hretrn, "<HRETRN>C</HRETRN>");
            } else {
                newRequestDate = newRequestDate.replace("<TxHead>", "<TxHead><HRETRN>C</HRETRN>").replace("<TXHEAD>", "<TXHEAD><HRETRN>C</HRETRN>");
            }
            return responseText + "##@##" + sendTestTxn(newRequestDate, ++repeat);
        }
        return responseText;
    }
}
