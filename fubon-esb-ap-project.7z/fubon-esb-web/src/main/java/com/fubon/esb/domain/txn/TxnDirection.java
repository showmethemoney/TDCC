package com.fubon.esb.domain.txn;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.beans.BeanUtils;

/**
 * 上行下行設定
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "TXN_DIRECTION")
public class TxnDirection implements Serializable {

    /** ID **/
    @Id
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    @Column(name = "ID")
    private String id;

    /** 名稱 HeaderCode **/
    @Column(name = "DIRECTION_NAME")
    private String name;

    /** 所屬電文定義 **/
    @Column(name = "DEFINITION_ID")
    private String definitionId;

    /** 上行下行標志 {U:Up上行,D:Down下行,H:head} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "DIRECTION")
    private DirectionType direction;

    /** 文件格式{T:TXT,X:XML} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "TYPE")
    private FileType type;

    /** 文件格式{T:TXT,X:XML} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "OUT_TYPE")
    private FileType outType;

    /** 使用的電文頭部 **/
    @Column(name = "HEAD_REF_ID")
    private String headRefId;

    /** 編碼 **/
    @Column(name = "ENCODING")
    private String encoding;

    /** 對應正本 **/
    @Column(name = "MAIN_ID")
    private String mainId;

    /** 創建者 **/
    @Column(name = "CREATED_USER")
    private String createUser;

    /** 創建時間 **/
    @Column(name = "TXN_HEADER_CREATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    /** 更新者 **/
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 **/
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTime;

    /** 狀態{M:Main正式版本,E:Edited編輯版本(暫存),S:Saved存儲版本(待復核)} **/
    @Enumerated(EnumType.STRING)
    @Column(name = "TXN_HEADER_STATUS")
    private TxnStatus txnHeaderStatus;

    @Transient
    private String headRefName;

    public TxnDirection() {

    }

    public TxnDirection(DirectionType direction) {
        this.direction = direction;
    }

    public TxnDirection(TxnDirection txnDirection, String headRefName) {
        if (txnDirection != null) {
            BeanUtils.copyProperties(txnDirection, this);
        }
        this.headRefName = headRefName;
    }

    /******* page inject enum ********/
    public void setDirectionP(String direction) {
        this.direction = DirectionType.valueOf(direction);
    }

    public void setTypeP(String type) {
        this.type = FileType.valueOf(type);
    }

    public void setOutTypeP(String outType) {
        this.outType = FileType.valueOf(outType);
    }

    /***************/

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefinitionId() {
        return definitionId;
    }

    public void setDefinitionId(String definitionId) {
        this.definitionId = definitionId;
    }

    public DirectionType getDirection() {
        return direction;
    }

    public void setDirection(DirectionType direction) {
        this.direction = direction;
    }

    public FileType getType() {
        return type;
    }

    public void setType(FileType type) {
        this.type = type;
    }

    public FileType getOutType() {
        return outType;
    }

    public void setOutType(FileType outType) {
        this.outType = outType;
    }

    public String getHeadRefId() {
        return headRefId;
    }

    public void setHeadRefId(String headRefId) {
        this.headRefId = headRefId;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getHeadRefName() {
        return headRefName;
    }

    public void setHeadRefName(String headRefName) {
        this.headRefName = headRefName;
    }

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public TxnStatus getTxnHeaderStatus() {
        return txnHeaderStatus;
    }

    public void setTxnHeaderStatus(TxnStatus txnHeaderStatus) {
        this.txnHeaderStatus = txnHeaderStatus;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

}
