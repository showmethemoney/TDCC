package com.fubon.esb.domain.txn;

/**
 * 
 * @author Shelly
 * @createdDate 2015-1-15
 */
public enum TxnManageCategoryType {

    /** 全部 */
    ALL("all"),

    /** 依交易代號分類 */
    TXN("txn"),

    /** 依channel分類 */
    CHANNEL("channel"),

    /** 依access channel分類 */
    ACCESSCHANNEL("accessChannel"),

    /** 依主機分類 */
    HOST("host"),

    /** 依業務群組分類 */
    TXNGROUP("txnGroup"),

    /** 依service分類 */
    SERVICE("service"),

    /** 依service版本分類 */
    SERVICEVERSION("serviceVersion"),

    /** 依connector塊別 */
    CONNECTOR("connector");

    private final String category;

    private TxnManageCategoryType(String category) {
        this.category = category;
    }

    public String toString() {
        return category;
    }

}
