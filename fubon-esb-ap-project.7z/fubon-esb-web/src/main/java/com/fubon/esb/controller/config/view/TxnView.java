package com.fubon.esb.controller.config.view;

import com.fubon.esb.domain.config.ConfigActiveStatus;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-6
 */
public class TxnView {

    private String txnCode;
    private String txnName;
    private String txnGroupCode;
    private String serviceCode;
    private String channelCode;
    private String connectorCode;
    private ConfigActiveStatus status;

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public String getTxnName() {
        return txnName;
    }

    public void setTxnName(String txnName) {
        this.txnName = txnName;
    }

    public String getTxnGroupCode() {
        return txnGroupCode;
    }

    public void setTxnGroupCode(String txnGroupCode) {
        this.txnGroupCode = txnGroupCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getConnectorCode() {
        return connectorCode;
    }

    public void setConnectorCode(String connectorCode) {
        this.connectorCode = connectorCode;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
