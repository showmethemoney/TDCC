package com.fubon.esb.domain;

/**
 * @author Robin
 * @createdDate Oct 30, 2014
 */
public enum ActiveStatus {

    /** Active */
    A("Active"),

    /** Inactive */
    I("Inactive"),

    D("Delete");

    private final String desc;

    private ActiveStatus(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }

}
