package com.fubon.esb.dao.job;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.Query;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.job.JobRecord;

@Repository
public class JobRecordDao extends LogDBJPADaoSupport<JobRecord> {

    public List<JobRecord> findDayRecords(String configId, Date startDate, Date endDate) {

        Query query = Query.from(JobRecord.class).where("configId=:configId").param("configId", configId);
        query.append(" and startTime >= :startTime ");
        query.setParam("startTime", startDate);
        query.append(" and startTime <= :endTime");
        query.setParam("endTime", endDate);
        //query.append(" and endTime >= :startTime ");
        //query.setParam("startTime", startDate);
        //query.append(" and endTime <= :endTime ");
        //query.setParam("endTime", endDate);
        query.orderBy(" startTime desc ");
        return jpaAccess.find(query);

    }

    public List<JobRecord> findRecordsByConfigId(String configId) {
        Query query = Query.from(JobRecord.class).where("configId=:configId").param("configId", configId);
        query.orderBy(" startTime desc");
        return jpaAccess.find(query);
    }

    public JobRecord getJobRecordById(String id) {
        return jpaAccess.get(JobRecord.class, id);
    }
}
