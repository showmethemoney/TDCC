package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.MailGroup;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-11
 */

@Repository
public class MailGroupDao extends JPADaoSupport<MailGroup> {

    public List<MailGroup> findMailGroups(String code, String name) {
        Query query = Query.from(MailGroup.class).append(" mailGroup where 1=1");
        if (StringUtils.isNotBlank(code)) {
            query.append(" and mailGroup.code like :code ");
            query.setParam("code", "%" + code.trim() + "%");
        }
        if (StringUtils.isNotBlank(name)) {
            query.append(" and mailGroup.name like :name");
            query.setParam("name", "%" + name + "%");
        }
        query.orderBy("id");
        return jpaAccess.find(query);
    }
    
    
    public List<MailGroup> findAllMailGroups() {
        Query query = Query.from(MailGroup.class).append(" mailGroup where 1=1 order by code");
        return jpaAccess.find(query);
    }
    
    public boolean codeDuplicate(String code) {
        Query query = Query.from(MailGroup.class).where("code = :code").param("code", code);
        return !jpaAccess.find(query).isEmpty();

    }

    public MailGroup getlById(String id) {
        return jpaAccess.get(MailGroup.class, id);
    }

    public void removeMailGroup(String id) {
        Query query = Query.create("delete from " + MailGroup.class.getName() + " where id = :id").param("id", id);
        jpaAccess.update(query);
    }
}
