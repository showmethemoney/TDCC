package com.fubon.esb.controller.config;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.EditTxnView;
import com.fubon.esb.controller.config.view.TxnConfigExcel;
import com.fubon.esb.controller.config.view.TxnConfigExcelVO;
import com.fubon.esb.controller.config.view.TxnExportExcelVO;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.PriorityType;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Adapter;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.HostService;
import com.fubon.esb.service.config.TxnConfigEditService;
import com.fubon.esb.service.config.TxnConfigExcelService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Shelly
 * @createdDate 2014-11-7
 */

@Controller
@RequestMapping("/txn")
public class TxnConfigController extends BaseController {

    @Inject
    private LoginContext loginContext;
    @Inject
    private HostService hostService;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private TxnConfigExcelService txnConfigExcelService;
    @Inject
    private TxnConfigEditService txnConfigEditService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSearchTxnList")
    public String viewSearchTxnGroupList(Model model) {
        return "/config/viewTxnList";
    }

    @RequirePermission(value = "050101")
    @RequestMapping("/viewTxnList")
    public String viewTxnList(Model model, TxnView txnView, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Txn> txns = txnConfigEditService.findLatestTxns(txnView, orderBy, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            txns = txnConfigEditService.findLatestTxns(txnView, orderBy, page);
        }
        model.addAttribute("txnView", txnView);
        model.addAttribute("orderBy", orderBy);
        model.addAttribute("txns", txns);
        model.addAttribute("page", page);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("orderPicUrl", txnConfigEditService.setOrderPicUrl(orderBy));
        return "/config/viewTxnList";
    }

    @RequirePermission(value = {"050102", "050103"})
    @RequestMapping("/viewTxn")
    public String viewTxn(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) { // 修改
            isAdd = false;
            Txn txn = txnConfigEditService.getTxnByIdWithRelatedInfo(id);
            Host host = hostService.getHostCodeByTxnId(id);
            List<String> channelCodes = txnConfigEditService.findRelatedChannelCodes(id);
            List<String> relatedTxnCodes = txnConfigEditService.getRelatedTxnCodes(id);
            model.addAttribute("txn", txn);
            model.addAttribute("host", host);
            model.addAttribute("channelIds", channelCodes.get(0));
            model.addAttribute("channelCodes", channelCodes.get(1));
            model.addAttribute("accessChannelCodes", channelCodes.get(2));
            model.addAttribute("txnRelatedIds", relatedTxnCodes.get(0));
            model.addAttribute("txnRelatedCodes", relatedTxnCodes.get(1));
        }
        model.addAttribute("isAdd", isAdd);
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        model.addAttribute("PRIORITYTYPE_H", PriorityType.H);
        model.addAttribute("PRIORITYTYPE_M", PriorityType.M);
        model.addAttribute("PRIORITYTYPE_L", PriorityType.L);
        return "/config/viewTxn";
    }

    
    @RequestMapping("/refreshTxn")
    @ResponseBody
    public Object refreshTxn(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
         
    	 if (StringUtils.isNotBlank(id))
               send_status=configChangeService.sendChangeEvent(ConfigType.CFG_TXN, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    
    @RequirePermission(value = {"050102", "050103"})
    @RequestMapping("saveOrUpdateTxn")
    @ResponseBody
    public ResultView saveOrUpdateTxn(@Valid Txn txn, EditTxnView editTxnView) {
        try {
            String updateId = txnConfigEditService.saveOrUpdateTxn(txn, editTxnView);
            if (StringUtils.isNotBlank(updateId))
                configChangeService.sendChangeEvent(ConfigType.CFG_TXN, updateId);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/txn/viewTxnList");
    }
    
    
    @RequestMapping("/findMainTxn")
    public String findMainTxn(Model model, @RequestParam(required = false) String code, @RequestParam(required = false) String id, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Txn> txns = txnConfigEditService.findMainTxn(code, id, page);
        model.addAttribute("code", code);
        model.addAttribute("page", page);
        model.addAttribute("txns", txns);
        return "/config/include/viewMainTxnList";
    }

    @RequestMapping("/findChannels")
    @ResponseBody
    public Map<String, Object> findChannels(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Channel> channels = txnConfigEditService.findChannels(id);
        result.put("channels", channels);
        return result;
    }

    @ResponseBody
    @RequestMapping({"/findTxnCodes"})
    public Object findTxnCodes(@RequestParam String key) {
        return autoQueryService.searchTxnCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findRelateTxnCodes"})
    public Object findRelateTxnCodes(@RequestParam String key, String id) {
        return autoQueryService.searchRelateTxnCodes(key, id);
    }

    @RequirePermission(value = "050104")
    @RequestMapping(value = "/reportTxnConfigExcel")
    public ModelAndView writeToRecordExcel(ModelMap model, TxnView txnView, OrderBy orderBy, HttpServletRequest request, HttpServletResponse response) {
        List<Txn> txns = txnConfigExcelService.findTxns(txnView, orderBy);
        List<TxnExportExcelVO> txnvos = new ArrayList<TxnExportExcelVO>();
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                TxnExportExcelVO txnvo = new TxnExportExcelVO();
                txnvo.setTxn(txn);
                String id = txn.getId();
                if (StringUtils.isNotBlank(id)) {
                    TxnConfigExcelVO txnConfigExcelVO = txnConfigExcelService.findTxnConfigExcel(id);
                    txnvo.setTxnConfigExcelVO(txnConfigExcelVO);
                    List<String> channelCodes = txnConfigEditService.findRelatedChannelCodes(id);
                    List<String> relatedTxnCodes = txnConfigExcelService.getRelatedTxnCodes(id);
                    txnvo.setChannelCodes(channelCodes);
                    txnvo.setRelatedTxnCodes(relatedTxnCodes);
                    txnvos.add(txnvo);
                }
            }
        }
        model.put("txnvos", txnvos);
        TxnConfigExcel txnConfigExcel = new TxnConfigExcel(messages);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.TxnConfig.title"));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, txnConfigEditService.createStr(txnView, messageStr), LogType.SYS_CFG_TXN);
        return new ModelAndView(txnConfigExcel, model);
    }

    @RequirePermission(value = "050101")
    @RequestMapping("/viewTxnDetail")
    public String viewTxnDetail(Model model, @RequestParam String id) {
        Txn txn = txnConfigEditService.getTxnByIdWithRelatedInfo(id);
        Host host = hostService.getHostCodeByTxnId(id);
        List<String> channelCodes = txnConfigEditService.findRelatedChannelCodes(id);
        List<String> relatedTxnCodes = txnConfigEditService.getRelatedTxnCodes(id);
        model.addAttribute("txn", txn);
        model.addAttribute("host", host);
        model.addAttribute("txnRelatedCodes", relatedTxnCodes.get(1));
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        model.addAttribute("PRIORITYTYPE_H", PriorityType.H);
        model.addAttribute("PRIORITYTYPE_M", PriorityType.M);
        model.addAttribute("channelIds", channelCodes.get(0));
        model.addAttribute("channelCodes", channelCodes.get(1));
        model.addAttribute("accessChannelCodes", channelCodes.get(2));
        model.addAttribute("txnRelatedIds", relatedTxnCodes.get(0));
        model.addAttribute("PRIORITYTYPE_L", PriorityType.L);
        return "/config/viewTxnDetail";
    }

    @RequestMapping("/deleteTxn")
    @ResponseBody
    public Object deleteTxn(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = txnConfigEditService.isRelatedTxn(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + (relateMessage.isEmpty() ? "" : ",與以下交易關聯：" + relateMessage));
        } else {
            txnConfigEditService.deleteTxn(id);
            flag = true;
            result.put("flag", true);
        }
        return result;
    }

    @ResponseBody
    @RequestMapping({"/findAdapterByKey"})
    public Object findAdapterByKey(@RequestParam String key, String key2) {
        return autoQueryService.searchAdapterByKey(key, key2);
    }

    @RequirePermission(value = {"050102", "050103"})
    @RequestMapping({"/findAdapters"})
    public String findAdapters(Model model, String adapterName, String connectorId, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Adapter> adapters = txnConfigEditService.findAdaptersByName(adapterName, connectorId, page);
        model.addAttribute("adapterName", adapterName);
        model.addAttribute("page", page);
        model.addAttribute("adapters", adapters);
        return "/config/include/viewRelAdapter";
    }
}
