package com.fubon.esb.domain.txn;

public class TxnFieldTestValueKey {

    private String fieldId;

    private Integer orderNo;

    private String refDirectionId;

    public TxnFieldTestValueKey(String fieldId, Integer orderNo, String refDirectionId) {
        this.fieldId = fieldId;
        this.orderNo = orderNo;
        this.refDirectionId = refDirectionId;
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public String getRefDirectionId() {
        return refDirectionId;
    }

    public void setRefDirectionId(String refDirectionId) {
        this.refDirectionId = refDirectionId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((fieldId == null) ? 0 : fieldId.hashCode());
        result = prime * result + ((orderNo == null) ? 0 : orderNo.hashCode());
        result = prime * result + ((refDirectionId == null) ? 0 : refDirectionId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TxnFieldTestValueKey other = (TxnFieldTestValueKey) obj;
        if (fieldId == null) {
            if (other.fieldId != null)
                return false;
        } else if (!fieldId.equals(other.fieldId)) {
            return false;
        }
        if (orderNo == null) {
            if (other.orderNo != null)
                return false;
        } else if (!orderNo.equals(other.orderNo)) {
            return false;
        }
        if (refDirectionId == null) {
            if (other.refDirectionId != null)
                return false;
        } else if (!refDirectionId.equals(other.refDirectionId)) {
            return false;
        }
        return true;
    }

}
