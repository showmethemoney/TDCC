package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fubon.esb.controller.txn.view.TestTxnVO;
import com.fubon.esb.dao.txn.TxnFieldTestValueDao;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;
import com.fubon.esb.domain.txn.TxnFieldTestValueKey;

@Service
public class TxnFieldTestValueService {

    @Inject
    private TxnFieldTestValueDao txnFieldTestValueDao;

    @Inject
    protected TxnFieldDefinitionService txnFieldService;

    /**
     * 修改或添加testValue
     * 
     * @param testValMap
     */
    @Transactional
    public void saveOrUpdateTestValues(List<TxnFieldTestValue> tftvs) {
        if (tftvs == null || tftvs.isEmpty())
            return;
        for (TxnFieldTestValue tftv : tftvs) {
            saveOrUpdateTestValue(tftv);
        }

    }

    @Transactional
    public void saveOrUpdateTestValue(TxnFieldTestValue tftv) {
        if (tftv == null)
            return;
        if (tftv.getOrderNo() == 1) {
            TxnFieldDefinition field = txnFieldService.getById(tftv.getFieldId());
            field.setTestValue(tftv.getTestValue());
            txnFieldService.update(field);
        }
        TxnFieldTestValue existTv = findByTxnFieldTestValueKey(new TxnFieldTestValueKey(tftv.getFieldId(), tftv.getOrderNo(), tftv.getRefDirectionId()));
        if (existTv != null) {
            existTv.setTestValue(tftv.getTestValue());
            txnFieldTestValueDao.update(existTv);
        } else if (StringUtils.isNoneBlank(tftv.getId())) {
            txnFieldTestValueDao.update(tftv);
        } else {
            tftv.setId(null);
            txnFieldTestValueDao.save(tftv);
        }
    }

    public TxnFieldTestValue findByTxnFieldTestValueKey(TxnFieldTestValueKey key) {
        if (StringUtils.isNoneBlank(key.getFieldId()) && key.getOrderNo() != null && StringUtils.isNoneBlank(key.getRefDirectionId())) {
            List<TxnFieldTestValue> results = txnFieldTestValueDao.getTestValue(key.getFieldId(), key.getOrderNo(), key.getRefDirectionId());
            if (results != null && !results.isEmpty()) {
                return results.get(0);
            }
        }
        return null;
    }

    public List<TxnFieldTestValue> findTestValuesByFieldId(String fid) {
        if (StringUtils.isBlank(fid))
            return null;
        return txnFieldTestValueDao.findTestValuesByFieldId(fid);
    }

    public List<TestTxnVO> findChildrenTestTxnVOs(String pFieldId) {
        List<TestTxnVO> vos = new ArrayList<TestTxnVO>(1);
        List<TxnFieldDefinition> cFields = txnFieldService.findChildren(pFieldId);
        if (cFields != null && !cFields.isEmpty()) {
            TestTxnVO ttVo = null;
            for (TxnFieldDefinition cField : cFields) {
                ttVo = new TestTxnVO();
                ttVo.setField(cField);
                ttVo.setTestValues(findTestValuesByFieldId(cField.getId()));
                vos.add(ttVo);
            }
        }
        return vos;
    }

    public List<TxnFieldTestValue> buildTestValueList(List<TxnFieldTestValue> tVals, String fid, int mustHasSize, Integer startOrder, String refDirctionId) {
        List<TxnFieldTestValue> result = new ArrayList<TxnFieldTestValue>(mustHasSize);
        for (int i = 0; i < mustHasSize; i++) {
            int index = indexOfTestValues(tVals, new TxnFieldTestValueKey(fid, startOrder + i, refDirctionId));
            if (index != -1) {
                result.add(tVals.get(index));
            } else {
                result.add(new TxnFieldTestValue(null, fid, refDirctionId, null, startOrder + i));
            }
        }
        return result;
    }

    private int indexOfTestValues(List<TxnFieldTestValue> tVals, TxnFieldTestValueKey key) {
        if (tVals != null && !tVals.isEmpty()) {
            TxnFieldTestValue tVal = null;
            for (int i = 0; i < tVals.size(); i++) {
                tVal = tVals.get(i);
                if (key.equals(tVal.getKey())) {
                    return i;
                }
            }
        }
        return -1;
    }

    public void fillTmpValuesIfy(List<TxnFieldTestValue> tempValueList, List<TxnFieldTestValue> tftvs, boolean updateTemp, int startOrder) {
        int startOrderSame = startOrder;
        if (tftvs == null || tftvs.isEmpty()) {
            return;
        }
        for (TxnFieldTestValue tftv : tftvs) {
            fillTmepValueIfy(tempValueList, tftv, updateTemp, startOrderSame);
            startOrderSame++;
        }

    }

    public void fillTmepValueIfy(List<TxnFieldTestValue> tempValueList, TxnFieldTestValue ttvo, boolean updateTemp, int orderNo) {
        TxnFieldTestValueKey key = ttvo.getKey();
        key.setOrderNo(orderNo);
        int index = indexOfTestValues(tempValueList, key);
        if (index != -1) {
            TxnFieldTestValue inTemp = tempValueList.get(index);
            if (updateTemp) {
                inTemp.setTestValue(ttvo.getTestValue());
            } else {
                ttvo.setTestValue(inTemp.getTestValue());
            }
            if (StringUtils.isNoneBlank(ttvo.getId()))
                inTemp.setId(ttvo.getId());
            return;
        }
        if (tempValueList != null) {
            tempValueList.add(ttvo);
        }
    }

    public String buildTestFieldsXmlStr(List<TxnFieldDefinition> mainFields) {
        StringBuffer xml = new StringBuffer(1024);
        for (TxnFieldDefinition mField : mainFields) {
            String testValue = getTestValue(mField.getId(), 1);
            if (!StringUtils.isNoneBlank(testValue)) {
                testValue = mField.getDefaultV();
            }
            xml.append(buildFieldNode(mField, testValue, 1));
        }
        return xml.toString();
    }

    public String buildRepeatFieldNode(TxnFieldDefinition pField, Integer cycles, Integer degree) {
        int startOrder = getStartOrder(degree);
        StringBuffer repeatFieldNode = new StringBuffer(1024);
        List<TestTxnVO> cTestVOs = findChildrenTestTxnVOs(pField.getId());
        for (int i = 0; i < cycles; i++) {
            repeatFieldNode.append("<TxRepeat>");
            for (TestTxnVO cTestVO : cTestVOs) {
                String testValue = "";
                int index = indexOfTestValues(cTestVO.getTestValues(), new TxnFieldTestValueKey(cTestVO.getField().getId(), startOrder + i, cTestVO.getField().getDirectionId()));
                if (index != -1) {
                    testValue = cTestVO.getTestValues().get(index).getTestValue();
                }
                if (!StringUtils.isNoneBlank(testValue)) {
                    testValue = cTestVO.getField().getDefaultV();
                }
                repeatFieldNode.append(buildFieldNode(cTestVO.getField(), testValue, startOrder + i));
            }
            repeatFieldNode.append("</TxRepeat>");
        }
        return repeatFieldNode.toString();
    }

    public String buildNodeByTestVOs(List<TestTxnVO> cTestVOs, Integer degree) {
        int startOrder = getStartOrder(degree);
        StringBuffer fieldNodes = new StringBuffer(1024);
        for (TestTxnVO cTestVO : cTestVOs) {
            String testValue = "";
            int index = indexOfTestValues(cTestVO.getTestValues(), new TxnFieldTestValueKey(cTestVO.getField().getId(), startOrder, cTestVO.getField().getDirectionId()));
            if (index != -1) {
                testValue = cTestVO.getTestValues().get(index).getTestValue();
            }
            if (!StringUtils.isNoneBlank(testValue)) {
                testValue = cTestVO.getField().getDefaultV();
            }
            fieldNodes.append(buildFieldNode(cTestVO.getField(), testValue, startOrder));
        }
        return fieldNodes.toString();
    }

    public String buildFieldNode(TxnFieldDefinition field, String testValue, Integer degree) {
        if (FieldType.R.equals(field.getFieldType())) {
            int cycles = 1;
            try {
                if ("C".equals(field.getRepeatType())) {
                    cycles = Integer.parseInt(testValue);
                } else if ("9".equals(field.getRepeatType())) {
                    cycles = Integer.parseInt(field.getValue());
                }
            } catch (Exception e) {
                cycles = 1;
            }
            return buildRepeatFieldNode(field, cycles, degree);

        } else if (FieldType.S.equals(field.getFieldType())) {
            List<TxnFieldDefinition> findCase = findCaseField(field.getId());
            List<TxnFieldTestValue> testValue2 = txnFieldTestValueDao.getTestValue(field.getId(), 1);
            TxnFieldDefinition findCaseField = null;
            for (TxnFieldDefinition caseField : findCase) {
                if (!testValue2.isEmpty() && caseField.getValue().equals(testValue2.get(0).getTestValue())) {
                    findCaseField = caseField;
                    return buildFieldNode(findCaseField, null, getStartOrder(degree));
                }
            }
            return "";

        } else if (FieldType.C.equals(field.getFieldType())) {
            List<TestTxnVO> cTestVOs = findChildrenTestTxnVOs(field.getId());
            return buildNodeByTestVOs(cTestVOs, degree);

        } else if (FieldType.F.equals(field.getFieldType())) {
            return "<" + field.getCode() + ">" + StringUtils.defaultString(testValue) + "</" + field.getCode() + ">";

        }
        return "";
    }

    public List<TxnFieldDefinition> findCaseField(String field) {
        return txnFieldService.findChildren(field);
    }

    public int getStartOrder(int degree) {
        return degree * 10 + 1;
    }

    public String getTestValue(String fieldId, int orderNo) {
        List<TxnFieldTestValue> testValues = txnFieldTestValueDao.getTestValue(fieldId, orderNo);
        if (testValues != null && !testValues.isEmpty()) {
            return testValues.get(0).getTestValue();
        }
        return null;
    }

    public String getHeadTestValue(String fieldId, String refDirectionId) {
        List<TxnFieldTestValue> testValues = txnFieldTestValueDao.getHeadTestValue(fieldId, refDirectionId);
        if (testValues != null && !testValues.isEmpty()) {
            return testValues.get(0).getTestValue();
        }
        return null;
    }

    public List<TxnFieldDefinition> getHeadFields(List<TxnFieldDefinition> headFields, String direction) {
        for (TxnFieldDefinition headfield : headFields) {
            headfield.setTestValue(getHeadTestValue(headfield.getId(), direction));
        }
        return headFields;
    }

    
    public List<TxnFieldDefinition> getFMPConnectionFields(String SPName, String LoginId, String Password){
    	List<TxnFieldDefinition> outList=new ArrayList<TxnFieldDefinition>();
    	
    	for(int i=0; i<3; i++){
    		TxnFieldDefinition tmp=new TxnFieldDefinition();
    		if(i==0){
    			tmp.setId("SPName");
    			tmp.setCode("SPName");
    			tmp.setName("SP Name");
    			tmp.setLength(10);
    			tmp.setTestValue(SPName);
    			tmp.setOptional(0);
    		}else if(i==1){
    			tmp.setId("LoginId");
    			tmp.setCode("LoginId");
    			tmp.setName("Login ID");
    			tmp.setLength(10);
    			tmp.setTestValue(LoginId);
    			tmp.setOptional(1);
    		}else if(i==2){
    			tmp.setId("Password");
    			tmp.setCode("Password");
    			tmp.setName("Password");
    			tmp.setLength(100);
    			tmp.setTestValue(Password);
    			tmp.setOptional(1);
    		}
    		tmp.setFieldTypeP("F");
    		tmp.setDataTypeP("X");
    		tmp.setJustifyP("L");
    		tmp.setIncludeChinese(0);
    		
    		outList.add(tmp);
    	}
    	
    	return outList;
    }
    
}
