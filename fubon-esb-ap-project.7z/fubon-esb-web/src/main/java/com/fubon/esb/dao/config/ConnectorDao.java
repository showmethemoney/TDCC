package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.Connector;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-7
 */
@Repository
public class ConnectorDao extends JPADaoSupport<Connector> {

    public List<Connector> findConnectors(String code, Page page) {
        Query query = Query.from(Connector.class).append(" connector where 1=1 ");
        if (StringUtils.isNotBlank(code)) {
            query.append(" and connector.code = :code ");
            query.setParam("code", code);
        }
        query.orderBy("connector.code").page(page);
        return jpaAccess.findPage(query);

    }

    public List<Connector> findConnectors(String connectorCode, Page page, String connectorName) {
        Query query = Query.from(Connector.class).append(" connector where 1=1 ");
        if (StringUtils.isNotBlank(connectorCode)) {
            query.append(" and connector.code = :connectorCode ");
            query.setParam("connectorCode", connectorCode);
        }
        if (StringUtils.isNoneBlank(connectorName)) {
            query.append(" and connector.name like :connectorName ");
            query.setParam("connectorName", "%" + connectorName + "%");
        }
        query.orderBy("connector.createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public Connector findConnectorById(String id) {
        Query query = Query.from(Connector.class).append(" connector where 1=1 ");
        if (StringUtils.isNotBlank(id)) {
            query.append(" and connector.id = :connectorid ");
            query.setParam("connectorid", id);
        }
        return jpaAccess.findOne(query);
    }

    public void updateSpecifiedFields(Connector connector) {
        Query query = Query.create("update from ").append(Connector.class).append(" connector set ");
        if (StringUtils.isNotBlank(connector.getCode())) {
            query.append(" connector.code = :connectorCode , ");
            query.setParam("connectorCode", connector.getCode());
        }
        if (StringUtils.isNoneBlank(connector.getName())) {
            query.append(" connector.name = :connectorName , ");
            query.setParam("connectorName", connector.getName());
        }
        if (StringUtils.isNoneBlank(connector.getMemo())) {
            query.append(" connector.memo = :memo , ");
            query.setParam("memo", connector.getMemo());
        }
        if (StringUtils.isNoneBlank(connector.getUpdatedUser())) {
            query.append(" connector.updatedUser = :updatedUser , ");
            query.setParam("updatedUser", connector.getUpdatedUser());
        }
        if (connector.getUpdatedTime() != null) {
            query.append(" connector.updatedTime = :updatedTime ");
            query.setParam("updatedTime", connector.getUpdatedTime());
        }
        if (StringUtils.isNoneBlank(connector.getId())) {
            query.append(" where connector.id = :id ");
            query.setParam("id", connector.getId());
        }
        jpaAccess.update(query);
    }

    public List<Connector> findConnectorByCode(String code) {
        Query query = Query.from(Connector.class).append(" connector where 1=1 ");
        if (StringUtils.isNotBlank(code)) {
            query.append(" and connector.code = :connectorcode ");
            query.setParam("connectorcode", code);
        }
        return jpaAccess.find(query);
    }
    
    public List<String> searchConnectorCodes(String key) {
        Query query = Query.create("select distinct code from " + Connector.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }
}
