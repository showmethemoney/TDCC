package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.Service;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.TxnGroup;
import com.fubon.esb.domain.config.TxnRelated;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Repository
public class TxnDao extends JPADaoSupport<Txn> {

    public List<Txn> findTxnsByChannleId(List<String> channelIds) {

        Query query = Query.from(Txn.class).where("channelId in (:channelIds)").param("channelIds", channelIds);
        return jpaAccess.find(query);
    }

    public Txn getTxnById(String id) {
        return jpaAccess.get(Txn.class, id);
    }

    public List<Txn> findTxnsByServceId(String serviceId) {
        Query query = Query.from(Txn.class).where("serviceId = :serviceId and (mainId is null or mainId='0')").param("serviceId", serviceId);
        return jpaAccess.find(query);
    }

    public List<Txn> findTxnsByGroupId(String txnGroupId) {
        Query query = Query.from(Txn.class).where("groupId = :groupId and (mainId is null or mainId='0')").param("groupId", txnGroupId);
        return jpaAccess.find(query);
    }

    public List<Txn> findTxnsByConnectorId(String connectorId) {
        Query query = Query.from(Txn.class).where("connectorId = :connectorId and mainId is null").param("connectorId", connectorId);
        return jpaAccess.find(query);
    }

    public List<Txn> findLatestTxns(TxnView txnView, OrderBy orderBy, Page page) {
        Query query = Query.create("select distinct txn from " + Txn.class.getName() + " txn ");
        createQueryTable(txnView, query);
        query.append(" where not exists(select t from ").append(Txn.class).append(" t where t.mainId = txn.id)");
        createQueryString(txnView, query);
        createQueryOrder(orderBy, query);
        query.page(page);
        return jpaAccess.findPage(query);
    }

    public void createQueryTable(TxnView txnView, Query query) {
        if (StringUtils.isNotBlank(txnView.getTxnGroupCode())) {
            query.append(" , ").append(TxnGroup.class).append(" txnGroup ");
        }
        if (StringUtils.isNotBlank(txnView.getServiceCode())) {
            query.append(" , ").append(Service.class).append(" service ");
        }
        if (StringUtils.isNotBlank(txnView.getChannelCode())) {
            query.append(" , ").append(Channel.class).append(" channel, ").append(TxnChannel.class).append(" txnChannel ");
        }
        if (StringUtils.isNotBlank(txnView.getConnectorCode())) {
            query.append(" , ").append(Connector.class).append(" connector ");
        }
    }

    public void createQueryString(TxnView txnView, Query query) {
        if (StringUtils.isNotBlank(txnView.getTxnGroupCode())) {
            query.append(" and txn.groupId=txnGroup.id and txnGroup.code = :txnGroupCode ");
            query.setParam("txnGroupCode", txnView.getTxnGroupCode().trim());
        }
        if (StringUtils.isNotBlank(txnView.getServiceCode())) {
            query.append(" and txn.serviceId=service.id and service.code = :serviceCode ");
            query.setParam("serviceCode", txnView.getServiceCode().trim());
        }
        if (StringUtils.isNotBlank(txnView.getChannelCode())) {
            query.append(" and txn.id = txnChannel.txnId and txnChannel.channelId = channel.id  and channel.code = :channelCode ");
            query.setParam("channelCode", txnView.getChannelCode().trim());
        }
        if (StringUtils.isNotBlank(txnView.getConnectorCode())) {
            query.append(" and txn.connectorId=connector.id and connector.code=:connectorCode ");
            query.setParam("connectorCode", txnView.getConnectorCode().trim());
        }
        if (StringUtils.isNotBlank(txnView.getTxnCode())) {
            query.append(" and txn.code = :txnCode ");
            query.setParam("txnCode", txnView.getTxnCode().trim());
        }
        if (StringUtils.isNotBlank(txnView.getTxnName())) {
            query.append(" and txn.name like :txnName ");
            query.setParam("txnName", "%" + txnView.getTxnName() + "%");
        }
        // if (txnView.getStatus() == null) { // 不查詢為刪除的交易
        // query.append(" and txn.status != :status ");
        // query.setParam("status", ConfigActiveStatus.D);
        // }
        if (txnView.getStatus() != null) {
            query.append(" and txn.status = :status ");
            query.setParam("status", txnView.getStatus());
        }
    }

    public void createQueryOrder(OrderBy orderBy, Query query) {
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            query.orderBy("txn.code");
        } else {
            query.orderBy("txn." + orderBy.getClause());
        }
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(Txn.class).append(" txn where not exists(select t from ").append(Txn.class).append(" t where t.mainId = txn.id) ").append(" and txn.code=:code").param("code", code)
                        .append(" and txn.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();

    }

    public List<Txn> findMainTxn(String code, String id, Page page) {
        Query query = Query.from(Txn.class).append(" txn where txn.mainId is null and txn.status = :status ").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(code)) {
            query.append(" and txn.code = :code ");
            query.setParam("code", code.trim());
        }
        if (StringUtils.isNotBlank(id)) {
            String mainId = jpaAccess.get(Txn.class, id).getMainId();
            query.append(" and txn.id <> :id ");
            query.setParam("id", (mainId != null && !"0".equals(mainId)) ? mainId : id);
        }
        query.append(" and txn.status = :status ").param("status", ConfigActiveStatus.A);
        query.orderBy("txn.code").page(page);
        return jpaAccess.findPage(query);

    }

    public List<String> searchTxnCodes(String key) {
        Query query = Query.create("select distinct code from " + Txn.class.getName() + " txn");
        query.append(" where not exists(select t from ").append(Txn.class).append(" t where t.mainId = txn.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchMainTxnCodes(String code, String id) {
        Query query = Query.create("select distinct code from " + Txn.class.getName() + " txn");
        query.where(" code like :code").param("code", code + "%");
        query.append(" and mainId is null");
        if (StringUtils.isNotBlank(id)) {
            String mainId = jpaAccess.get(Txn.class, id).getMainId();
            query.append(" and txn.id <> :id ");
            query.setParam("id", (mainId != null && !"0".equals(mainId)) ? mainId : id);
        }

        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<Txn> findTxnConfigDaoList(TxnView txnView, OrderBy orderBy) {
        Query query = Query.create("select distinct txn from " + Txn.class.getName() + " txn ");
        createQueryTable(txnView, query);
        query.append(" where not exists(select t from ").append(Txn.class).append(" t where t.mainId = txn.id)");
        createQueryString(txnView, query);
        createQueryOrder(orderBy, query);
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        Txn txnDel = jpaAccess.get(Txn.class, id);
        if (StringUtils.isNotBlank(txnDel.getMainId()) && !"0".equals(txnDel.getMainId())) { // 帶有正本的副本
            jpaAccess.delete(txnDel); // 刪掉副本
            jpaAccess.update(Query.create("update ").append(Txn.class).append(" txn set txn.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", txnDel.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(Txn.class).append(" txn set txn.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id").param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(關聯業務群組、關聯Service、關聯Channel、關聯Connector、關聯交易狀態,關聯Adapter)
    public List<TxnRelated> isTxnRelatedTxn(String id) {
        Query queryRelTxn = Query.create("select txnRelated  from " + TxnRelated.class.getName() + " txnRelated");
        queryRelTxn.append(" where  txnRelated.relatedTxnId = :relatedTxnId ").param("relatedTxnId", id);
        queryRelTxn.append(" or txnRelated.txnId = :txnId").param("txnId", id);
        return jpaAccess.find(queryRelTxn);
    }

    public List<Txn> isTxnRelated(String id) {
        Query queryTxn = Query.create("select txn  from " + Txn.class.getName() + " txn");
        queryTxn.append(" where ((txn.groupId is not null and txn.groupId !='') or (txn.serviceId is not null and txn.serviceId !='') ");
        queryTxn.append(" or (txn.adapterId is not null and txn.adapterId != '') ");
        queryTxn.append(" or (txn.connectorId is not null and txn.connectorId != '')) and id = :id").param("id", id);
        return jpaAccess.find(queryTxn);
    }

    public List<TxnChannel> isTxnRelatedChannel(String id) {
        Query queryTxnChannel = Query.create("select txnChannel  from " + TxnChannel.class.getName() + " txnChannel");
        queryTxnChannel.append(" where  txnChannel.txnId = :txnId ").param("txnId", id);
        return jpaAccess.find(queryTxnChannel);
    }

    public List<Txn> isDeleteAdapter(String adapterId) {
        Query query = Query.from(Txn.class).append(" txn where 1=1 ");
        if (StringUtils.isNotBlank(adapterId)) {
            query.append(" and txn.adapterId = :adapterId ");
            query.setParam("adapterId", adapterId);
        }
        return jpaAccess.find(query);
    }

}
