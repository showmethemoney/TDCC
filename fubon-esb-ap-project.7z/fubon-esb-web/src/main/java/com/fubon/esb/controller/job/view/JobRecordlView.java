package com.fubon.esb.controller.job.view;

public class JobRecordlView {

    private String jobSystemCode;
    private String branchCode;
    private String code;
    private String name;
    private String runningTime;
    private String status;

    public String getJobSystemCode() {
        return jobSystemCode;
    }

    public void setJobSystemCode(String jobSystemCode) {
        this.jobSystemCode = jobSystemCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRunningTime() {
        return runningTime;
    }

    public void setRunningTime(String runningTime) {
        this.runningTime = runningTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
