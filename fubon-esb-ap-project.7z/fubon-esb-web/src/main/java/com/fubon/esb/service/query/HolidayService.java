package com.fubon.esb.service.query;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.dao.config.HolidayDao;
import com.fubon.esb.domain.config.Holiday;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-12
 */
@Service
public class HolidayService {

    @Inject
    private HolidayDao holidyDao;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;

    public List<List<Holiday>> findHolidysByYear(Integer year) {

        StringBuilder message = new StringBuilder();
        message.append(getMessage("log_message_holiday")).append(year);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message.toString(), LogType.SEARCH_HOLIDAY); // 添加查詢Log

        if (year == null) {
            return null;
        }

        List<Holiday> holidys = holidyDao.findHolidysByYear(year);
        if (holidys == null || holidys.isEmpty()) {
            return null;
        }

        List<List<Holiday>> result = new ArrayList<>();

        int month = 0;
        while (month < 12) {
            List<Holiday> tmp = findHolidysByMonth(holidys, month); // 按月分類
            fullfillHolidyList(tmp); // 將數據填充完整
            result.add(tmp);
            month++;
        }

        return result;
    }

    private List<Holiday> findHolidysByMonth(List<Holiday> allHolidys, int month) {
        List<Holiday> holidies = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        for (Holiday holidy : allHolidys) {
            cal.setTime(holidy.getDay());
            if (cal.get(Calendar.MONTH) == month) {
                holidies.add(holidy);
            }
        }
        allHolidys.removeAll(holidies);
        return holidies;
    }

    private void fullfillHolidyList(List<Holiday> holidies) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(holidies.get(0).getDay());
        int startDay = cal.get(Calendar.DAY_OF_WEEK);
        if (startDay > 1) {
            // 最初不是星期天
            for (int i = 0; i < (startDay - 1); i++) {
                cal.add(Calendar.DAY_OF_YEAR, -1);
                Holiday holidy = new Holiday(cal.getTime(), false);
                holidies.add(0, holidy);
            }
        }

        // 要裝滿6*7條數據
        cal.setTime(holidies.get(holidies.size() - 1).getDay());
        while (holidies.size() < 42) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
            Holiday holidy = new Holiday(cal.getTime(), false);
            holidies.add(holidy);
        }
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

}
