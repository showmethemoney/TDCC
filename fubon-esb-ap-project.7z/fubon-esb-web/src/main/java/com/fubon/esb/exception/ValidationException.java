package com.fubon.esb.exception;

import java.util.List;

import com.comwave.core.error.IgnoredException;

/**
 * @author james
 * @createdDate 2014-11-6
 */
@IgnoredException
public class ValidationException extends RuntimeException {

    private final List<String> errorMessages;

    public ValidationException(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

}
