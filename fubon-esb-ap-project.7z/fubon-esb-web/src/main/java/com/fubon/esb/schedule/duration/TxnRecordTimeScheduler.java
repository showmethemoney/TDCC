package com.fubon.esb.schedule.duration;

import java.util.Calendar;

import javax.sql.DataSource;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.scheduling.quartz.QuartzJobBean;


/**
 * @author Ethan Lee
 */
public class TxnRecordTimeScheduler extends QuartzJobBean
{
	protected static final Logger logger = LoggerFactory.getLogger( TxnRecordTimeScheduler.class );
	public static final String NAMED_DATASOURCE = "datasource";
	private static final String NAMED_DELETE_TXN_RECORD_TIME = "DELETE FROM txn_record_time WHERE created_time <= :deleteTime";

	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		NamedParameterJdbcTemplate jdbcTemplate = null;

		try {
			DataSource dataSource = (DataSource) context.getMergedJobDataMap().get( NAMED_DATASOURCE );

			jdbcTemplate = new NamedParameterJdbcTemplate( dataSource );

			Calendar current = Calendar.getInstance();
			current.add( Calendar.MINUTE, -5 );

			SqlParameterSource namedParameters = new MapSqlParameterSource( "deleteTime", current.getTime() );

			jdbcTemplate.update( NAMED_DELETE_TXN_RECORD_TIME, namedParameters );
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
