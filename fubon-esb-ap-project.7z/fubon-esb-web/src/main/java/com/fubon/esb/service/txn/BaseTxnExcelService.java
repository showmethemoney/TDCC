package com.fubon.esb.service.txn;

import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.fubon.esb.domain.txn.DataType;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;

/**
 * @author nice
 * @createdDate 2015-1-7
 */
public class BaseTxnExcelService extends BaseTxnService {
    public static final String TAG_TX_FIELD = "Tx Field";
    public static final String TAG_TX_REPEAT = "Tx Repeat";
    public static final String TAG_TX_REPEAT_END = "Tx Repeat-End";
    public static final String TAG_TX_SWITCH = "Tx Switch";
    public static final String TAG_TX_SWITCH_END = "Tx Switch-End";
    public static final String TAG_TX_CASE = "Tx Case";
    public static final String TAG_TX_CASE_END = "Tx Case-End";

    public String getStringCellValue(Cell cell) {
        if (cell == null)
            return null;
        int cellType = cell.getCellType();
        if (cellType == Cell.CELL_TYPE_NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        } else {
            return cell.getStringCellValue();
        }
    }

    public Integer getIntegerCellValue(Cell cell) {
        if (cell == null)
            return null;
        int cellType = cell.getCellType();
        if (cellType == Cell.CELL_TYPE_NUMERIC) {
            return (int) cell.getNumericCellValue();
        } else {
            if (StringUtils.isBlank(cell.getStringCellValue())) {
                return null;
            }
            try {
                return Integer.valueOf(cell.getStringCellValue());
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }

    public Cell setAsTextAndIngoreNull(Cell cell, Object value) {
        if (value != null) {
            String text = String.valueOf(value);
            cell.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell.setCellValue(text);
        }
        return cell;
    }

    public String validateTxnField(Sheet sheet, TxnFieldDefinition field) {
        String erroMsg = "";
        if (field.getFieldType() == null) {
            erroMsg += "Field Type無效,";
            return erroMsg;
        }
        if (FieldType.F.equals(field.getFieldType())) {
            if (StringUtils.isBlank(field.getCode())) {
                erroMsg += "Field ID不能為空,";
            }
            // else if (field.getCode().length() > 30) {
            // erroMsg += "Field ID長度不能超過30位,";
            // }
            if (StringUtils.isBlank(field.getName())) {
                erroMsg += "欄位名稱不能為空,";
            }
            // else if (field.getName().length() > 30) {
            // erroMsg += "欄位名稱長度不能超過30位,";
            // }
            if (field.getLength() == null) {
                erroMsg += "欄位長度不能為空,";
            }
            // else if (field.getLength() > 30) {
            // erroMsg += "欄位長度不能超過30位,";
            // }
            if (field.getDataType() == null) {
                erroMsg += "欄位資料型態無效,";
            }
            if (field.getJustify() == null) {
                erroMsg += "對齊方式無效,";
            }
            if (field.getOptional() == null) {
                erroMsg += "是否必填無效,";
            }
            if (field.getIncludeChinese() == null) {
                erroMsg += "是否中文無效,";
            }
            // if (field.getScale() != null && field.getScale() > 5) {
            // erroMsg += "欄位小數位數不能超過5位,";
            // }
            // erroMsg += validateTxnFieldOptional(field);
        } else {
            if (StringUtils.isBlank(field.getValue()))
                erroMsg += "Field ID不能為空,";
            // if (FieldType.R.equals(field.getFieldType()) || FieldType.S.equals(field.getFieldType()))
            // erroMsg += validateReferInExcel(sheet, field.getValue());
        }
        return erroMsg;
    }

    public String validateTxnFieldOptional(TxnFieldDefinition field) {
        DataType dataType = field.getDataType();
        Integer length = field.getLength();
        if (dataType == null || length == null) {
            return "";
        }
        StringBuffer erroMsg = new StringBuffer(1024);
        String padChar = field.getPadChar();
        String defaultV = field.getDefaultV();
        int padCharL = 1;
        int defaultVL = length;
        if (DataType.H.equals(dataType)) {
            padCharL = 4;
            defaultVL = length * 4;
        }
        if (StringUtils.isNoneBlank(defaultV) && DataType.H.equals(dataType) && !defaultV.matches("^(0x)?[0-9A-F]+$")) {
            erroMsg.append("欄位預設值必須為Hex Code,");
        } else if (StringUtils.isNoneBlank(defaultV) && DataType.N.equals(dataType) && !defaultV.matches("\\d+")) {
            erroMsg.append("欄位預設值必須為整數,");
        }
        if (StringUtils.isNoneBlank(padChar) && padChar.length() > padCharL) {
            erroMsg.append("欄位補充字元不能超過").append(padCharL).append("位,");
        }
        if (StringUtils.isNoneBlank(defaultV) && defaultV.length() > defaultVL) {
            erroMsg.append("欄位預設值不能超過").append(defaultVL).append("位,");
        }
        return erroMsg.toString();
    }

    public String validateReferInExcel(Sheet sheet, String referCode) {
        TxnDirection headerDir = txnDirectionService.getHeaderDirByName(getStringCellValue(sheet.getRow(0).getCell(5)));
        for (Iterator<Row> rowIterator = sheet.rowIterator(); rowIterator.hasNext();) {
            Row row = rowIterator.next();
            if (referCode.equals(getStringCellValue(row.getCell(1)))) {
                return "";
            }
        }
        if (headerDir != null && txnFieldService.findByTxnCode(referCode, headerDir.getId()) != null) {
            return "";
        }
        return "未找到對應Field Id的欄位,";
    }
}
