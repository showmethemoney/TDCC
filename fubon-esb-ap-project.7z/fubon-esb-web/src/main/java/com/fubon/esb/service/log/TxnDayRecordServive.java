package com.fubon.esb.service.log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.query.view.TxnDayRecordsVO;
import com.fubon.esb.dao.log.TxnDayRecordDao;
import com.fubon.esb.dao.log.TxnRecordDurationDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.log.TxnRecord;
import com.fubon.esb.domain.log.TxnRecordMsg;

/**
 * @author Qigers
 * @createdDate 2014-11-12
 */
@Service(value = "txnDayRecordServive")
public class TxnDayRecordServive {

    @Inject
    private TxnDayRecordDao txnDayRecordDao;
    
    @Inject
    private TxnRecordDurationDao txnRecordDurationDao;
    
    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;
    
    public Map<String, String> findDurationByTrackingIds(List<TxnRecord> txnRecords) {   	
    	return txnRecordDurationDao.findDurationByTrackingIds( txnRecords );
    }
    
    public Object findTxnDayRecordPageList(TxnDayRecordsVO vo, OrderBy orderBy, Page page, Boolean isSearch) {
        String time = vo.getStartHour() + ":" + vo.getStartMinute() + " ~ " + vo.getEndHour() + ":" + vo.getEndMinute();
        Date today = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        time = sdf.format(today) + " " + time;
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.dayrecord.search") + "   ");
        messageStr.append("  " + messages.getMessage("log.dayrecord.time") + time);
        if (isSearch) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createShowMessage(vo, messageStr), LogType.SEARCH_TXN_RECORD);
        }
        return txnDayRecordDao.findTxnDayRecordDaoList(vo, orderBy, page);
    }

    public TxnRecord findTxnRecordDetail(TxnDayRecordsVO vo, Page page, String recordId) {
        return txnDayRecordDao.findTxnRecordDetailDao(vo, page, recordId);
    }

    public TxnRecord findTxnRecordDetail(String recordId) {
        return txnDayRecordDao.findTxnRecordExcelDetailDao(recordId);
    }

    public Object findTxnRecordMsgDetailPageList(TxnDayRecordsVO vo, Page page, String trackingId) {
        return txnDayRecordDao.findTxnRecordMsgDetailDaoList(vo, page, trackingId);
    }

    public Object findTxnRecordMsgDetailList(String trackingId) {
        return txnDayRecordDao.findTxnRecordMsgDetailExcelDaoList(trackingId);
    }

    public TxnRecordMsg findTxnRecordMsg(String messageId) {
        return txnDayRecordDao.findTxnRecordMsg(messageId);
    }

    public Object findRecords(TxnDayRecordsVO vo) {
        String time = vo.getStartHour() + ":" + vo.getStartMinute() + " ~ " + vo.getEndHour() + ":" + vo.getEndMinute();
        Date today = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        time = sdf.format(today) + " " + time;
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.dayrecord.export.excel") + "   ");
        messageStr.append("  " + messages.getMessage("log.dayrecord.time") + time);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createShowMessage(vo, messageStr), LogType.SEARCH_TXN_RECORD);
        vo.setSequence(vo.getSequence().replaceAll("^(0+)", ""));
        return txnDayRecordDao.findTxnRecordDaoList(vo);
    }

    String createShowMessage(TxnDayRecordsVO dayRecordVO, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(dayRecordVO.getTxnCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnCode") + dayRecordVO.getTxnCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getChannelCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnChannelCode") + dayRecordVO.getChannelCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getSequence())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnSequence") + dayRecordVO.getSequence());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getReturnCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnReturnCode") + dayRecordVO.getReturnCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getHostCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnHostCode") + dayRecordVO.getHostCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getGroupCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnGroupCode") + dayRecordVO.getGroupCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getServiceCode())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnServiceCode") + dayRecordVO.getServiceCode());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getDuration())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txn.timeout") + dayRecordVO.getDuration());
        }
        if (StringUtils.isNotBlank(dayRecordVO.getMessage())) {
            messageStr.append("  " + messages.getMessage("log.dayrecord.txnMsg.message") + dayRecordVO.getMessage());
        }
        return messageStr.toString();
    }

    public List<String> searchTxnCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchTxnCodes(key);
    }

    public List<String> searchChannelCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchChannelCodes(key);
    }

    public List<String> searchHostCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchHostCodes(key);
    }

    public List<String> searchGroupCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchGroupCodes(key);
    }

    public List<String> searchUUIDs(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchUUIDs(key);
    }

    public List<String> searchServiceCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return txnDayRecordDao.searchServiceCodes(key);
    }
}
