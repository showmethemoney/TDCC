package com.fubon.esb.dao.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.system.view.UserApprovalVO;
import com.fubon.esb.domain.system.RoleUser;
import com.fubon.esb.domain.system.UserConfig;

/**
 * @author Qigers
 * @createdDate 2015-01-12
 */
@Repository
public class UserConfigDao extends JPADaoSupport<UserConfig> {

    public List<UserConfig> findUsersForApprove(UserApprovalVO vo, Date startDate, Date endDate) {
        Query query = Query.from(UserConfig.class).append(" where 1=1 ");
        if (StringUtils.isNotBlank(vo.getStartDateStr())) {
            query.append(" and updatedTime >= :startDate");
            query.setParam("startDate", startDate);
        }
        if (StringUtils.isNotBlank(vo.getEndDateStr())) {
            query.append(" and updatedTime <= :endDate");
            query.setParam("endDate", endDate);
        }
        if (StringUtils.isNotBlank(vo.getUserId())) {
            query.append(" and userId like :userId ");
            query.setParam("userId", "%" + vo.getUserId() + "%");
        }
        if (StringUtils.isNotBlank(vo.getUpdatedUser())) {
            query.append(" and updatedUser like :updatedUser ");
            query.setParam("updatedUser", "%" + vo.getUpdatedUser() + "%");
        }
        query.append(" and mainId !=null ");
        List<UserConfig> userConfigs = jpaAccess.find(query);
        if (userConfigs == null) {
            return new ArrayList<UserConfig>();
        }
        return userConfigs;
    }

    public List<UserConfig> findLatestUserConfigs(String userId, String username, String subject, Page page) {
        Query query = Query.from(UserConfig.class).append(" where 1=1 ");
        if (StringUtils.isNotBlank(username)) {
            query.append(" and username like :username ");
            query.setParam("username", "%" + username + "%");
        }
        if (StringUtils.isNotBlank(subject)) {
            query.append(" and subject like :subject ");
            query.setParam("subject", "%" + subject + "%");
        }
        if (StringUtils.isNotBlank(userId)) {
            query.append(" and userId = :userId ");
            query.setParam("userId", userId);
        }
        //query.append(" and mainId !=null and mainId='0'");
        query.append(" and (mainId =null or mainId='0')");
        query.page(page).orderBy("id");
        List<UserConfig> userConfigs = jpaAccess.findPage(query);
        if (userConfigs == null) {
            return new ArrayList<UserConfig>();
        }
        return userConfigs;
    }

    public List<UserConfig> findUserConfigs(String userId, String username, String subject) {
        Query query = Query.from(UserConfig.class).append(" where 1=1 ");
        if (StringUtils.isNotBlank(userId)) {
            query.append(" and userId = :userId ");
            query.setParam("userId", userId);
        }
        if (StringUtils.isNotBlank(username)) {
            query.append(" and username like :username ");
            query.setParam("username", "%" + username + "%");
        }
        if (StringUtils.isNotBlank(subject)) {
            query.append(" and subject like :subject ");
            query.setParam("subject", "%" + subject + "%");
        }
        //query.append(" and mainId !=null and mainId='0'");
        query.orderBy("id");
        List<UserConfig> userConfigs = jpaAccess.findPage(query);
        if (userConfigs == null) {
            return new ArrayList<UserConfig>();
        }
        return userConfigs;
    }

    public List<String> searchUserIds(String key) {
        Query query = Query.create("select distinct userId from " + UserConfig.class.getName());
        query.where(" userId like :userId").param("userId", key + "%");
        query.orderBy("userId");
        return jpaAccess.find(query);
    }

    public UserConfig getById(String id) {
        return jpaAccess.get(UserConfig.class, id);
    }

    public UserConfig getByMainId(String mainId) {
        Query query = Query.from(UserConfig.class).where("mainId = :mainId").param("mainId", mainId);
        UserConfig userConfig = (UserConfig) jpaAccess.find(query).get(0);
        if (userConfig == null) {
            userConfig = new UserConfig();
        }
        return userConfig;
    }

    public boolean idDuplicate(String id) {
        Query query = Query.from(UserConfig.class).where("id = :id").param("id", id);
        return !jpaAccess.find(query).isEmpty();
    }

    public boolean mainIdDuplicate(String mainId) {
        Query query = Query.from(UserConfig.class).where("mainId = :mainId").param("mainId", mainId);
        return jpaAccess.find(query).isEmpty();
    }

    public boolean userIdDuplicate(String userId) {
        Query query = Query.from(UserConfig.class).where("userId = :userId").param("userId", userId);
        return !jpaAccess.find(query).isEmpty();
    }

    public void removeUserConfig(String id) {
        Query query = Query.create("delete from " + UserConfig.class.getName() + " where id = :id").param("id", id);
        jpaAccess.update(query);
    }

    public void addUserConfig(UserConfig userConfig) {
        jpaAccess.save(userConfig);
    }

    public void updateUserConfig(UserConfig userConfig) {
        jpaAccess.update(userConfig);
    }

    public List<UserConfig> findUserList(String userId, Page page) {
        StringBuilder jql = new StringBuilder();
        jql.append("from ").append(UserConfig.class.getName()).append(" where mainId is null ");
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(userId)) {
            jql.append(" and userId like :userId ");
            params.put("userId", "%" + userId + "%");
        }

        Query query = Query.create(jql.toString()).orderBy("userId").page(page);
        query.putParams(params);

        return jpaAccess.findPage(query);
    }

    public List<UserConfig> findUserListByRole(String roleId) {
        Query query = Query.create("from " + UserConfig.class.getName() + " b where exists ( from " + RoleUser.class.getName() + " r where r.roleId = :roleId and r.userId = b.id )");
        query.param("roleId", roleId);
        query.orderBy("b.userId");
        return jpaAccess.find(query);
    }

}
