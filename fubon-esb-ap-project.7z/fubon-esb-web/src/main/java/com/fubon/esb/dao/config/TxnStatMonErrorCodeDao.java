package com.fubon.esb.dao.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.Query;
import com.fubon.esb.controller.query.view.TxnStatSearchVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.config.TxnStatMonErrorCode;

/**
 * @author Leckie Zhang
 * @createdDate 2015-1-15
 */
@Repository
public class TxnStatMonErrorCodeDao extends LogDBJPADaoSupport<TxnStatMonErrorCode> {

    @Inject
    private TxnStatMonDao txnStatMonDao;

    public List<TxnStatMonErrorCode> findTxnStats(TxnStatSearchVO vo) {

        Map<String, Object> params = new HashMap<String, Object>();

        StringBuilder jql = new StringBuilder(getJql(vo, params));
        if (vo.getOrder() != null) {
            jql.append(" order by ").append(vo.getOrder().getClause());
        } else {
            jql.append(" order by day");
        }
        Query query = Query.create(jql.toString());
        query.putParams(params);
        if (vo.getPage() != null) {
            query.page(vo.getPage());
        }

        return jpaAccess.findPage(query);
    }

    private String getJql(TxnStatSearchVO vo, Map<String, Object> params) {
        StringBuilder jql = new StringBuilder();
        jql.append("  from ").append(TxnStatMonErrorCode.class.getName()).append(" where 1=1 ").append(" and month between :start and :end ");
        params.put("start", txnStatMonDao.formatDate(txnStatMonDao.getDateByYearMonth(vo.getStartYear(), vo.getStartMonth(), true)));
        params.put("end", txnStatMonDao.formatDate(txnStatMonDao.getDateByYearMonth(vo.getEndYear(), vo.getEndMonth(), false)));
        
        if (StringUtils.isNotBlank(vo.getValue1())) {
            jql.append(" and value like :value1 ");
            params.put("value1", "%" + vo.getValue1() + "%");
        }
        if (StringUtils.isNotBlank(vo.getValue2e())) {
            jql.append(" and value2 like :value2 ");
            params.put("value2", "%" + vo.getValue2e() + "%");
        }
        if (StringUtils.isNotBlank(vo.getValue3())) {
            jql.append(" and value3 like :value3 ");
            params.put("value3", "%" + vo.getValue3() + "%");
        }

        jql.append(" and type = :type ");
        params.put("type", vo.getType());

        return jql.toString();
    }

}
