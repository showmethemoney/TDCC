package com.fubon.esb.controller.query.view;

import java.util.Date;

import com.comwave.core.database.OrderBy;

/**
 * @author Qigers
 * @createdDate 2014-11-12
 */
public class TxnDayRecordsVO {

    private String startDate;
    private String startHour;
    private String startMinute;
    private String endHour;
    private String endMinute;
    private String txnCode;
    private String channelCode;
    private String sequence;

    private String returnCode;
    private String hostCode;
    private String groupCode;
    private String serviceCode;

    private String duration;
    private String message;

    private String trackingId;

    private String workstationCode;

    private String teller;

    private String sysDate;

    private String sysTime;

    private Date createTime;

    private Integer tempCurrentPage;

    private String uuid;
    
    private OrderBy sonOrderBy;
    
    private boolean calDuration = false;
    
    public boolean isCalDuration() {
		return calDuration;
	}

	public void setCalDuration(boolean calDuration) {
		this.calDuration = calDuration;
	}

	public String getStartHour() {
        return startHour;
    }

    public void setStartHour(String startHour) {
        this.startHour = startHour;
    }

    public String getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(String startMinute) {
        this.startMinute = startMinute;
    }

    public String getEndHour() {
        return endHour;
    }

    public void setEndHour(String endHour) {
        this.endHour = endHour;
    }

    public String getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(String endMinute) {
        this.endMinute = endMinute;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getHostCode() {
        return hostCode;
    }

    public void setHostCode(String hostCode) {
        this.hostCode = hostCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getWorkstationCode() {
        return workstationCode;
    }

    public void setWorkstationCode(String workstationCode) {
        this.workstationCode = workstationCode;
    }

    public String getTeller() {
        return teller;
    }

    public void setTeller(String teller) {
        this.teller = teller;
    }

    public String getSysDate() {
        return sysDate;
    }

    public void setSysDate(String sysDate) {
        this.sysDate = sysDate;
    }

    public String getSysTime() {
        return sysTime;
    }

    public void setSysTime(String sysTime) {
        this.sysTime = sysTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getTempCurrentPage() {
        return tempCurrentPage;
    }

    public void setTempCurrentPage(Integer tempCurrentPage) {
        this.tempCurrentPage = tempCurrentPage;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }


    public OrderBy getSonOrderBy() {
        return sonOrderBy;
    }

    public void setSonOrderBy(OrderBy sonOrderBy) {
        this.sonOrderBy = sonOrderBy;
    }
}
