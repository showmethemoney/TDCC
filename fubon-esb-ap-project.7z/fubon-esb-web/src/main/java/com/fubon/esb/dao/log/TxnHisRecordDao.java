package com.fubon.esb.dao.log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.query.view.TxnHisRecordsVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.log.TxnHisRecord;
import com.fubon.esb.domain.log.TxnHisRecordMsg;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Qigers
 * @createdDate 2014-11-14
 */
@Repository
public class TxnHisRecordDao extends LogDBJPADaoSupport<TxnHisRecordMsg> {

    @Inject
    private TimeZoneService timeZoneService;

    private Date getStartTime(TxnHisRecordsVO vo) {
        String today = vo.getStartDate();
        Date startTime = getFullTime(today, "00", "00", "00", "000");
        if (StringUtils.isNotBlank(vo.getStartHour()) || StringUtils.isNotBlank(vo.getStartMinute())) {
            startTime = getFullTime(today, vo.getStartHour(), vo.getStartMinute(), "00", "000");
        }
        return startTime;
    }

    private Date getFullTime(String date, String hour, String minute, String second, String millisecond) {

        if (StringUtils.isNotBlank(date) && StringUtils.isNotBlank(hour) && StringUtils.isNotBlank(minute)) {
            try {
                return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").parse(date + " " + hour + ":" + minute + ":" + second + "." + millisecond);
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
                return null;
            }
        }
        return null;
    }

    private Date getEndTime(TxnHisRecordsVO vo) {
        String today = vo.getStartDate();
        Date endTime = getFullTime(today, "23", "59", "59", "999");
        if (StringUtils.isNotBlank(vo.getEndHour()) || StringUtils.isNotBlank(vo.getEndMinute())) {
            endTime = getFullTime(today, vo.getEndHour(), vo.getEndMinute(), "59", "999");
        }
        return endTime;
    }

    private StringBuilder getSqlCondition(TxnHisRecordsVO vo, StringBuilder jql, Map<String, Object> params) {
        Date startTime = getStartTime(vo);
        Date endTime = getEndTime(vo);
        if (startTime != null) {
            jql.append(" and t.startTime >= :startTime ");
            params.put("startTime", timeZoneService.getTZDateByService(startTime));
        }
        if (StringUtils.isNotBlank(vo.getUuid())) {
            jql.append(" and t.uuid = :uuid ");
            params.put("uuid", vo.getUuid());
        }
        if (endTime != null) {
            jql.append(" and t.startTime <= :endTime ");
            params.put("endTime", timeZoneService.getTZDateByService(endTime));
        }
        if (StringUtils.isNotBlank(vo.getTxnCode())) {
            jql.append(" and t.txnCode = :txnCode ");
            params.put("txnCode", vo.getTxnCode());
        }
        if (StringUtils.isNotBlank(vo.getChannelCode())) {
            jql.append(" and t.channelCode = :channelCode ");
            params.put("channelCode", vo.getChannelCode());
        }
        if (StringUtils.isNotBlank(vo.getSequence())) {
            jql.append(" and t.sequence = :sequence ");
            params.put("sequence", vo.getSequence().replaceAll("^(0+)", ""));
        }
        if (StringUtils.isNotBlank(vo.getReturnCode())) {
            jql.append(" and t.returnCode like :returnCode ");
            params.put("returnCode", "%" + vo.getReturnCode() + "%");
        }
        // if (StringUtils.isNotBlank(vo.getGroupCode())) {
        // jql.append(" and t.groupCode = :groupCode ");
        // params.put("groupCode", vo.getGroupCode());
        // }
        // if (StringUtils.isNotBlank(vo.getServiceCode())) {
        // jql.append(" and t.serviceCode = :serviceCode ");
        // params.put("serviceCode", vo.getServiceCode());
        // }
        // if (StringUtils.isNotBlank(vo.getDuration())) {
        // jql.append(" and t.duration >= :duration ");
        // params.put("duration", vo.getDuration());
        // }
        // if (StringUtils.isNotBlank(vo.getMessage())) {
        // jql.append(" and t.trackingId in ( select tm.trackingId from " + TxnHisRecordMsg.class.getName() + " tm where 1=1 and tm.message like :message )");
        // params.put("message", "%" + vo.getMessage() + "%");
        // }
        return jql;
    }

    public Object findTxnHisRecordDaoList(TxnHisRecordsVO vo, OrderBy orderBy, Page page) {
        StringBuilder jql = new StringBuilder();
        jql.append("select t from " + TxnHisRecord.class.getName() + " t where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        jql = getSqlCondition(vo, jql, params);

        Query query = Query.create(jql.toString());
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            query.orderBy(" startTime desc ");
        } else {
            query.orderBy(orderBy.getClause());
        }
        query.page(page).putParams(params);
        List<TxnHisRecord> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<TxnHisRecord>();
        }
        return txnRecords;
    }

    public TxnHisRecord findTxnHisRecordDetailDao(String id) {
        StringBuilder jql = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(id)) {
            jql.append(" from ").append(TxnHisRecord.class.getName()).append(" where 1=1 " + " and id=:id ");
            params.put("id", id);
        }
        Query query = Query.create(jql.toString());
        query.putParams(params);
        TxnHisRecord txnHisRecord = (TxnHisRecord) jpaAccess.find(query).get(0);
        if (txnHisRecord == null) {
            return new TxnHisRecord();
        }
        return txnHisRecord;
    }

    public Object findTxnRecordDetailDaoList(TxnHisRecordsVO vo, Page page, String trackingId) {
        StringBuilder jqls = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(trackingId)) {
            jqls.append(" select tm from " + TxnHisRecordMsg.class.getName() + " tm ").append(" , ").append(TxnHisRecord.class.getName()).append(" t ")
                    .append(" where 1=1 " + " and t.trackingId=tm.trackingId and tm.trackingId=:trackingId ");
            params.put("trackingId", trackingId);
        }
        if (vo.getSonOrderBy() != null && StringUtils.isNotBlank(vo.getSonOrderBy().getField())) {
            jqls.append(" order by ").append(vo.getSonOrderBy().getClause());
        } else {
            jqls.append(" order by tm.createTime ");
        }
        Query query = Query.create(jqls.toString());
        query.page(page).putParams(params);
        List<TxnHisRecordsVO> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    public Object findTxnRecordDetailExcelDaoList(String trackingId) {
        StringBuilder jqlString = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(trackingId)) {
            jqlString.append(" select tm from " + TxnHisRecordMsg.class.getName() + " tm ").append(" , ").append(TxnHisRecord.class.getName()).append(" t ")
                    .append(" where 1=1 " + " and t.trackingId=tm.trackingId and tm.trackingId=:trackingId ");
            params.put("trackingId", trackingId);
        }
        Query query = Query.create(jqlString.toString());
        query.orderBy(" tm.createTime ");
        query.putParams(params);
        List<TxnHisRecordsVO> txnRecords = jpaAccess.findPage(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    public Object findTxnHisRecordDaoList(TxnHisRecordsVO vo) {
        StringBuilder jql = new StringBuilder();
        jql.append("select t from " + TxnHisRecord.class.getName() + " t where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        jql = getSqlCondition(vo, jql, params);
        Query query = Query.create(jql.toString());
        query.orderBy("  startTime desc ");
        query.putParams(params);
        List<TxnHisRecord> txnRecords = jpaAccess.find(query);
        if (txnRecords == null) {
            return new ArrayList<>();
        }
        return txnRecords;
    }

    public TxnHisRecordMsg findTxnHisRecordMsg(String id) {
        StringBuilder jql = new StringBuilder();
        Map<String, Object> params = new HashMap<String, Object>();
        jql.append(" from " + TxnHisRecordMsg.class.getName());
        jql.append(" where 1=1 ");
        jql.append(" and id= :id");
        params.put("id", id);
        Query query = Query.create(jql.toString());
        query.putParams(params);
        TxnHisRecordMsg txnHisRecordMsg = (TxnHisRecordMsg) jpaAccess.find(query).get(0);
        if (txnHisRecordMsg == null) {
            return new TxnHisRecordMsg();
        }
        return txnHisRecordMsg;
    }

    public List<String> searchServiceCodes(String key) {
        Query query = Query.create("select distinct serviceCode from " + TxnHisRecord.class.getName());
        query.where(" serviceCode like :serviceCode").param("serviceCode", key + "%");
        query.orderBy("serviceCode");
        return jpaAccess.find(query);
    }

    public List<String> searchGroupCodes(String key) {
        Query query = Query.create("select distinct groupCode from " + TxnHisRecord.class.getName());
        query.where(" groupCode like :groupCode").param("groupCode", key + "%");
        query.orderBy("groupCode");
        return jpaAccess.find(query);
    }

    public List<String> searchHostCodes(String key) {
        Query query = Query.create("select distinct hostCode from " + TxnHisRecord.class.getName());
        query.where(" hostCode like :hostCode").param("hostCode", key + "%");
        query.orderBy("hostCode");
        return jpaAccess.find(query);
    }

    public List<String> searchChannelCodes(String key) {
        Query query = Query.create("select distinct channelCode from " + TxnHisRecord.class.getName());
        query.where(" channelCode like :channelCode").param("channelCode", key + "%");
        query.orderBy("channelCode");
        return jpaAccess.find(query);
    }

    public List<String> searchTxnCodes(String key) {
        Query query = Query.create("select distinct txnCode from " + TxnHisRecord.class.getName());
        query.where(" txnCode like :txnCode").param("txnCode", key + "%");
        query.orderBy("txnCode");
        return jpaAccess.find(query);
    }

    public List<String> searchUUIDs(String key) {
        Query query = Query.create("select distinct uuid from " + TxnHisRecord.class.getName());
        query.where(" uuid like :uuid").param("uuid", key + "%");
        query.orderBy("uuid");
        return jpaAccess.find(query);
    }
}
