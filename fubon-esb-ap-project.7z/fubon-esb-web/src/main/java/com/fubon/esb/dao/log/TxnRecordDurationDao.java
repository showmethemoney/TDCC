package com.fubon.esb.dao.log;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Query;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.log.TxnRecord;
import com.fubon.esb.domain.log.TxnRecordDuration;
import com.fubon.esb.domain.log.TxnRecordTime;


/**
 * @author Ethan Lee
 */
@Repository
public class TxnRecordDurationDao extends LogDBJPADaoSupport<TxnRecordDuration>
{

	@Transactional(propagation = Propagation.REQUIRED)
	public int deleteTxnRecordTimeByTime(Date dateTime) {
		return jpaAccess.update( Query.create( "delete from " + TxnRecordTime.class.getName() + " where createTime <= :dateTime" ).param( "dateTime", dateTime ) );
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public int deleteTxnRecordDurationByTime(Date dateTime) {
		return jpaAccess.update( Query.create( "delete from " + TxnRecordDuration.class.getName() + " where createTime <= :dateTime" ).param( "dateTime", dateTime ) );
	}

	@Transactional(propagation = Propagation.NEVER)
	public Map<String, String> findDurationByTrackingIds(List<TxnRecord> txnRecords) {
		Map<String, String> result = new HashMap<String, String>();
		
		Query query = Query.create( "SELECT o FROM " + TxnRecordDuration.class.getName() + " o WHERE o.trackingId = :trackingId" );
		String trackingId = null;
		TxnRecordDuration entity = null;
		
		for (TxnRecord txnRecord : txnRecords) {
			trackingId = txnRecord.getTrackingId();
			query.param( "trackingId", trackingId );
			
			entity = (TxnRecordDuration) jpaAccess.findOne( query );
			
			if (null != entity) {
				result.put( trackingId, entity.getDuration() );
			}
		}

		return result;
	}
}
