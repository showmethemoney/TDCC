package com.fubon.esb.controller.txn.view;

import com.fubon.esb.domain.txn.TxnFieldTestValue;

public class TestTxnArray {

    private TxnFieldTestValue[] testValues;

    public TxnFieldTestValue[] getTestValues() {
        return testValues;
    }

    public void setTestValues(TxnFieldTestValue[] testValues) {
        this.testValues = testValues;
    }

}
