package com.fubon.esb.controller.config.view;

import com.fubon.esb.domain.system.Adapter;

public class ArrayAdapter {

    private Adapter[] adapterArray;

    public Adapter[] getAdapterArray() {
        return adapterArray;
    }

    public void setAdapterArray(Adapter[] adapterArray) {
        this.adapterArray = adapterArray;
    }
}
