package com.fubon.esb.schedule.ems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.antlr.stringtemplate.StringTemplate;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.comwave.core.mail.Mail;
import com.comwave.core.mail.MailSender;
import com.fubon.esb.ScheduleConfig;
import com.fubon.esb.domain.config.MailGroup;
import com.fubon.esb.domain.config.MailItem;
import com.fubon.esb.service.config.MailGroupService;
import com.tibco.tibjms.admin.QueueInfo;


/**
 * @author Ethan Lee
 */

public class EMSMonitorScheduler extends QuartzJobBean
{
	protected static final Logger logger = LoggerFactory.getLogger( EMSMonitorScheduler.class );
	public static final String SEPERATOR = ",";
	public static final String NAMED_EMS_URLS = "ems.url";
	public static final String NAMED_EMS_USERNAME = "ems.username";
	public static final String NAMED_EMS_PASSWORD = "ems.password";
	public static final String NAMED_MAX_PENDING = "ems.max.pending";
	public static final String NAMED_MAIL_SUBJECT = "EMS Queue Monitor Alarm";
	public static final String NAMED_SERVICE = "mailGroupService";
	
	class EMSMonitorQueue
	{
		private String queueName = null;
		private long pendingMessageCount = 0l;

		public EMSMonitorQueue() {}

		public EMSMonitorQueue(String queueName, long pendingMessageCount) {
			this.queueName = queueName;
			this.pendingMessageCount = pendingMessageCount;
		}

		public String getQueueName() {
			return queueName;
		}

		public long getPendingMessageCount() {
			return pendingMessageCount;
		}

		public void setQueueName(String queueName) {
			this.queueName = queueName;
		}

		public void setPendingMessageCount(long pendingMessageCount) {
			this.pendingMessageCount = pendingMessageCount;
		}

	}

	@Override
	protected void executeInternal(JobExecutionContext executionContext) throws JobExecutionException {

		try {
			JobDataMap jobData = executionContext.getJobDetail().getJobDataMap();
			String urls = jobData.getString( NAMED_EMS_URLS );
			String username = jobData.getString( NAMED_EMS_USERNAME );
			String password = jobData.getString( NAMED_EMS_PASSWORD );
			long maxPending = jobData.getLong( NAMED_MAX_PENDING );

			EMSAdminConsole console = null;
			Map<String, List<EMSMonitorQueue>> result = new HashMap<String, List<EMSMonitorQueue>>();

			for (String url : urls.split( SEPERATOR )) {
				console = new EMSAdminConsole();

				List<QueueInfo> queueInfos = console.getQueueInfo( url, username, password );

				List<EMSMonitorQueue> maxPendingMessageQueues = new ArrayList<EMSMonitorQueue>();
				for (QueueInfo queueInfo : queueInfos) {
					EMSMonitorQueue maxPendingMessageQueue = null;

					if (maxPending <= queueInfo.getPendingMessageCount()) {
						maxPendingMessageQueue = new EMSMonitorQueue( queueInfo.getName(), queueInfo.getPendingMessageCount() );

						maxPendingMessageQueues.add( maxPendingMessageQueue );
					}
				}

				if (!maxPendingMessageQueues.isEmpty()) {
					result.put( url, maxPendingMessageQueues );
				}
			}

			if (!result.isEmpty()) {
				MailGroupService mailGroupService = (MailGroupService) jobData.get( NAMED_SERVICE );
				
				List<String> receivers = new ArrayList<String>();
				List<MailGroup> mailGroups = mailGroupService.findMailGroups( "SYSTEM", "SYSTEM" );
				// 用 like 會找出有 SYSTEM 關鍵字的 mail group
				for (MailGroup mailGroup : mailGroups) {
					if ("SYSTEM".equals( mailGroup.getCode() ) && "SYSTEM".equals( mailGroup.getName() )) {
						List<MailItem> mailItems = mailGroupService.findMailItems( mailGroup.getId() );

						for (MailItem mailItem : mailItems) {
							receivers.add( mailItem.getMail() );
						}
					}
				}

				StringTemplate engine = new StringTemplate( IOUtils.toString( getClass().getClassLoader().getResourceAsStream( "template/EMSMonitor.html" ) ) );
				engine.setAttribute( "result", result );

				Mail mail = new Mail();
				mail.withSubject( EMSMonitorScheduler.NAMED_MAIL_SUBJECT );
				mail.from( jobData.getString( ScheduleConfig.NAMED_MAIL_FROM ) );
				mail.withHtmlBody( engine.toString() );
				
				for (String receiver : receivers) {
					mail.addTo( receiver );
				}

				MailSender sender = new MailSender();
				sender.setHost( jobData.getString( ScheduleConfig.NAMED_MAIL_SERVER ) );
				if (StringUtils.isNoneBlank( jobData.getString( ScheduleConfig.NAMED_MAIL_SERVER_PORT ) )) {
					sender.setPort( Integer.parseInt( jobData.getString( ScheduleConfig.NAMED_MAIL_SERVER_PORT ) ) );
				}

				sender.send( mail );
			}
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}

}
