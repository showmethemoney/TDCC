package com.fubon.esb.service.config;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.dao.config.ConnectorDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.system.AdapterDao;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Adapter;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-10
 */

@Service
public class ConnectorService {

    @Inject
    protected Messages messages;

    @Inject
    private ConnectorDao connectorDao;

    @Inject
    private TxnDao txnDao;

    @Inject
    private AdapterDao adapterDao;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private ConnectorCompareService connectorCompareService;

    public List<Connector> findConnectors(String code, Page page) {
        return connectorDao.findConnectors(code, page);
    }

    public List<Connector> findConnectors(String connectorCode, Page page, String connectorName) {
        return connectorDao.findConnectors(connectorCode, page, connectorName);
    }

    @Transactional
    public void saveOrUpdateConnector(Connector connector) {
        if (StringUtils.isNotBlank(connector.getId())) {
            Connector oldConnector = connectorDao.findConnectorById(connector.getId());
            connectorCompareService.sendMail(connector, oldConnector);
            connectorDao.updateSpecifiedFields(connector);
            updateAdapter(connector.getAdapterArray(), connector.getId());
            delteteAdapter(connector.getDeleteArray());
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("system.connector.update", oldConnector.getCode(), oldConnector.getName()), LogType.SYS_CFG_CONNECTOR);
        } else {
            connectorDao.save(connector);
            List<Connector> findConnectorByCode = connectorDao.findConnectorByCode(connector.getCode());
            saveAdapter(connector.getAdapterArray(), findConnectorByCode.get(0).getId());
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("system.connector.add", connector.getCode(), connector.getName()), LogType.SYS_CFG_CONNECTOR);
            connectorCompareService.sendMail(connector, null);
        }
    }

    private void delteteAdapter(Adapter[] adapterArray) {
        for (Adapter adapter : adapterArray) {
            Adapter adapter2 = adapterDao.get(adapter.getId());
            adapterDao.deleteAdapter(adapter2);
        }

    }

    private void saveAdapter(Adapter[] adapterArray, String connectorId) {
        for (Adapter adapter : adapterArray) {
            adapter.setConnectorId(connectorId);
            if ("".equals(adapter.getId())) {
                adapter.setId(null);
            }
            adapterDao.save(adapter);
        }

    }

    private void updateAdapter(Adapter[] adapterArray, String connectorId) {
        for (Adapter adapter : adapterArray) {
            adapter.setConnectorId(connectorId);
            if (!StringUtils.isNotBlank(adapter.getId())) {
                adapter.setId(null);
                adapterDao.save(adapter);
            }
        }
    }

    public Connector findConnectorById(String id) {
        return connectorDao.findConnectorById(id);
    }

    public String getTxnCodes(String connectorId) {
        List<Txn> txns = txnDao.findTxnsByConnectorId(connectorId);
        StringBuilder txnCodeBuffer = new StringBuilder();
        String txnCodes = "";
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                txnCodeBuffer.append(txn.getCode() + ",");
            }
            txnCodes = txnCodeBuffer.toString().substring(0, txnCodeBuffer.toString().length() - 1);
        }
        return txnCodes;
    }

    public List<Txn> findTxns(String connectorId) {
        return txnDao.findTxnsByConnectorId(connectorId);
    }

    public List<Adapter> findAdapter(String connectorId) {
        return adapterDao.findTxnsByConnectorId(connectorId);
    }

    public List<Connector> findConnectorByCode(String code) {
        return connectorDao.findConnectorByCode(code);
    }

    public boolean isDeleteAdapter(String adapterId) {
        List<Txn> txn = txnDao.isDeleteAdapter(adapterId);
        if (txn.isEmpty()) {
            return true;
        }
        return false;

    }
}
