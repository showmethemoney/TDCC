package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.domain.config.JobSysMail;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.service.config.JobSystemSettingService;
import com.fubon.esb.service.job.JobRecordService;

/**
 * @author Qigers
 * @createdDate 2014-12-11
 */

@Controller
@RequestMapping("jobSystemSetting")
public class JobSystemSettingController extends BaseController {
    @Inject
    private JobSystemSettingService jobSystemSettingService;
    @Inject
    private JobRecordService jobRecordService;
    @Inject
    private LoginContext loginContext;

    @RequirePermission(value = "040301")
    @RequestMapping(value = "/viewJobSystemSettingList", method = RequestMethod.GET)
    public String findJobSystemSettings(Model model, String systemCode, String systemName, String systemStatus) {
        Page page = new Page(1);
        model.addAttribute("page", page);
        model.addAttribute("systemCode", systemCode);
        model.addAttribute("systemName", systemName);
        model.addAttribute("systemStatus", "");
        // model.addAttribute("jobSystemSettingList", null);
        List<JobSystemSetting> jobSystemSettingList = jobSystemSettingService.findJobSystemSettings(systemCode, systemName, page, systemStatus);
        model.addAttribute("jobSystemSettingList", jobSystemSettingList);
        return "/config/viewJobSystemSettingList";

    }

    @RequirePermission(value = "040301")
    @RequestMapping(value = "/viewJobSystemSettingList", method = RequestMethod.POST)
    public String viewSearchJobSystemSettings(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, String systemCode, String systemName, String systemStatus) {
        Page page = new Page(currentPage);
        List<JobSystemSetting> jobSystemSettingList = jobSystemSettingService.findJobSystemSettings(systemCode.trim(), systemName.trim(), page, systemStatus);
        model.addAttribute("page", page);
        model.addAttribute("systemCode", systemCode.trim());
        model.addAttribute("systemName", systemName.trim());
        model.addAttribute("systemStatus", systemStatus);
        model.addAttribute("jobSystemSettingList", jobSystemSettingList);
        return "/config/viewJobSystemSettingList";
    }

    @RequirePermission(value = {"040302", "040303"})
    @RequestMapping(value = "/addOrUpdate", method = RequestMethod.GET)
    public String addOrUpdate(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        JobSystemSetting jobSystemSetting;
        if (StringUtils.isNotBlank(id)) {
            isAdd = false;
            jobSystemSetting = jobSystemSettingService.getById(id);
            List<JobSysMail> jobSysMails = jobSystemSettingService.findJobSysMails(id);
            model.addAttribute("jobSysMails", jobSysMails);
        } else {
            jobSystemSetting = new JobSystemSetting();
            jobSystemSetting.setCreatedUser(loginContext.loginedUserId());
            jobSystemSetting.setCreatedTime(new Date());
        }
        List<String> userRoles = jobRecordService.findUserBranchCodeList();
        String userBranch = "";
        if (!userRoles.isEmpty()) {
            userBranch = userRoles.get(0);
        }
        if (StringUtils.isBlank(jobSystemSetting.getBranchCode())) {
            jobSystemSetting.setBranchCode(userBranch);
        }
        model.addAttribute("jobSystemSetting", jobSystemSetting);
        model.addAttribute("isAdd", isAdd);
        return "/config/viewJobSystemSetting";
    }

    @RequirePermission(value = {"040302", "040303"})
    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResultView saveOrUpdate(@Valid JobSystemSetting jobSystemSetting, String[] mails) {
        String currentUser = loginContext.loginedUserId();
        jobSystemSetting.setSystemCode(jobSystemSetting.getSystemCode().trim());
        jobSystemSetting.setBranchCode(jobSystemSetting.getBranchCode().trim());
        jobSystemSettingService.saveOrUpdate(jobSystemSetting, currentUser, mails);
        return ResultView.success("jobSystemSetting/viewJobSystemSettingList");
    }

    @RequirePermission(value = "040301")
    @RequestMapping(value = "/view", method = RequestMethod.GET)
    public String view(Model model, @RequestParam(required = false) String id) {
        JobSystemSetting jobSystemSetting = jobSystemSettingService.getById(id);
        List<JobSysMail> jobSysMails = jobSystemSettingService.findJobSysMails(id);
        model.addAttribute("jobSysMails", jobSysMails);
        model.addAttribute("jobSystemSetting", jobSystemSetting);
        return "/config/viewJobSystemSettingDetail";
    }

    @RequirePermission(value = "040304")
    @RequestMapping("/removeJobSystemSetting")
    @ResponseBody
    public Map<String, Object> removeJobSystemSetting(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        Boolean bl = jobSystemSettingService.searchJSSIdRelated(id);
        if (!bl) {
            jobSystemSettingService.removeJobSystemSetting(id);
        }
        result.put("flag", bl);
        return result;
    }

    @RequirePermission(value = "040306")
    @RequestMapping("/removeQueueMsg")
    @ResponseBody
    public Map<String, Object> removeQueueMsg(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        jobSystemSettingService.removeQueueMsg(id);
        result.put("flag", true);
        return result;
    }

    @RequirePermission(value = "040305")
    @RequestMapping("/changeJobSystemSettingStatus")
    @ResponseBody
    public Map<String, Object> changeJobSystemSettingStatus(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        String ss = jobSystemSettingService.sendChangeStatus(id);
        result.put("flag", true);
        result.put("getid", id);
        boolean isActive = false;
        if ("Active".equals(ss)) {
            isActive = true;
        }
        result.put("isActive", isActive);
        return result;
    }

    @RequestMapping("/validateCode")
    @ResponseBody
    public Map<String, Object> validateCode(String id, String systemCode) {
        Map<String, Object> result = new HashMap<String, Object>();
        String systemCode1 = systemCode.trim();
        Boolean flag = jobSystemSettingService.validCodeDuplicate(systemCode1);
        if (flag && StringUtils.isNotBlank(id)) {
            JobSystemSetting jss = jobSystemSettingService.getById(id);
            if (systemCode1.equals(jss.getSystemCode())) {
                flag = false;
            }
        }
        result.put("flag", flag);
        return result;
    }

    @ResponseBody
    @RequestMapping({"/search/systemCodes"})
    public Object searchSystemCodes(@RequestParam String key) {
        return jobSystemSettingService.searchSystemCodes(key);
    }
}
