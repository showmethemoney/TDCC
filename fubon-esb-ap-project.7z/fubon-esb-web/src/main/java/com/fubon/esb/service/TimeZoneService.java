package com.fubon.esb.service;

import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.domain.system.User;

/**
 * @author james
 * @createdDate 2014-11-28
 */
@Service
public class TimeZoneService {

    @Inject
    private LoginContext loginContext;

    public Date getTZDate(Date date) {
        if (date == null)
            return null;
        User user = loginContext.loginedUser(User.class);
        return getDateByTimeZone(date, user.getTimeZone());
    }

    public static Date getDateByTimeZone(Date date, String timeZone) {
        if (date == null || timeZone == null || timeZone.length() == 0)
            return date;
        int diff = 8 - Integer.valueOf(timeZone.replace("GMT", ""));
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.HOUR, -diff);
        return cal.getTime();
    }

    public Date getTZDateByService(Date date) {
        if (date == null)
            return null;
        User user = loginContext.loginedUser(User.class);
        return getDateByTimeZoneByService(date, user.getTimeZone());
    }

    public static Date getDateByTimeZoneByService(Date date, String timeZone) {
        if (date == null || timeZone == null || timeZone.length() == 0)
            return date;
        int diff = 8 - Integer.valueOf(timeZone.replace("GMT", ""));
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.HOUR, diff);
        return cal.getTime();
    }

}
