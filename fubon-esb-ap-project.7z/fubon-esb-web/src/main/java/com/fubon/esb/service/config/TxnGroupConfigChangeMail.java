package com.fubon.esb.service.config;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Service;

import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.view.EditTxnView;
import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.PriorityType;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnGroup;

@Service
public class TxnGroupConfigChangeMail {
    @Inject
    private HostDao hostDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private TxnConfigService txnConfigService;
    @Inject
    private AccessChannelCompareService accessChannelCompareService;
    @Inject
    private ConfigChangeService configChangeService;
    public String nextLine = "\r";

    public void compareTxnGroupUpdate(TxnGroup originTxnGroup, TxnGroup newTxnGroup) {
        StringBuilder message = new StringBuilder("業務群組設定").append("(業務群組代號：").append(newTxnGroup.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append(nextLine);
        if (originTxnGroup == null || "0".equals(originTxnGroup.getMainId())) { // 只有副本
            compareTxnGroupAdd(false, newTxnGroup);
            return;
        }
        StringBuilder messageOrigin = new StringBuilder();
        StringBuilder messageNew = new StringBuilder();
        if (!accessChannelCompareService.compare(newTxnGroup.getCode(), originTxnGroup.getCode())) {
            messageOrigin.append("業務群組代號：").append(originTxnGroup.getCode()).append(nextLine);
            messageNew.append("業務群組代號：").append(newTxnGroup.getCode()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxnGroup.getName(), originTxnGroup.getName())) {
            messageOrigin.append("業務群組名稱：").append(originTxnGroup.getName()).append(nextLine);
            messageNew.append("業務群組稱：").append(newTxnGroup.getName()).append(nextLine);
        }
        String originHostCode = getHostCode(originTxnGroup.getHostId());
        String newHostCode = getHostCode(newTxnGroup.getHostId());
        if (!accessChannelCompareService.compare(newHostCode, originHostCode)) {
            messageOrigin.append("關聯主機代號：").append(originHostCode).append(nextLine);
            messageNew.append("關聯主機代號：").append(newHostCode).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxnGroup.getStatus().toString(), originTxnGroup.getStatus().toString())) {
            messageOrigin.append("使用狀態：").append(accessChannelCompareService.getDisplayName(originTxnGroup.getStatus())).append(nextLine);
            messageNew.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newTxnGroup.getStatus())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxnGroup.getEffectType().toString(), originTxnGroup.getEffectType().toString())) {
            messageOrigin.append("生效類型：").append(accessChannelCompareService.getDisplayName(originTxnGroup.getEffectType())).append(nextLine);
            messageNew.append("生效類型：").append(accessChannelCompareService.getDisplayName(newTxnGroup.getEffectType())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxnGroup.getEffectTime(), originTxnGroup.getEffectTime())) {
            if (accessChannelCompareService.isEffectTypeBooked(originTxnGroup.getEffectType())) {
                messageOrigin.append("生效時間：").append(DateFormatUtils.format(originTxnGroup.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
            if (accessChannelCompareService.isEffectTypeBooked(newTxnGroup.getEffectType())) {
                messageNew.append("生效時間：").append(DateFormatUtils.format(newTxnGroup.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
        }
        if (messageNew.length() == 0) {
            return;
        }
        message.append("現形生效內容：").append(nextLine).append(messageOrigin).append(nextLine).append("變更後內容 : ").append(nextLine).append(messageNew);
        configChangeService.sendMailRequest("業務群組設定變更", message.toString());
    }

    public void compareTxnGroupAdd(boolean isAdd, TxnGroup newTxnGroup) {
        StringBuilder message = new StringBuilder();
        if (isAdd) {
            message.append("業務群組設定新增，新增者：").append(loginContext.loginedUserId()).append(nextLine).append("新增內容： ").append(nextLine);
        } else {
            message.append("業務群組設定").append("(業務群組代號：").append(newTxnGroup.getCode()).append(")變更，變更者：").append(loginContext.loginedUserId()).append(nextLine).append("現形生效內容：").append(nextLine)
                    .append(nextLine).append("變更後內容：").append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxnGroup.getCode())) {
            message.append("業務群組代號：").append(newTxnGroup.getCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxnGroup.getName())) {
            message.append("業務群組名稱：").append(newTxnGroup.getName()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxnGroup.getHostId())) {
            Host host = hostDao.getById(newTxnGroup.getHostId());
            if (host != null) {
                message.append("關聯主機：").append(host.getCode()).append(nextLine);
            }
        }
        if (newTxnGroup.getStatus() != null) {
            message.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newTxnGroup.getStatus())).append(nextLine);
        }
        if (newTxnGroup.getEffectType() != null) {
            message.append("生效類型：").append(accessChannelCompareService.getDisplayName(newTxnGroup.getEffectType())).append(nextLine);
        }
        if (newTxnGroup.getEffectTime() != null && accessChannelCompareService.isEffectTypeBooked(newTxnGroup.getEffectType())) {
            message.append("生效時間：").append(DateFormatUtils.format(newTxnGroup.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
        }

        configChangeService.sendMailRequest(isAdd ? "業務群組設定新增" : "業務群組設定變更", message.toString());
    }

    // Txn交易設定郵件內容
    public void compareUpdate(Txn originTxn, Txn newTxn, EditTxnView editTxnView) {
        StringBuilder messageHead = new StringBuilder();
        messageHead.append("交易設定").append("(交易代號：").append(newTxn.getCode()).append(")變更,變更者：").append(loginContext.loginedUserId()).append(nextLine);
        if (originTxn == null || "0".equals(originTxn.getMainId())) { // 只有副本
            compareAdd(false, newTxn, editTxnView);
            return;
        }
        StringBuilder messageOrigin = new StringBuilder();
        StringBuilder messageNew = new StringBuilder();
        txnConfigService.getRelatedInfo(originTxn);
        txnConfigService.getRelatedInfo(newTxn);
        if (!accessChannelCompareService.compare(newTxn.getCode(), originTxn.getCode())) {
            messageOrigin.append("交易代號：").append(originTxn.getCode()).append(nextLine);
            messageNew.append("交易代號：").append(newTxn.getCode()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getName(), originTxn.getName())) {
            messageOrigin.append("交易名稱：").append(originTxn.getName()).append(nextLine);
            messageNew.append("交易名稱：").append(newTxn.getName()).append(nextLine);
        }
        setUpdateTxnMailContentPart1(originTxn, newTxn, editTxnView, messageOrigin, messageNew);
        setUpdateTxnMailContentPart2(originTxn, newTxn, editTxnView, messageOrigin, messageNew);
        if (messageNew.toString().isEmpty()) {
            return;
        }
        messageHead.append("現形生效內容：").append(nextLine).append(messageOrigin).append(nextLine).append("變更後內容：").append(nextLine).append(messageNew);
        configChangeService.sendMailRequest("交易設定變更", messageHead.toString());
    }

    public void compareAdd(boolean isAdd, Txn newTxn, EditTxnView editTxnView) {
        StringBuilder messageHead = new StringBuilder();
        txnConfigService.getRelatedInfo(newTxn);
        if (!isAdd) {
            messageHead.append("交易功能設定").append("(交易代號：").append(newTxn.getCode()).append(")變更,變更者：").append(loginContext.loginedUserId()).append(nextLine).append("現形生效內容：").append(nextLine)
                    .append(nextLine).append("變更後內容：").append(nextLine);
        } else {
            messageHead.append("交易功能設定新增,新增者：").append(loginContext.loginedUserId()).append(nextLine);
            messageHead.append("新增內容：").append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getCode())) {
            messageHead.append("交易代號：").append(newTxn.getCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getName())) {
            messageHead.append("交易名稱：").append(newTxn.getName()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getGroupId())) {
            messageHead.append("關聯業務群組代號：").append(((TxnGroup) newTxn.getExt("txnGroup")).getCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getServiceId())) {
            messageHead.append("關聯Service代號：").append(((com.fubon.esb.domain.config.Service) newTxn.getExt("service")).getCode()).append(nextLine);
        }
        setAddTxnMailContent(newTxn, editTxnView, messageHead);
        configChangeService.sendMailRequest(isAdd ? "交易設定新增" : "交易設定變更", messageHead.toString());
    }

    public String getHostCode(String hostId) {
        String hostCode = "";
        if (StringUtils.isNotBlank(hostId)) {
            Host host = hostDao.getById(hostId);
            if (host != null) {
                hostCode = host.getCode();
            }
        }
        return hostCode;
    }

    public void setUpdateTxnMailContentPart1(Txn originTxn, Txn newTxn, EditTxnView editTxnView, StringBuilder messageOrigin, StringBuilder messageNew) {
        if (!accessChannelCompareService.compare((TxnGroup) newTxn.getExt("txnGroup"), (TxnGroup) originTxn.getExt("txnGroup"))) {
            messageOrigin.append("關聯業務群組代號：").append(((TxnGroup) originTxn.getExt("txnGroup")) != null ? ((TxnGroup) originTxn.getExt("txnGroup")).getCode() : "").append(nextLine);
            messageNew.append("關聯業務群組代號：").append(((TxnGroup) newTxn.getExt("txnGroup")) != null ? ((TxnGroup) newTxn.getExt("txnGroup")).getCode() : "").append(nextLine);
        }
        if (!accessChannelCompareService.compare((com.fubon.esb.domain.config.Service) newTxn.getExt("service"), (com.fubon.esb.domain.config.Service) originTxn.getExt("service"))) {
            messageOrigin.append("關聯Service代號：")
                    .append(((com.fubon.esb.domain.config.Service) originTxn.getExt("service")) != null ? ((com.fubon.esb.domain.config.Service) originTxn.getExt("service")).getCode() : "")
                    .append(nextLine);
            messageNew.append("關聯Service代號：")
                    .append(((com.fubon.esb.domain.config.Service) newTxn.getExt("service")) != null ? ((com.fubon.esb.domain.config.Service) newTxn.getExt("service")).getCode() : "")
                    .append(nextLine);
        }
        String originChannelCode = txnConfigService.findRelatedChannelCodes(originTxn.getId()).get(1);
        String newChannelCode = txnConfigService.findchannelCode(editTxnView.getChannelIds());
        if (!accessChannelCompareService.compare(newChannelCode, originChannelCode)) {
            messageOrigin.append("關聯Channel代號：").append(originChannelCode).append(nextLine);
            messageNew.append("關聯Channel代號：").append(newChannelCode).append(nextLine);
        }

        if (!accessChannelCompareService.compare(newTxn.getHostDriveQueue(), originTxn.getHostDriveQueue())) {
            messageOrigin.append("HostDriveQueue：").append(originTxn.getHostDriveQueue()).append(nextLine);
            messageNew.append("HostDriveQueue：").append(newTxn.getHostDriveQueue()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getTransTxnCode(), originTxn.getTransTxnCode())) {
            messageOrigin.append("轉換TxID：").append(originTxn.getTransTxnCode()).append(nextLine);
            messageNew.append("轉換TxID：").append(newTxn.getTransTxnCode()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getToQueue(), originTxn.getToQueue())) {
            messageOrigin.append("To Queue：").append(originTxn.getToQueue()).append(nextLine);
            messageNew.append("To Queue：").append(newTxn.getToQueue()).append(nextLine);
        }
    }

    public void setUpdateTxnMailContentPart2(Txn originTxn, Txn newTxn, EditTxnView editTxnView, StringBuilder messageOrigin, StringBuilder messageNew) {
        if (!accessChannelCompareService.compare(newTxn.getTimeout(), originTxn.getTimeout())) {
            messageOrigin.append("交易 Timeout：").append(originTxn.getTimeout() == null ? "" : originTxn.getTimeout()).append(nextLine);
            messageNew.append("交易 Timeout：").append(newTxn.getTimeout() == null ? "" : newTxn.getTimeout()).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getPriority().toString(), originTxn.getPriority().toString())) {
            messageOrigin.append("交易優先權：").append(displayName(originTxn.getPriority())).append(nextLine);
            messageNew.append("交易優先權：").append(displayName(newTxn.getPriority())).append(nextLine);
        }
        if (!accessChannelCompareService.compare((Connector) newTxn.getExt("connector"), (Connector) originTxn.getExt("connector"))) {
            messageOrigin.append("交易Connector：").append(((Connector) originTxn.getExt("connector")) != null ? ((Connector) originTxn.getExt("connector")).getCode() : "").append(nextLine);
            messageNew.append("交易Connector：").append(((Connector) newTxn.getExt("connector")) != null ? ((Connector) newTxn.getExt("connector")).getCode() : "").append(nextLine);
        }
        String originRelatedTxnCode = txnConfigService.getRelatedTxnCodes(originTxn.getId()).get(1);
        String newRelatedTxnCode = txnConfigService.findRelateTxnCode(editTxnView.getTxnRelatedIds());
        if (!accessChannelCompareService.compare(newRelatedTxnCode, originRelatedTxnCode)) {
            messageOrigin.append("關聯交易代號：").append(originRelatedTxnCode).append(nextLine);
            messageNew.append("關聯交易代號：").append(newRelatedTxnCode).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getStatus().toString(), originTxn.getStatus().toString())) {
            messageOrigin.append("使用狀態：").append(accessChannelCompareService.getDisplayName(originTxn.getStatus())).append(nextLine);
            messageNew.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newTxn.getStatus())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getEffectType().toString(), originTxn.getEffectType().toString())) {
            messageOrigin.append("生效類型：").append(accessChannelCompareService.getDisplayName(originTxn.getEffectType())).append(nextLine);
            messageNew.append("生效類型：").append(accessChannelCompareService.getDisplayName(newTxn.getEffectType())).append(nextLine);
        }
        if (!accessChannelCompareService.compare(newTxn.getEffectTime(), originTxn.getEffectTime())) {
            if (accessChannelCompareService.isEffectTypeBooked(originTxn.getEffectType())) {
                messageOrigin.append("生效時間：").append(DateFormatUtils.format(originTxn.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
            if (accessChannelCompareService.isEffectTypeBooked(newTxn.getEffectType())) {
                messageNew.append("生效時間：").append(DateFormatUtils.format(newTxn.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
            }
        }
    }

    public void setAddTxnMailContent(Txn newTxn, EditTxnView editTxnView, StringBuilder messageHead) {
        if (StringUtils.isNotBlank(editTxnView.getChannelIds())) {
            String newChannelCode = txnConfigService.findchannelCode(editTxnView.getChannelIds());
            messageHead.append("關聯Channel代號：").append(newChannelCode).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getHostDriveQueue())) {
            messageHead.append("HostDriveQueue：").append(newTxn.getHostDriveQueue()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getTransTxnCode())) {
            messageHead.append("轉換TxID：").append(newTxn.getTransTxnCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getToQueue())) {
            messageHead.append("To Queue：").append(newTxn.getToQueue()).append(nextLine);
        }
        if (newTxn.getTimeout() != null) {
            messageHead.append("交易 Timeout：").append(newTxn.getTimeout()).append(nextLine);
        }
        if (newTxn.getPriority() != null) {
            messageHead.append("交易優先權：").append(displayName(newTxn.getPriority())).append(nextLine);
        }
        if (StringUtils.isNotBlank(newTxn.getConnectorId())) {
            messageHead.append("交易Connector：").append(((Connector) newTxn.getExt("connector")).getCode()).append(nextLine);
        }
        if (StringUtils.isNotBlank(editTxnView.getTxnRelatedIds())) {
            String newRelatedTxnCode = txnConfigService.findRelateTxnCode(editTxnView.getTxnRelatedIds());
            messageHead.append("關聯交易代號：").append(newRelatedTxnCode).append(nextLine);
        }
        if (newTxn.getStatus() != null) {
            messageHead.append("使用狀態：").append(accessChannelCompareService.getDisplayName(newTxn.getStatus())).append(nextLine);
        }
        if (newTxn.getEffectType() != null) {
            messageHead.append("生效類型：").append(accessChannelCompareService.getDisplayName(newTxn.getEffectType())).append(nextLine);
        }
        if (newTxn.getEffectTime() != null && accessChannelCompareService.isEffectTypeBooked(newTxn.getEffectType())) {
            messageHead.append("生效時間：").append(DateFormatUtils.format(newTxn.getEffectTime(), "yyyy/MM/dd HH:mm:ss")).append(nextLine);
        }

    }

    public String displayName(PriorityType type) {
        if ("H".equals(type.name())) {
            return "高";
        } else if ("M".equals(type.name())) {
            return "中";
        } else
            return "低";
    }
}
