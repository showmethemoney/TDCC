package com.fubon.esb.dao.system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.Branch;
import com.fubon.esb.domain.system.RoleBranch;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-29
 */
@Repository
public class BranchDao extends JPADaoSupport<Branch> {

    public List<Branch> findBranchList(String branchName, Page page) {
        StringBuilder jql = new StringBuilder();
        jql.append("from ").append(Branch.class.getName()).append(" where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(branchName)) {
            jql.append(" and name like :branchName ");
            params.put("branchName", "%" + branchName + "%");
        }

        Query query = Query.create(jql.toString()).orderBy("code").page(page);
        query.putParams(params);

        return jpaAccess.findPage(query);
    }

    public List<Branch> findBranchListByRole(String roleId) {
        Query query = Query.create("from " + Branch.class.getName() + " b where exists ( from " + RoleBranch.class.getName() + " r where r.roleId = :roleId and r.branchCode = b.code )");
        query.param("roleId", roleId);
        query.orderBy("b.code");
        return jpaAccess.find(query);
    }

}
