package com.fubon.esb.controller.system.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-6
 */
public class ApprovalSearchVO {

    private String startDateStr;

    private String endDateStr;

    private String groupName;

    private String roleName;

    private String updatedUser;

    public Date getStartDate() {
        if (StringUtils.isBlank(startDateStr)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(startDateStr);
        } catch (ParseException e) {
            return null;
        }
    }

    public String getStartDateStr() {
        return startDateStr;
    }

    public void setStartDateStr(String startDateStr) {
        this.startDateStr = startDateStr;
    }

    public Date getEndDate() {
        if (StringUtils.isBlank(endDateStr)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(endDateStr + " 23:59:59");
        } catch (ParseException e) {
            return null;
        }
    }

    public String getEndDateStr() {
        return endDateStr;
    }

    public void setEndDateStr(String endDateStr) {
        this.endDateStr = endDateStr;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

}
