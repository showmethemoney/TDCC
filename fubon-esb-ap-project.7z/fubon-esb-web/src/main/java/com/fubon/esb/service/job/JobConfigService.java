package com.fubon.esb.service.job;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.LogDBConfig;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.job.view.JobConfigView;
import com.fubon.esb.dao.config.JobSystemSettingDao;
import com.fubon.esb.dao.job.JobConfigDao;
import com.fubon.esb.dao.job.JobRecordDao;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.domain.job.JobConfig;
import com.fubon.esb.domain.job.JobRecord;
import com.fubon.esb.domain.job.JobStatus;
import com.fubon.esb.domain.job.LastRunningStatusType;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-13
 */

@Service
public class JobConfigService extends BaseJobConfigService {

    @Inject
    private JobConfigDao jobConfigDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private Messages messages;
    @Inject
    private JobRecordDao jobRecordDao;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private JobSystemSettingDao jobSystemSettingDao;

    public List<JobConfig> findJobConfigList(JobConfigView jobConfgView, String status, List<String> jobSystemIds, OrderBy orderBy, Page page) {
        JobStatus jobStatus = null;

        if (StringUtils.isNotBlank(status)) {
            jobStatus = JobStatus.valueOf(status);
        }
        if (status == null) {
            jobStatus = JobStatus.valueOf("A");
        }
        List<JobConfig> configs = jobConfigDao.findJobConfigs(jobConfgView, jobStatus, jobSystemIds, orderBy, page);
        setJobSysCodeList(configs);
        return configs;
    }

    public void setIfShowMemo(List<JobConfig> jobConfigs) {
        for (JobConfig jobConfig : jobConfigs) {
            if (!(findDayJobRecords(jobConfig.getId(), null)).isEmpty()) {
                jobConfig.setIfMemo("true");
            } else
                jobConfig.setIfMemo("false");
        }
    }

    public JobConfig getById(String id) {
        return jobConfigDao.getJobConfigById(id);
    }

    public JobConfig setJobSysCode(JobConfig jobConfig) {
        if (StringUtils.isNotBlank(jobConfig.getJobSystemId())) {
            JobSystemSetting jobsystem = jobSystemSettingDao.get(jobConfig.getJobSystemId());
            if (jobsystem != null) {
                jobConfig.setJobSystemCode(jobsystem.getSystemCode());
                jobConfig.setBranchCode(jobsystem.getBranchCode());
            }
        }
        return jobConfig;
    }

    public void setJobSysCodeList(List<JobConfig> jobConfigs) {
        if (!jobConfigs.isEmpty()) {
            for (JobConfig jobConfig : jobConfigs) {
                setJobSysCode(jobConfig);
            }
        }
    }

    @Transactional
    public void saveOrUpdate(JobConfig jobConfig) throws DuplicatedException {
        if (StringUtils.isNotBlank(jobConfig.getId())) {
            JobConfig oldJobConfig = getById(jobConfig.getId());
            String oldCode = oldJobConfig.getCode();
            String oldName = oldJobConfig.getName();
            updateJobConfig(jobConfig);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("job.config.log.update"), oldCode, oldName), LogType.JOB_MANAGE_CONFIG);
        } else {
            jobConfig.setId(null);
            saveJobConfig(jobConfig);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("job.config.log.add"), jobConfig.getCode(), jobConfig.getName()), LogType.JOB_MANAGE_CONFIG);
        }
    }

    public void saveJobConfig(JobConfig jobConfig) throws DuplicatedException {
        if (validJobConfigDuplicate(jobConfig.getCode(), jobConfig.getJobSystemId())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        existDependJob(jobConfig);
        jobConfig.setCreatedTime(new Date());
        jobConfig.setCreatedUser(loginContext.loginedUserId());
        jobConfigDao.save(jobConfig);
    }

    public void updateJobConfig(JobConfig jobConfig) throws DuplicatedException {
        if (validJobConfigDuplicate(jobConfig)) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        JobConfig persiJobConfig = getById(jobConfig.getId());
        jobConfig.setCreatedTime(persiJobConfig.getCreatedTime());
        jobConfig.setCreatedUser(persiJobConfig.getCreatedUser());
        jobConfig.setUpdatedTime(new Date());
        existDependJob(jobConfig);
        jobConfig.setUpdatedUser(loginContext.loginedUserId());
        jobConfigDao.update(jobConfig);
    }

    public boolean validJobConfigDuplicate(String code, String jobSystemId) {
        return jobConfigDao.codeDuplicate(code, jobSystemId);
    }

    public boolean existJob(String code, String jobSystemId) {
        return jobConfigDao.getByCode(code, jobSystemId).isEmpty() ? false : true;
    }

    public boolean validJobConfigDuplicate(JobConfig jobConfig) {
        JobConfig updateJobConfig = getById(jobConfig.getId());
        String oldCode = updateJobConfig.getCode();
        String oldJobSystemId = updateJobConfig.getJobSystemId();
        return (!oldCode.equals(jobConfig.getCode()) || !oldJobSystemId.equals(jobConfig.getJobSystemId())) && jobConfigDao.codeDuplicate(jobConfig.getCode(), jobConfig.getJobSystemId());
    }

    public void existDependJob(JobConfig jonConfig) throws DuplicatedException {
        if (StringUtils.isNoneBlank(jonConfig.getDependCodes())) {
            String[] splitCodes = jonConfig.getDependCodes().split("&|\\|");
            for (String code : splitCodes) {
                String codes[] = code.split("\\.");
                if (codes == null || codes.length <= 1) {
                    throw new DuplicatedException(messages.getMessage("depend_job_code_form_error"));
                }
                String jobSystemCode = codes[0];
                String jobCode = codes[1];
                JobSystemSetting jobSystem = jobSystemSettingDao.findJobSystemByCode(jobSystemCode);
                String jobSytsemId = jobSystem == null ? "" : jobSystem.getId();
                if (!existJob(jobCode, jobSytsemId)) {
                    throw new DuplicatedException(messages.getMessage("job_valid_code_exist", code));
                }
                if (jobCode.equals(jonConfig.getCode()) && jonConfig.getJobSystemId().equals(jobSytsemId)) {
                    throw new DuplicatedException(messages.getMessage("job_valid_code_same", code));
                }
                // if (dependJob != null && !dependJob.getJobSystemId().equals(jonConfig.getJobSystemId())) {
                // throw new DuplicatedException(messages.getMessage("job_valid_dependCode_jobsys", code));
                // }//前置排程的系統
            }
        }
    }

    @Transactional
    public void removeJobConfig(String id) {
        JobConfig jobConfig = jobConfigDao.getJobConfigById(id);
        String jobCode = jobConfig.getCode();
        String jobName = jobConfig.getName();
        jobConfigDao.delete(jobConfig);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("job.config.log.delete"), jobCode, jobName), LogType.JOB_MANAGE_CONFIG);
    }

    public List<JobRecord> findDayJobRecords(String configId, String runningDate) {
        Date startDate = null;
        Date endDate = null;
        if (StringUtils.isNotBlank(runningDate)) {
            startDate = timeZoneService.getTZDateByService(formatToDateTime(runningDate, "00", "00", "00"));
            endDate = timeZoneService.getTZDateByService(formatToDateTime(runningDate, "23", "59", "59"));
        } else {
            startDate = timeZoneService.getTZDateByService(formatToDateTime(new SimpleDateFormat("yyyy/MM/dd").format(new Date()), "00", "00", "00"));
            endDate = timeZoneService.getTZDateByService(formatToDateTime(new SimpleDateFormat("yyyy/MM/dd").format(new Date()), "23", "59", "59"));
        }
        return jobRecordDao.findDayRecords(configId, startDate, endDate);
    }

    public JobRecord getLatestJobRecord(String id, String searchRunningTime) {
        JobRecord jobRecord = null;
        List<JobRecord> jobRecords = findDayJobRecords(id, searchRunningTime);
        if (!jobRecords.isEmpty()) {
            jobRecord = jobRecords.get(0);
        }
        return jobRecord;
    }

    @Transactional(LogDBConfig.LOG_DB_JPA_TXN)
    public void saveMemo(String jobRecordId, String memo) {
        JobRecord jobRecord = jobRecordDao.getJobRecordById(jobRecordId);
        JobConfig jobConfig = jobConfigDao.getJobConfigById(jobRecord.getConfigId());
        jobRecord.setRemark(memo);
        jobRecordDao.update(jobRecord);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("job.record.log.memo", jobConfig.getCode(), jobConfig.getName()), LogType.JOB_MANAGE_SEARCH);
    }

    public boolean hasRunningJob(List<JobConfig> jobConfigs) {
        if (jobConfigs != null) {
            for (JobConfig jobConfig : jobConfigs) {
                if (jobConfig.getLastRunningTime() != null && jobConfig.getLastRunningStatus() == LastRunningStatusType.R
                        && dateAddMinute(jobConfig.getLastRunningTime(), jobConfig.getMaxTime() != null ? jobConfig.getMaxTime() : 0).before(new Date()))
                    return true;
            }
        }
        return false;
    }

    public List<JobConfig> findAllJobConfig(List<String> userBranchCodes) {
        return jobConfigDao.findAllJobRecords(userBranchCodes);
    }

    public JobSystemSetting getJobSysByConfig(JobConfig jobConfig) {
        if (jobConfig != null && StringUtils.isNotBlank(jobConfig.getJobSystemId())) {
            return jobSystemSettingDao.getlById(jobConfig.getJobSystemId());
        } else
            return null;
    }
}
