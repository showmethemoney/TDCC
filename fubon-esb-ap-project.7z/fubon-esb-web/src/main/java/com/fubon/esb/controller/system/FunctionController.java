package com.fubon.esb.controller.system;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.service.system.FunctionService;
import com.fubon.esb.service.system.RoleService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Controller
@RequestMapping("/system")
public class FunctionController extends BaseController {

    @Inject
    private FunctionService functionService;

    @Inject
    private RoleService roleService;

    /**
     * 權限設置
     * 
     * @param roleId 最新的角色ID
     */
    @RequestMapping("viewFuncList")
    @RequirePermission({"070104", "070105"})
    public String viewFuncList(Model model, String roleId) {
        model.addAttribute("functions", functionService.findAllFunctions(roleId));
        model.addAttribute("roleId", roleId);
        model.addAttribute("role", roleService.getRoleById(roleId));
        return "/system/viewFuncList";
    }

    /**
     * 保存權限
     */
    @RequestMapping("saveOrUpdateFuncList")
    @RequirePermission({"070104", "070105"})
    @ResponseBody
    public ResultView saveOrUpdateFuncList(String roleId, String[] funcCodes) {
        try {
            functionService.updateRoleFuncList(roleId, funcCodes);
        } catch (Exception e) {
            addError(e.getMessage());
            validate();
        }

        return ResultView.success("/system/viewRole?roleId=" + roleService.getRoleOriginId(roleId) + "&groupId=" + roleService.getRoleById(roleId).getGroupId());
    }

}
