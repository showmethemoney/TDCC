package com.fubon.esb;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

import com.comwave.core.log.LogSettings;
import com.comwave.core.platform.config.DefaultSiteConfig;
import com.comwave.core.platform.login.LoginInterceptor;
import com.comwave.core.platform.model.ModelBuilderInterceptor;
import com.comwave.core.platform.permission.PermissionInterceptor;
import com.comwave.core.platform.session.SessionProviderType;
import com.comwave.core.platform.setting.RuntimeEnvironment;
import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;
import com.fubon.esb.service.log.AppLogMessageFilter;

/**
 * @author Bribin
 * @createdDate Sep 10, 2014
 */
@Configuration
@ComponentScan(basePackageClasses = WebConfig.class)
public class WebConfig extends DefaultSiteConfig {

    @Inject
    private Environment env;

    // @Inject
    // private EntityManagerFactory entityManagerFactory;

    @Bean
    @Override
    public RuntimeSettings runtimeSettings() {
        RuntimeSettings settings = super.runtimeSettings();
        settings.setEnvironment(env.getProperty("site.environment", RuntimeEnvironment.class, RuntimeEnvironment.PROD));
        settings.setVersion(env.getProperty("runtime.version", "current"));
        return settings;
    }

    @Bean
    @Override
    public LogSettings logSettings() {
        LogSettings logSettings = super.logSettings();
        logSettings.setLogMessageFilter(new AppLogMessageFilter());
        return logSettings;
    }

    @Override
    public SiteSettings siteSettings() {
        SiteSettings settings = new SiteSettings();
        settings.setLoginPage("redirect:/viewLogin");
        settings.setErrorPage("/error/exception");
        settings.setResourceNotFoundPage("/error/notFound");
        settings.setPermissionNotAllowedPage("/error/noPermission");

        // settings.setSessionTimeOut(TimeLength.minutes(15));
        settings.setSessionTimeOutPage("redirect:/viewLogin");
        settings.setSessionProviderType(env.getProperty("site.sessionProviderType", SessionProviderType.class, SessionProviderType.LOCAL));
        settings.setRemoteSessionServer(env.getProperty("site.remoteSessionServer"));

        settings.setJSDir("/static/js");
        settings.setCSSDir("/static/css");
        return settings;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("/static/");
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("redirect:/viewLogin");
    }

    @Bean
    public MultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(5000000); // 5M
        return multipartResolver;
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registerDefaultInterceptors(registry);
        // registry.addWebRequestInterceptor(openEntityManagerInViewInterceptor());
        registry.addInterceptor(loginInterceptor());
        registry.addInterceptor(permissionInterceptor());
        registry.addInterceptor(modelBuilderInterceptor());
    }

    @Bean
    public LoginInterceptor loginInterceptor() {
        return new LoginInterceptor();
    }

    @Bean
    public PermissionInterceptor permissionInterceptor() {
        return new PermissionInterceptor();
    }

    // @Bean
    // public OpenEntityManagerInViewInterceptor openEntityManagerInViewInterceptor() {
    // OpenEntityManagerInViewInterceptor openEntityManagerInViewInterceptor = new OpenEntityManagerInViewInterceptor();
    // openEntityManagerInViewInterceptor.setEntityManagerFactory(entityManagerFactory);
    // return openEntityManagerInViewInterceptor;
    // }

    @Bean
    public ModelBuilderInterceptor modelBuilderInterceptor() {
        return new ModelBuilderInterceptor();
    }

}
