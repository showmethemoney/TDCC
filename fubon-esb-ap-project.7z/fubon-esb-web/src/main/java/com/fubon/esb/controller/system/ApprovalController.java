package com.fubon.esb.controller.system;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.system.view.ApprovalSearchVO;
import com.fubon.esb.service.system.ApprovalService;

/**
 * 權限復核controller
 * @author Leckie Zhang
 * @createdDate 2014-11-6
 */
@Controller
@RequestMapping("system")
public class ApprovalController extends BaseController {
    
    @Inject
    private ApprovalService approvalService;
    
    /**
     * 系統權限覆核
     * @param vo 
     *          頁面傳入的查詢條件
     * @param isSearch
     *          查詢標誌
     */
    @RequestMapping("viewApprovalList")
    @RequirePermission(value = "070201")
    public String viewApprovalList(Model model, ApprovalSearchVO vo, Boolean isSearch) {
        if (isSearch != null && isSearch) {
            model.addAttribute("approvalLogs", approvalService.findAllGroupRoleForApproval(vo));
            model.addAttribute("vo", vo);
            model.addAttribute("isSearch", isSearch);
        } else {
            // 默認顯示所有數據
            ApprovalSearchVO v = new ApprovalSearchVO();
            model.addAttribute("approvalLogs", approvalService.findAllGroupRoleForApproval(v));
            model.addAttribute("vo", v);
            model.addAttribute("isSearch", true);
        }
        return "/system/viewApprovalList";
    }
    
    /**
     * 查看覆核信息
     */
    @RequestMapping("viewApproval")
    @RequirePermission(value = "070201")
    public String viewApproval(Model model, String groupId, String roleId, Boolean isApproval) {
        model.addAttribute("log", approvalService.getApprovalLog(groupId, roleId));
        model.addAttribute("isApproval", isApproval);
        return "/system/viewApproval";
    }
    
    /**
     * 執行覆核操作
     */
    @RequestMapping("runApproval")
    @ResponseBody
    @RequirePermission(value = "070202")
    public ResultView runApproval(String groupId, String roleId, String modifyContent) {
        try {
            approvalService.runApproval(groupId, roleId, modifyContent);
        } catch (Exception e) {
            addError(e.getMessage());
            validate();
        }

        return ResultView.success("");
    }

}
