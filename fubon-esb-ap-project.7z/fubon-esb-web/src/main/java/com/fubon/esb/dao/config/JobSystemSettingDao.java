package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.domain.config.JobSystemSettingStatus;

/**
 * @author Qigers
 * @createdDate 2014-12-11
 */

@Repository
public class JobSystemSettingDao extends JPADaoSupport<JobSystemSetting> {

    public List<JobSystemSetting> findJobSystemSettings(String systemCode, String systemName, Page page, String status, List<String> userBranchCodes) {
        Query query = Query.from(JobSystemSetting.class).append(" where 1=1");
        if (userBranchCodes != null) {
            query.append(" and branchCode in :userBranchCodes");
            query.setParam("userBranchCodes", userBranchCodes);
        }
        if (StringUtils.isNotBlank(systemCode)) {
            query.append(" and systemCode = :systemCode");
            query.setParam("systemCode", systemCode);
        }
        if (StringUtils.isNotBlank(systemName)) {
            query.append(" and systemName like :systemName ");
            query.setParam("systemName", "%" + systemName + "%");
        }
        if (StringUtils.isNotBlank(status)) {
            query.append(" and status = :status");
            query.setParam("status", JobSystemSettingStatus.D);
        } else {
            query.append(" and status != :status");
            query.setParam("status", JobSystemSettingStatus.D);
        }
        query.page(page).orderBy("systemCode");
        return jpaAccess.findPage(query);
    }

    public JobSystemSetting getlById(String id) {
        return jpaAccess.get(JobSystemSetting.class, id);
    }

    public void removeJobSystemSetting(String id) {
        Query query = Query.create("delete from " + JobSystemSetting.class.getName() + " where id = :id").param("id", id);
        jpaAccess.update(query);
    }

    public void addJobSystemSetting(JobSystemSetting jobSystemSetting) {
        jpaAccess.save(jobSystemSetting);
    }

    public void updateJobSystemSetting(JobSystemSetting jobSystemSetting) {
        jpaAccess.update(jobSystemSetting);
    }

    public void sendChangeStatus(JobSystemSetting jobSystemSetting) {
        updateJobSystemSetting(jobSystemSetting);
    }

    public boolean idDuplicate(String id) {
        Query query = Query.from(JobSystemSetting.class).where("ID = :id").param("id", id);
        return !jpaAccess.find(query).isEmpty();
    }

    public boolean codeDuplicate(String systemCode) {
        Query query = Query.from(JobSystemSetting.class).where("systemCode = :systemCode").param("systemCode", systemCode).append(" and status != :status").param("status", JobSystemSettingStatus.D);
        return !jpaAccess.find(query).isEmpty();
    }

    public List<String> searchSystemCodes(String key) {
        Query query = Query.create("select distinct systemCode from " + JobSystemSetting.class.getName());
        query.where(" systemCode like :systemCode").param("systemCode", key + "%");
        query.orderBy("systemCode");
        return jpaAccess.find(query);
    }

    public JobSystemSetting findJobSystemByCode(String jobSystemCode) {
        Query query =
                Query.from(JobSystemSetting.class).where("systemCode = :systemCode").param("systemCode", jobSystemCode).append(" and status != :status").param("status", JobSystemSettingStatus.D);
        return jpaAccess.findOne(query);
    }
}
