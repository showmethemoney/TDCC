package com.fubon.esb.dao.txn;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.txn.DirectionType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnStatus;


/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Repository
public class TxnDirectionDao extends JPADaoSupport<TxnDirection>
{

	public TxnDirection findByDefIdAndDir(String defId, DirectionType direction) {
		Query query = Query.from( TxnDirection.class );
		query.where( " definitionId=:defiId and direction=:direc" ).param( "defiId", defId ).param( "direc", direction );
		query.page( new Page( 1, 1 ) );
		List<TxnDirection> result = jpaAccess.find( query );
		if (result != null && !result.isEmpty()) {
			return result.get( 0 );
		}
		return null;
	}

	public TxnDirection findByDefIdAndDirAttachHeadName(String defId, DirectionType direction) {
		Query query = Query.create( " select new " ).append( TxnDirection.class ).append( "(t,h.name) from " );
		query.append( TxnDirection.class ).append( " t," ).append( TxnDirection.class ).append( " h " );
		query.where( "  t.headRefId=h.id and t.definitionId=:defiId and t.direction=:direc" ).param( "defiId", defId ).param( "direc", direction );
		query.page( new Page( 1, 1 ) );
		List<TxnDirection> result = jpaAccess.find( query );
		if (result != null && !result.isEmpty()) {
			return result.get( 0 );
		}
		return null;
	}

	public List<TxnDirection> getByTxnDefId(String txnDefId) {
		Query query = Query.from( TxnDirection.class ).where( "definitionId=:defId" ).param( "defId", txnDefId );
		return jpaAccess.find( query );
	}

	public void removeByTxnDef(String txnDefId) {
		Query query = Query.create( "delete From " + TxnDirection.class.getName() + " where definitionId=:defId" ).param( "defId", txnDefId );
		jpaAccess.update( query );
	}

	public List<TxnDirection> findHeadDirections() {
		Query query = Query.from( TxnDirection.class ).where( "direction='" + DirectionType.H + "'" + " and txnHeaderStatus=" + "'" + TxnStatus.M + "'" )
		        .orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<TxnDirection> findHeadDirsByName(String name) {
		Query query = Query.from( TxnDirection.class ).where( "direction='" + DirectionType.H + "'" + " and txnHeaderStatus=" + "'" + TxnStatus.M + "'" );
		query.append( " and name=:name" ).param( "name", name );
		return jpaAccess.find( query );
	}

	public List<TxnDirection> findPageByCodeNameAndStatusAddtion(String name, TxnStatus txnHeaderStatus, Page page) {
		Query query = Query.from( TxnDirection.class ).append( " m " ).where( " txnHeaderStatus !=:deleteStatus" ).param( "deleteStatus", TxnStatus.D );
		if (StringUtils.isNotBlank( name )) {
			query.append( " and name = :name" );
			query.param( "name", name );
		}
		if (txnHeaderStatus != null) {
			query.append( " and txnHeaderStatus=:txnHeaderStatus" );
			query.param( "txnHeaderStatus", txnHeaderStatus );
		}
		query.append( " and direction='" + DirectionType.H + "'" + " and not exists(select 1 from " ).append( TxnDirection.class )
		        .append( " c where m.id=c.mainId)" );
		query.orderBy( "name" );
		query.page( page );
		return jpaAccess.findPage( query );
	}

	public List<String> searchTxnNames(String key) {
		Query query = Query.create( "select distinct name from " + TxnDirection.class.getName() + " m " );
		query.where( " name like :name and txnHeaderStatus!=:txnHeaderStatus and direction='" + DirectionType.H + "'" ).param( "name", key + "%" )
		        .param( "txnHeaderStatus", TxnStatus.D );
		query.append( " and not exists(select 1 from " ).append( TxnDirection.class ).append( " c where m.id=c.mainId)" );
		query.orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<String> searchWaitApproveNames(String key) {
		List<TxnStatus> headStatus = new ArrayList<TxnStatus>();
		headStatus.add( TxnStatus.S );
		headStatus.add( TxnStatus.D );
		Query query = Query.create( "select distinct name from " + TxnDirection.class.getName() );
		query.where( " direction='" + DirectionType.H + "' and name like :name  and txnHeaderStatus in (:txnHeaderStatus) " )
		        .param( "txnHeaderStatus", headStatus ).param( "name", key + "%" );
		query.orderBy( "name" );
		return jpaAccess.find( query );
	}

	public List<String> searchDefinitionIdByHeadRefId(String key) {
		Query query = Query.create( "select distinct definitionId from " + TxnDirection.class.getName() );
		query.where( " headRefId = :headRefId" ).param( "headRefId", key );
		// query.orderBy("name");
		return jpaAccess.find( query );
	}

	public TxnDirection findHeadDirByID(String id) {
		return jpaAccess.get( TxnDirection.class, id );
	}

	public TxnDirection findHeadDirByMainID(String mainId) {
		Query query = Query.from( TxnDirection.class ).where( "mainId = :mainId" ).param( "mainId", mainId );
		List<TxnDirection> txnDirectionList = jpaAccess.find( query );
		if (txnDirectionList.isEmpty()) {
			return new TxnDirection();
		} else {
			return txnDirectionList.get( 0 );
		}
	}

	public void removeTxnHeaderById(String id) {
		Query query = Query.create( "delete From " + TxnDirection.class.getName() + " where id=:id" ).param( "id", id );
		jpaAccess.update( query );
	}

	/** ifExist **/
	public List<TxnDirection> getByTxnCodeButSelf(String selfId, String mainId, String name) {
		return jpaAccess
		        .find( Query.from( TxnDirection.class ).where( " (:selfId is null or id!=:selfId)  and (:mainId is null or id!=:mainId) and name=:name" )
		                .param( "selfId", selfId ).param( "mainId", mainId ).param( "name", name ) );
	}

	/** ifExist name **/
	public boolean nameDuplicate(String selfId, String mainId, String name) {
		Query query = Query.from( TxnDirection.class ).where( "name = :name and id!=:selfId and id!=:mainId " ).param( "name", name ).param( "selfId", selfId )
		        .param( "mainId", mainId );
		return !jpaAccess.find( query ).isEmpty();
	}

	/** AprrovedList **/
	public List<TxnDirection> searchWaitToCheckTxnDirecs(String name, Page page) {
		Query query = Query.from( TxnDirection.class ).where( " 1=1 and direction='" + DirectionType.H + "'" );
		query.append( " and (txnHeaderStatus = :savedStatus or txnHeaderStatus = :deleteStatus)" ).param( "savedStatus", TxnStatus.S ).param( "deleteStatus",
		        TxnStatus.D );
		if (StringUtils.isNotBlank( name )) {
			query.append( " and name=:name" );
			query.param( "name", name );
		}
		query.page( page );
		return jpaAccess.findPage( query );
	}

	public List<TxnDirection> findHeaderStatusByName(String name) {
		Query query = Query.from( TxnDirection.class ).where( "txnHeaderStatus='" + TxnStatus.E + "'" );
		query.append( " and name=:name" ).param( "name", name );
		return jpaAccess.find( query );
	}
}
