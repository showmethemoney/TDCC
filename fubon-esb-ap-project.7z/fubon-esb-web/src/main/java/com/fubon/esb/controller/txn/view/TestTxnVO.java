package com.fubon.esb.controller.txn.view;

import java.util.List;

import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;

public class TestTxnVO {

    private TxnFieldDefinition field;

    private List<TxnFieldTestValue> testValues;

    private List<TestTxnVO> children;

    public TxnFieldDefinition getField() {
        return field;
    }

    public void setField(TxnFieldDefinition field) {
        this.field = field;
    }

    public List<TxnFieldTestValue> getTestValues() {
        return testValues;
    }

    public void setTestValues(List<TxnFieldTestValue> testValues) {
        this.testValues = testValues;
    }

    public List<TestTxnVO> getChildren() {
        return children;
    }

    public void setChildren(List<TestTxnVO> children) {
        this.children = children;
    }

}
