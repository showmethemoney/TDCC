package com.fubon.esb.service.config;

import java.util.ArrayList;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.fubon.esb.controller.config.view.EditTxnView;
import com.fubon.esb.controller.config.view.TxnView;
import com.fubon.esb.dao.config.ConnectorDao;
import com.fubon.esb.dao.config.ServiceDao;
import com.fubon.esb.dao.config.TxnChannelDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnGroupDao;
import com.fubon.esb.dao.config.TxnRelatedDao;
import com.fubon.esb.dao.system.AdapterDao;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.TxnRelated;
import com.fubon.esb.domain.system.Adapter;

/**
 * @author Shelly @createdDate 2014-11-7
 */
@Service
public class TxnConfigService {
    @Inject
    private TxnDao txnDao;
    @Inject
    private TxnGroupDao txnGroupDao;
    @Inject
    private ServiceDao serviceDao;
    @Inject
    private ConnectorDao connectorDao;
    @Inject
    private TxnChannelDao txnChannelDao;
    @Inject
    private TxnRelatedDao txnRelatedDao;
    @Inject
    private ChannelService channelService;
    @Inject
    private AdapterDao adapterDao;

    public List<Txn> findLatestTxns(TxnView txnView, OrderBy orderBy, Page page) {
        List<Txn> txns = txnDao.findLatestTxns(txnView, orderBy, page);
        if (!txns.isEmpty()) {
            findTxnReatedInfo(txns);
        }
        return txns;
    }

    public void getRelatedInfo(Txn txn) {
        if (StringUtils.isNotBlank(txn.getGroupId())) {
            txn.setExt("txnGroup", txnGroupDao.get(txn.getGroupId()));
        }
        if (StringUtils.isNotBlank(txn.getServiceId())) {
            txn.setExt("service", serviceDao.get(txn.getServiceId()));
        }
        if (StringUtils.isNotBlank(txn.getConnectorId())) {
            txn.setExt("connector", connectorDao.get(txn.getConnectorId()));
        }
        if (StringUtils.isNotBlank(txn.getAdapterId())) {
            txn.setExt("adapter", adapterDao.get(txn.getAdapterId()));
        }
    }

    public void findTxnReatedInfo(List<Txn> txns) {
        for (Txn txn : txns) {
            getRelatedInfo(txn);
        }
    }

    public Txn getTxnById(String id) {
        return txnDao.get(id);
    }

    public Txn getTxnByIdWithRelatedInfo(String id) {
        Txn txn = txnDao.get(id);
        getRelatedInfo(txn);
        return txn;
    }

    public boolean isCodeDuplicated(String code) {
        return txnDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(Txn txn) {
        Txn updateTxn = null;
        updateTxn = getTxnById(txn.getId());
        String oldCode = updateTxn.getCode();
        return isCodeDuplicated(txn.getCode().trim()) && !oldCode.equals(txn.getCode());
    }

    public List<Txn> findMainTxn(String code, String id, Page page) {
        return txnDao.findMainTxn(code, id, page);
    }

    public List<String> findRelatedChannelCodes(String id) {
        List<String> codes = new ArrayList<String>();
        List<Channel> channels = channelService.findChannelsByTxnId(id);
        StringBuilder channelCodesBuilder = new StringBuilder();
        StringBuilder channelIdsBuilder = new StringBuilder();
        StringBuilder accessChannelCodesBuilder = new StringBuilder();
        String channelCodes = "";
        String accessChannelCodes = "";
        String channelIds = "";
        if (!channels.isEmpty()) {
            for (Channel channel : channels) {
                channelCodesBuilder.append(channel.getCode() + ",");
                channelIdsBuilder.append(channel.getId() + ",");
                if (channel.getData() != null) {
                    accessChannelCodesBuilder.append(channel.getData() + ",");
                }
            }
        }
        channelCodes = channelCodesBuilder.toString();
        channelIds = channelIdsBuilder.toString();
        if (!channelCodes.isEmpty()) {
            channelCodes = channelCodes.substring(0, channelCodes.length() - 1);
            channelIds = channelIds.substring(0, channelIds.length() - 1);
        }
        accessChannelCodes = accessChannelCodesBuilder.toString();
        if (!accessChannelCodes.isEmpty()) {
            accessChannelCodes = accessChannelCodes.substring(0, accessChannelCodes.length() - 1);
        }
        codes.add(channelIds);
        codes.add(channelCodes);
        codes.add(accessChannelCodes);
        return codes;
    }

    public List<String> getRelatedTxnCodes(String id) {
        List<String> relatedTxnCodes = new ArrayList<String>();
        List<TxnRelated> txnRelateds = txnRelatedDao.findByTxnId(id);
        StringBuilder txnRelatedIdsBuilder = new StringBuilder();
        String txnRelatedIds = "";
        StringBuilder txnRelatedCodesBuilder = new StringBuilder();
        String txnRelatedCodes = "";
        if (!txnRelateds.isEmpty()) {
            for (TxnRelated txnRelated : txnRelateds) {
                txnRelatedIdsBuilder.append(txnRelated.getRelatedTxnId() + ",");
                if (txnDao.get(txnRelated.getRelatedTxnId()) != null) {
                    txnRelatedCodesBuilder.append(txnDao.get(txnRelated.getRelatedTxnId()).getCode() + ",");
                }
            }
            txnRelatedIds = !txnRelatedIdsBuilder.toString().isEmpty() ? txnRelatedIdsBuilder.toString().substring(0, txnRelatedIdsBuilder.toString().length() - 1) : "";
            txnRelatedCodes = !txnRelatedCodesBuilder.toString().isEmpty() ? txnRelatedCodesBuilder.toString().substring(0, txnRelatedCodesBuilder.toString().length() - 1) : "";
        }
        relatedTxnCodes.add(txnRelatedIds);
        relatedTxnCodes.add(txnRelatedCodes);
        return relatedTxnCodes;
    }

    @SuppressWarnings("unchecked")
    private void updateTxnRelatedList(List<TxnRelated> newList, List<TxnRelated> oldList) {
        if (!CollectionUtils.isEqualCollection(oldList, newList)) {
            List<TxnRelated> sameList = (List<TxnRelated>) CollectionUtils.retainAll(oldList, newList);
            newList.removeAll(sameList);
            oldList.removeAll(sameList);
            txnRelatedDao.removeTxnRelatedlList(oldList); // 刪除舊的的TxnRelated
            txnRelatedDao.addTxnRelatedList(newList); // 插入新增TxnRelated
        }
    }

    @SuppressWarnings("unchecked")
    private void updateTxnChannelList(List<TxnChannel> newList, List<TxnChannel> oldList) {
        if (!CollectionUtils.isEqualCollection(oldList, newList)) {
            List<TxnChannel> sameList = (List<TxnChannel>) CollectionUtils.retainAll(oldList, newList);
            newList.removeAll(sameList);
            oldList.removeAll(sameList);
            txnChannelDao.removeTxnChannelList(oldList); // 刪除舊的的TxnChannel
            txnChannelDao.addTxnChannelList(newList); // 保存新增的TxnChannel
        }
    }

    public void updateTxnChannelAndTxnRelated(String txnId, EditTxnView editTxnView) {
        List<TxnChannel> newTxnChannelList = new ArrayList<>();
        if (editTxnView.getChannelIds() != null && editTxnView.getChannelIds().length() > 0) {
            for (String channelId : editTxnView.getChannelIds().split(",")) {
                newTxnChannelList.add(new TxnChannel(txnId, channelId));
            }
        }
        List<TxnChannel> oldTxnChannelList = txnChannelDao.findByTxnId(txnId);
        updateTxnChannelList(newTxnChannelList, oldTxnChannelList);
        List<TxnRelated> newTxnRelatedList = new ArrayList<>();
        if (editTxnView.getTxnRelatedIds() != null && editTxnView.getTxnRelatedIds().length() > 0) {
            for (String txnRelatedId : editTxnView.getTxnRelatedIds().split(",")) {
                newTxnRelatedList.add(new TxnRelated(txnId, txnRelatedId));
            }
        }
        List<TxnRelated> oldTxnRelatedList = txnRelatedDao.findByTxnId(txnId);
        updateTxnRelatedList(newTxnRelatedList, oldTxnRelatedList);
    }

    public List<Channel> findChannels(String id) {
        List<Channel> channels = new ArrayList<>();
        List<TxnChannel> txnChannels = txnChannelDao.findByTxnId(id);
        if (!txnChannels.isEmpty()) {
            for (TxnChannel txnChannel : txnChannels) {
                channels.add(channelService.getById(txnChannel.getChannelId()));
            }
        }
        return channels;
    }

    public String findchannelCode(String channelIds) {
        StringBuilder channelCodesBuilder = new StringBuilder();
        if (StringUtils.isNotBlank(channelIds)) {
            for (String channelId : channelIds.split(",")) {
                channelCodesBuilder.append(channelService.getById(channelId).getCode()).append(",");
            }
        }
        String channelCodes = channelCodesBuilder.toString();
        if (!channelCodes.isEmpty()) {
            channelCodes = channelCodes.substring(0, channelCodes.length() - 1);
        }
        return channelCodes;
    }

    public String findRelateTxnCode(String txnRelatedIds) {
        StringBuilder relatedTxnCodeBuilder = new StringBuilder();
        if (StringUtils.isNotBlank(txnRelatedIds)) {
            for (String relatedId : txnRelatedIds.split(",")) {
                Txn txn = getTxnById(relatedId);
                if (txn != null)
                    relatedTxnCodeBuilder.append(txn.getCode()).append(",");
            }
        }
        String relatedCodes = relatedTxnCodeBuilder.toString();
        if (!relatedCodes.isEmpty()) {
            relatedCodes = relatedCodes.substring(0, relatedCodes.length() - 1);
        }
        return relatedCodes;
    }

    public List<Adapter> findAdaptersByName(String adpapterName, String connectorId, Page page) {
        return adapterDao.findAdapterByName(adpapterName, connectorId, page);
    }
}
