package com.fubon.esb.controller.system.view;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.system.UserConfig;

public class UserConfigExcelVO extends AbstractExcelView {
    @Override
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("系統帳號設定");
        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 13); // 字體高度
        font.setColor(HSSFFont.COLOR_NORMAL); // 字體顏色
        font.setFontName("宋體"); // 字體
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // 寬度
        sheet.setDefaultColumnWidth(12);
        sheet.setColumnWidth(8, 20 * 256);
        sheet.setColumnWidth(6, 20 * 256);
        HSSFCellStyle cellTitleStyle = workbook.createCellStyle();
        cellTitleStyle.setFont(font);
        sheetTitle(sheet, cellTitleStyle);
        // SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
        List<UserConfig> list = (List<UserConfig>) obj.get("userConfigExcelList");
        int len = list.size();
        for (int i = 0; i < len; i++) {
            getCell(sheet, i + 1, 0).setCellValue(list.get(i).getUsername());
            getCell(sheet, i + 1, 1).setCellValue(list.get(i).getUserId());
            getCell(sheet, i + 1, 2).setCellValue(list.get(i).getSubject());
            getCell(sheet, i + 1, 3).setCellValue(list.get(i).getExtNumber());
            // getCell(sheet, i + 1, 4).setCellValue(list.get(i).getEmail());
            // getCell(sheet, i + 1, 5).setCellValue(list.get(i).getUpdatedUser());
            // String updateStr = "";
            // Date updateTime = list.get(i).getUpdatedTime();
            // if (null != updateTime) {
            // updateStr = sdf.format(updateTime);
            // }
            //
            // getCell(sheet, i + 1, 6).setCellValue(updateStr);
            // getCell(sheet, i + 1, 7).setCellValue(list.get(i).getApprovedUser());
            // Date approvedTime = list.get(i).getApprovedTime();
            // String approvedStr = "";
            // if (null != approvedTime) {
            // approvedStr = sdf.format(approvedTime);
            // }
            // getCell(sheet, i + 1, 8).setCellValue(approvedStr);
        }
        String saveFileName = "系統帳號設定" + sdf1.format(new Date()) + ".xls";
        saveFileName = URLEncoder.encode(saveFileName, "UTF-8");
        // saveFileName = StringUtils.replace(saveFileName, "+", "%20");
        exportResponseExcel(response, saveFileName);
        OutputStream ops = response.getOutputStream();
        workbook.write(ops);
        ops.flush();
        ops.close();
    }

    private void sheetTitle(HSSFSheet sheet, HSSFCellStyle cellTitleStyle) {
        // getCell(sheet, 0, 7).setCellStyle(cellTitleStyle);
        // getCell(sheet, 0, 6).setCellStyle(cellTitleStyle);
        // getCell(sheet, 0, 4).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 1).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 2).setCellStyle(cellTitleStyle);
        // getCell(sheet, 0, 5).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellStyle(cellTitleStyle);
        // getCell(sheet, 0, 8).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 3).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellValue("中文姓名");
        getCell(sheet, 0, 1).setCellValue("系統帳號");
        getCell(sheet, 0, 2).setCellValue("科別");
        getCell(sheet, 0, 3).setCellValue("分機資訊");
        // getCell(sheet, 0, 4).setCellValue("Email ");
        // getCell(sheet, 0, 5).setCellValue("修改人");
        // getCell(sheet, 0, 6).setCellValue("修改時間");
        // getCell(sheet, 0, 7).setCellValue("覆核人 ");
        // getCell(sheet, 0, 8).setCellValue("覆核時間 ");
    }

    private void exportResponseExcel(HttpServletResponse response, String filename) {
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + filename);
    }
}
