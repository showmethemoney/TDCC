package com.fubon.esb.controller.log.view;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-29
 */
public class OperationLogSearchVO {

    String startDate;
    String startHour;
    String startMinute;
    String endDate;
    String endHour;
    String endMinute;
    String level;
    String moduleFunction;
    String opUser;
    String message;
    String excludeMessage;
    Boolean flag;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getStartHour() {
        return startHour;
    }

    public void setStartHour(String startHour) {
        this.startHour = startHour;
    }

    public String getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(String startMinute) {
        this.startMinute = startMinute;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEndHour() {
        return endHour;
    }

    public void setEndHour(String endHour) {
        this.endHour = endHour;
    }

    public String getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(String endMinute) {
        this.endMinute = endMinute;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getModuleFunction() {
        return moduleFunction;
    }

    public void setModuleFunction(String moduleFunction) {
        this.moduleFunction = moduleFunction;
    }

    public String getOpUser() {
        return opUser;
    }

    public void setOpUser(String opUser) {
        this.opUser = opUser;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

	public String getExcludeMessage() {
		return excludeMessage;
	}

	public void setExcludeMessage(String excludeMessage) {
		this.excludeMessage = excludeMessage;
	}
}
