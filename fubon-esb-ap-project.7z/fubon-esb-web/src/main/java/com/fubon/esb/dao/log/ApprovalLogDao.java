package com.fubon.esb.dao.log;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.log.view.ApprovalLogSearchVO;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;

/**
 * @author Blue
 * @createdDate 2014-11-10
 */
@Repository
public class ApprovalLogDao extends JPADaoSupport<ApprovalLog> {

    /**
     * 查詢ApprovalLogList集合
     * 
     * @param page
     * @param endDate
     * @param startDate
     * 
     * */
    public List<ApprovalLog> findAllApprovalLogR(ApprovalLogSearchVO vo, Page page, Date startDate, Date endDate) {
        Query query =
                Query.from(ApprovalLog.class).append(" alm  where  exists (select 1 from " + ApprovalLog.class.getName()).append(" al, ").append(Group.class.getName()).append(" sg, ")
                        .append(Role.class.getName()).append(" ro where al.groupId=sg.id and al.roleId=ro.id");
        addCommonJql(query, vo, startDate, endDate);
        query.append(" and alm.id=al.id) ");
        query.append(" order by alm.updatedTime desc");
        query.page(page);
        List<ApprovalLog> approvalLogs = jpaAccess.findPage(query);
        if (approvalLogs == null) {
            return new ArrayList<>();
        }
        return approvalLogs;
    }

    public List<ApprovalLog> findAllApprovalLogG(ApprovalLogSearchVO vo, Page page, Date startDate, Date endDate) {
        Query query = Query.from(ApprovalLog.class).append(" alm  where  exists (select 1 from " + ApprovalLog.class.getName()).append(" al, ").append(Group.class.getName());
        query.append(" sg where al.groupId=sg.id");
        addCommonJql(query, vo, startDate, endDate);
        query.append(" and alm.id=al.id) ");
        query.append(" order by alm.updatedTime desc");
        query.page(page);
        List<ApprovalLog> approvalLogs = jpaAccess.findPage(query);
        if (approvalLogs == null) {
            return new ArrayList<>();
        }
        return approvalLogs;
    }

    public List<ApprovalLog> findAllApprovalLog(ApprovalLogSearchVO vo, Page page, Date startDate, Date endDate) {
        Query query = Query.from(ApprovalLog.class).append(" alm where 1=1");
        addCommonJql(query, vo, startDate, endDate);
        query.append(" order by alm.updatedTime desc");
        query.page(page);
        List<ApprovalLog> approvalLogs = jpaAccess.findPage(query);
        if (approvalLogs == null) {
            return new ArrayList<>();
        }
        return approvalLogs;
    }

    private void addCommonJql(Query query, ApprovalLogSearchVO vo, Date startDate, Date endDate) {
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 1) {
            query.append(" and alm.roleId =null and alm.modifyFlag!=4");
        }
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 2) {
            query.append(" and alm.roleId is not null ");
            query.append(" and (alm.modifyFlag =1 or alm.modifyFlag=3)");
        }
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 3) {
            query.append(" and alm.roleId is not null ");
            query.append(" and (alm.modifyFlag =2 or alm.modifyFlag=3)");
        }
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 4) {
            query.append(" and (alm.modifyFlag =4)");
        }
        if (StringUtils.isNotBlank(vo.getUpdatedUser())) {
            query.append(" and alm.updatedUser like :updatedUser");
            query.param("updatedUser", "%" + vo.getUpdatedUser() + "%");
        }
        if (vo.getGroupName() != null && !"".equals(vo.getGroupName())) {
            query.append(" and sg.name like :gname");
            query.param("gname", "%" + vo.getGroupName() + "%");
        }
        if (vo.getRoleName() != null && !"".equals(vo.getRoleName())) {
            query.append(" and ro.name like :rname");
            query.param("rname", "%" + vo.getRoleName() + "%");
        }
        if (vo.getStartDate() != null) {
            query.append(" and alm.updatedTime >= :start");
            query.param("start", startDate);
        }
        if (vo.getEndDate() != null) {
            query.append(" and alm.updatedTime <= :end");
            query.param("end", endDate);
        }
    }

    public ApprovalLog getApprovalLogDetail(String id) {
        return jpaAccess.get(ApprovalLog.class, id);
    }

}
