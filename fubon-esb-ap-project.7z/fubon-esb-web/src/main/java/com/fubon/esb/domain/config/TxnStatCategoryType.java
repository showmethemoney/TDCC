package com.fubon.esb.domain.config;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-19
 */
public enum TxnStatCategoryType {
    
    /**全部*/
    A("A", "txnStat_category_a"),
    
    /**依主機別*/
    H("H", "txnStat_category_h"),
    
    /**依Channel別*/
    C("C", "txnStat_category_c"),
    
    /**依交易代碼別*/
    T("T", "txnStat_category_t"),
    
    /**依業務群組別*/
    G("G", "txnStat_category_g"),
    
    /**依ErrorCode別*/
    E("E", "txnStat_category_e"),
    
    /**依回應時間別*/
    D("D", "txnStat_category_d"),
    
    /**依Channel+交易代碼別*/
    CT("CT", "txnStat_category_ct"),
    
    /**依Channel版塊別*/
    CB("CB", "txnStat_category_cb"),
    
    /**依交易群版塊別*/
    GB("GB", "txnStat_category_gb"),
    
    /**應用系統代號統計*/
    U("U", "txnStat_category_u");
    
    
    private String category;

    private String name;

    private TxnStatCategoryType(String category, String name) {
        this.category = category;
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return category;
    }

}
