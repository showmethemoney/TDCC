package com.fubon.esb.service.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnGroupDao;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnGroup;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-6
 */

@Service
public class HostService {

    @Inject
    private HostDao hostDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private TxnGroupDao txnGroupDao;
    @Inject
    private TxnGroupService txnGroupService;
    @Inject
    private TxnDao txnDao;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private HostLogMailService hostLogMailService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private ConfigChangeService configChangeService;

    public List<Host> findLatestHosts(String code, String name, ConfigActiveStatus status, Page page) {
        return hostDao.findLatestHosts(code, name, status, page);
    }

    @Transactional
    public String saveOrUpdateHost(Host host, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        String currentUser = loginContext.loginedUserId();
        String hostId;
        if (StringUtils.isNotBlank(host.getId())) {
            Host oldHost = null == getHostById(host.getId()) ? new Host() : getHostById(host.getId());
            String oldCode = StringUtils.isBlank(oldHost.getCode()) ? "" : oldHost.getCode();
            String oldName = StringUtils.isBlank(oldHost.getName()) ? "" : oldHost.getName();
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            hostLogMailService.createMailRelatedLog(host, oldHost, currentUser, effectTime);

            hostId = updateHost(host, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改主機設定。主機代號：" + oldCode + "，主機名稱：" + oldName, LogType.SYS_CFG_HOST);
        } else {
            host.setId(null);

            hostId = saveHost(host, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增主機設定。主機代號：" + host.getCode() + "，主機名稱：" + host.getName(), LogType.SYS_CFG_HOST);
        }
        return hostId;
    }

    public String saveHost(Host host, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        String oldCode = StringUtils.isBlank(host.getCode()) ? "" : host.getCode();
        if (isCodeDuplicated(oldCode.trim())) {
            throw new DuplicatedException("已存在相同代號！");
        }
        if (EffectType.B.equals(host.getEffectType())) {
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            host.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            host.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(host.getEffectType())) {
            host.setEffectTime(null);
            host.setMainId(null);
        }
        // 建立者
        host.setCreatedUser(loginContext.loginedUserId());
        host.setCreatedTime(new Date());

        String addStr = "主機設定新增，新增者：" + loginContext.loginedUserId() + "\r";
        addStr += "新增內容：\r";
        addStr += "主機代號：" + host.getCode() + "\r";
        addStr += "主機名稱：" + host.getName() + "\r";
        addStr += "使用狀態：" + ("A".equals(host.getStatus().name()) ? "啟用" : "停用") + "\r";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        addStr += "生效類型：" + ("I".equals(host.getEffectType().name()) ? "即時生效" : ("預約生效\r預約生效時間：" + sdf.format(stringToDate(effectDate, effectHour, effectMinute)))) + "\r";
        configChangeService.sendMailRequest("主機設定新增", addStr);
        hostDao.save(host);
        // configChangeService.sendChangeEvent(ConfigType.CFG_HOST,
        // host.getId());
        return host.getId();
    }

    public String updateHost(Host host, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        setProperty(host);
        if (isCodeDuplicated(host)) {
            throw new DuplicatedException("已存在相同代號！");
        }
        if (EffectType.B.equals(host.getEffectType())) {
            Date effectTime = stringToDate(effectDate, effectHour, effectMinute);
            host.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            if (host.getMainId() == null) { // 正本生效-->復制修改後的對象作為副本，正本保持不變
                Host copyHost = new Host(); // 新建副本
                BeanUtils.copyProperties(host, copyHost, "id");
                copyHost.setMainId(host.getId());
                hostDao.save(copyHost);
                // configChangeService.sendChangeEvent(ConfigType.CFG_HOST,
                // copyHost.getId());
                return copyHost.getId();
            } else { // 副本預約生效-->直接修改
                hostDao.update(host);
                // configChangeService.sendChangeEvent(ConfigType.CFG_HOST,
                // host.getId());
                return host.getId();
            }
        } else if (EffectType.I.equals(host.getEffectType())) {
            host.setEffectTime(null);
            if (host.getMainId() == null || "0".equals(host.getMainId())) { // 正本立即生效-->直接修改
                host.setMainId(null);
                hostDao.update(host);
                // configChangeService.sendChangeEvent(ConfigType.CFG_HOST,
                // host.getId());
                return host.getId();
            } else { // 副本有指向的正本
                Host mainHost = getHostById(host.getMainId());
                BeanUtils.copyProperties(host, mainHost, "id");
                mainHost.setMainId(null);
                hostDao.update(mainHost);
                hostDao.delete(hostDao.get(host.getId())); // 刪除副本
                // configChangeService.sendChangeEvent(ConfigType.CFG_HOST,
                // mainHost.getId());
                return mainHost.getId();
            }
        } else
            return null;
    }

    public void setProperty(Host host) {
        Host persiHost = getHostById(host.getId());
        host.setCreatedTime(persiHost.getCreatedTime());
        host.setCreatedUser(persiHost.getCreatedUser());
        host.setMainId(persiHost.getMainId());
        host.setUpdatedUser(loginContext.loginedUserId());
        host.setUpdatedTime(new Date());
    }

    public Date stringToDate(String effectDate, String effectHour, String effectMinute) {
        Date effectTime = null;
        try {
        	System.out.println("effectDate= "+effectDate+" effectHour="+effectHour+" effectMinute="+effectMinute);
            effectTime = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(effectDate + " " + effectHour + ":" + effectMinute);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return effectTime;
    }

    public Host getHostById(String id) {
        return hostDao.get(id);
    }

    public Host getHostCodeByTxnId(String txnId) {
        Host host = null;
        Txn txn = txnDao.get(txnId);
        String groupId = txn.getGroupId();
        if (StringUtils.isNotBlank(groupId)) {
            String hostId = txnGroupDao.get(groupId).getHostId();
            if (hostId != null) {
                host = hostDao.getById(hostId);

            }
        }
        return host;
    }

    public boolean isCodeDuplicated(String code) {
        return hostDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(Host host) {
        Host updateHost = getHostById(host.getId());
        String oldCode = updateHost.getCode();
        String code = StringUtils.isBlank(host.getCode()) ? "" : host.getCode();
        return hostDao.isDuplicatedByCode(code.trim()) && !oldCode.equals(code);
    }

    public String findTxnCodes(String id) {
        String txnCodes = "";
        String mainId = getHostById(id).getMainId();
        List<TxnGroup> txnGroups = txnGroupDao.findTxnGroupByHostId((mainId != null && !"0".equals(mainId)) ? mainId : id);
        if (!txnGroups.isEmpty()) {
            txnCodes = txnGroupService.getTxnCodes(txnGroups.get(0).getId());
        }
        return txnCodes;
    }

    @Transactional
    public void deleteHost(String id) {
        hostDao.updateStatus(id);
    }

    // 是否有关联Host
    public boolean isRelatedHost(String id, StringBuilder message) {
        List<TxnGroup> txnGroups = hostDao.isRelatedHost(id);
        if (!txnGroups.isEmpty()) {
            for (TxnGroup txnGroup : txnGroups) {
                message.append(txnGroup.getCode()).append(",");
            }
        }
        return !txnGroups.isEmpty();
    }
}
