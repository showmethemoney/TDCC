package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.ReturnCode;

/**
 * @author Qigers
 * @createdDate 2014-11-17
 */

@Repository
public class ReturnCodeDao extends JPADaoSupport<ReturnCode> {

    public List<ReturnCode> findReturnCodes(String groupCode, String returnCode, Page page) {
        Query query = Query.from(ReturnCode.class).append(" where 1=1");
        if (StringUtils.isNotBlank(groupCode)) {
            query.append(" and groupCode like :groupCode ");
            query.setParam("groupCode", "%" + groupCode + "%");
        }
        if (StringUtils.isNotBlank(returnCode)) {
            query.append(" and returnCode = :returnCode");
            query.setParam("returnCode", returnCode);
        }
        query.page(page).orderBy("id");
        return jpaAccess.findPage(query);
    }

    public ReturnCode getlById(String id) {
        return jpaAccess.get(ReturnCode.class, id);
    }

    public void removeReturnCode(String id) {
        Query query = Query.create("delete from " + ReturnCode.class.getName() + " where id = :id").param("id", id);
        jpaAccess.update(query);
    }

    public void addReturnCode(ReturnCode returnCode) {
        jpaAccess.save(returnCode);
    }

    public void updateReturnCode(ReturnCode returnCode) {
        jpaAccess.update(returnCode);
    }

    public boolean idDuplicate(String id) {
        Query query = Query.from(ReturnCode.class).where("ID = :id").param("id", id);
        return !jpaAccess.find(query).isEmpty();
    }

    public boolean codeDuplicate(String groupCode, String returnCode) {
        Query query = Query.from(ReturnCode.class).where("groupCode = :groupCode").param("groupCode", groupCode).append(" and returnCode = :returnCode").param("returnCode", returnCode);
        return !jpaAccess.find(query).isEmpty();
    }

    public List<String> searchReturnCodes(String key) {
        Query query = Query.create("select distinct returnCode from " + ReturnCode.class.getName());
        query.where(" returnCode like :returnCode").param("returnCode", key + "%");
        query.orderBy("returnCode");
        return jpaAccess.find(query);
    }
}
