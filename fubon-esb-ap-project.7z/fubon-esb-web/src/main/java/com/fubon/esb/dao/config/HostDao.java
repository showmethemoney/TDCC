package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.TxnGroup;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-4
 */
@Repository
public class HostDao extends JPADaoSupport<Host> {

    public Host getById(String id) {
        return jpaAccess.get(Host.class, id);
    }

    public List<Host> findMainHosts(String code, Page page) {
        Query query = Query.from(Host.class).append(" host where host.mainId is null and host.status=:status").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(code)) {
            query.append(" and host.code = :code ");
            query.setParam("code", code.trim());
        }
        query.orderBy("host.code").page(page);
        return jpaAccess.findPage(query);
    }

    public List<Host> findLatestHosts(String code, String name, ConfigActiveStatus status, Page page) {
        Query query = Query.from(Host.class).append(" host where not exists(select h from ").append(Host.class).append(" h where h.mainId = host.id) ");
        if (StringUtils.isNotBlank(code)) {
            query.append(" and host.code = :code");
            query.setParam("code", code.trim());
        }
        if (StringUtils.isNotBlank(name)) {
            query.append(" and host.name like :name");
            query.setParam("name", "%" + name + "%");
        }
        // if (status == null) {
        // query.append(" and host.status != :status");
        // query.setParam("status", ConfigActiveStatus.D);
        // }
        if (status != null) {
            query.append(" and host.status = :status");
            query.setParam("status", status);
        }
        query.orderBy("createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(Host.class).append(" host where not exists(select h from ").append(Host.class).append(" h where h.mainId = host.id) ").append(" and host.code=:code").param("code", code);
        query.append(" and host.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();

    }

    public List<String> searchMainHostCodes(String key) {
        Query query = Query.create("select distinct code from " + Host.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.append(" and mainId is null and host.status=:status").param("status", ConfigActiveStatus.A);
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchHostCodes(String key) {
        Query query = Query.create("select distinct code from " + Host.class.getName() + " host");
        query.append(" where not exists(select h from ").append(Host.class).append(" h where h.mainId = host.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        Host host = jpaAccess.get(Host.class, id);
        if (StringUtils.isNotBlank(host.getMainId()) && !"0".equals(host.getMainId())) { // 如果是帶有正本的副本
            jpaAccess.delete(host); // 刪掉副本
            jpaAccess.update(Query.create("update ").append(Host.class).append(" host set host.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id")
                    .param("id", host.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(Host.class).append(" host set host.status = :status").param("status", ConfigActiveStatus.D).append(" where id = :id").param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(關聯主機)
    public List<TxnGroup> isRelatedHost(String id) {
        Query relHost = Query.create("select txnGroup  from " + TxnGroup.class.getName() + " txnGroup");
        relHost.append(" where txnGroup.hostId = :id ").param("id", id);
        return jpaAccess.find(relHost);
    }

}
