package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.Workstation;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-31
 */
@Repository
public class WorkstationDao extends JPADaoSupport<Workstation> {

    public List<Workstation> findBychannelId(String channelId) {
        Query query = Query.from(Workstation.class).where("channelId=:channelId").param("channelId", channelId);
        return jpaAccess.find(query);
    }

    public void saveWorkstation(String channelId, String[] workstationCodes) {
        if (workstationCodes != null && workstationCodes.length > 0) {
            for (String code : workstationCodes) {
                if (StringUtils.isNotBlank(code)) {
                    Workstation workstation = new Workstation(channelId, code);
                    jpaAccess.save(workstation);
                }
            }
        }

    }

    public void addWorkstationList(List<Workstation> list) {
        for (Workstation wk : list) {
            jpaAccess.save(wk);
        }
    }

    public void removeWorkstationList(List<Workstation> list) {
        for (Workstation wk : list) {
            jpaAccess.delete(wk);
        }
    }

    public void deleteByChannelId(String id) {
        jpaAccess.update(Query.create("delete " + Workstation.class.getName() + " where channelId=:channelId").param("channelId", id));
    }

    public List<Workstation> findByWorkstationCode(String code) {
        Query query = Query.from(Workstation.class).where("code=:code").param("code", code);
        return  jpaAccess.find(query);
    }
    
    public List<String> searchWorkstationCodes(String key) {
        Query query = Query.create("select distinct code from " + Workstation.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }
    
    public List<String> findWorkstationCodesByChannelId(String channelId) {
        Query query = Query.create("select code from " + Workstation.class.getName());
        query.where("channelId = :channelId").param("channelId", channelId);
        query.orderBy("code");
        return jpaAccess.find(query);
    }
    
}
