package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum DataType {

    X("txn.datatype.x"), N("txn.datatype.n"), H("txn.datatype.h");

    private String propKey;

    DataType(String propKey) {
        this.propKey = propKey;
    }

    public String getPropKey() {
        return propKey;
    }

}
