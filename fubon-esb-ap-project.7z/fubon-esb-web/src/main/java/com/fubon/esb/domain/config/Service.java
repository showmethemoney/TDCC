package com.fubon.esb.domain.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;


/**
 * Service設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_SERVICE")
public class Service extends ConfigBaseEntity {

    /** 代號 */
    @NotEmpty
    @Column(name = "SERVICE_CODE")
    private String code;

    /** 名稱 */
    @Column(name = "SERVICE_NAME")
    @NotEmpty
    private String name;

    /** 使用狀態 **/
    @Column(name = "SERVICE_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private ConfigActiveStatus status;

    /** 版本號 */
    @Column(name = "VERSION")
    private String version;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
