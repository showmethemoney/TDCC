package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.TxnGroupView;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnGroup;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.TxnGroupService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-4
 */
@Controller
@RequestMapping("/txnGroup")
public class TxnGroupController extends BaseController {

    @Inject
    private TxnGroupService txnGroupService;
    @Inject
    private LoginContext loginContext;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSerachTxnGroup")
    public String viewTxnGroupList(Model model) {
        return "/config/viewTxnGroupList";
    }

    @RequirePermission(value = "050401")
    @RequestMapping("/viewTxnGroupList")
    public String viewTxnGroupList(Model model, TxnGroupView viewTxnGroup, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<TxnGroup> txnGroups = txnGroupService.findLatestTxnGroup(viewTxnGroup, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            txnGroups = txnGroupService.findLatestTxnGroup(viewTxnGroup, page);
        }
        model.addAttribute("txnGroups", txnGroups);
        model.addAttribute("page", page);
        model.addAttribute("viewTxnGroup", viewTxnGroup);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        return "/config/viewTxnGroupList";
    }

    @RequirePermission(value = {"050402", "050403"})
    @RequestMapping("/viewTxnGroup")
    public String viewTxnGroup(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) { // 修改
            isAdd = false;
            TxnGroup txnGroup = txnGroupService.getById(id);
            String txnCodes = txnGroupService.getTxnCodes(id);
            model.addAttribute("txnGroup", txnGroup);
            model.addAttribute("txnCodes", txnCodes);
        }
        model.addAttribute("isAdd", isAdd);
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewTxnGroup";
    }

    
    @RequestMapping("refreshTxnGroup")
    @ResponseBody
    public Object refreshTxnGroup(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
    	
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_TXN_GROUP, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    
    @RequestMapping("/saveOrUpdateTxnGroup")
    @ResponseBody
    public ResultView saveOrUpdateTxnGroup(@Valid TxnGroup txnGroup, String effectDate, String effectHour, String effectMinute) {
        try {
            String txnGroupId = txnGroupService.saveOrUpdateTxnGroup(txnGroup, effectDate, effectHour, effectMinute);
            configChangeService.sendChangeEvent(ConfigType.CFG_TXN_GROUP, txnGroupId);
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/txnGroup/viewTxnGroupList");
    }

    @RequestMapping("/viewHostCodeList")
    public String viewHostCodeList(Model model, @RequestParam(required = false) String hostCode, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Host> hosts = txnGroupService.findMainHosts(hostCode, page);
        model.addAttribute("hosts", hosts);
        model.addAttribute("page", page);
        model.addAttribute("hostCode", hostCode);
        return "/config/include/viewMainHostCodeList";
    }

    @RequestMapping("/findTxns")
    @ResponseBody
    public Map<String, Object> findTxns(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Txn> txns = txnGroupService.findTxnsByTxnGroupId(id);
        result.put("flag", true);
        result.put("txns", txns);
        return result;
    }

    @RequestMapping("/findMainTxnGroup")
    public String findMainTxnGroup(Model model, String code, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<TxnGroup> txnGroups = txnGroupService.findMainTxnGroup(code, page);
        model.addAttribute("code", code);
        model.addAttribute("page", page);
        model.addAttribute("txnGroups", txnGroups);
        return "/config/include/viewMainTxnGroupList";
    }

    @ResponseBody
    @RequestMapping({"/findMainTxnGroupCodes"})
    public Object findTxnMainGroupCodes(@RequestParam String key) {
        return autoQueryService.searchMainTxnGroupCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findTxnGroupCodes"})
    public Object findTxnGroupCodes(@RequestParam String key) {
        return autoQueryService.searchTxnGroupCodes(key);
    }

    @RequirePermission(value = "050401")
    @RequestMapping("/viewTxnGroupDetail")
    public String viewTxnGroupDetail(Model model, @RequestParam String id) {
        if (StringUtils.isNotBlank(id)) {
            TxnGroup txnGroup = txnGroupService.getById(id);
            String txnCodes = txnGroupService.getTxnCodes(id);
            model.addAttribute("txnGroup", txnGroup);
            model.addAttribute("txnCodes", txnCodes);
        }
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewTxnGroupDetail";
    }

    // 刪除
    @RequestMapping("/deleteTxnGroup")
    @ResponseBody
    public Object deleteTxnGroup(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = txnGroupService.isRelatedTxnGroup(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + (relateMessage.isEmpty() ? "" : "," + messages.getMessage("config.txn.relatedTxn") + relateMessage));
        } else {
            txnGroupService.deleteTxnGroup(id);
            flag = true;
            result.put("flag", flag);
        }
        return result;
    }
}
