package com.fubon.esb.controller.txn.view;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.txn.DataType;
import com.fubon.esb.domain.txn.JustifyType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;

public class ExportOneHeaderExcel extends AbstractExcelView {
    @Override
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("Header");
        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 13); // 字體高度
        font.setColor(HSSFFont.COLOR_NORMAL); // 字體顏色
        font.setFontName("宋體"); // 字體
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // 寬度
        sheet.setDefaultColumnWidth(12);
        // sheet.setColumnWidth(8, 20 * 256);
        // sheet.setColumnWidth(6, 20 * 256);
        HSSFCellStyle cellTitleStyle = workbook.createCellStyle();
        cellTitleStyle.setFont(font);
        sheetTitle(sheet, cellTitleStyle);
        // SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
        TxnDirection txnDirection = (TxnDirection) obj.get("txnDirection");
        List<TxnFieldDefinition> txnFieldDefinitionList = (List<TxnFieldDefinition>) obj.get("txnFieldDefinitionList");
        int len = txnFieldDefinitionList.size();
        for (int i = 0; i < len; i++) {
            getCell(sheet, i + 1, 0).setCellValue(txnFieldDefinitionList.get(i).getCode());
            getCell(sheet, i + 1, 1).setCellValue(txnFieldDefinitionList.get(i).getName());
            getCell(sheet, i + 1, 2).setCellValue(
                    txnFieldDefinitionList.get(i).getDataType() == DataType.X ? "字串" : txnFieldDefinitionList.get(i).getDataType() == DataType.N
                            ? "數值"
                            : txnFieldDefinitionList.get(i).getDataType() == DataType.H ? "Hex Code" : "");
            getCell(sheet, i + 1, 3).setCellValue(String.valueOf(txnFieldDefinitionList.get(i).getLength() != null ? txnFieldDefinitionList.get(i).getLength() : ""));
            getCell(sheet, i + 1, 4).setCellValue(String.valueOf(txnFieldDefinitionList.get(i).getScale() != null ? txnFieldDefinitionList.get(i).getScale() : ""));
            getCell(sheet, i + 1, 5).setCellValue(txnFieldDefinitionList.get(i).getDefaultV());
            getCell(sheet, i + 1, 6).setCellValue(txnFieldDefinitionList.get(i).getPadChar());
            getCell(sheet, i + 1, 7).setCellValue(txnFieldDefinitionList.get(i).getJustify() == JustifyType.L ? "左對齊" : txnFieldDefinitionList.get(i).getJustify() == JustifyType.R ? "右對齊" : "");
            getCell(sheet, i + 1, 8).setCellValue(txnFieldDefinitionList.get(i).getIncludeChinese() == 1 ? "是" : txnFieldDefinitionList.get(i).getIncludeChinese() == 0 ? "否" : "");
            getCell(sheet, i + 1, 9).setCellValue(txnFieldDefinitionList.get(i).getOptional() == 0 ? "是" : txnFieldDefinitionList.get(i).getOptional() == 1 ? "否" : "");
        }
        String saveDirectionName = txnDirection.getName() + ".xls";
        String saveHeaderExcelName = URLEncoder.encode(saveDirectionName, "UTF-8");
        saveHeaderExcelName = StringUtils.replace(saveHeaderExcelName, "+", "%20");
        exportResponseExcel(response, saveHeaderExcelName);
        OutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        outputStream.flush();
        outputStream.close();
    }

    private void sheetTitle(HSSFSheet sheet, HSSFCellStyle cellTitleStyle) {
        getCell(sheet, 0, 7).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 6).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 4).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 1).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 2).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 5).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 8).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 9).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 3).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellValue("Field ID");
        getCell(sheet, 0, 1).setCellValue("名稱");
        getCell(sheet, 0, 2).setCellValue("資料型態 ");
        getCell(sheet, 0, 3).setCellValue("長度");
        getCell(sheet, 0, 4).setCellValue("小數位數");
        getCell(sheet, 0, 5).setCellValue("預設值");
        getCell(sheet, 0, 6).setCellValue("補充字元 ");
        getCell(sheet, 0, 7).setCellValue("對齊方式 ");
        getCell(sheet, 0, 8).setCellValue("是否中文");
        getCell(sheet, 0, 9).setCellValue("是否必填");
    }

    private void exportResponseExcel(HttpServletResponse response, String filename) {
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + filename);
    }
}
