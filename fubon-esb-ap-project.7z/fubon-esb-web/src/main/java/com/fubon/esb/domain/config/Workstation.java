package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * WorkStation設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_WORKSTATION")
public class Workstation implements Serializable {

    private static final long serialVersionUID = -7139440035700620994L;

    /** 所屬Channel */
    @Id
    @Column(name = "CHANNEL_ID")
    private String channelId;

    /** WORKSTATION_ID */
    @Id
    @Column(name = "WORKSTATION_CODE")
    private String code;

    public Workstation() {
        super();
    }

    public Workstation(String channelId, String code) {
        super();
        this.channelId = channelId;
        this.code = code;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((channelId == null) ? 0 : channelId.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Workstation other = (Workstation) obj;
        if (channelId == null) {
            if (other.channelId != null)
                return false;
        } else if (!channelId.equals(other.channelId))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        return true;
    }

}
