package com.fubon.esb.domain.job;

public enum RunType {

    A("自動"), M("手動");

    private final String desc;

    private RunType(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }
}
