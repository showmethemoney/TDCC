package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 業務群組
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_TXN_GROUP")
public class TxnGroup extends ConfigBaseEntity implements Serializable {

    /** 代號 */
    @NotEmpty
    @Column(name = "GROUP_CODE")
    private String code;

    /** 名稱 */
    @Column(name = "GROUP_NAME")
    @NotEmpty
    private String name;

    /** 使用狀態 **/
    @Column(name = "GROUP_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private ConfigActiveStatus status;

    /** 關聯主機 */
    @Column(name = "HOST_ID")
    private String hostId;

    public String getHostId() {
        return hostId;
    }

    public void setHostId(String hostId) {
        this.hostId = hostId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

}
