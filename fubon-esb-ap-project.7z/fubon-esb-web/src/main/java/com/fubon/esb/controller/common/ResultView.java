package com.fubon.esb.controller.common;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author james
 * @createdDate 2014-11-6
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "result-view")
public class ResultView {

    @XmlElement(name = "status")
    private ResultStatus status;

    @XmlElement(name = "redirectUrl")
    private String redirectUrl;

    @XmlElementWrapper(name = "errorMessages")
    @XmlElement(name = "errorMessage")
    private List<String> errorMessages;

    public static ResultView success(String redirectUrl) {
        ResultView resultView = new ResultView();
        resultView.setStatus(ResultStatus.SUCCESS);
        resultView.setRedirectUrl(redirectUrl);
        return resultView;
    }

    public static ResultView error(List<String> errorMessages) {
        ResultView resultView = new ResultView();
        resultView.setStatus(ResultStatus.ERROR);
        resultView.setErrorMessages(errorMessages);
        return resultView;
    }

    public ResultStatus getStatus() {
        return status;
    }

    public void setStatus(ResultStatus status) {
        this.status = status;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

}
