package com.fubon.esb.service.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.TxnGroupView;
import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.TxnGroupDao;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.config.TxnGroup;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-4
 */
@Service
public class TxnGroupService {

    @Inject
    private TxnGroupDao txnGroupDao;
    @Inject
    private HostDao hostDao;
    @Inject
    private TxnDao txnDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private Messages messages;
    @Inject
    private TxnGroupConfigChangeMail txnGroupConfigChangeMail;

    public List<TxnGroup> findLatestTxnGroup(TxnGroupView viewTxnGroup, Page page) {
        List<TxnGroup> txnGroups = txnGroupDao.findLatestTxnGroup(viewTxnGroup, page);
        if (!txnGroups.isEmpty()) {
            findTxnGroupHostCodeInfo(txnGroups);
        }
        return txnGroups;
    }

    public void findTxnGroupHostCodeInfo(List<TxnGroup> txnGroups) {
        for (TxnGroup txnGroup : txnGroups) {
            if (txnGroup.getHostId() != null) {
                Host host = hostDao.getById(txnGroup.getHostId());
                if (host != null) {
                    txnGroup.setData(host.getCode());
                }
            }
        }
    }

    public List<TxnGroup> findMainTxnGroup(String code, Page page) {
        List<TxnGroup> txnGroups = txnGroupDao.findMainTxnGroup(code, page);
        if (!txnGroups.isEmpty()) {
            findTxnGroupHostCodeInfo(txnGroups);
        }
        return txnGroups;
    }

    @Transactional
    public String saveOrUpdateTxnGroup(TxnGroup txnGroup, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        String txnGroupId;
        if (StringUtils.isNotBlank(txnGroup.getId())) {
            TxnGroup oldTxnGroup = getById(txnGroup.getId());
            String oldCode = oldTxnGroup.getCode();
            String oldName = oldTxnGroup.getName();
            txnGroupId = updateTxnGroup(txnGroup, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改業務群組,業務群組代號：" + oldCode + "，業務群組名稱：" + oldName, LogType.SYS_CFG_TXN_GROUP);
        } else {
            txnGroup.setId(null);
            txnGroupId = saveTxnGroup(txnGroup, effectDate, effectHour, effectMinute);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增業務群組,業務群組代號：" + txnGroup.getCode() + "，業務群組名稱：" + txnGroup.getName(), LogType.SYS_CFG_TXN_GROUP);
        }
        return txnGroupId;
    }

    public String saveTxnGroup(TxnGroup txnGroup, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        if (isCodeDuplicated(txnGroup.getCode().trim())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(txnGroup.getEffectType())) {
            Date effectTime = timeZoneService.getTZDateByService(stringToDate(effectDate, effectHour, effectMinute));
            txnGroup.setEffectTime(effectTime);
            txnGroup.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(txnGroup.getEffectType())) {
            txnGroup.setEffectTime(null);
            txnGroup.setMainId(null);
        }
        // 建立者
        txnGroup.setCreatedUser(loginContext.loginedUserId());
        txnGroup.setCreatedTime(new Date());
        txnGroupDao.save(txnGroup);
        txnGroupConfigChangeMail.compareTxnGroupAdd(true, txnGroup);
        return txnGroup.getId();
    }

    public String updateTxnGroup(TxnGroup txnGroup, String effectDate, String effectHour, String effectMinute) throws DuplicatedException {
        setProperty(txnGroup);
        if (isCodeDuplicated(txnGroup)) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (EffectType.B.equals(txnGroup.getEffectType())) {
            Date effectTime = timeZoneService.getTZDateByService(stringToDate(effectDate, effectHour, effectMinute));
            txnGroup.setEffectTime(effectTime);
            if (txnGroup.getMainId() == null) { // 正本生效-->復制修改後的對象作為副本，正本保持不變
                TxnGroup copyTxnGroup = new TxnGroup(); // 新建副本
                BeanUtils.copyProperties(txnGroup, copyTxnGroup, "id");
                copyTxnGroup.setMainId(txnGroup.getId());
                txnGroupConfigChangeMail.compareTxnGroupUpdate(getById(txnGroup.getId()), copyTxnGroup);
                txnGroupDao.save(copyTxnGroup);
                return copyTxnGroup.getId();
            } else { // 副本預約生效-->直接修改
                txnGroupConfigChangeMail.compareTxnGroupUpdate("0".equals(txnGroup.getMainId()) ? getById(txnGroup.getId()) : getById(txnGroup.getMainId()), txnGroup);
                txnGroupDao.update(txnGroup);
                return txnGroup.getId();
            }
        } else if (EffectType.I.equals(txnGroup.getEffectType())) {
            txnGroup.setEffectTime(null);
            if (txnGroup.getMainId() == null || "0".equals(txnGroup.getMainId())) { // 正本立即生效-->直接修改
                txnGroup.setMainId(null);
                txnGroupConfigChangeMail.compareTxnGroupUpdate(getById(txnGroup.getId()), txnGroup);
                txnGroupDao.update(txnGroup);
                return txnGroup.getId();
            } else { // 副本有指向的正本
                TxnGroup mainTxnGroup = getById(txnGroup.getMainId());
                TxnGroup originTxngroup = new TxnGroup();
                BeanUtils.copyProperties(mainTxnGroup, originTxngroup, "id");
                BeanUtils.copyProperties(txnGroup, mainTxnGroup, "id");
                mainTxnGroup.setMainId(null);
                txnGroupConfigChangeMail.compareTxnGroupUpdate(originTxngroup, mainTxnGroup);
                txnGroupDao.update(mainTxnGroup);
                txnGroupDao.delete(txnGroupDao.get(txnGroup.getId())); // 刪除副本
                return mainTxnGroup.getId();
            }
        } else
            return null;
    }

    public void setProperty(TxnGroup txnGroup) {
        TxnGroup persiTxnService = getById(txnGroup.getId());
        txnGroup.setCreatedTime(persiTxnService.getCreatedTime());
        txnGroup.setCreatedUser(persiTxnService.getCreatedUser());
        txnGroup.setMainId(persiTxnService.getMainId());
        txnGroup.setUpdatedUser(loginContext.loginedUserId());
        txnGroup.setUpdatedTime(new Date());
    }

    public TxnGroup getById(String id) {
        TxnGroup txnGroup = null;
        txnGroup = txnGroupDao.get(id);
        Host host = hostDao.getById(txnGroup.getHostId());
        if (host != null) {
            txnGroup.setData(host.getCode());
        }
        return txnGroup;
    }

    public String getTxnCodes(String txnGroupId) {
        String mainId = getById(txnGroupId).getMainId();
        List<Txn> txns = txnDao.findTxnsByGroupId((mainId != null && !"0".equals(mainId)) ? mainId : txnGroupId);
        StringBuilder txnCodeBuffer = new StringBuilder();
        String txnCodes = "";
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                txnCodeBuffer.append(txn.getCode() + ",");
            }
            txnCodes = txnCodeBuffer.toString().substring(0, txnCodeBuffer.toString().length() - 1);
        }
        return txnCodes;
    }

    public List<Host> findMainHosts(String hostCode, Page page) {
        return hostDao.findMainHosts(hostCode, page);
    }

    public Date stringToDate(String effectDate, String effectHour, String effectMinute) {
        Date effectTime = null;
        try {
            effectTime = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(effectDate + " " + effectHour + ":" + effectMinute);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return effectTime;
    }

    public boolean isCodeDuplicated(String code) {
        return txnGroupDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(TxnGroup txnGroup) {
        TxnGroup updateTxnGroup = null;
        updateTxnGroup = getById(txnGroup.getId());
        String oldCode = updateTxnGroup.getCode();
        return txnGroupDao.isDuplicatedByCode(txnGroup.getCode().trim()) && !oldCode.equals(txnGroup.getCode());

    }

    public List<Txn> findTxnsByTxnGroupId(String id) {
        String mainId = getById(id).getMainId();
        return txnDao.findTxnsByGroupId((mainId != null && !"0".equals(mainId)) ? mainId : id);
    }

    @Transactional
    public void deleteTxnGroup(String id) {
        txnGroupDao.updateStatus(id);
    }

    // 是否有关联主機和交易
    public boolean isRelatedTxnGroup(String id, StringBuilder message) {
        List<Txn> txns = txnGroupDao.isTxnGroupRelatedTxn(id);
        List<Host> hosts = txnGroupDao.isTxnGroupRelateHost(id);
        if (!txns.isEmpty()) {
            for (Txn txn : txns) {
                if (id.equals(txn.getGroupId())) {
                    message.append(txn.getCode()).append(",");
                }
            }
        }
        return !txns.isEmpty() || !hosts.isEmpty();
    }
}
