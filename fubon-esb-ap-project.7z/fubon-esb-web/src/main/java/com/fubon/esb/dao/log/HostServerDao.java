package com.fubon.esb.dao.log;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.Query;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.log.HostStatus;
import com.fubon.esb.domain.log.ServerStatus;

/**
 * @author Qigers
 * @createdDate 2014-11-21
 */
@Repository
public class HostServerDao extends LogDBJPADaoSupport<HostStatus> {

    public Object findHostStatusList() {
        StringBuilder jql = new StringBuilder();
        jql.append("from " + HostStatus.class.getName());
        Query query = Query.create(jql.toString());
        List<HostStatus> hostStatusList = jpaAccess.find(query);
        if (hostStatusList == null) {
            return new ArrayList<>();
        }
        return hostStatusList;
    }

    public Object findServerStatusList() {
        StringBuilder jql = new StringBuilder();
        jql.append("from " + ServerStatus.class.getName());
        Query query = Query.create(jql.toString());
        List<ServerStatus> serverStatusList = jpaAccess.find(query);
        if (serverStatusList == null) {
            return new ArrayList<>();
        }
        return serverStatusList;
    }
}
