package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum JustifyType {

    L("txn.justifytype.l"), R("txn.justifytype.r");

    private String propKey;

    JustifyType(String propKey) {
        this.propKey = propKey;
    }

    public String getPropKey() {
        return propKey;
    }

}
