package com.fubon.esb.domain.txn;

/**
 * @author nice
 * @createdDate 2014-10-30
 */
public enum TxnStatus {

    /** 狀態{M:Main正式版本,E:Edited編輯版本(暫存),S:Saved存儲版本(待復核)} ,D(刪除中) **/
    M("Main"), S("Saved"), E("Edited"), D("deleting");

    private String desc;

    TxnStatus(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

}
