package com.fubon.esb.service.txn;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import com.fubon.esb.controller.txn.view.TxnVO;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnFieldDefinition;

/**
 * @author Qigers
 * @createdDate 2015-3-26
 */
@Service
public class TxnHeaderExcelWriteService extends BaseTxnExcelService {

    public Workbook createTxnWorkbook(TxnVO txnVO) throws Exception {
        Workbook workbook = new HSSFWorkbook();
        fillWorkbookByTxn(workbook, txnVO);
        logToDB(messages.getMessage("txn.edit.log.report.txn", txnVO.getHeadDirection().getName(), txnVO.getHeadDirection().getName()));
        return workbook;
    }

    public void fillWorkbookByTxn(Workbook workbook, TxnVO txnVO) throws Exception {
        if (txnVO != null) {
            Sheet sheet = workbook.createSheet("Header");
            fillSheetByTxnFields(sheet, txnVO.getHeadFields());
        }
    }

    public Sheet fillSheetByTxnFields(Sheet sheet, List<TxnFieldDefinition> fields) {
        sheet.setDefaultColumnWidth(12);
        fillTxnHeaderTitleRow(sheet.createRow(0));
        Row sheetRow = null;
        if (fields != null && !fields.isEmpty())
            for (int i = 0, j = 1; i < fields.size(); i++) {
                TxnFieldDefinition txnFieldDefinition = fields.get(i);
                if (FieldType.F.equals(txnFieldDefinition.getFieldType()) && txnFieldDefinition.isSplitField()) {
                    continue;
                } else if (!FieldType.F.equals(txnFieldDefinition.getFieldType()) && txnFieldDefinition.isSplitField()) {
                    sheetRow = sheet.createRow(j);
                    setAsTextAndIngoreNull(sheetRow.createCell(0), txnFieldDefinition.getName());
                    j++;
                    continue;
                }
                sheetRow = sheet.createRow(j);
                fillTxnFieldRow(sheetRow, txnFieldDefinition);
                j++;
            }
        return sheet;
    }

    public void fillTxnHeaderTitleRow(Row sheetRow) {
        Workbook workbook = sheetRow.getSheet().getWorkbook();
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        style.setFont(font);
        setAsTextAndIngoreNull(sheetRow.createCell(0), "Field ID").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(7), "對齊方式").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(9), "是否必填").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(5), "欄位小數位數").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(6), "欄位補充字元").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(3), "欄位資料型態").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(4), "欄位長度").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(8), "是否中文").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(1), "欄位預設值").setCellStyle(style);
        setAsTextAndIngoreNull(sheetRow.createCell(2), "欄位名稱").setCellStyle(style);
    }

    public void fillTxnFieldRow(Row sheetRow, TxnFieldDefinition field) {
        if (sheetRow == null || field == null)
            return;
        if (FieldType.F.equals(field.getFieldType())) {
            setAsTextAndIngoreNull(sheetRow.createCell(0), field.getCode());
        } else if (field.getFieldType() != null) {
            setAsTextAndIngoreNull(sheetRow.createCell(0), field.getValue());
            return;
        }
        setAsTextAndIngoreNull(sheetRow.createCell(1), field.getDefaultV());
        setAsTextAndIngoreNull(sheetRow.createCell(2), field.getName());
        if (field.getDataType() != null)
            setAsTextAndIngoreNull(sheetRow.createCell(3), messages.getMessage(field.getDataType().getPropKey()));
        setAsTextAndIngoreNull(sheetRow.createCell(4), field.getLength());
        setAsTextAndIngoreNull(sheetRow.createCell(5), field.getScale());
        setAsTextAndIngoreNull(sheetRow.createCell(6), field.getPadChar());
        if (field.getJustify() != null)
            setAsTextAndIngoreNull(sheetRow.createCell(7), messages.getMessage(field.getJustify().getPropKey()));
        if (Integer.valueOf(1).equals(field.getIncludeChinese())) {
            setAsTextAndIngoreNull(sheetRow.createCell(8), messages.getMessage("txn.includechinese.yes"));
        } else if (Integer.valueOf(0).equals(field.getIncludeChinese())) {
            setAsTextAndIngoreNull(sheetRow.createCell(8), messages.getMessage("txn.includechinese.no"));
        }
        if (Integer.valueOf(1).equals(field.getOptional())) {
            setAsTextAndIngoreNull(sheetRow.createCell(9), messages.getMessage("txn.required.no"));
        } else if (Integer.valueOf(0).equals(field.getOptional())) {
            setAsTextAndIngoreNull(sheetRow.createCell(9), messages.getMessage("txn.required.yes"));
        }
    }
}
