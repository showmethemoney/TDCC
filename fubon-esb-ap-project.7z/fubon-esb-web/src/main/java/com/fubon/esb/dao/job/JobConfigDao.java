package com.fubon.esb.dao.job;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.job.view.JobConfigView;
import com.fubon.esb.controller.job.view.JobRecordlView;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.domain.job.JobConfig;
import com.fubon.esb.domain.job.JobStatus;
import com.fubon.esb.domain.job.LastRunningStatusType;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-13
 */
@Repository
public class JobConfigDao extends JPADaoSupport<JobConfig> {

    public void buildQueryString(Query query, JobConfigView jobConfigView, JobStatus jobStatus, List<String> userBranchCodes) {
        if ((userBranchCodes != null && !userBranchCodes.isEmpty()) || StringUtils.isNotBlank(jobConfigView.getJobSystemCode())) {
            query.append(",").append(JobSystemSetting.class).append(" jobSystem ");
        }
        query.append(" where 1=1 ");
        if (userBranchCodes != null && !userBranchCodes.isEmpty()) {
            query.append(" and jobSystem.branchCode in :userBranchCodes");
            query.setParam("userBranchCodes", userBranchCodes);
        }
        if (StringUtils.isNotBlank(jobConfigView.getJobSystemCode())) {
            query.append(" and jobSystem.systemCode in :jobSystemCode");
            query.setParam("jobSystemCode", jobConfigView.getJobSystemCode());
        }
        if (StringUtils.isNotBlank(jobConfigView.getCode())) {
            query.append(" and jobConfig.code like :code ");
            query.setParam("code", "%" + jobConfigView.getCode() + "%");
        }
        if (StringUtils.isNotBlank(jobConfigView.getName())) {
            query.append(" and jobConfig.name like :name ");
            query.setParam("name", "%" + jobConfigView.getName() + "%");
        }
        if (jobStatus != null) {
            query.append(" and jobConfig.status = :status ");
            query.setParam("status", jobStatus);
        }
        if (jobStatus == null) {
            query.append(" and jobConfig.status != :status ");
            query.setParam("status", JobStatus.D);
        }
        if (userBranchCodes != null || StringUtils.isNotBlank(jobConfigView.getJobSystemCode())) {
            query.append(" and jobConfig.jobSystemId = jobSystem.id");
        }
    }

    public List<JobConfig> findJobConfigs(JobConfigView jobConfigView, JobStatus jobStatus, List<String> userBranchCodes, OrderBy orderBy, Page page) {
        Query query = Query.create("select jobConfig from ").append(JobConfig.class).append(" jobConfig ");
        buildQueryString(query, jobConfigView, jobStatus, userBranchCodes);
        int startTime = 0;
        int endTime = 0;
        if (jobConfigView.getStartHour() != null && jobConfigView.getStartMinute() != null && jobConfigView.getEndHour() != null && jobConfigView.getEndMinute() != null) {
            startTime = Integer.valueOf(jobConfigView.getStartHour() + "" + (100 + jobConfigView.getStartMinute()));
            endTime = Integer.valueOf(jobConfigView.getEndHour() + "" + (100 + jobConfigView.getEndMinute()));
        }
        if (!(startTime == 100 && endTime == 100) && jobConfigView.getStartHour() != null && jobConfigView.getStartMinute() != null && jobConfigView.getEndHour() != null
                && jobConfigView.getEndMinute() != null) {
            query.append(" and cast(CONCAT(cast(jobConfig.startHour as string),cast((jobConfig.startMinute+100) as string)) as integer)  >= :startTime ");
            query.param("startTime", startTime);
        }
        if (!(startTime == 100 && endTime == 100) && jobConfigView.getStartHour() != null && jobConfigView.getStartMinute() != null && jobConfigView.getEndHour() != null
                && jobConfigView.getEndMinute() != null) {
            query.append(" and cast(CONCAT(cast(jobConfig.endHour as string),cast((jobConfig.endMinute+100) as string)) as integer)  <= :endTime ");
            query.param("endTime", endTime);
        }
        if (StringUtils.isNotBlank(orderBy.getField())) {
            if ("startTime".equals(orderBy.getField()))
                query.orderBy(" cast(CONCAT(cast(jobConfig.startHour as string),cast((jobConfig.startMinute+100) as string)) as integer) ").append(orderBy.isAsc() ? " asc" : " desc");
            else if ("endTime".equals(orderBy.getField())) {
                query.orderBy(" cast(CONCAT(cast(jobConfig.endHour as string),cast((jobConfig.endMinute+100) as  string)) as integer) ").append(orderBy.isAsc() ? " asc" : " desc");
            }
        } else if (StringUtils.isBlank(orderBy.getField())) {
            query.orderBy("jobConfig.createdTime");
        }
        query.page(page);
        return jpaAccess.findPage(query);
    }

    public JobConfig getJobConfigById(String id) {
        return jpaAccess.get(JobConfig.class, id);
    }

    public boolean codeDuplicate(String code, String jobSyStemId) {
        StringBuilder ql =
                new StringBuilder("select jobConfig from ").append(JobConfig.class.getName()).append(" jobConfig where jobConfig.code=:jobConfigCode and jobConfig.status != :status ")
                        .append(" and exists (from ").append(JobSystemSetting.class.getName()).append(" jobSystem where jobSystem.id=jobConfig.jobSystemId and jobSystem.id=:jobSystemId)");
        Query query = Query.create(ql.toString()).param("jobConfigCode", code).param("status", JobStatus.D).param("status", JobStatus.D).param("jobSystemId", jobSyStemId);
        return !jpaAccess.find(query).isEmpty();
    }

    public void removeJobConfig(String id) {
        Query query = Query.create("delete from " + JobConfig.class.getName() + " where id = :id").param("id", id);
        jpaAccess.update(query);
    }

    public List<JobConfig> findJobRecords(JobRecordlView jobRecordlView, List<String> userBranchCodeList, OrderBy orderBy, Page page) {
        Query query = Query.create("select jobConfig from " + JobConfig.class.getName() + " jobConfig");
        if ((userBranchCodeList != null && !userBranchCodeList.isEmpty()) || StringUtils.isNotBlank(jobRecordlView.getJobSystemCode())) {
            query.append(",").append(JobSystemSetting.class).append(" jobSystem ");
        }
        query.append(" where 1=1 ");
        query.append(" and jobConfig.status != :activeStatus").setParam("activeStatus", JobStatus.D);
        if (userBranchCodeList != null && !userBranchCodeList.isEmpty()) {
            query.append(" and jobSystem.branchCode in :userBranchCodeList ");
            query.setParam("userBranchCodeList", userBranchCodeList);
        }
        if (StringUtils.isNotBlank(jobRecordlView.getJobSystemCode())) {
            query.append(" and jobSystem.systemCode in :jobSystemCode");
            query.setParam("jobSystemCode", jobRecordlView.getJobSystemCode());
        }
        if (StringUtils.isNotBlank(jobRecordlView.getCode())) {
            query.append(" and jobConfig.code like :code ");
            query.setParam("code", "%" + jobRecordlView.getCode() + "%");
        }
        if (StringUtils.isNotBlank(jobRecordlView.getName())) {
            query.append(" and jobConfig.name like :name ");
            query.setParam("name", "%" + jobRecordlView.getName() + "%");
        }
        if (StringUtils.isNotBlank(jobRecordlView.getStatus())) {
            if (!"N".equalsIgnoreCase(jobRecordlView.getStatus())) {
                query.append(" and jobConfig.lastRunningStatus=:status ");
                query.setParam("status", LastRunningStatusType.valueOf(jobRecordlView.getStatus()));
            } else if ("N".equalsIgnoreCase(jobRecordlView.getStatus())) {
                query.append(" and (jobConfig.lastRunningStatus is null or  jobConfig.lastRunningStatus='')");
            }
        }
        if (userBranchCodeList != null || StringUtils.isNotBlank(jobRecordlView.getJobSystemCode())) {
            query.append(" and jobConfig.jobSystemId=jobSystem.id");
        }
        if (StringUtils.isNotBlank(orderBy.getField())) {
            if ("startTime".equals(orderBy.getField())) {
                query.orderBy(" cast(CONCAT(cast(jobConfig.startHour as string),cast((jobConfig.startMinute+100) as string)) as integer) ").append(orderBy.isAsc() ? " asc" : " desc");
            } else if ("endTime".equals(orderBy.getField())) {
                query.orderBy(" cast(CONCAT(cast(jobConfig.endHour as string),cast((jobConfig.endMinute+100) as  string)) as integer) ").append(orderBy.isAsc() ? " asc" : " desc");
            } else if ("realStartTime".equals(orderBy.getField())) {
                query.orderBy(" jobConfig.lastRunningTime ").append(orderBy.isAsc() ? " asc" : " desc");
            } else if ("status".equals(orderBy.getField())) {
                query.orderBy(" jobConfig.lastRunningStatus ").append(orderBy.isAsc() ? " asc" : " desc");
            }
        }
        query.page(page);
        return jpaAccess.findPage(query);
    }

    public boolean searchJSSIdRelated(String jobSystemId) {
        Query query = Query.from(JobConfig.class).where("jobSystemId = :jobSystemId").param("jobSystemId", jobSystemId);
        return !jpaAccess.find(query).isEmpty();
    }

    public List<JobConfig> findAllJobRecords(List<String> userBranchCodes) {
        Query query = Query.create("select jobConfig from " + JobConfig.class.getName() + " jobConfig");
        if (userBranchCodes != null) {
            query.append(",").append(JobSystemSetting.class).append(" jobSystem");
        }
        query.append(" where 1=1");
        if (userBranchCodes != null) {
            query.append(" and jobSystem.branchCode in :userBranchCodes and jobSystem.id=jobConfig.jobSystemId");
            query.param("userBranchCodes", userBranchCodes);
        }
        query.append(" and jobConfig.status != :activeStatus").setParam("activeStatus", JobStatus.D);

        return jpaAccess.findPage(query);
    }

    public List<JobConfig> getByCode(String code, String jobSystemId) { // update
        Query query = Query.from(JobConfig.class).where("code = :code").param("code", code);
        query.append(" and jobSystemId=:jobSystemId").param("jobSystemId", jobSystemId);
        return jpaAccess.find(query);
    }

}
