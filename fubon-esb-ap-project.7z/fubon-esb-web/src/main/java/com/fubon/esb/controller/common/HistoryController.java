package com.fubon.esb.controller.common;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.session.SessionContext;
import com.comwave.core.platform.session.SessionKey;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.view.History;

/**
 * @author nice
 * @createdDate 2014-12-1
 */
@Controller
@RequestMapping("/history")
public class HistoryController extends BaseController {

    @Inject
    protected SessionContext sessionContext;

    private static final SessionKey<History> HISTORY_KEY = SessionKey.key("history", History.class);

    @ResponseBody
    @RequestMapping("/addHistory")
    public Object addHistory(String url, String html) {
        sessionContext.set(HISTORY_KEY, new History(url, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">" + html));
        return true;
    }

    @RequestMapping("/goHistory")
    public void goHistory(HttpServletRequest request, HttpServletResponse response) throws Exception {
        History history = sessionContext.get(HISTORY_KEY);
        if (StringUtils.isBlank(history.getHtml())) {
            if (StringUtils.isBlank(history.getUrl())) {
                response.sendRedirect(request.getContextPath() + "/home");
                return;
            }
            response.sendRedirect(history.getUrl());
            return;
        }
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        response.getWriter().println(history.getHtml());
        response.flushBuffer();
        response.getWriter().close();
    }

}
