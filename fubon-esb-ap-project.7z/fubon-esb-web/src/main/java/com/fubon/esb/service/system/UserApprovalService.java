package com.fubon.esb.service.system;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.system.view.UserApprovalVO;
import com.fubon.esb.dao.system.UserConfigDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.log.ApprovalLogService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Qigers
 * @createdDate 2015-1-14
 */
@Service
public class UserApprovalService {
    @Inject
    private UserConfigDao userConfigDao;
    @Inject
    private UserConfigService userConfigService;
    @Inject
    private Messages messages;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private ApprovalLogService approvalLogService;
    @Inject
    private LoginContext loginContext;

    public List<UserConfig> findAllUserForApproval(UserApprovalVO vo) {
        Date startDate = getFullTime(vo.getStartDateStr(), "00:00:00.000");
        Date endDate = getFullTime(vo.getEndDateStr(), "23:59:59.999");
        return userConfigDao.findUsersForApprove(vo, startDate, endDate);
    }

    private Date getFullTime(String searchDate, String time) {
        if (StringUtils.isNotBlank(searchDate) && StringUtils.isNotBlank(time)) {
            try {
                return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").parse(searchDate + " " + time);
            } catch (ParseException e) {
                // logger.error(e.getMessage(), e);
                return null;
            }
        }
        return null;
    }

    @Transactional
    public Boolean runUserApproval(String id, String modifyContent) {
        UserConfig userConfig = userConfigService.getById(id);
        if (userConfig.getUpdatedUser().equals(loginContext.loginedUserId())) {
            return true;
        } else {
            if ("0".equals(userConfig.getMainId())) {
                userConfig.setMainId(null);
                userConfig.setApprovedTime(new Date());
                userConfig.setApprovedUser(loginContext.loginedUserId());
                userConfigDao.update(userConfig);
            } else {
                UserConfig mainIdConfig = userConfigDao.getById(userConfig.getMainId());
                BeanUtils.copyProperties(userConfig, mainIdConfig, "id", "mainId", "modifyFlag");
                mainIdConfig.setId(userConfig.getMainId());
                mainIdConfig.setMainId(null);
                mainIdConfig.setApprovedTime(new Date());
                mainIdConfig.setApprovedUser(loginContext.loginedUserId());
                userConfigDao.update(mainIdConfig);
                userConfigDao.removeUserConfig(id);
            }
            String message = messages.getMessage("system.log.userConfig.approval") + ": " + userConfig.getUserId() + "," + userConfig.getUsername();
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, message, LogType.SYS_USER_APPROVAL);
            approvalLogService.addUserConfigApprovalLog(userConfig, modifyContent, 4); // 覆核日誌
            return false;
        }
    }
}
