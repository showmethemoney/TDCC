package com.fubon.esb.controller.config.view;

/**
 * @author Qigers
 * @createdDate 2014-11-24
 */
public class TxnConfigExcelVO {
    private String txnId;
    private String txnCode;
    private String txnName;
    private String txnGroupCode;
    private String hostCode;
    private String serviceCode;
    private String serviceVerstion;
    private String channelCode;
    private String accessChannelCode;
    private String appCode;
    private String appName;
    private String bgGroup;
    private String hostDriveQueue;
    private String transTxnCode;
    private String toQueue;
    private Integer timeOut;
    private String connectorCode;
    private String adapterName;
    private String priority;
    private String relatedTxnId;
    private String txnStatus;
    private String effctype;
    private String effctime;
    private String memo;
    private String createdUser;
    private String createdTime;

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public String getTxnName() {
        return txnName;
    }

    public void setTxnName(String txnName) {
        this.txnName = txnName;
    }

    public String getTxnGroupCode() {
        return txnGroupCode;
    }

    public void setTxnGroupCode(String txnGroupCode) {
        this.txnGroupCode = txnGroupCode;
    }

    public String getHostCode() {
        return hostCode;
    }

    public void setHostCode(String hostCode) {
        this.hostCode = hostCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceVerstion() {
        return serviceVerstion;
    }

    public void setServiceVerstion(String serviceVerstion) {
        this.serviceVerstion = serviceVerstion;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getAccessChannelCode() {
        return accessChannelCode;
    }

    public void setAccessChannelCode(String accessChannelCode) {
        this.accessChannelCode = accessChannelCode;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getBgGroup() {
        return bgGroup;
    }

    public void setBgGroup(String bgGroup) {
        this.bgGroup = bgGroup;
    }

    public String getEffctype() {
        return effctype;
    }

    public void setEffctype(String effctype) {
        this.effctype = effctype;
    }

    public String getHostDriveQueue() {
        return hostDriveQueue;
    }

    public void setHostDriveQueue(String hostDriveQueue) {
        this.hostDriveQueue = hostDriveQueue;
    }

    public String getTransTxnCode() {
        return transTxnCode;
    }

    public void setTransTxnCode(String transTxnCode) {
        this.transTxnCode = transTxnCode;
    }

    public String getToQueue() {
        return toQueue;
    }

    public void setToQueue(String toQueue) {
        this.toQueue = toQueue;
    }

    public Integer getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(Integer timeOut) {
        this.timeOut = timeOut;
    }

    public String getConnectorCode() {
        return connectorCode;
    }

    public void setConnectorCode(String connectorCode) {
        this.connectorCode = connectorCode;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getRelatedTxnId() {
        return relatedTxnId;
    }

    public void setRelatedTxnId(String relatedTxnId) {
        this.relatedTxnId = relatedTxnId;
    }

    public String getEffctime() {
        return effctime;
    }

    public void setEffctime(String effctime) {
        this.effctime = effctime;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getAdapterName() {
        return adapterName;
    }

    public void setAdapterName(String adapterName) {
        this.adapterName = adapterName;
    }

}
