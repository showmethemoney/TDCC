package com.fubon.esb.controller.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.MailGroup;
import com.fubon.esb.domain.config.MailItem;
import com.fubon.esb.domain.config.MailPhone;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.MailGroupService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-11
 */
@Controller
@RequestMapping("/mailGroup")
public class MailGroupController extends BaseController {

    @Inject
    private MailGroupService mailGroupService;
    @Inject
    private ConfigChangeService configChangeService;

    @RequestMapping("/viewSearchMailGroup")
    public String viewSearchMailGroup(Model model) {
        return "/config/viewMailGroupList";
    }

    @RequirePermission(value = "050901")
    @RequestMapping("/viewMailGroupList")
    public String findMaiGroups(Model model, String code, String name) {
        List<MailGroup> mailGroups = mailGroupService.findMailGroups(code, name);
        model.addAttribute("code", code);
        model.addAttribute("name", name);
        model.addAttribute("mailGroups", mailGroups);
        return "/config/viewMailGroupList";

    }

    @RequirePermission(value = {"050902", "050903"})
    @RequestMapping("/viewMailGroup")
    public String viewMailGroup(Model model, String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) {
            isAdd = false;
            MailGroup mailGroup = mailGroupService.getById(id);
            List<MailItem> mailItems = mailGroupService.findMailItems(id);
            List<MailPhone> mailPhones = mailGroupService.fndMailPhones(id);
            model.addAttribute("mailItems", mailItems);
            model.addAttribute("mailGroup", mailGroup);
            model.addAttribute("mailPhones", mailPhones);
        }
        model.addAttribute("isAdd", isAdd);
        return "/config/viewMailGroup";
    }
    
    
    @RequestMapping("/refreshMailGroup")
    @ResponseBody
    public Object refreshMailGroup(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
         
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_MAIL_GROUP, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResultView saveOrUpdate(@Valid MailGroup mailGroup, String[] mails, String[] phones) {
        try {
            mailGroupService.saveOrUpdate(mailGroup, mails, phones);
            configChangeService.sendChangeEvent(ConfigType.CFG_MAIL_GROUP, mailGroup.getId());
        } catch (DuplicatedException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/mailGroup/viewMailGroupList");
    }

    @RequirePermission(value = "050904")
    @RequestMapping("/removeMailGroup")
    @ResponseBody
    public Map<String, Object> removeMailGroup(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        mailGroupService.removeMailGroup(id);
        configChangeService.sendChangeEvent(ConfigType.CFG_MAIL_GROUP, id);
        result.put("flag", true);
        return result;
    }

    @RequestMapping("/findMailsAndPhones")
    @ResponseBody
    public Map<String, Object> findMailsAndPhones(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        String mails = mailGroupService.findMailsByGroupId(id);
        String phones = mailGroupService.findPhonesByGroupId(id);
        result.put("mails", mails);
        result.put("phones", phones);
        return result;
    }

    @RequirePermission(value = "050901")
    @RequestMapping("/viewMailGroupDetail")
    public String viewMailGroupDetail(Model model, String id) {
        MailGroup mailGroup = mailGroupService.getById(id);
        List<MailItem> mailItems = mailGroupService.findMailItems(id);
        List<MailPhone> mailPhones = mailGroupService.fndMailPhones(id);
        model.addAttribute("mailItems", mailItems);
        model.addAttribute("mailGroup", mailGroup);
        model.addAttribute("mailPhones", mailPhones);
        return "/config/viewMailGroupDetail";
    }

}
