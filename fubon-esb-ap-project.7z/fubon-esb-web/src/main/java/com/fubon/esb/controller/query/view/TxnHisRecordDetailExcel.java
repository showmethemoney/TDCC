package com.fubon.esb.controller.query.view;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.log.TxnHisRecord;
import com.fubon.esb.domain.log.TxnHisRecordMsg;

public class TxnHisRecordDetailExcel extends AbstractExcelView {
    @Override
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("歷史交易記錄明細");
        sheet.setDefaultColumnWidth(12);
        sheet.setColumnWidth(9, 20 * 256);
        sheet.setColumnWidth(10, 100 * 256);
        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 13); // 字體高度
        font.setColor(HSSFFont.COLOR_NORMAL); // 字體顏色
        font.setFontName("宋體"); // 字體
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // 寬度
        // 設置單元格類型
        HSSFCellStyle cellTitleStyle = workbook.createCellStyle();
        cellTitleStyle.setFont(font);
        sheetTitle(sheet, cellTitleStyle);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat forFileNameFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        TxnHisRecord txnHisRecord = (TxnHisRecord) obj.get("txnHisRecord");
        List<TxnHisRecordMsg> list = (List<TxnHisRecordMsg>) obj.get("txnHisRecordMsgDetailExcelList");
        int len = list.size();
        for (int i = 0; i < len; i++) {
            getCell(sheet, i + 1, 0).setCellValue(list.get(i).getEngineName());
            getCell(sheet, i + 1, 1).setCellValue(txnHisRecord.getWorkstationCode());
            String sequence = txnHisRecord.getSequence();
            if (StringUtils.isNotBlank(sequence)) {
                sequence = new java.text.DecimalFormat("0000000").format(Integer.parseInt(sequence));
            }
            getCell(sheet, i + 1, 2).setCellValue(sequence);
            getCell(sheet, i + 1, 3).setCellValue(txnHisRecord.getTeller());
            getCell(sheet, i + 1, 4).setCellValue(list.get(i).getTxnCode());
            getCell(sheet, i + 1, 5).setCellValue(txnHisRecord.getSysDate());
            getCell(sheet, i + 1, 6).setCellValue(txnHisRecord.getSysTime());
            getCell(sheet, i + 1, 7).setCellValue(list.get(i).getReturnCode());
            getCell(sheet, i + 1, 10).setCellValue(list.get(i).getMessage());
            getCell(sheet, i + 1, 8).setCellValue(StringUtils.isNoneBlank(list.get(i).getLayer()) ? list.get(i).getLayer().substring(0, 1) + "(" + list.get(i).getDirection() + ")" : "");
            getCell(sheet, i + 1, 9).setCellValue(sdf.format(list.get(i).getCreateTime()));
        }
        String lisijiaoyijilumingxi = "歷史交易記錄明細" + forFileNameFormat.format(new Date()) + ".xls";
        lisijiaoyijilumingxi = URLEncoder.encode(lisijiaoyijilumingxi, "UTF-8");
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + lisijiaoyijilumingxi);
        OutputStream ouputStream = response.getOutputStream();
        workbook.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();
    }

    private void sheetTitle(HSSFSheet sheet, HSSFCellStyle cellTitleStyle) {
        getCell(sheet, 0, 2).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 1).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 5).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 4).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 3).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 8).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 7).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 6).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 10).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 9).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 0).setCellValue("機器名稱");
        getCell(sheet, 0, 1).setCellValue("工作站代號");
        getCell(sheet, 0, 2).setCellValue("交易序號");
        getCell(sheet, 0, 3).setCellValue("櫃員代號");
        getCell(sheet, 0, 4).setCellValue("交易代號 ");
        getCell(sheet, 0, 5).setCellValue("系統日期");
        getCell(sheet, 0, 6).setCellValue("系統時間");
        getCell(sheet, 0, 7).setCellValue("交易回應碼");
        getCell(sheet, 0, 10).setCellValue("內容");
        getCell(sheet, 0, 8).setCellValue("內部層 ");
        getCell(sheet, 0, 9).setCellValue("建立時間 ");
    }
}
