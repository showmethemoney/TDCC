package com.fubon.esb.controller.system;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.system.view.UserApprovalVO;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.system.UserApprovalService;
import com.fubon.esb.service.system.UserConfigService;

/**
 * 帳號復核controller
 * 
 * @author Qigers
 * @createdDate 2015-1-14
 */
@Controller
@RequestMapping("/system")
public class UserConfigApprovalController extends BaseController {

    @Inject
    private UserApprovalService userApprovalService;

    @Inject
    private UserConfigService userConfigService;

    @RequestMapping("viewUserApprovalList")
    @RequirePermission(value = "070401")
    public String viewUserApprovalList(Model model, UserApprovalVO vo, Boolean isSearch) {
        // if (isSearch != null && isSearch) {
        model.addAttribute("userApprovals", userApprovalService.findAllUserForApproval(vo));
        model.addAttribute("vo", vo);
        model.addAttribute("isSearch", isSearch);
        // }
        return "/system/viewUserApprovalList";
    }

    @RequestMapping("viewUserApproval")
    @RequirePermission(value = "070401")
    public String viewUserApproval(Model model, Boolean isApproval, String id) {
        UserConfig userConfig = userConfigService.getById(id);
        model.addAttribute("userConfig", userConfig);
        String modifyContent = "";
        if ("0".equals(userConfig.getMainId())) {
            modifyContent = "系統帳號-" + userConfig.getUserId() + "\r中文姓名-" + userConfig.getUsername() + "\r科別-" + userConfig.getSubject() + "\r分機資訊-" + userConfig.getExtNumber();
        } else {
            UserConfig mainUserConfig = userConfigService.getById(userConfig.getMainId());
            if (!mainUserConfig.getUserId().equals(userConfig.getUserId())) {
                modifyContent += "系統帳號-" + userConfig.getUserId();
            }
            if (!mainUserConfig.getUsername().equals(userConfig.getUsername())) {
                modifyContent += "\r中文姓名-" + userConfig.getUsername();
            }
            if (!mainUserConfig.getSubject().equals(userConfig.getSubject())) {
                modifyContent += "\r科別-" + userConfig.getSubject();
            }
            if (!mainUserConfig.getExtNumber().equals(userConfig.getExtNumber())) {
                modifyContent += "\r分機資訊-" + userConfig.getExtNumber();
            }
        }
        model.addAttribute("modifyContent", modifyContent);
        model.addAttribute("isApproval", isApproval);
        return "/system/viewUserApproval";
    }

    /**
     * 執行覆核操作
     */
    @RequestMapping("runUserApproval")
    @ResponseBody
    @RequirePermission(value = "070402")
    public Map<String, Object> runUserApproval(String id, String modifyContent) {
        Map<String, Object> result = new HashMap<>();
        Boolean flag = userApprovalService.runUserApproval(id, modifyContent);
        result.put("flag", flag);
        return result;
    }

}
