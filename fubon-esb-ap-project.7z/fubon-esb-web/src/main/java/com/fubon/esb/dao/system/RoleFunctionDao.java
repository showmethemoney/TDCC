package com.fubon.esb.dao.system;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.RoleFunction;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-3
 */
@Repository
public class RoleFunctionDao extends JPADaoSupport<RoleFunction> {
    
    /**
     * 批量新增
     */
    public void saveRoleFunctionList(List<RoleFunction> roleFuncList) {
        for (RoleFunction rf : roleFuncList) {
            jpaAccess.save(rf);
        }
    }
    
    /**
     * 批量刪除
     */
    public void removeRoleFunctionList(List<RoleFunction> roleFuncList) {
        for (RoleFunction rf : roleFuncList) {
            jpaAccess.delete(rf);
        }
    }
    
    public List<RoleFunction> findRoleFuncListByRoleId(String roleId) {
        return jpaAccess.find(Query.from(RoleFunction.class).where("roleId = :roleId").param("roleId", roleId));
    }
    
    public void batchDeleteByRole(String roleId) {
        jpaAccess.update(Query.create("delete " + RoleFunction.class.getName() + " where roleId=:roleId").param("roleId", roleId));
    }
    
    public List<String> findFunctionListByRoleId(String roleId) {
        return jpaAccess.find(Query.create("select funcCode from " + RoleFunction.class.getName() + " where roleId = :roleId").param("roleId", roleId));
    }
    
}
