package com.fubon.esb.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comwave.core.platform.login.LoginContext;

/**
 * @author Bribin
 * @createdDate Sep 10, 2014
 */
@Controller
public class HomeController extends BaseController {

    @Inject
    private LoginContext loginContext;

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home(Model model) {
        String loginedUserId = loginContext.loginedUserId();
        model.addAttribute("userId", loginedUserId);
        return "/home";
    }

}
