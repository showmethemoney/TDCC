package com.fubon.esb.service.config;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.fubon.esb.dao.config.HostDao;
import com.fubon.esb.domain.config.Host;

/**
 * @author Qigers
 * @createdDate 2014-12-31
 */
@Service
public class HostLogMailService {

    @Inject
    private HostDao hostDao;
    @Inject
    private ConfigChangeService configChangeService;

    public Host getHostById(String id) {
        return hostDao.get(id);
    }

    public void createMailRelatedLog(Host host, Host oldHost, String currentUser, Date effectTime) {
        if (null == (oldHost.getMainId()) || "0".equals(oldHost.getMainId())) {
            Boolean statusFlag = oldHost.getStatus().toString().equals(host.getStatus().toString());
            Boolean effectTypeFlag = oldHost.getEffectType().name().equals(host.getEffectType().name());
            Boolean nameFlag = oldHost.getName().equals(host.getName());
            Boolean codeFlag = oldHost.getCode().equals(host.getCode());
            Boolean effecttimeFlag = true;
            if (("B".equals(host.getEffectType().name())) && ("B".equals(oldHost.getEffectType().name()))) {
                effecttimeFlag = effectTime.equals(oldHost.getEffectTime());
            }
            Boolean updateFlag = codeFlag && nameFlag && statusFlag && effectTypeFlag && effecttimeFlag;
            if (!updateFlag) {
                configChangeService.sendMailRequest("主機設定更變", createUpdateStr(host, oldHost, currentUser, effectTime));
            } else if ("0".equals(oldHost.getMainId())) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                String contents = "現形生效內容：\r\r\r";
                contents += "\r變更後內容：\r";
                contents += "主機代號：" + host.getCode() + "\r";
                contents += "主機名稱：" + host.getName() + "\r";
                contents += "使用狀態：" + ("I".equals(host.getStatus().name()) ? "停用" : "啟用") + "\r";
                contents += "生效類型：" + ("I".equals(host.getEffectType().name()) ? "即時" : ("預約生效 \r預約生效時間：" + sdf.format(effectTime))) + "\r";
                configChangeService.sendMailRequest("主機設定更變", contents);
            }
        } else {
            Host mainHost = getHostById(oldHost.getMainId());
            Boolean statusFlag = mainHost.getStatus().toString().equals(host.getStatus().toString());
            Boolean effectTypeFlag = mainHost.getEffectType().name().equals(host.getEffectType().name());
            Boolean nameFlag = mainHost.getName().equals(host.getName());
            Boolean codeFlag = mainHost.getCode().equals(host.getCode());
            Boolean effecttimeFlag = true;
            if (("B".equals(host.getEffectType().name())) && ("B".equals(mainHost.getEffectType().name()))) {
                effecttimeFlag = effectTime.equals(mainHost.getEffectTime());
            }
            Boolean updateFlag = codeFlag && nameFlag && statusFlag && effectTypeFlag && effecttimeFlag;
            if (!updateFlag) {
                configChangeService.sendMailRequest("主機設定更變", createUpdateMainStr(host, mainHost, currentUser, effectTime));
            }
        }
    }

    private String createUpdateMainStr(Host host, Host mainHost, String currentUser, Date effectTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Boolean nameFlag = mainHost.getName().equals(host.getName());
        Boolean codeFlag = mainHost.getCode().equals(host.getCode());
        Boolean effectTypeFlag = mainHost.getEffectType().name().equals(host.getEffectType().name());
        Boolean statusFlag = mainHost.getStatus().toString().equals(host.getStatus().toString());
        Boolean effecttimeFlag = true;
        if (("B".equals(host.getEffectType().name())) && ("B".equals(mainHost.getEffectType().name()))) {
            effecttimeFlag = effectTime.equals(mainHost.getEffectTime());
        }
        Boolean updateFlag = codeFlag && nameFlag && statusFlag && effectTypeFlag && effecttimeFlag;
        String updateStr = "";
        if (!updateFlag) {
            updateStr = "主機設定(主機代號：" + host.getCode() + ")變更，變更者：" + currentUser + "\r";
            updateStr += "現形生效內容：\r";
            if (!codeFlag) {
                updateStr += "主機代號：" + mainHost.getCode() + "\r";
            }
            if (!nameFlag) {
                updateStr += "主機名稱：" + mainHost.getName() + "\r";
            }
            if (!statusFlag) {
                updateStr += "使用狀態：" + ("A".equals(mainHost.getStatus().name()) ? "啟用" : "停用") + "\r";
            }
            if ((!effectTypeFlag) || (!effecttimeFlag)) {
                updateStr += "生效類型：即時生效\r";
            }
            updateStr += "\r變更後內容：\r";
            if (!codeFlag) {
                updateStr += "主機代號：" + host.getCode() + "\r";
            }
            if (!nameFlag) {
                updateStr += "主機名稱：" + host.getName() + "\r";
            }
            if (!statusFlag) {
                updateStr += "使用狀態：" + ("A".equals(host.getStatus().name()) ? "啟用" : "停用") + "\r";
            }
            if ((!effectTypeFlag) || (!effecttimeFlag)) {
                updateStr += "生效類型：" + ("I".equals(host.getEffectType().name()) ? "即時" : ("預約生效" + "\r" + "預約生效時間：" + sdf.format(effectTime))) + "\r";
            }
        }
        return updateStr;
    }

    private String createUpdateStr(Host host, Host oldHost, String currentUser, Date effectTime) {
        Boolean codeFlag = oldHost.getCode().equals(host.getCode());
        Boolean nameFlag = oldHost.getName().equals(host.getName());
        Boolean statusFlag = oldHost.getStatus().toString().equals(host.getStatus().toString());
        Boolean effectTypeFlag = oldHost.getEffectType().name().equals(host.getEffectType().name());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Boolean effecttimeFlag = true;
        if (("B".equals(host.getEffectType().name())) && ("B".equals(oldHost.getEffectType().name()))) {
            effecttimeFlag = effectTime.equals(oldHost.getEffectTime());
        }
        Boolean updateFlag = codeFlag && nameFlag && statusFlag && effectTypeFlag && effecttimeFlag;
        String updateStr = "";
        if (!updateFlag) {
            updateStr = "主機設定(主機代號：" + host.getCode() + ")變更，變更者：" + currentUser + "\r";
            if ("0".equals(oldHost.getMainId())) {
                updateStr += "現形生效內容：\r\r\r";
            } else {
                updateStr += "現形生效內容：\r";
                updateStr += addEffect(oldHost, host, effecttimeFlag);
            }
            updateStr += "\r變更後內容：\r";
            if ("0".equals(oldHost.getMainId())) {
                updateStr += "主機代號：" + host.getCode() + "\r";
                updateStr += "主機名稱：" + host.getName() + "\r";
                updateStr += "使用狀態：" + ("I".equals(host.getStatus().name()) ? "停用" : "啟用") + "\r";
                updateStr += "生效類型：" + ("I".equals(host.getEffectType().name()) ? "即時" : ("預約生效 \r預約生效時間：" + sdf.format(effectTime))) + "\r";
            } else if (!codeFlag) {
                updateStr += "主機代號：" + host.getCode() + "\r";
            } else if (!nameFlag) {
                updateStr += "主機名稱：" + host.getName() + "\r";
            } else if (!statusFlag) {
                updateStr += "使用狀態：" + ("I".equals(host.getStatus().name()) ? "停用" : "啟用") + "\r";
            } else if ((!effectTypeFlag) || (!effecttimeFlag)) {
                updateStr += "生效類型：" + ("I".equals(host.getEffectType().name()) ? "即時" : ("預約生效 \r預約生效時間：" + sdf.format(effectTime))) + "\r";
            }
        }
        return updateStr;
    }

    private String addEffect(Host oldHost, Host host, Boolean effecttimeFlag) {
        Boolean codeFlag = oldHost.getCode().equals(host.getCode());
        Boolean nameFlag = oldHost.getName().equals(host.getName());
        Boolean statusFlag = oldHost.getStatus().toString().equals(host.getStatus().toString());
        Boolean effectTypeFlag = oldHost.getEffectType().name().equals(host.getEffectType().name());
        String updateString = "";
        if (!codeFlag) {
            updateString += "主機代號：" + oldHost.getCode() + "\r";
        }
        if (!nameFlag) {
            updateString += "主機名稱：" + oldHost.getName() + "\r";
        }
        if (!statusFlag) {
            updateString += "使用狀態：" + ("I".equals(oldHost.getStatus().name()) ? "停用" : "啟用") + "\r";
        }
        if ((!effectTypeFlag) || (!effecttimeFlag)) {
            updateString += "生效類型： 即時\r";
        }
        return updateString;
    }
}
