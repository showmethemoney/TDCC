package com.fubon.esb.dao.system;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.system.view.ApprovalSearchVO;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Repository
public class GroupDao extends JPADaoSupport<Group> {
    
    @Inject
    private TimeZoneService timeZoneService;

    public void saveGroup(Group group) {
        jpaAccess.save(group);
    }

    public void updateGroup(Group group) {
        jpaAccess.update(group);
    }

    public Group getGroupById(String id) {
        return jpaAccess.get(Group.class, id);
    }

    public Group getGroupByMainId(String mainId) {
        return jpaAccess.findOne(Query.from(Group.class).where("mainId = :mainId").param("mainId", mainId));
    }

    public List<Group> findLatestGroups() {
        return jpaAccess.find(Query.from(Group.class).where("mainId is null or mainId = '0' ").orderBy("orderNo"));
    }

    public List<ApprovalLog> findGroupsToAppoval(ApprovalSearchVO vo) {
        if (StringUtils.isNotBlank(vo.getRoleName())) {
            return new ArrayList<>();
        }

        StringBuilder jql = new StringBuilder();
        jql.append("select new ").append(ApprovalLog.class.getName()).append("(g.id, '', g.modifyFlag, g.updatedUser, g.updatedTime) from ").append(Group.class.getName())
                .append(" g where g.mainId is not null  ");
        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotBlank(vo.getGroupName())) {
            jql.append(" and g.name like :groupName ");
            params.put("groupName", "%" + vo.getGroupName() + "%");
        }
        if (StringUtils.isNotBlank(vo.getUpdatedUser())) {
            jql.append(" and g.updatedUser like :user ");
            params.put("user", "%" + vo.getUpdatedUser() + "%");
        }
        if (vo.getStartDate() != null) {
            jql.append(" and g.updatedTime >= :start");
            params.put("start", timeZoneService.getTZDateByService(vo.getStartDate()));
        }
        if (vo.getEndDate() != null) {
            jql.append(" and g.updatedTime <= :end");
            params.put("end", timeZoneService.getTZDateByService(vo.getEndDate()));
        }

        Query query = Query.create(jql.toString());
        query.putParams(params);

        List<ApprovalLog> approvalLogs = jpaAccess.find(query);
        if (approvalLogs == null) {
            return new ArrayList<>();
        }
        return approvalLogs;
    }

    /** 根據Ad Group獲取有效的群組 */
    public Group getGroupByAdGroup(String adGroup) {
        return jpaAccess.findOne(Query.from(Group.class).where("adGroup=:adGroup and mainId is null and status=:status").param("adGroup", adGroup).param("status", ActiveStatus.A));
    }

    public List<Group> findGroupByAdGroup(String adGroup) {
        return jpaAccess.find(Query.from(Group.class).where("adGroup=:adGroup").param("adGroup", adGroup));
    }
    
    public List<Group> findGroupByIds(Collection<String> ids) {
        return jpaAccess.find(Query.from(Group.class).where("id in (:ids)").param("ids", ids));
    }

}
