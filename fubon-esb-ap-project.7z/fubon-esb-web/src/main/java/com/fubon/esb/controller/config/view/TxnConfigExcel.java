package com.fubon.esb.controller.config.view;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.domain.config.Txn;

/**
 * @author Qigers
 * @createdDate 2014-11-24
 */
public class TxnConfigExcel extends AbstractExcelView {

    private final Messages messages;

    public TxnConfigExcel(Messages messages) {
        this.messages = messages;
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void buildExcelDocument(Map<String, Object> obj, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HSSFSheet sheet = workbook.createSheet("工作表1");
        sheet.setDefaultColumnWidth(21);
        sheet.setColumnWidth(2, 29 * 256);
        sheet.setColumnWidth(3, 29 * 256);
        sheet.setColumnWidth(4, 29 * 256);
        sheet.setColumnWidth(5, 29 * 256);
        sheet.setColumnWidth(6, 43 * 256);
        sheet.setColumnWidth(7, 43 * 256);
        sheet.setColumnWidth(15, 17 * 256);
        sheet.setColumnWidth(16, 14 * 256);
        sheet.setColumnWidth(17, 18 * 256);
        sheet.setColumnWidth(18, 18 * 256);
        sheet.setColumnWidth(19, 43 * 256);
        sheet.setColumnWidth(20, 14 * 256);
        sheet.setColumnWidth(22, 140 * 256);
        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 13); // 字體高度
        font.setColor(HSSFFont.COLOR_NORMAL); // 字體顏色
        font.setFontName("宋體"); // 字體
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // 寬度
        // 設置單元格類型
        HSSFCellStyle cellTitleStyle = workbook.createCellStyle();
        cellTitleStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        HSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(true);
        getCell(sheet, 0, 13).setCellStyle(cellStyle);
        sheetTitle(sheet, cellTitleStyle);
        List<TxnExportExcelVO> list = (List<TxnExportExcelVO>) obj.get("txnvos");
        setSheetCell(list, sheet, cellStyle);
        String filename = messages.getMessage("Excel.TxnConfig.title") + sdf.format(new Date()) + ".xls";
        filename = URLEncoder.encode(filename, "UTF-8");
        // filename = StringUtils.replace(filename, "+", "%20");
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment;filename=" + filename);
        OutputStream ouputStream = response.getOutputStream();
        workbook.write(ouputStream);
        ouputStream.flush();
        ouputStream.close();
    }

    private void setSheetCell(List<TxnExportExcelVO> list, HSSFSheet sheet, HSSFCellStyle cellStyle) {
        int len = list.size();
        for (int i = 0; i < len; i++) {
            TxnConfigExcelVO txnConfigExcelVO = list.get(i).getTxnConfigExcelVO();
            if (txnConfigExcelVO == null) {
                txnConfigExcelVO = new TxnConfigExcelVO();
            }
            Txn txn = list.get(i).getTxn();
            if (txn == null) {
                txn = new Txn();
            }
            getCell(sheet, i + 1, 0).setCellValue(txn.getCode());
            getCell(sheet, i + 1, 1).setCellValue(txn.getName());
            getCell(sheet, i + 1, 2).setCellValue(txnConfigExcelVO.getTxnGroupCode());
            getCell(sheet, i + 1, 3).setCellValue(txnConfigExcelVO.getHostCode());
            getCell(sheet, i + 1, 4).setCellValue(txnConfigExcelVO.getServiceCode());
            getCell(sheet, i + 1, 5).setCellValue(txnConfigExcelVO.getServiceVerstion());
            getCell(sheet, i + 1, 6).setCellStyle(cellStyle);
            getCell(sheet, i + 1, 6).setCellValue(list.get(i).getChannelCodes().get(1));
            getCell(sheet, i + 1, 7).setCellValue(list.get(i).getChannelCodes().get(2));
            getCell(sheet, i + 1, 8).setCellValue(txnConfigExcelVO.getAppCode());
            getCell(sheet, i + 1, 9).setCellValue(txnConfigExcelVO.getAppName());
            getCell(sheet, i + 1, 10).setCellValue(txnConfigExcelVO.getBgGroup());
            getCell(sheet, i + 1, 11).setCellValue(txn.getHostDriveQueue());
            getCell(sheet, i + 1, 12).setCellValue(txn.getTransTxnCode());
            getCell(sheet, i + 1, 13).setCellValue(txn.getToQueue());
            getCell(sheet, i + 1, 14).setCellValue(txn.getTellerCode());
            getCell(sheet, i + 1, 15).setCellValue(getTimeout(String.valueOf(txn.getTimeout())));
            getCell(sheet, i + 1, 16).setCellValue(messages.getMessage(txn.getPriority() == null ? "" : "Excel.TxnConfig.priority." + txn.getPriority().name()));
            getCell(sheet, i + 1, 17).setCellValue(txnConfigExcelVO.getConnectorCode());
            getCell(sheet, i + 1, 18).setCellValue(txnConfigExcelVO.getAdapterName());
            getCell(sheet, i + 1, 19).setCellStyle(cellStyle);
            getCell(sheet, i + 1, 19).setCellValue(list.get(i).getRelatedTxnCodes().get(1));
            getCell(sheet, i + 1, 20).setCellValue(messages.getMessage(txn.getStatus() != null ? "Excel.TxnConfig.status." + txn.getStatus().name() : ""));
            if (StringUtils.isBlank(txnConfigExcelVO.getEffctime())) {
                getCell(sheet, i + 1, 21).setCellValue("即時");
            } else {
                getCell(sheet, i + 1, 21).setCellValue(txnConfigExcelVO.getEffctime().substring(0, 19));
            }
            HSSFCell cellMemo = getCell(sheet, i + 1, 21);
            cellMemo.setCellStyle(cellStyle);
            getCell(sheet, i + 1, 22).setCellValue(txn.getMemo());
            getCell(sheet, i + 1, 23).setCellValue(txnConfigExcelVO.getCreatedUser());
            getCell(sheet, i + 1, 24).setCellValue(StringUtils.isBlank(txnConfigExcelVO.getCreatedTime()) ? "" : txnConfigExcelVO.getCreatedTime().substring(0, 19));
        }
    }

    private String getTimeout(String iStr) {
        String str = iStr;
        if ("null".equals(str)) {
            str = "";
        }
        return str;
    }

    private void setStyle(HSSFSheet sheet, HSSFCellStyle cellTitleStyle) {
        getCell(sheet, 0, 0).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 1).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 2).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 3).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 4).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 5).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 6).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 7).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 8).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 9).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 10).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 11).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 12).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 13).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 14).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 15).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 16).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 17).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 18).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 19).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 20).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 21).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 22).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 23).setCellStyle(cellTitleStyle);
        getCell(sheet, 0, 24).setCellStyle(cellTitleStyle);
    }

    private void sheetTitle(HSSFSheet sheet, HSSFCellStyle cellTitleStyle) {
        setStyle(sheet, cellTitleStyle);
        getCell(sheet, 0, 0).setCellValue("交易代號");
        getCell(sheet, 0, 1).setCellValue("交易名稱");
        getCell(sheet, 0, 2).setCellValue("關聯業務群組代號");
        getCell(sheet, 0, 3).setCellValue("關聯主機代號");
        getCell(sheet, 0, 4).setCellValue("關聯 Service 代號 ");
        getCell(sheet, 0, 5).setCellValue("關聯 Service版本代號");
        getCell(sheet, 0, 6).setCellValue("關聯Channel代號");
        getCell(sheet, 0, 7).setCellValue("關聯Access Channel代號 ");
        getCell(sheet, 0, 8).setCellValue("應用系統代號");
        getCell(sheet, 0, 9).setCellValue("應用系統簡稱");
        getCell(sheet, 0, 10).setCellValue("BG GROUP");
        getCell(sheet, 0, 11).setCellValue("HostDriveQueue");
        getCell(sheet, 0, 12).setCellValue("轉換TxID");
        getCell(sheet, 0, 13).setCellValue("To Queue");
        getCell(sheet, 0, 14).setCellValue("櫃員代號");
        getCell(sheet, 0, 15).setCellValue("交易 Timeout");
        getCell(sheet, 0, 16).setCellValue("交易優先權 ");
        getCell(sheet, 0, 17).setCellValue("交易Connector");
        getCell(sheet, 0, 18).setCellValue("關聯Adapter");
        getCell(sheet, 0, 19).setCellValue("關聯交易代號");
        getCell(sheet, 0, 20).setCellValue("使用狀態 ");
        getCell(sheet, 0, 21).setCellValue("生效時間");
        getCell(sheet, 0, 22).setCellValue("備註 ");
        getCell(sheet, 0, 23).setCellValue("建立者");
        getCell(sheet, 0, 24).setCellValue("建立時間 ");
    }
}
