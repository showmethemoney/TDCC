package com.fubon.esb.schedule.ems;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;


/**
 * @author Ethan Lee
 */
public class EMSAdminConsole implements Serializable
{
	protected static final Logger logger = LoggerFactory.getLogger( EMSAdminConsole.class );

	public EMSAdminConsole() {}

	public List<QueueInfo> getQueueInfo(String serverUrl, String username, String password) {
		List<QueueInfo> result = new ArrayList<QueueInfo>();
		TibjmsAdmin console = null;
		
		try {
			if (StringUtils.isBlank( serverUrl )) {
				throw new IllegalArgumentException( "ems server url can not be null" );
			}
			
			console = new TibjmsAdmin( serverUrl, username, password );

			QueueInfo[] queueInfos = console.getQueues();

			// filte the queue name contains "connector, service", exclude "fubon.esb.REPLYAS400S00A.Connector" and "fubon.esb.REPLYAS400S00B.Connector" toLowerCase
			for (int i = 0; i < queueInfos.length; i++) {
				QueueInfo queueInfo = queueInfos[i];
				
				String queueName = queueInfo.getName().toLowerCase();
				
				if(! queueName.equalsIgnoreCase( "fubon.esb.REPLYAS400S00A.Connector" ) && 
				   ! queueName.equalsIgnoreCase( "fubon.esb.REPLYAS400S00B.Connector" )	) {
					
					if (queueName.endsWith( "connector" ) || queueName.endsWith( "service" ) ) {
						result.add( queueInfo );
					}
				}
			}
			
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		} finally {
			if (null != console) {
				try {
					console.close();
				} catch (Throwable cause) {}
			}
		} 

		return result;
	}
}
