package com.fubon.esb.dao.config;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.MailItem;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-12
 */
@Repository
public class MailItemDao extends JPADaoSupport<MailItem> {

    public List<MailItem> findMailItems(String groupId) {
        Query query = Query.from(MailItem.class).where("groupId = :groupId").param("groupId", groupId);
        return jpaAccess.find(query);
    }

    public void addMailItemList(List<MailItem> mailItems) {
        for (MailItem mailItem : mailItems) {
            jpaAccess.save(mailItem);
        }
    }

    public void removeMailItemList(List<MailItem> mailItems) {
        for (MailItem mailItem : mailItems) {
            jpaAccess.delete(mailItem);
        }
    }

    public void saveMailItems(String groupId, String[] mails) {
        if (mails != null && mails.length > 0) {
            for (String mail : mails) {
                MailItem mailItem = new MailItem(groupId, mail);
                jpaAccess.save(mailItem);
            }
        }
    }

    public void removeByGroupId(String groupId) {
        Query query = Query.create("delete from " + MailItem.class.getName() + " where groupId = :groupId").param("groupId", groupId);
        jpaAccess.update(query);
    }
}
