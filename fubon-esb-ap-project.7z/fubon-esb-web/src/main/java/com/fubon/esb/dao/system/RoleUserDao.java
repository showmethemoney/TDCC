package com.fubon.esb.dao.system;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.RoleUser;

/**
 * @author Leckie Zhang
 * @createdDate 2015-1-13
 */
@Repository
public class RoleUserDao extends JPADaoSupport<RoleUser> {

    public List<RoleUser> findRoleUserByRoleId(String roleId) {
        return jpaAccess.find(Query.from(RoleUser.class).where("roleId = :id").param("id", roleId));
    }
    
    /**批量新增*/
    public void saveRoleUsers(List<RoleUser> roleUsers) {
        for (RoleUser roleUser : roleUsers) {
            jpaAccess.save(roleUser);
        }
    }
    
    /**批量刪除*/
    public void removeRoleUsers(List<RoleUser> roleUsers) {
        for (RoleUser roleUser : roleUsers) {
            jpaAccess.delete(roleUser);
        }
    }
    
    public void batchDeleteByRole(String roleId) {
        jpaAccess.update(Query.create("delete " + RoleUser.class.getName() + " where roleId=:roleId").param("roleId", roleId));
    }
    
    public List<String> findUserIdsByRole(String roleId) {
        return jpaAccess.find(Query.create("select userId from " + RoleUser.class.getName() + "  where roleId=:roleId").param("roleId", roleId));
    }
    
    /**
     * 通過UserConfig.id批量刪除關聯
     */
    public void batchDeleteByUser(String userId) {
        jpaAccess.update(Query.create("delete " + RoleUser.class.getName() + " where userId=:id").param("id", userId));
    }

}
