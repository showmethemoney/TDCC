package com.fubon.esb.domain.system;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * 系統帳號設定
 * 
 * @author Qigers
 * @createdDate 2015-01-12
 */
@Entity(name = "SYS_USER")
public class UserConfig {

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 用戶帳號 */
    @Column(name = "USER_ID")
    private String userId;

    /** 用戶名稱 */
    @Column(name = "USER_NAME")
    private String username;

    /** 科別 */
    @Column(name = "SUBJECT")
    private String subject;

    /** 分機號碼 */
    @Column(name = "MAIN_ID")
    private String mainId;

    /** 分機號碼 */
    @Column(name = "EXT_NUMBER")
    private String extNumber;

    /** Email */
    @Column(name = "EMAIL")
    private String email;

    /** 修改人 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 修改時間 */
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTime;

    /** 覆核人 */
    @Column(name = "APPROVED_USER")
    private String approvedUser;

    /** 覆核時間 */
    @Column(name = "APPROVED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date approvedTime;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getExtNumber() {
        return extNumber;
    }

    public void setExtNumber(String extNumber) {
        this.extNumber = extNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getApprovedUser() {
        return approvedUser;
    }

    public void setApprovedUser(String approvedUser) {
        this.approvedUser = approvedUser;
    }

    public Date getApprovedTime() {
        return approvedTime;
    }

    public void setApprovedTime(Date approvedTime) {
        this.approvedTime = approvedTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserConfig other = (UserConfig) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
