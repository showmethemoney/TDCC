package com.fubon.esb.controller.txn.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.service.txn.TxnExcelReadServcie;
import com.fubon.esb.service.txn.TxnExcelWriteService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author nice
 * @createdDate 2014-11-14
 */
public class TxnExcelView extends AbstractExcelView {

    private String tempZipDir;

    private final TxnService txnService;

    private final TxnExcelReadServcie txnExcelReadServcie;

    private final TxnExcelWriteService txnExcelWriteService;

    public TxnExcelView(TxnService txnService, TxnExcelReadServcie txnExcelReadServcie, TxnExcelWriteService txnExcelWriteService) {
        this.txnService = txnService;
        this.txnExcelReadServcie = txnExcelReadServcie;
        this.txnExcelWriteService = txnExcelWriteService;
    }

    @Override
    protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
        super.prepareResponse(request, response);
    }

    @Override
    protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        TxnVO txnVO = (TxnVO) model.get("txnExcelVO");
        String fileName = null;
        if (txnVO != null) {
            txnExcelWriteService.fillWorkbookByTxn(workbook, txnVO);
            fileName = txnVO.getDefinition().getTxnCode() + "." + txnVO.getDefinition().getName() + ".xls";
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "utf-8"));
        }
    }

    private void createTempZipDir() {
        String tempDir = ZipCompressor.ZIP_EXCEL_TEMP_DIR + "\\" + System.currentTimeMillis();
        File file = null;
        file = new File(tempDir);
        file.mkdirs();
        tempZipDir = tempDir;
    }

    private String createExcelInTempZipDir(String fileName) {
        Assert.notNull(tempZipDir, "tempZipDir can not be null before create new excel");
        return tempZipDir + "\\" + fileName + ".xls";
    }

    public void writeZipFileToResponse(List<TxnVO> txnVOs, HttpServletRequest request, HttpServletResponse response) {
        prepareResponse(request, response);
        InputStream is = null;
        try {
            createExcelsInTempZipDir(txnVOs);
            File zipFile = new File(ZipCompressor.compressDirection(tempZipDir));
            response.addHeader("Content-Disposition", "attachment;filename=" + zipFile.getName());
            is = new FileInputStream(zipFile);
            IOUtils.copy(is, response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeQuietly(is);
            ZipCompressor.clearZipDirection(tempZipDir);
        }
    }

    public void createExcelsInTempZipDir(List<TxnVO> txnVOs) throws Exception {
        if (txnVOs == null || txnVOs.isEmpty())
            return;
        createTempZipDir();
        File file = null;
        OutputStream os = null;
        for (TxnVO txnVO : txnVOs) {
            Workbook workbook = txnExcelWriteService.createTxnWorkbook(txnVO);
            if (workbook != null) {
                file = new File(createExcelInTempZipDir(txnVO.getDefinition().getTxnCode() + "." + txnVO.getDefinition().getName()));
                os = new FileOutputStream(file);
                workbook.write(os);
            }
        }
    }

    @Transactional
    public Map<String, Object> saveTxnsFromUploadedFile(TxnDefinition txnDef, File file, boolean isCompress) throws Exception {
        Map<String, List<String>> errorMsgs = new HashMap<String, List<String>>(1);
        List<TxnExcelVO> excelVOs = txnExcelReadServcie.readTxnVOsFromExcel(txnDef, file, isCompress);
        List<String> savedTxnDefIds = new ArrayList<String>(1);
        if (excelVOs != null && !excelVOs.isEmpty()) {
            for (TxnExcelVO excelVO : excelVOs) {
                if (excelVO.isValid()) {
                    txnService.saveFromTxnExcelVO(excelVO);
                    savedTxnDefIds.add(excelVO.getDefinition().getId());
                } else {
                    errorMsgs.put(excelVO.getExcelName(), excelVO.getExcelErrors());
                }
            }
        }
        Map<String, Object> result = new HashMap<String, Object>(1);
        result.put("errorMsgs", errorMsgs);
        result.put("returnDefIds", savedTxnDefIds);
        return result;
    }

}
