package com.fubon.esb.domain.job;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Transient;

/**
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "JOB_CONFIG")
public class JobConfig extends JobConfigBaseEntity {

    @Column(name = "LAST_RUNNING_TIME")
    private Date lastRunningTime;

    @Column(name = "LAST_RUNNING_STATUS")
    @Enumerated(EnumType.STRING)
    private LastRunningStatusType lastRunningStatus;

    @Column(name = "RUN_TIMES")
    private Integer runTimes;

    @Transient
    private String ifMemo;

    /** 系統代號 **/
    @Column(name = "JOB_SYSTEM_ID")
    private String jobSystemId;

    /** 手動執行排程參數範例 */
    @Column(name = "PARAMS_EXAMPLE")
    private String paramsExample;

    /** 排程異常通知 */
    @Column(name = "NOTIFICATION")
    private Integer notification;

    /** 排程通知Mail */
    @Column(name = "NOTIFICATION_MAILS")
    private String notificationMails;

    /** 排程通知Phones */
    @Column(name = "NOTIFICATION_PHONES")
    private String notificationPhones;

    /** 月-執行類型 */
    @Column(name = "MONTH_TYPE")
    private String monthType;

    /** 營業日|日曆日 */
    @Column(name = "WORK_TYPE")
    private String workType;

    /** 月前幾天 */
    @Column(name = "BEFORM_DAY")
    private Integer beforeDay;

    /** 群組代號 */
    @Column(name = "MAIL_GROUP_CODE")
    private String mailGroupCode;

    @Transient
    private String jobSystemCode;

    @Transient
    private String branchCode;

    public String getJobSystemCode() {
        return jobSystemCode;
    }

    public void setJobSystemCode(String jobSystemCode) {
        this.jobSystemCode = jobSystemCode;
    }

    public String getIfMemo() {
        return ifMemo;
    }

    public Date getLastRunningTime() {
        return lastRunningTime;
    }

    public void setLastRunningTime(Date lastRunningTime) {
        this.lastRunningTime = lastRunningTime;
    }

    public LastRunningStatusType getLastRunningStatus() {
        return lastRunningStatus;
    }

    public void setLastRunningStatus(LastRunningStatusType lastRunningStatus) {
        this.lastRunningStatus = lastRunningStatus;
    }

    public Integer getRunTimes() {
        return runTimes;
    }

    public void setRunTimes(Integer runTimes) {
        this.runTimes = runTimes;
    }

    public void setIfMemo(String ifMemo) {
        this.ifMemo = ifMemo;
    }

    public String getJobSystemId() {
        return jobSystemId;
    }

    public void setJobSystemId(String jobSystemId) {
        this.jobSystemId = jobSystemId;
    }

    public String getParamsExample() {
        return paramsExample;
    }

    public void setParamsExample(String paramsExample) {
        this.paramsExample = paramsExample;
    }

    public Integer getNotification() {
        return notification;
    }

    public void setNotification(Integer notification) {
        this.notification = notification;
    }

    public String getNotificationMails() {
        return notificationMails;
    }

    public void setNotificationMails(String notificationMails) {
        this.notificationMails = notificationMails;
    }

    public String getNotificationPhones() {
        return notificationPhones;
    }

    public void setNotificationPhones(String notificationPhones) {
        this.notificationPhones = notificationPhones;
    }

    public String getMonthType() {
        return monthType;
    }

    public void setMonthType(String monthType) {
        this.monthType = monthType;
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public Integer getBeforeDay() {
        return beforeDay;
    }

    public void setBeforeDay(Integer beforeDay) {
        this.beforeDay = beforeDay;
    }

    public String getMailGroupCode() {
        return mailGroupCode;
    }

    public void setMailGroupCode(String mailGroupCode) {
        this.mailGroupCode = mailGroupCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

}
