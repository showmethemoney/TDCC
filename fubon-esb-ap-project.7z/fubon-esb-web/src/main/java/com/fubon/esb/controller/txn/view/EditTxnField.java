package com.fubon.esb.controller.txn.view;

import com.fubon.esb.domain.txn.TxnFieldDefinition;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
public class EditTxnField {

    public static final String EDIT_TYPE_ADD = "add";

    public static final String EDIT_TYPE_MOVE = "move";

    public static final String EDIT_TYPE_MODIFY = "modify";

    public static final String EDIT_TYPE_DELETE = "delete";

    public static final String DIREC_TYPE_UP = "U";

    public static final String DIREC_TYPE_DOWN = "D";

    private String trid;

    private String parentTrid;

    private String editType;

    private String blongDirec;

    private TxnFieldDefinition txnField;

    public String getTrid() {
        return this.trid;
    }

    public void setTrid(String trid) {
        this.trid = trid;
    }

    public String getParentTrid() {
        return this.parentTrid;
    }

    public void setParentTrid(String parentTrid) {
        this.parentTrid = parentTrid;
    }

    public String getEditType() {
        return this.editType;
    }

    public void setEditType(String editType) {
        this.editType = editType;
    }

    public String getBlongDirec() {
        return this.blongDirec;
    }

    public void setBlongDirec(String blongDirec) {
        this.blongDirec = blongDirec;
    }

    public TxnFieldDefinition getTxnField() {
        return this.txnField;
    }

    public void setTxnField(TxnFieldDefinition txnField) {
        this.txnField = txnField;
    }
}
