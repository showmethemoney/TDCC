package com.fubon.esb.dao.txn;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;

/**
 * @author nice
 * @fromdDate 2014-10-23
 */
@Repository
public class TxnFieldDefinitionDao extends JPADaoSupport<TxnFieldDefinition> {

    public List<TxnFieldDefinition> findMainFieldsByDirecId(String direcId) {
        Query query = Query.from(TxnFieldDefinition.class).where("directionId=:direcId and (parentId is null or parentId='')").param("direcId", direcId).orderBy("orderNo");
        return jpaAccess.find(query);
    }

    public List<TxnFieldDefinition> findChildren(String parentId) {
        Query query = Query.from(TxnFieldDefinition.class).where("parentId=:pId").param("pId", parentId).orderBy("orderNo");
        return jpaAccess.find(query);
    }

    public void removeByTxnDirection(String dirId) {
        Query query = Query.create("delete from " + TxnFieldDefinition.class.getName()).where("directionId=:dirId").param("dirId", dirId);
        jpaAccess.update(query);
    }

    public List<TxnFieldDefinition> getByTxnDirId(String dirId, OrderBy orderBy) {
        Query query = Query.from(TxnFieldDefinition.class).where("directionId=:dirId").param("dirId", dirId).orderBy(orderBy);
        return jpaAccess.find(query);
    }

    public TxnFieldDefinition getFirst(OrderBy orderBy) {
        Query query = Query.from(TxnFieldDefinition.class).orderBy(orderBy);
        query.page(new Page(1, 1));
        List<TxnFieldDefinition> result = jpaAccess.find(query);
        if (result != null && !result.isEmpty()) {
            return result.get(0);
        }
        return null;
    }

    public Integer getMaxOrderByTxn(String defId) {
        Query query = Query.create("select max(orderNo) from ").append(TxnFieldDefinition.class).append(" tf");
        query.where(" exists(select 1 from ").append(TxnDirection.class).append(" tdir where tf.directionId=tdir.id and tdir.definitionId=:defId)");
        query.param("defId", defId);
        return jpaAccess.findOne(query);
    }

    public void update(String fieldId, String values) {
        Query query = Query.create("update from ").append(TxnFieldDefinition.class).append(" txnField set ");
        query.append(" txnField.testValue = :testValue ");
        query.setParam("testValue", values);
        if (StringUtils.isNotBlank(fieldId)) {
            query.append(" where txnField.id = :id ");
            query.setParam("id", fieldId);
        }
        jpaAccess.update(query);
    }

    public TxnFieldDefinition findByTxnCode(String code, String directionId) {
        if (StringUtils.isBlank(code) || StringUtils.isBlank(directionId)) {
            return null;
        }
        Query query = Query.from(TxnFieldDefinition.class);
        query.append(" where code =:code  and directionId =:directionId ");
        query.param("code", code).param("directionId", directionId);
        return jpaAccess.findOne(query);
    }

    public void deleteTestValuesByDirId(String dirId) {
        Query query = Query.create("delete from ").append(TxnFieldTestValue.class).append(" test");
        query.append(" where exists(select 1 from ").append(TxnFieldDefinition.class);
        query.append(" f where f.id=test.fieldId and f.directionId=:dirId)").param("dirId", dirId);
        jpaAccess.update(query);
    }

    public void deleteTestValuesByField(String fid) {
        Query query = Query.create("delete from ").append(TxnFieldTestValue.class);
        query.append(" where fieldId=:fid ").param("fid", fid);
        jpaAccess.update(query);
    }

    public TxnFieldDefinition findCaseFieldByCaseValue(String switchId, String caseValue) {
        Query query = Query.from(TxnFieldDefinition.class).append(" Where parentId=:sId and value=:cValue");
        query.param("sId", switchId).param("cValue", caseValue);
        List<Object> result = jpaAccess.find(query);
        if (result != null && !result.isEmpty())
            return (TxnFieldDefinition) result.get(0);
        return null;
    }

    public List<TxnFieldDefinition> findCaseChildren(String switchId, String caseValue) {
        TxnFieldDefinition caseField = findCaseFieldByCaseValue(switchId, caseValue);
        if (caseField == null) {
            return null;
        }
        Query query = Query.from(TxnFieldDefinition.class).append(" Where parentId=:pId");
        query.param("pId", caseField.getId());
        return jpaAccess.find(query);
    }

}
