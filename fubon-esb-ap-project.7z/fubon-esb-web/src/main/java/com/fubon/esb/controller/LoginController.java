package com.fubon.esb.controller;

import javax.inject.Inject;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comwave.core.platform.cookie.RequireCookie;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.session.RequireSession;
import com.fubon.esb.crypto.EncryptionUtils;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.service.LDAPTool;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
@Controller
@RequireCookie
@RequireSession
public class LoginController {
    
    private final Logger log = LoggerFactory.getLogger(LoginController.class);

    @Inject
    private LoginContext loginContext;
    
    @Inject
    private LDAPTool ldapTool;
    
    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private Messages messages;

    @RequestMapping(value = "/viewLogin", method = RequestMethod.GET)
    public String viewLogin() {
        return "viewLogin";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(@Valid String userId, @Valid String password, String timeZone, Model model) {
        User user;
        try {
            user = ldapTool.getLdapString(userId, password);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            model.addAttribute("loginERR", "true");
            return "viewLogin";
        }
        if (user == null) {
            model.addAttribute("loginERR", "true");
            return "viewLogin";
        }
        user.setTimeZone(timeZone);
        loginContext.login(user.getUserId());
        loginContext.login(user);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("title_name_login") + ": " + userId, LogType.SYS_LOGIN);
        return "redirect:/home";
    }

    @RequestMapping("/encrypt")
    public String encrypt(Model model, String args) throws Exception {
        if (args != null && args.length() > 0) {
            model.addAttribute("encrypt", "ENC(" + EncryptionUtils.encrypt(args) + ")");
        }
        return "/common/encrypt";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout() {
        String userId = loginContext.loginedUserId();
        if (userId != null) {
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, messages.getMessage("title_name_logout") + ": " + userId, LogType.SYS_LOGOUT);
        }
        loginContext.logout();
        return "redirect:/viewLogin";
    }

}
