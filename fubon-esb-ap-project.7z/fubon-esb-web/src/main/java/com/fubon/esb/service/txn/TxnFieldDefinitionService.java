package com.fubon.esb.service.txn;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.OrderBy;
import com.fubon.esb.controller.txn.view.EditTxnField;
import com.fubon.esb.dao.txn.TxnFieldDefinitionDao;
import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;

/**
 * @author nice
 * @createdDate 2014-10-23
 */
@Service
public class TxnFieldDefinitionService extends TxnLogService {

    private final Logger logger = LoggerFactory.getLogger(TxnFieldDefinitionService.class);

    @Inject
    private TxnFieldDefinitionDao txnFieldDao;

    private String getFieldTypeMsg(FieldType fieldType) {
        String msg = null;
        switch (fieldType) {
            case F:
                msg = messages.getMessage("txn.fieldtype.f.name");
                break;
            case S:
                msg = messages.getMessage("txn.fieldtype.s.name");
                break;
            case C:
                msg = messages.getMessage("txn.fieldtype.c.name");
                break;
            case R:
                msg = messages.getMessage("txn.fieldtype.r.name");
                break;
            default:
                break;
        }
        return msg;
    }

    @Transactional
    public void save(TxnFieldDefinition txnField) {
        if (txnField != null) {
            txnFieldDao.save(txnField);
        }
    }

    @Transactional
    public void remove(TxnFieldDefinition txnField) {
        if (txnField != null) {
            txnFieldDao.delete(txnField);
            txnFieldDao.deleteTestValuesByField(txnField.getId());
            logToDB(messages.getMessage("txn.edit.log.field.delete", getFieldTypeMsg(txnField.getFieldType()), txnField.getCode() == null ? txnField.getValue() : txnField.getCode(),
                    txnField.getName()));
        }
    }

    public TxnFieldDefinition getById(String id) {
        if (id == null)
            return null;
        return (TxnFieldDefinition) txnFieldDao.get(id);
    }

    public List<TxnFieldDefinition> findMainsByDirId(String direcId) {
        return txnFieldDao.findMainFieldsByDirecId(direcId);
    }

    public List<TxnFieldDefinition> findChildren(String parentId) {
        if (StringUtils.isBlank(parentId)) {
            return null;
        }
        return txnFieldDao.findChildren(parentId);
    }

    @Transactional
    public synchronized void batchProcessFromVOs(TxnDefinition definition, EditTxnField[] eFields, String upDirecId, String downDirecId) {
        Map<String, String> savedIds = new HashMap<String, String>();
        Integer maxOrder = getMaxOrderByTxn(definition.getId());
        if ((eFields != null) && (eFields.length > 0)) {
            TxnFieldDefinition field = null;
            for (EditTxnField etf : eFields) {
                if (etf == null)
                    continue;
                maxOrder += 1;
                field = etf.getTxnField();
                field = settingField(field);
                if ("D".equals(etf.getBlongDirec())) {
                    field.setDirectionId(downDirecId);
                } else {
                    field.setDirectionId(upDirecId);
                }
                logger.debug(String.format("start process editType[%s] trId[%s] parentTrId[%s] id[%s] parentId[%s]!",
                        new Object[] {etf.getEditType(), etf.getTrid(), etf.getParentTrid(), field.getId(), field.getParentId()}));
                if ("add".equals(etf.getEditType())) {
                	Integer temp = (etf.getTxnField().getOrderNo() != null ? etf.getTxnField().getOrderNo() : maxOrder);
                    saveFromVO(savedIds, etf, temp);
                } else if ("delete".equals(etf.getEditType())) {
                    removeAndChildren(field.getId());
                } else if ("move".equals(etf.getEditType())) {
                    moveOrder(field);
                } else if ("modify".equals(etf.getEditType())) {
                    modifyUnPersistenceField(field);
                }
            }
        }
    }

    @Transactional
    public synchronized void batchProcessHeaderFromVOs(EditTxnField[] eFields, String headDirecId, boolean hasQueryOrderBy) {
        Map<String, String> savedIds = new HashMap<String, String>();
        Integer orderNo = 0;
        if (hasQueryOrderBy) {
            orderNo = getMaxOrderByTxn(headDirecId);
        }
        if ((eFields != null) && (eFields.length > 0)) {
            TxnFieldDefinition field = null;
            for (EditTxnField etf : eFields) {
                if (etf == null)
                    continue;
                orderNo += 1;
                field = etf.getTxnField();
                field = settingField(field);
                field.setDirectionId(headDirecId);
                logger.debug(String.format("start process editType[%s] trId[%s] parentTrId[%s] id[%s] parentId[%s]!",
                        new Object[] {etf.getEditType(), etf.getTrid(), etf.getParentTrid(), field.getId(), field.getParentId()}));
                if ("add".equals(etf.getEditType())) {
                    saveFromVO(savedIds, etf, field.getOrderNo() != null ? field.getOrderNo() : orderNo);
                } else if ("delete".equals(etf.getEditType())) {
                    removeAndChildren(field.getId());
                } else if ("move".equals(etf.getEditType())) {
                    moveOrder(field);
                } else if ("modify".equals(etf.getEditType())) {
                    modifyUnPersistenceField(field);
                }
            }
        }
    }

    // @Transactional
    // public void saveFromVO(Map<String, String> savedIds, EditTxnField etField) {
    // TxnFieldDefinition field = etField.getTxnField();
    // field.setId(null);
    // // field.setOrderNo(orderNo);
    // if ((StringUtils.isBlank(field.getParentId())) && (StringUtils.isNotBlank(etField.getParentTrid()))) {
    // field.setParentId((String) savedIds.get(etField.getParentTrid()));
    // }
    // save(field);
    // logToDB(messages.getMessage("txn.edit.log.field.add", getFieldTypeMsg(field.getFieldType()), field.getCode() == null ? field.getValue() : field.getCode(), field.getName()));
    // savedIds.put(etField.getTrid(), field.getId());
    // }

    @Transactional
    public void saveFromVO(Map<String, String> savedIds, EditTxnField etField, Integer orderNo) {
        TxnFieldDefinition field = etField.getTxnField();
        field.setId(null);
        field.setOrderNo(orderNo);
        if ((StringUtils.isBlank(field.getParentId())) && (StringUtils.isNotBlank(etField.getParentTrid()))) {
            field.setParentId((String) savedIds.get(etField.getParentTrid()));
        }
        save(field);
        logToDB(messages.getMessage("txn.edit.log.field.add", getFieldTypeMsg(field.getFieldType()), field.getCode() == null ? field.getValue() : field.getCode(), field.getName()));
        savedIds.put(etField.getTrid(), field.getId());
    }

    @Transactional
    public void removeAndChildren(String fieldId) {
        List<TxnFieldDefinition> children = findChildren(fieldId);
        if ((children != null) && (!children.isEmpty())) {
            for (TxnFieldDefinition c : children) {
                remove(c);
            }
        }
        remove(getById(fieldId));
    }

    @Transactional
    public void moveOrder(TxnFieldDefinition field) {
        String id = field.getId();
        Integer orderNo = field.getOrderNo();
        if ((StringUtils.isBlank(id)) || (orderNo == null)) {
            logger.warn(String.format("move id[%s] to orderNo[%d] has null value canceled!", new Object[] {id, orderNo}));
            return;
        }
        TxnFieldDefinition dbField = getById(id);
        if (dbField != null) {
            logToDB(messages.getMessage("txn.edit.log.field.move", getFieldTypeMsg(dbField.getFieldType()), dbField.getCode() == null ? dbField.getValue() : dbField.getCode(), dbField.getOrderNo(),
                    orderNo));
            dbField.setOrderNo(orderNo);
            update(dbField);
        }
    }

    @Transactional
    public void modifyUnPersistenceField(TxnFieldDefinition field) {
        if (StringUtils.isBlank(field.getId())) {
            return;
        }
        TxnFieldDefinition target = getById(field.getId());
        if (target == null) {
            return;
        }
        logToDB(messages.getMessage("txn.edit.log.field.update", getFieldTypeMsg(target.getFieldType()), target.getCode() == null ? target.getValue() : target.getCode(), target.getName()));
        BeanUtils.copyProperties(field, target);
        update(target);
    }

    @Transactional
    public void update(TxnFieldDefinition field) {
        if (field == null)
            return;
        txnFieldDao.update(field);
    }

    @Transactional
    public void removeByTxnDirection(String dirId) {
        if (StringUtils.isBlank(dirId)) {
            return;
        }
        txnFieldDao.deleteTestValuesByDirId(dirId);
        txnFieldDao.removeByTxnDirection(dirId);
    }

    public List<TxnFieldDefinition> findByTxnDirId(String dirId, OrderBy orderBy) {
        if (StringUtils.isBlank(dirId)) {
            return null;
        }
        return txnFieldDao.getByTxnDirId(dirId, orderBy);
    }

    public TxnFieldDefinition getFirst(OrderBy orderBy) {
        return txnFieldDao.getFirst(orderBy);
    }

    public Integer getMaxOrderByTxn(String defId) {
        if (StringUtils.isBlank(defId))
            return Integer.valueOf(0);
        Integer maxOrder = txnFieldDao.getMaxOrderByTxn(defId);
        return maxOrder == null ? Integer.valueOf(0) : maxOrder;
    }

    /**
     * 依欄位找到對應的TxnFieldDefinition
     * 
     * @param code
     * @param directionId
     */
    public TxnFieldDefinition findByTxnCode(String code, String directionId) {
        return txnFieldDao.findByTxnCode(code, directionId);
    }

    @Transactional
    public void saveOrUpdateTestValue(TxnFieldTestValue tftv) {
        if (tftv == null)
            return;
    }

    public List<TxnFieldDefinition> findCaseFieldsByChoice(String switchId, String caseValue) {
        return txnFieldDao.findCaseChildren(switchId, caseValue);
    }

    public TxnFieldDefinition settingField(TxnFieldDefinition field) {
        String code = null;
        String value = null;
        if (field != null) {
            code = field.getCode();
            value = field.getValue();
        }
        if (field != null && StringUtils.isNotBlank(code)) {
            field.setCode(code.trim());
        }
        if (field != null && StringUtils.isNotBlank(value)) {
            field.setValue(value.trim());
        }
        return field;
    }

}
