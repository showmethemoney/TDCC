package com.fubon.esb.domain.system;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "CFG_ADAPTER")
public class Adapter implements Serializable {

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 所属Connector */
    @Column(name = "CONNECTOR_ID")
    private String connectorId;

    /** Adapter名称 */
    @Column(name = "ADAPTER_NAME")
    private String adapterName;

    /** 网址 */
    @Column(name = "URL")
    private String url;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }

    public String getAdapterName() {
        return adapterName;
    }

    public void setAdapterName(String adapterName) {
        this.adapterName = adapterName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
