package com.fubon.esb.domain.job;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-17
 */
@Entity(name = "JOB_RECORD")
public class JobRecord {
    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    @Column(name = "CONFIG_ID")
    private String configId;

    @Column(name = "START_TIME")
    private Date startTime;

    @Column(name = "END_TIME")
    private Date endTime;

    @Column(name = "RUN_TYPE")
    @Enumerated(EnumType.STRING)
    private RunType runType;

    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private JobRecordStatusType status;

    @Column(name = "MESSAGE")
    private String message;

    /** 手動執行者 */
    @Column(name = "EXECUTE_USER")
    private String executeUser;

    /** 備註 **/
    @Column(name = "REMARK")
    private String remark;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public JobRecordStatusType getStatus() {
        return status;
    }

    public void setStatus(JobRecordStatusType status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getExecuteUser() {
        return executeUser;
    }

    public void setExecuteUser(String executeUser) {
        this.executeUser = executeUser;
    }

    public RunType getRunType() {
        return runType;
    }

    public void setRunType(RunType runType) {
        this.runType = runType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}
