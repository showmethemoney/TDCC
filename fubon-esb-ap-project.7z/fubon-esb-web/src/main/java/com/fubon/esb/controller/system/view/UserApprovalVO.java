package com.fubon.esb.controller.system.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Qigers
 * @createdDate 2015-1-14
 */
public class UserApprovalVO {

    private String userId;

    private String updatedUser;

    private String endDateStr;

    private String startDateStr;

    public Date getStartDate() {
        if (StringUtils.isBlank(startDateStr)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(startDateStr + " 00:00:00");
        } catch (ParseException e) {
            return null;
        }
    }

    public void setStartDateStr(String startDateStr) {
        this.startDateStr = startDateStr;
    }

    public String getStartDateStr() {
        return startDateStr;
    }

    public Date getEndDate() {
        if (StringUtils.isBlank(endDateStr)) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(endDateStr + " 23:59:59");
        } catch (ParseException e) {
            return null;
        }
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEndDateStr() {
        return endDateStr;
    }

    public void setEndDateStr(String endDateStr) {
        this.endDateStr = endDateStr;
    }
}
