package com.fubon.esb.service.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 
 * @author Shelly
 * @createdDate 2015-3-26
 */

@Service
public class BaseJobConfigService {

    private final Logger logger = LoggerFactory.getLogger(BaseJobConfigService.class);

    public Date formatToDateTime(String dateStr, String hour, String minute, String second) {
        Date runningDate = null;
        try {
            runningDate = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(dateStr + " " + hour + ":" + minute + ":" + second);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        return runningDate;
    }

    public Date formatToDate(String dateStr) {
        Date runningDate = null;
        try {
            runningDate = new SimpleDateFormat("yyyy/MM/dd").parse(dateStr);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        return runningDate;
    }

    public Date dateAddMinute(Date date, int minute) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MINUTE, minute);
        return c.getTime();
    }

    public boolean checkDatePreMonth(String dateStr) {
        Date runningDate = formatToDate(dateStr);
        Date currDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currDate);
        calendar.add(Calendar.MONTH, -1);
        Date preMonth = calendar.getTime();
        return runningDate.after(preMonth);
    }
}
