package com.fubon.esb.controller.system;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.service.system.GroupService;
import com.fubon.esb.service.system.RoleService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Controller
@RequestMapping("/system")
public class RoleController extends BaseController {

    @Inject
    private GroupService groupService;

    @Inject
    private RoleService roleService;

    /**
     * 進入Role修改頁面
     */
    @RequestMapping("viewRole")
    @RequirePermission("070101")
    public String viewRole(Model model, String groupId, String roleId) {
        model.addAttribute("group", groupService.getGroupById(groupId));
        Role role = roleService.getRoleById(roleId);
        if (role != null) {
            model.addAttribute("users", roleService.findUserListByRole(role.getId()));   
        }
        model.addAttribute("role", role);
        model.addAttribute("groupId", groupId);
        model.addAttribute("roleId", roleId);
        model.addAttribute("STATUS_ACTIVE", ActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ActiveStatus.I);
        return "/system/viewRole";
    }

    /**
     * 新增或修改 role
     */
    @RequestMapping("saveOrUpdateRole")
    @RequirePermission({"070104", "070105"})
    @ResponseBody
    public Map<String, Object> saveOrUpdateRole(Role role, String[] userIds) {
        Map<String, Object> result = new HashMap<>();
        roleService.saveOrUpdateRole(role, userIds);
        result.put("flag", true);
        result.put("groupId", role.getGroupId());
        result.put("roleId", role.getId());
        return result;
    }

    /**
     * 分頁地在彈窗中顯示用戶信息
     */
    @RequestMapping("viewBranchList")
    @RequirePermission({"070104", "070105"})
    public String viewBranchList(Model model, String branchName, @RequestParam(required = false, defaultValue = "1") Integer currentPage) {
        Page page = new Page(currentPage);
        model.addAttribute("users", roleService.findUserList(branchName, page));
        model.addAttribute("branchName", branchName);
        model.addAttribute("page", page);
        return "/system/viewBranchList";
    }
    
    @RequestMapping("viewRoleFromFunc")
    @RequirePermission("070101")
    public String viewRoleFromFunc(Model model, String roleId) {
        Role role = roleService.getRoleById(roleId);
        return viewRole(model, role.getGroupId(), roleService.getRoleOriginId(role));
    }

}
