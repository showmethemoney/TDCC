package com.fubon.esb.service.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.dao.system.GroupDao;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.domain.ActiveStatus;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Service
public class GroupService {

    @Inject
    private GroupDao groupDao;

    @Inject
    private RoleDao roleDao;

    @Inject
    private LoginContext loginContext;

    @Inject
    private Messages messages;

    @Inject
    private OperationLogService operationLogService;

    /**
     * 通過群組Id查詢可以修改的群組Group
     */
    public Group getGroupById(String id) {
        if (StringUtils.isBlank(id)) {
            return null;
        }

        Group group = groupDao.getGroupByMainId(id);
        if (group == null) {
            // group未修改過
            group = groupDao.getGroupById(id);
        }

        return group;
    }

    @Transactional
    public void saveGroup(Group group) throws Exception {
        if (isAdGroupRepeat(group)) {
            throw new Exception(getMessage("function_message_error_adGroupRepeat"));
        }

        group.setName(group.getName().trim());
        group.setAdGroup(group.getAdGroup().trim());
        group.setUpdatedUser(loginContext.loginedUserId()); // 修改人員
        group.setUpdatedTime(new Date()); // 修改時間
        Group oldGroup = null;
        StringBuilder logMessage = new StringBuilder();

        if (StringUtils.isBlank(group.getId())) {
            group.setMainId("0");
            group.setModifyFlag(getModifyFlagByGroup(group, oldGroup));
            groupDao.saveGroup(group); // 新增
            logMessage.append(getMessage("system_log_group_add")).append(": ").append(group.getName());
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, logMessage.toString(), LogType.SYS_FUNC_MANAGE);
            return;
        } else {
            oldGroup = groupDao.getGroupById(group.getId());
        }

        logMessage.append(getMessage("system_log_group_edit")).append(": ").append(oldGroup.getName());
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, logMessage.toString(), LogType.SYS_FUNC_MANAGE);
        if (StringUtils.isNotBlank(group.getMainId())) {
            group.setModifyFlag(getModifyFlagByGroup(group, oldGroup));
            groupDao.update(group); // 重複修改
            return;
        }

        group.setMainId(group.getId());
        group.setId(null);
        group.setModifyFlag(getModifyFlagByGroup(group, oldGroup));
        groupDao.saveGroup(group); // 最新修改
    }

    private boolean isAdGroupRepeat(Group group) {
        List<Group> groups = groupDao.findGroupByAdGroup(group.getAdGroup());

        if (groups == null || groups.isEmpty()) {
            return false; // 不重複，返回假
        }

        if (groups.size() == 1) {
            String groupId = groups.get(0).getId();
            if (groupId.equals(group.getId()) || groupId.equals(group.getMainId())) {
                return false;
            }
            return true;
        }

        if (groups.get(0).getId().equals(group.getMainId()) || groups.get(1).getId().equals(group.getMainId())) {
            return false;
        }
        return true;
    }

    public List<Group> findAllGroups() {
        List<Group> groups = groupDao.findLatestGroups();

        if (groups == null) {
            return new ArrayList<>();
        }

        for (Group group : groups) {
            group.setRoles(roleDao.findRoleListByGroupId(group.getId()));
        }

        return groups;
    }

    /**
     * 根據ID獲取Group，同時查詢出轄下所有Role
     */
    public Group getFullGroup(String id) {
        Group group = groupDao.getGroupByMainId(id);
        if (group == null) {
            // group未修改過
            group = groupDao.getGroupById(id);
        }
        group.setRoles(roleDao.findRoleListByGroupId(id));

        return group;
    }

    /**
     * 返回Group最初對ID
     */
    public String getGroupOriginId(Group group) {
        if (StringUtils.isBlank(group.getMainId()) || "0".equals(group.getMainId())) {
            return group.getId();
        }

        return group.getMainId();
    }

    /**
     * 修改Group後的內容標誌
     */
    public Integer getModifyFlagByGroup(Group newGroup, Group oldGroup) {
        return 1;
    }

    public ApprovalLog getGroupApprovalLogByGroupId(String groupId) {
        ApprovalLog approvalLog = new ApprovalLog();
        Group group = groupDao.getGroupById(groupId);
        Group oldGroup = null;
        if (!"0".equals(group.getMainId())) {
            oldGroup = groupDao.getGroupById(group.getMainId());
        }

        approvalLog.setGroup(group);
        approvalLog.setModifyFlag(group.getModifyFlag());
        approvalLog.setUpdatedUser(group.getUpdatedUser());
        approvalLog.setUpdatedTime(group.getUpdatedTime());
        approvalLog.setModifyContent(getGroupModifyContent(group, oldGroup));

        return approvalLog;
    }

    private String getGroupModifyContent(Group newGroup, Group oldGroup) {
        StringBuilder content = new StringBuilder();

        if (oldGroup == null) { // 新增
            if (StringUtils.isNotBlank(newGroup.getName())) {
                content.append(getMessage("system.approval.group.name")).append("-").append(newGroup.getName()).append("\r\n");
            }
            if (StringUtils.isNotBlank(newGroup.getAdGroup())) {
                content.append(getMessage("system.approval.group.ad")).append("-").append(newGroup.getAdGroup()).append("\r\n");
            }
            if (newGroup.getStatus() != null) {
                content.append(getMessage("system.approval.group.status")).append("-").append(getStatus(newGroup.getStatus())).append("\r\n");
            }
            if (newGroup.getOrderNo() != null) {
                content.append(getMessage("system.approval.group.orderNo")).append("-").append(newGroup.getOrderNo()).append("\r\n");
            }
            if (StringUtils.isNotBlank(newGroup.getDesc())) {
                content.append(getMessage("system.approval.group.desc")).append("-").append(newGroup.getDesc()).append("\r\n");
            }

            return content.toString();
        }

        if (!newGroup.getName().equals(oldGroup.getName())) {
            content.append(getMessage("system.approval.group.name")).append("-").append(newGroup.getName()).append("\r\n");
        }
        if (!newGroup.getAdGroup().equals(oldGroup.getAdGroup())) {
            content.append(getMessage("system.approval.group.ad")).append("-").append(newGroup.getAdGroup()).append("\r\n");
        }
        if (!newGroup.getStatus().equals(oldGroup.getStatus())) {
            content.append(getMessage("system.approval.group.status")).append("-").append(getStatus(newGroup.getStatus())).append("\r\n");
        }
        if (!checkInt(newGroup.getOrderNo()).equals(checkInt(oldGroup.getOrderNo()))) {
            content.append(getMessage("system.approval.group.orderNo")).append("-").append(newGroup.getOrderNo()).append("\r\n");
        }
        if (!newGroup.getDesc().equals(oldGroup.getDesc())) {
            content.append(getMessage("system.approval.group.desc")).append("-").append(newGroup.getDesc()).append("\r\n");
        }

        return content.toString();
    }
    
    private String checkInt(Integer i) {
        if (i == null) {
            return "";
        } else {
            return String.valueOf(i);
        }
    }

    /** 根據Ad Group獲取有效的群組 */
    public Group getGroupByAdGroup(String adGroup) {
        return groupDao.getGroupByAdGroup(adGroup);
    }
    
    public String getStatus(ActiveStatus status) {
        if (status == null) {
            return "";
        }
        if (status.equals(ActiveStatus.A)) {
            return getMessage("system.approval.active");
        } else {
            return getMessage("system.approval.inactive");
        }
    }
    
    public List<Group> findGroupByRoles(List<Role> roles) {
        Set<String> ids = new HashSet<>();
        for (Role role : roles) {
            ids.add(role.getGroupId());
        }
        return groupDao.findGroupByIds(ids);
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

}
