package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * Mail通知群組
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_MAIL_GROUP")
public class MailGroup implements Serializable {

    private static final long serialVersionUID = 4444697189727856019L;

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 群組代號 */
    @Column(name = "MAIL_CODE")
    private String code;

    /** 群組名稱 */
    @Column(name = "MAIL_NAME")
    private String name;

    /** 備註 */
    @Column(name = "MEMO")
    private String memo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

}
