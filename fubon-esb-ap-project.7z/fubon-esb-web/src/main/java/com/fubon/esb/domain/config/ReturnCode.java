package com.fubon.esb.domain.config;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

/**
 * 交易回應代碼
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */             
@Entity(name = "CFG_RETURN_CODE")
public class ReturnCode implements Serializable {
    private static final long serialVersionUID = 5909714750932969016L;

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 業務群組代號 */
    @Column(name = "GROUP_CODE")
    private String groupCode;

    /** 交易回應代碼 */
    @Column(name = "RETURN_CODE")
    private String returnCode;

    /** 交易回應代碼說明 */
    @Column(name = "DESCZ")
    private String descz;

    /** 解決方案 */
    @Column(name = "SOLUTION")
    private String solution;

    /** 建立者 */
    @Column(name = "CREATED_USER")
    private String createdUser;

    /** 建立時間 */
    @Column(name = "CREATED_TIME")
    private Date createdTime;

    /** 更新者 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getDescz() {
        return descz;
    }

    public void setDescz(String descz) {
        this.descz = descz;
    }

}
