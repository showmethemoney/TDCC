package com.fubon.esb.dao.log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.controller.log.view.OperationLogSearchVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-23
 */
@Repository
public class OperationLogDao extends LogDBJPADaoSupport<OperationLog> {

    @Inject
    private TimeZoneService timeZoneService;

    private Date getFullTime(String searchDate, String hour, String minute, String second, String millisecond) {
        if (StringUtils.isNotBlank(searchDate) && StringUtils.isNotBlank(hour) && StringUtils.isNotBlank(minute)) {
            try {
                return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").parse(searchDate + " " + hour + ":" + minute + ":" + second + "." + millisecond);
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
                return null;
            }
        }
        return null;
    }

    public String getModule(OperationLogSearchVO vo) {
        String module;
        if ("".equals(vo.getModuleFunction()) || null == vo.getModuleFunction()) {
            module = "";
        } else if (vo.getModuleFunction().startsWith("#")) {
            module = "";
        } else if (vo.getModuleFunction().endsWith("#")) {
            module = vo.getModuleFunction().substring(0, vo.getModuleFunction().length() - 1);
        } else {
            String[] array = vo.getModuleFunction().split("#");
            module = array[0];
        }
        return module;
    }

    public String getFunction(OperationLogSearchVO vo) {
        String function;
        if ("".equals(vo.getModuleFunction()) || null == vo.getModuleFunction()) {
            function = "";
        } else if (vo.getModuleFunction().startsWith("#")) {
            function = vo.getModuleFunction().substring(1);
        } else if (vo.getModuleFunction().endsWith("#")) {
            function = "";
        } else {
            String[] array = vo.getModuleFunction().split("#");
            function = array[1];
        }
        return function;
    }

    private StringBuilder getSqlCondition(OperationLogSearchVO vo, StringBuilder jql, Map<String, Object> params, String message) {
        Date startTime = getFullTime(vo.getStartDate(), vo.getStartHour(), vo.getStartMinute(), "00", "000");
        Date endTime = getFullTime(vo.getEndDate(), vo.getEndHour(), vo.getEndMinute(), "59", "999");
        String module = getModule(vo);
        String function = getFunction(vo);
        String level = vo.getLevel();
        if (StringUtils.isNotBlank(vo.getStartDate())) {
            jql.append(" and opTime >= :startTime ");
            params.put("startTime", timeZoneService.getTZDateByService(startTime));
        }
        if (StringUtils.isNotBlank(vo.getEndDate())) {
            jql.append(" and opTime <= :endTime ");
            params.put("endTime", timeZoneService.getTZDateByService(endTime));
        }
        if (StringUtils.isNotBlank(level)) {
            jql.append(" and level = :level ");
            params.put("level", level);
        }
        if (StringUtils.isNotBlank(module)) {
            jql.append(" and module = :module ");
            params.put("module", module);
        }
        if (StringUtils.isNotBlank(message)) {
            jql.append(" and message like :message ");
            params.put("message", "%" + message + "%");
        }
        if (StringUtils.isNotBlank(function)) {
            jql.append(" and function = :function ");
            params.put("function", function);
        }
        return jql;
    }

    public Object findOperationLogDaoList(OperationLogSearchVO vo, OrderBy orderBy, Page page, String message) {
        StringBuilder jql = new StringBuilder();
        jql.append("from " + OperationLog.class.getName() + " where 1=1 ");
        Map<String, Object> params = new HashMap<String, Object>();
        jql = getSqlCondition(vo, jql, params, message);
        if (StringUtils.isNotBlank(vo.getOpUser())) {
            jql.append(" and opUser like :opUser ");
            params.put("opUser", "%" + vo.getOpUser() + "%");
        }
        
        if (StringUtils.isNotBlank(vo.getExcludeMessage())) {
            jql.append(" and message not like :excludeMessage ");
            params.put("excludeMessage", "%" + vo.getExcludeMessage() + "%");
        }

        Query query = Query.create(jql.toString());
        if (!StringUtils.isNotBlank(orderBy.getField())) {
            query.orderBy(" opTime desc");
        } else {
            query.orderBy(orderBy.getClause());
        }
        query.page(page).putParams(params);
        List<OperationLog> operationLogs = jpaAccess.findPage(query);
        if (operationLogs == null) {
            return new ArrayList<>();
        }
        return operationLogs;
    }
}
