package com.fubon.esb;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.fubon.esb.schedule.duration.TxnRecordDurationScheduler;
import com.fubon.esb.schedule.duration.TxnRecordTimeScheduler;
import com.fubon.esb.schedule.ems.EMSMonitorScheduler;
import com.fubon.esb.service.config.MailGroupService;


/**
 * @author Ethan Lee
 */
@Configuration
public class ScheduleConfig
{
	protected static final String NAMED_CRON_EXPRESSION_EMS_MONITOR = "schedule.EMSMonitorScheduler.cron.expression";
	protected static final String NAMED_CRON_EXPRESSION_TXN_RECORD_DURATION = "schedule.TxnRecordDurationScheduler.cron.expression";
	protected static final String NAMED_CRON_EXPRESSION_TXN_RECORD_TIME = "schedule.TxnRecordTimeScheduler.cron.expression";
	public static final String NAMED_MAIL_TO = "mail.to";
	public static final String NAMED_MAIL_FROM = "mail.from";
	public static final String NAMED_MAIL_SERVER = "mail.server";
	public static final String NAMED_MAIL_SERVER_PORT = "mail.server.port";

	@Autowired
	Environment environment = null;
	@Autowired
	MailGroupService mailGroupService = null;
	@Autowired
	DataSource logDbDataSource = null;
	
	/**
	 * 監控 EMS 是否有積Queue 情況
	 */
	@Bean
	public JobDetailFactoryBean jobDetailEMSMonitorFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setDurability( true );
		factory.setJobClass( com.fubon.esb.schedule.ems.EMSMonitorScheduler.class );

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put( EMSMonitorScheduler.NAMED_EMS_PASSWORD, environment.getProperty( EMSMonitorScheduler.NAMED_EMS_PASSWORD ) );
		parameters.put( EMSMonitorScheduler.NAMED_MAX_PENDING, environment.getProperty( EMSMonitorScheduler.NAMED_MAX_PENDING ) );
		parameters.put( EMSMonitorScheduler.NAMED_EMS_URLS, environment.getProperty( EMSMonitorScheduler.NAMED_EMS_URLS ) );
		parameters.put( EMSMonitorScheduler.NAMED_EMS_USERNAME, environment.getProperty( EMSMonitorScheduler.NAMED_EMS_USERNAME ) );
		parameters.put( EMSMonitorScheduler.NAMED_SERVICE, mailGroupService );		
		
		parameters.put( ScheduleConfig.NAMED_MAIL_FROM, environment.getProperty( ScheduleConfig.NAMED_MAIL_FROM ) );
		parameters.put( ScheduleConfig.NAMED_MAIL_SERVER, environment.getProperty( ScheduleConfig.NAMED_MAIL_SERVER ) );
		parameters.put( ScheduleConfig.NAMED_MAIL_SERVER_PORT, environment.getProperty( ScheduleConfig.NAMED_MAIL_SERVER_PORT ) );
		
		factory.setJobDataAsMap( parameters );

		return factory;
	}
	
	/**
	 * 每五分鐘刪除 TXN_RECORD_TIME
	 */
	@Bean
	public JobDetailFactoryBean jobDetailTxnRecordTimeFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setDurability( true );
		factory.setJobClass( com.fubon.esb.schedule.duration.TxnRecordTimeScheduler.class );

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put( TxnRecordTimeScheduler.NAMED_DATASOURCE, logDbDataSource );
		
		factory.setJobDataAsMap( parameters );

		return factory;
	}
	
	/**
	 * 每一天刪除 TXN_RECORD_DURATION
	 */
	@Bean
	public JobDetailFactoryBean jobDetailTxnRecordDurationFactoryBean() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setDurability( true );
		factory.setJobClass( com.fubon.esb.schedule.duration.TxnRecordDurationScheduler.class );

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put( TxnRecordDurationScheduler.NAMED_DATASOURCE, logDbDataSource );
		
		factory.setJobDataAsMap( parameters );

		return factory;
	}
	
	/**
	 * 監控 EMS 是否有積Queue 情況
	 */
	@Bean
	public CronTriggerFactoryBean cronTriggerEMSMonitorTriggerFactoryBean() {
		CronTriggerFactoryBean factory = new CronTriggerFactoryBean();
		factory.setJobDetail( jobDetailEMSMonitorFactoryBean().getObject() );

		factory.setCronExpression( environment.getProperty( ScheduleConfig.NAMED_CRON_EXPRESSION_EMS_MONITOR ) );

		return factory;
	}
	
	/**
	 * 每一天刪除 TXN_RECORD_TIME
	 */
	@Bean
	public CronTriggerFactoryBean cronTriggerTxnRecordDurationTriggerFactoryBean() {
		CronTriggerFactoryBean factory = new CronTriggerFactoryBean();
		factory.setJobDetail( jobDetailTxnRecordDurationFactoryBean().getObject() );

		factory.setCronExpression( environment.getProperty( ScheduleConfig.NAMED_CRON_EXPRESSION_TXN_RECORD_DURATION ) );

		return factory;
	}
	
	/**
	 * 每五分鐘刪除 TXN_RECORD_TIME
	 */
	@Bean
	public CronTriggerFactoryBean cronTriggerTxnRecordTimeTriggerFactoryBean() {
		CronTriggerFactoryBean factory = new CronTriggerFactoryBean();
		factory.setJobDetail( jobDetailTxnRecordTimeFactoryBean().getObject() );

		factory.setCronExpression( environment.getProperty( ScheduleConfig.NAMED_CRON_EXPRESSION_TXN_RECORD_TIME ) );

		return factory;
	}
	
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() {
		SchedulerFactoryBean scheduler = new SchedulerFactoryBean();
		
		scheduler.setTriggers( 
			cronTriggerEMSMonitorTriggerFactoryBean().getObject(),
			cronTriggerTxnRecordTimeTriggerFactoryBean().getObject(),
			cronTriggerTxnRecordDurationTriggerFactoryBean().getObject()
		);

		return scheduler;
	}
}
