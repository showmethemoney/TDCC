package com.fubon.esb.domain.log;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;

/**
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_APPROVAL_LOG")
public class ApprovalLog {

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 所屬群組 */
    @Column(name = "GROUP_ID")
    private String groupId;

    /** 所屬角色 */
    @Column(name = "ROLE_ID")
    private String roleId;

    /** 修改內容標志 */
    @Column(name = "MODIFY_FLAG")
    private Integer modifyFlag;

    /** 修改詳細內容 */
    @Column(name = "MODIFY_DETAIL")
    private String modifyDetail;

    /** 修改人 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 修改時間 */
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTime;

    /** 復核人 */
    @Column(name = "APPROVED_USER")
    private String approvedUser;

    /** 復核時間 */
    @Column(name = "APPROVED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date approvedTime;

    /** 關聯群組 */
    @Transient
    private Group group;

    /** 關聯角色 */
    @Transient
    private Role role;

    /** 修改內容 */
    @Transient
    private String modifyContent;

    public ApprovalLog() {
    }

    public ApprovalLog(String groupId, String roleId, Integer modifyFlag, String updatedUser, Date updatedTime) {
        this.groupId = groupId;
        this.roleId = roleId;
        this.modifyFlag = modifyFlag;
        this.updatedUser = updatedUser;
        this.updatedTime = updatedTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

    public String getModifyDetail() {
        return modifyDetail;
    }

    public void setModifyDetail(String modifyDetail) {
        this.modifyDetail = modifyDetail;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getApprovedUser() {
        return approvedUser;
    }

    public void setApprovedUser(String approvedUser) {
        this.approvedUser = approvedUser;
    }

    public Date getApprovedTime() {
        return approvedTime;
    }

    public void setApprovedTime(Date approvedTime) {
        this.approvedTime = approvedTime;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getModifyContent() {
        return modifyContent;
    }

    public void setModifyContent(String modifyContent) {
        this.modifyContent = modifyContent;
    }

}
