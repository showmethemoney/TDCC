package com.fubon.esb.domain.log;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Qigers
 * @createdDate 2014-11-21
 */
@Entity(name = "SERVER_STATUS")
public class ServerStatus {
    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 系統名稱 */
    @Column(name = "SERVER_NAME")
    private String serverName;

    /** CPU */
    @Column(name = "CPU")
    private String cpu;

    /** Memory */
    @Column(name = "MEMORY")
    private String memory;

    /** 硬碟使用量 */
    @Column(name = "DISK")
    private String disk;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getMemory() {
        return memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public String getDisk() {
        return disk;
    }

    public void setDisk(String disk) {
        this.disk = disk;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
