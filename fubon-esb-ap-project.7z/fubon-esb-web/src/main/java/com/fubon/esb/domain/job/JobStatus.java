package com.fubon.esb.domain.job;

public enum JobStatus {
    
    A("Active"), I("InActive"), D("Delete");

    private final String desc;

    private JobStatus(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
