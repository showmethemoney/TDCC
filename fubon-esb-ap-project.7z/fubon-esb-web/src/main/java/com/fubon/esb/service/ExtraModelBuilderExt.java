package com.fubon.esb.service;

import java.util.Map;

import javax.inject.Inject;

import org.springframework.core.env.Environment;

import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.model.ExtraModelBuilder;

/**
 * @author james
 * @createdDate 2014-11-04
 */
public class ExtraModelBuilderExt extends ExtraModelBuilder {

    @Inject
    private Messages message;

    @Inject
    private Environment env;
    
    @Inject
    private LoginContext loginContext;

    @Inject
    private TimeZoneService timeZoneService;

    @Override
    public void mergeTo(Map<String, Object> model) {
        super.mergeTo(model);
        model.put("i18n", message);
        model.put("URL_BWPM", env.getRequiredProperty("bw.http.url.bwpm"));
        model.put("URL_TIBCO_ADMINISTRATOR", env.getRequiredProperty("bw.http.url.tibco.administrator"));
        model.put("loginUserId", loginContext.loginedUserId());
        model.put("dateUtil", timeZoneService);
    }

}
