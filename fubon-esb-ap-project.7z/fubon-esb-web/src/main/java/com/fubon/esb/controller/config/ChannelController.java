package com.fubon.esb.controller.config;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.common.ResultView;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.ChannelQueryParam;
import com.fubon.esb.controller.config.view.EditChannelView;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Workstation;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ChannelService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.WorkStationBranchIPService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Controller
@RequestMapping("/channel")
public class ChannelController extends BaseController {

    @Inject
    private ChannelService channelService;
    @Inject
    private LoginContext loginContext;
    @Inject
    private WorkStationBranchIPService workStationBranchIPService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSearchChannelList")
    public String viewChannelList(Model model) {
        return "/config/viewChannelList";
    }

    @RequirePermission(value = "050201")
    @RequestMapping("/viewChannelList")
    public String viewChannelList(Model model, ChannelQueryParam cp, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Channel> channelList = channelService.findLatestChannels(cp, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            channelList = channelService.findLatestChannels(cp, page);
        }
        model.addAttribute("channelList", channelList);
        model.addAttribute("code", cp.getCode());
        model.addAttribute("name", cp.getName());
        model.addAttribute("status", cp.getStatus());
        model.addAttribute("workstationId", cp.getWorkstationId());
        model.addAttribute("page", page);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        return "/config/viewChannelList";
    }

    
    @RequestMapping("/refreshChannel")
    @ResponseBody
    public Object refreshChannel(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
    	 
         if (StringUtils.isNotBlank(id))
             send_status=configChangeService.sendChangeEvent(ConfigType.CFG_CHANNEL, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    
    @RequirePermission(value = "050202")
    @RequestMapping("/viewAddChannel")
    public String viewAddChannel(Model model) {
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        return "/config/viewAddChannel";

    }

    @RequirePermission(value = "050203")
    @RequestMapping("/viewUpdateChannel")
    public String viewUpdateChannel(Model model, @RequestParam(required = false) String id) {
        Channel channel = null;
        String txnCodes = "";
        if (StringUtils.isNotBlank(id)) {
            channel = channelService.getById(id);
            txnCodes = channelService.txnCodesById(id);
        }
        model.addAttribute("channel", channel);
        model.addAttribute("txnCodes", txnCodes);
        model.addAttribute("workstations", workStationBranchIPService.findWorkstationByChannelId(id));
        model.addAttribute("branchIps", workStationBranchIPService.findBranchIPByChanelId(id));
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewUpdateChannel";
    }

    @RequestMapping("/saveChannel")
    @ResponseBody
    public ResultView saveChannel(Model model, @Valid Channel channel, EditChannelView editChannel) {
        try {
            String channelId = null;
            channelId = channelService.saveChannel(channel, editChannel);
            configChangeService.sendChangeEvent(ConfigType.CFG_CHANNEL, channelId);
        } catch (DuplicatedException | NoSuchAlgorithmException | UnsupportedEncodingException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/channel/viewChannelList");
    }

    @RequestMapping("/updateChannel")
    @ResponseBody
    public ResultView updateChannel(Model model, @Valid Channel channel, EditChannelView editChannel) {
        try {
            String channelId = null;
            channelId = channelService.updateChannel(channel, editChannel);
            configChangeService.sendChangeEvent(ConfigType.CFG_CHANNEL, channelId);
        } catch (DuplicatedException | NoSuchAlgorithmException | UnsupportedEncodingException e) {
            addError(e.getMessage());
            validate();
        }
        return ResultView.success("/channel/viewChannelList");
    }

    @RequestMapping("/findWorkstations")
    @ResponseBody
    public Map<String, Object> findWorkstations(Model mode, @RequestParam String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        try {
            List<Workstation> workstations = channelService.findWorkStations(id);
            result.put("flag", true);
            result.put("workstations", workstations);
        } catch (Exception e) {
            result.put("flag", false);
        }
        return result;
    }

    @RequestMapping("/findMainChannels")
    public String findMainChannels(Model model, String code, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Channel> channels = channelService.findMainChannels(code, page);
        model.addAttribute("code", code);
        model.addAttribute("page", page);
        model.addAttribute("channels", channels);
        return "/config/include/viewMainChannelList";
    }

    @ResponseBody
    @RequestMapping({"/findMainChannelCodes"})
    public Object findMainChannelCodes(@RequestParam String key) {
        return autoQueryService.searchMainChannelCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findChannelCodes"})
    public Object findChannelCodes(@RequestParam String key) {
        return autoQueryService.searchChannelCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findWorkstationCodes"})
    public Object findWorkstationCodes(@RequestParam String key) {
        return autoQueryService.serchWorkstationCodes(key);
    }

    @RequirePermission(value = "050201")
    @RequestMapping("/viewChannelDetail")
    public String viewChannelDetail(Model model, @RequestParam String id) {
        Channel channel = null;
        String txnCodes = "";
        channel = channelService.getById(id);
        txnCodes = channelService.txnCodesById(id);
        model.addAttribute("channel", channel);
        model.addAttribute("txnCodes", txnCodes);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", ConfigActiveStatus.I);
        model.addAttribute("workstations", workStationBranchIPService.findWorkstationByChannelId(id));
        model.addAttribute("branchIps", workStationBranchIPService.findBranchIPByChanelId(id));
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewChannelDetail";
    }

    // 刪除
    @RequestMapping("/deleteChannel")
    @ResponseBody
    public Object deleteChannel(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = channelService.isRelatedChannel(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + (relateMessage.isEmpty() ? "" : "，與以下交易關聯" + relateMessage));
        } else {
            channelService.deleteChannel(id);
            flag = true;
            result.put("flag", flag);
        }
        return result;
    }
}
