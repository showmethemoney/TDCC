/**
 * $Revision: 1.42 $ $Author: neal_xu $ $Date: 2013/05/31 01:21:40 $
 * 
 * Author: Eric Yang Date : May 6, 2010 4:48:29 PM
 * 
 */
package com.fubon.esb.service;

import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.service.system.GroupService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-11-17
 */
@Service
public class LDAPTool {

    private String providerurl;

    private String domain;

    private String searchBase;

    private String userId;

    @Inject
    private Environment env;

    @Inject
    private RoleDao roleDao;
    
    @Inject
    private GroupService groupService;

    @PostConstruct
    public void init() {
        domain = env.getProperty("ldap_domian");
        searchBase = env.getProperty("ldap_search_base");
        providerurl = env.getProperty("ldap_provider_url");
    }

    public User getLdapString(String userId, String password) throws Exception {
        Properties properties = new Properties();
        StringBuilder adminName = new StringBuilder(userId);
        this.userId = userId;

        if (StringUtils.isNotBlank(domain))
            adminName.append("@").append(domain);

        properties.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        // set security credentials, note using simple cleartext authentication
        properties.put(Context.SECURITY_AUTHENTICATION, "simple");
        properties.put(Context.SECURITY_PRINCIPAL, adminName.toString());
        properties.put(Context.SECURITY_CREDENTIALS, password);
        // connect to my domain controller
        properties.put(Context.PROVIDER_URL, providerurl);

        // return ldapSearch(properties);return
        return getResult(ldapSearch(properties));
    }

    private NamingEnumeration ldapSearch(Properties properties) throws Exception {

        // Create the initial directory context
        LdapContext ctx = new InitialLdapContext(properties, null);

        // Create the search controls
        SearchControls searchCtls = new SearchControls();

        // Specify the search scope
        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        // specify the LDAP search filter
        String searchFilter = "(&(objectCategory=*)(objectClass=user)(sAMAccountName=" + userId + "))";

        String returnedAtts[] = {"cn", "displayName", "memberOf", "sAMAccountName"};
        searchCtls.setReturningAttributes(returnedAtts);

        // Search for objects using the filter
        NamingEnumeration answer = ctx.search(searchBase, searchFilter, searchCtls);
        ctx.close();
        return answer;

    }

    private User getResult(NamingEnumeration answer) throws Exception {
        // Loop through the search results
        while (answer.hasMoreElements()) {
            SearchResult sr = (SearchResult) answer.next();

            Attributes attrs = sr.getAttributes();
            if (attrs != null) {
                User user = new User();
                for (NamingEnumeration ae = attrs.getAll(); ae.hasMore();) {
                    Attribute attr = (Attribute) ae.next();
                    for (NamingEnumeration e = attr.getAll(); e.hasMore();) {
                        if ("displayName".equals(attr.getID())) {
                            user.setUserName(e.next().toString());
                        } else if ("sAMAccountName".equals(attr.getID())) {
                            user.setUserId(e.next().toString());
                        } else {
                            e.next();
                        }
                    }
                }
                List<Role> roleList = roleDao.findRoleByUserId(user.getUserId());
                if (roleList == null || roleList.isEmpty()) {
                    roleList = roleDao.findRoleByADGroup(Group.DEFAULTADGROUP);
                }
                user.setGroups(groupService.findGroupByRoles(roleList));
                user.setRoleList(roleList);
                return user;
            }
        }

        return null;
    }

}
