package com.fubon.esb.service.system;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.system.RoleUserDao;
import com.fubon.esb.dao.system.UserConfigDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Qigers
 * @createdDate 2015-01-12
 */
@Service
public class UserConfigService {

    @Inject
    private UserConfigDao userConfigDao;

    @Inject
    private Messages messages;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private RoleUserDao roleUserDao;

    public List<UserConfig> findAllUsers(String userId, String username, String subject, Page page) {
        return userConfigDao.findLatestUserConfigs(userId, username, subject, page);
    }

    public List<UserConfig> findUserConfigs(String userId, String username, String subject) {
        return userConfigDao.findUserConfigs(userId, username, subject);
    }

    public List<String> searchUserIds(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return userConfigDao.searchUserIds(key);
    }

    public UserConfig getById(String id) {
        return userConfigDao.getById(id);
    }

    public UserConfig getByMainId(String mainId) {
        return userConfigDao.getByMainId(mainId);
    }

    public boolean validIdDuplicate(String id) {
        return userConfigDao.idDuplicate(id);
    }

    public boolean validMainIdDuplicate(String mainId) {
        return userConfigDao.mainIdDuplicate(mainId);
    }

    public boolean validUserIdDuplicate(String userId) {
        return userConfigDao.userIdDuplicate(userId);
    }

    @Transactional
    public void removeUserConfig(String id) {
        UserConfig uc = getById(id);
        roleUserDao.batchDeleteByUser(id);
        if (!validMainIdDuplicate(id)) {
            userConfigDao.removeUserConfig(getByMainId(id).getId());
        }
        userConfigDao.removeUserConfig(id);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.returncode.delete"));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(uc, messageStr), LogType.SYS_USER_CONFIG);
    }

    private String createStr(UserConfig userConfig, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(userConfig.getUserId())) {
            messageStr.append(messages.getMessage("log.userConfig.userId") + userConfig.getUserId());
        }
        if (StringUtils.isNotBlank(userConfig.getUsername())) {
            messageStr.append(messages.getMessage("log.userConfig.username") + userConfig.getUsername());
        }
        return messageStr.toString();
    }

    @Transactional
    public void updateAddSave(UserConfig userConfig, String id, String currentUser) {
        if (userConfigDao.mainIdDuplicate(id)) {
            userConfig.setMainId(id);
            userConfig.setUpdatedTime(new Date());
            userConfig.setUpdatedUser(currentUser);
            userConfigDao.addUserConfig(userConfig);
        }
    }

    @Transactional
    public void saveOrUpdate(UserConfig userConfig, String currentUser, String id, String mainId) {
        if (StringUtils.isNotBlank(id)) {
            UserConfig oldUserConfig = getById(id);
            if ("null".equals(oldUserConfig.getMainId())) {
                userConfig.setMainId(id);
                userConfig.setUpdatedTime(new Date());
                userConfig.setUpdatedUser(currentUser);
                userConfigDao.addUserConfig(userConfig);
            } else {
                userConfig.setMainId(mainId);
                userConfig.setUpdatedTime(new Date());
                userConfig.setUpdatedUser(currentUser);
                StringBuilder messageStr = new StringBuilder();
                messageStr.append(messages.getMessage("log.userConfig.update"));
                operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(oldUserConfig, messageStr), LogType.SYS_USER_CONFIG);
                userConfigDao.updateUserConfig(userConfig);
            }
        } else {
            if (validIdDuplicate(userConfig.getUserId())) {
                throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
            }
            if (!"0".equals(userConfig.getMainId())) {
                userConfig.setId(null);
            }
            userConfig.setUpdatedTime(new Date());
            userConfig.setUpdatedUser(currentUser);
            userConfigDao.addUserConfig(userConfig);
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.userConfig.add"));
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(userConfig, messageStr), LogType.SYS_USER_CONFIG);
        }
    }

}
