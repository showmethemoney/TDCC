package com.fubon.esb.service.job;

import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.comwave.core.http.HTTPClient;
import com.comwave.core.http.HTTPMethod;
import com.comwave.core.http.HTTPRequest;
import com.comwave.core.http.HTTPResponse;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.domain.job.JobConfig;

/**
 * @author james
 * @createdDate 2014-11-27
 */
@Service
public class JobExecuteService {

    @Inject
    private Environment env;
    @Inject
    private HTTPClient httpClient;
    @Inject
    private LoginContext loginContext;

    public String jobExecute(JobConfig jobConfig, String jobParam) {
        String url = env.getRequiredProperty("bw.http.url.job.execute");
        HTTPRequest request = new HTTPRequest(url, HTTPMethod.POST);
        String jobExecuteText = composeJobExecute(jobConfig, jobParam);
        request.text(jobExecuteText, ContentType.APPLICATION_JSON);
        HTTPResponse response = httpClient.execute(request);
        String responseText = response.responseText();
        if (responseText.startsWith("Success")) {
            return null;
        } else if (responseText.startsWith("Fail:")) {
            return responseText.substring(5);
        } else {
            return responseText;
        }
    }

    private String composeJobExecute(JobConfig jobConfig, String jobParam) {
        StringBuilder sb = new StringBuilder();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        sb.append("<Scheduler xmlns = \"http://fubon.com.tw/XSD/ESB/Scheduler/SchedulerDefine\">");
        sb.append("<ScheduleInformation>");
        sb.append("<ID>").append(StringUtils.isNotBlank(jobConfig.getId()) ? replaceChars(jobConfig.getId()) : "").append("</ID>");
        sb.append("<params>").append(StringUtils.isNotBlank(jobParam) ? replaceChars(jobParam) : "").append("</params>");
        sb.append("<JobCode>").append(StringUtils.isNotBlank(jobConfig.getCode()) ? replaceChars(jobConfig.getCode()) : "").append("</JobCode>");
        sb.append("<JobName>").append(StringUtils.isNotBlank(jobConfig.getName()) ? replaceChars(jobConfig.getName()) : "").append("</JobName>");
        sb.append("<QueueName>").append(StringUtils.isNotBlank(jobConfig.getQueueName()) ? replaceChars(jobConfig.getQueueName()) : "").append("</QueueName>");
        sb.append("<DayType>").append((jobConfig.getDayType() != null) ? jobConfig.getDayType().name() : "").append("</DayType>");
        if (jobConfig.getDay() != null) {
            sb.append("<Day>").append(jobConfig.getDay()).append("</Day>");
        }
        sb.append("<DURATION>").append((jobConfig.getDuration() != null) ? jobConfig.getDuration() : "").append("</DURATION>");
        sb.append("<DEPEND_ID>").append(StringUtils.isNotBlank(jobConfig.getDependCodes()) ? replaceChars(jobConfig.getDependCodes()) : "").append("</DEPEND_ID>");
        sb.append("<MAX_TIME>").append(jobConfig.getMaxTime() != null ? jobConfig.getMaxTime() : "").append("</MAX_TIME>");
        sb.append("<START_HOUR>").append(jobConfig.getStartHour() != null ? jobConfig.getStartHour() : "").append("</START_HOUR>");
        sb.append("<START_MINUTE>").append(jobConfig.getStartMinute() != null ? jobConfig.getStartMinute() : "").append("</START_MINUTE>");
        sb.append("<LAST_RUNNING_TIME>").append((jobConfig.getLastRunningTime() != null) ? jobConfig.getLastRunningTime() : "").append("</LAST_RUNNING_TIME>");
        sb.append("<LAST_RUNNING_STATUS>").append((jobConfig.getLastRunningStatus() != null) ? jobConfig.getLastRunningStatus().name() : "").append("</LAST_RUNNING_STATUS>");
        sb.append("<RUN_TIIMES>").append((jobConfig.getRunTimes() != null) ? jobConfig.getRunTimes() : "").append("</RUN_TIIMES>");
        sb.append("<MONTH_TYPE>").append(StringUtils.isNotBlank(jobConfig.getMonthType()) ? jobConfig.getMonthType() : "").append("</MONTH_TYPE>");
        sb.append("<WORK_TYPE>").append(StringUtils.isNotBlank(jobConfig.getWorkType()) ? jobConfig.getWorkType() : "").append("</WORK_TYPE>");
        sb.append("<BEFORM_DAY>").append((jobConfig.getBeforeDay() != null) ? jobConfig.getBeforeDay() : "").append("</BEFORM_DAY>");
        sb.append("<RUN_TYPE>").append("M").append("</RUN_TYPE>");
        sb.append("<EXECUTE_USER>").append(StringUtils.isNotBlank(loginContext.loginedUserId()) ? loginContext.loginedUserId() : "").append("</EXECUTE_USER>");
        sb.append("<NOTIFICATION_MAILS>").append((jobConfig.getNotificationMails() != null) ? jobConfig.getNotificationMails() : "").append("</NOTIFICATION_MAILS>");
        sb.append("<NOTIFICATION_PHONES>").append((jobConfig.getNotificationPhones() != null) ? jobConfig.getNotificationPhones() : "").append("</NOTIFICATION_PHONES>");
        sb.append("</ScheduleInformation>");
        sb.append("<CurrentInformation>");
        sb.append("<CurrentDay>").append(calendar.get(Calendar.DAY_OF_MONTH)).append("</CurrentDay>");
        sb.append("<CurrentWeekDay>").append(calendar.get(Calendar.DAY_OF_WEEK)).append("</CurrentWeekDay>");
        sb.append("<CurrentHour>").append(calendar.get(Calendar.HOUR_OF_DAY)).append("</CurrentHour>");
        sb.append("<CurrentMinute>").append(calendar.get(Calendar.MINUTE)).append("</CurrentMinute>");
        sb.append("</CurrentInformation>");
        sb.append("</Scheduler>");
        return sb.toString();
    }

    public String replaceChars(String strReplace) {
        return strReplace.replaceAll("&", "&amp;").replace(">", "&gt;").replace("<", "&lt;");
    }
}
