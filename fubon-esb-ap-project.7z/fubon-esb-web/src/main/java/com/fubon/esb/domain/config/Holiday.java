package com.fubon.esb.domain.config;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

/**
 * 假日檔設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_HOLIDAY")
public class Holiday implements Serializable {

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "paymentableGenerator")
    @GenericGenerator(name = "paymentableGenerator", strategy = "identity")
    private BigInteger id;

    /** 日期 */
    @Column(name = "DAY")
    @Temporal(TemporalType.DATE)
    private Date day;

    /** 類型 H:Holiday W:Workday */
    @Column(name = "TYPE")
    private String type;

    /** 是否為當前月數據 */
    @Transient
    private Boolean enable;

    public Holiday() {
    }

    public Holiday(Holiday h) {
        this.id = h.getId();
        this.day = h.getDay();
        this.type = h.getType();
        this.enable = true;
    }

    public Holiday(Date day, Boolean enable) {
        this.day = day;
        this.enable = enable;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }
}
