package com.fubon.esb.service.config;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.controller.config.view.ChannelQueryParam;
import com.fubon.esb.controller.config.view.EditChannelView;
import com.fubon.esb.crypto.EncryptionUtils;
import com.fubon.esb.dao.config.AccessChannelDao;
import com.fubon.esb.dao.config.BranchIPDao;
import com.fubon.esb.dao.config.ChannelDao;
import com.fubon.esb.dao.config.TxnChannelDao;
import com.fubon.esb.dao.config.TxnDao;
import com.fubon.esb.dao.config.WorkstationDao;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.TxnChannel;
import com.fubon.esb.domain.config.Workstation;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Service
public class ChannelService {
    @Inject
    private ChannelDao channelDao;
    @Inject
    private WorkstationDao workstationDao;
    @Inject
    private BranchIPDao branchIPDao;
    @Inject
    private AccessChannelDao accessChannelDao;
    @Inject
    private TxnChannelDao txnChannelDao;
    @Inject
    private TxnDao txnDao;
    @Inject
    private LoginContext loginContext;
    @Inject
    private Messages messages;
    @Inject
    private WorkStationBranchIPService workStationBranchIPService;
    @Inject
    private TimeZoneService timeZoneService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private ChannelCompareService channelCompareService;
    @Inject
    private Environment env;

    public List<Channel> findChannelsByAccessChannelId(String accessChannelId) {
        return channelDao.findChannelsByAccessChannelId(accessChannelId);
    }

    public List<Channel> findLatestChannels(ChannelQueryParam cp, Page page) {
        List<Channel> channels = channelDao.findLatestChannels(cp, page);
        if (!channels.isEmpty())
            findRelateAccessChannelInfo(channels);
        return channels;
    }

    public List<Workstation> findWorkStations(String channelId) {
        return workstationDao.findBychannelId(channelId);
    }

    @Transactional
    public String saveChannel(Channel channel, EditChannelView editChannel) throws DuplicatedException, NoSuchAlgorithmException, UnsupportedEncodingException {
        if (isCodeDuplicated(channel.getCode().trim())) {
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        }
        if (StringUtils.isBlank(channel.getAccessChannelId())) {
            throw new DuplicatedException(messages.getMessage("config_valid_accesschannel_notnull"));
        }
        if (EffectType.B.equals(channel.getEffectType())) {
            Date effectTime = stringToDate(editChannel.getEffectDate(), editChannel.getEffectHour(), editChannel.getEffectMinute());
            channel.setEffectTime(timeZoneService.getTZDateByService(effectTime));
            channel.setMainId("0"); // 預約生效設為副本;
        } else if (EffectType.I.equals(channel.getEffectType())) {
            channel.setEffectTime(null);
            channel.setMainId(null);
        }
        if (StringUtils.isNotBlank(channel.getLoginPassWord())) { // 密碼加密
            String big5 = env.getRequiredProperty("bw.password.encoding");
            channel.setLoginPassWord(EncryptionUtils.getMD5(channel.getLoginPassWord(), big5));
        }
        channel.setCreatedUser(loginContext.loginedUserId()); // 建立者
        channel.setCreatedTime(new Date());
        channelDao.save(channel);
        String channelId = channel.getId();
        if (StringUtils.isNotBlank(channelId)) {
            workStationBranchIPService.saveBranchIPAndWorkStation(true, editChannel.getBranchIps(), editChannel.getWorkstationCodes(), channelId);
        }
        channelCompareService.sendMail(channel, null, editChannel);
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "新增Channel。Channel代號：" + channel.getCode() + "，Channel名稱：" + channel.getName(), LogType.SYS_CFG_CHANNEL);
        return channel.getId();
    }

    public void findRelateAccessChannelInfo(List<Channel> channels) {
        for (Channel ch : channels) {
            if (ch.getAccessChannelId() != null) {
                AccessChannel ac = accessChannelDao.getAccessChannelById(ch.getAccessChannelId());
                if (ac != null)
                    ch.setData(ac.getCode());
            }
        }
    }

    public Channel getById(String id) {
        Channel channel = channelDao.get(id);
        AccessChannel ac = null;
        if (channel.getAccessChannelId() != null) {
            ac = accessChannelDao.get(channel.getAccessChannelId());
            if (ac != null)
                channel.setData(ac.getCode());
        }
        return channel;
    }

    public String txnCodesById(String id) {
        List<TxnChannel> txnChannels = null;
        Channel channel = channelDao.get(id);
        String txnCodes = "";
        StringBuilder txnCodesBuilder = new StringBuilder();
        txnChannels = txnChannelDao.findByChannelId((channel.getMainId() != null && !"0".equals(channel.getMainId())) ? channel.getMainId() : id);
        if (txnChannels != null && !txnChannels.isEmpty()) {
            for (TxnChannel txnChannel : txnChannels) {
                if (txnDao.getTxnById(txnChannel.getTxnId()) != null) {
                    txnCodesBuilder.append(txnDao.getTxnById(txnChannel.getTxnId()).getCode() + ",");
                }
            }
        }
        if (txnCodesBuilder.length() > 0) {
            txnCodes = txnCodesBuilder.toString();
            txnCodes = txnCodes.substring(0, txnCodes.length() - 1);
        }
        return txnCodes;
    }

    @Transactional
    public String updateChannel(Channel channel, EditChannelView editChannel) throws DuplicatedException, NoSuchAlgorithmException, UnsupportedEncodingException {
        setProperty(channel);
        if (isCodeDuplicated(channel))
            throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
        if (StringUtils.isBlank(channel.getAccessChannelId()))
            throw new DuplicatedException(messages.getMessage("config_valid_accesschannel_notnull"));
        Channel oldChannel = getById(channel.getId());
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, "修改Channel。Channel代號：" + oldChannel.getCode() + "，Channel名稱：" + oldChannel.getName(), LogType.SYS_CFG_CHANNEL);
        if (EffectType.B.equals(channel.getEffectType())) { // 預約生效
            channel.setEffectTime(timeZoneService.getTZDateByService(stringToDate(editChannel.getEffectDate(), editChannel.getEffectHour(), editChannel.getEffectMinute())));
            if (channel.getMainId() == null) { // 正本，新建副本(新建關聯的workStation和branchIp)
                Channel newChannel = new Channel();
                BeanUtils.copyProperties(channel, newChannel, "id");
                newChannel.setMainId(channel.getId());
                channelCompareService.sendMail(newChannel, getById(channel.getId()), editChannel);
                channelDao.save(newChannel);
                workStationBranchIPService.saveBranchIPAndWorkStation(false, editChannel.getBranchIps(), editChannel.getWorkstationCodes(), newChannel.getId());
                return newChannel.getId();
            } else { // 副本-直接修改
                channelCompareService.sendMail(channel, getById("0".equals(channel.getMainId()) ? channel.getId() : channel.getMainId()), editChannel);
                channelDao.update(channel);
                workStationBranchIPService.updateWorkstationAndBranchIp(true, channel.getId(), editChannel);
                return channel.getId();
            }
        } else if (EffectType.I.equals(channel.getEffectType())) { // 立即預約
            channel.setEffectTime(null);
            if (channel.getMainId() == null || "0".equals(channel.getMainId())) { // 正本-直接修改
                channel.setMainId(null);
                channelCompareService.sendMail(channel, getById(channel.getId()), editChannel);
                channelDao.update(channel);
                workStationBranchIPService.updateWorkstationAndBranchIp(true, channel.getId(), editChannel);
                return channel.getId();
            } else {
                Channel mainChannel = channelDao.get(channel.getMainId()); // 副本，找到正本復制屬性
                Channel originChannel = new Channel();
                BeanUtils.copyProperties(mainChannel, originChannel);
                BeanUtils.copyProperties(channel, mainChannel, "id");
                mainChannel.setMainId(null);
                channelCompareService.sendMail(mainChannel, originChannel, editChannel);
                channelDao.update(mainChannel);
                workStationBranchIPService.updateWorkstationAndBranchIp(false, mainChannel.getId(), editChannel); // 更新正本的branchIp和workstation
                workstationDao.deleteByChannelId(channel.getId());
                branchIPDao.deleteByChannelId(channel.getId());
                channelDao.delete(channelDao.get(channel.getId()));
                return mainChannel.getId();
            }
        } else
            return null;
    }

    /** 將頁面沒有的屬性賦值 */
    public void setProperty(Channel channel) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        channel.setUpdatedTime(new Date());
        channel.setUpdatedUser(loginContext.loginedUserId());
        Channel persiChannel = getById(channel.getId());
        channel.setMainId(persiChannel.getMainId());
        channel.setCreatedTime(persiChannel.getCreatedTime());
        channel.setCreatedUser(persiChannel.getCreatedUser());
        String oldPassword = persiChannel.getLoginPassWord(); // 密碼加密
        if (StringUtils.isBlank(channel.getLoginPassWord())) {
            channel.setLoginPassWord("");
        } else if (StringUtils.isNotBlank(channel.getLoginPassWord())) {
            String newPassword = null;
            newPassword = channel.getLoginPassWord();
            if (StringUtils.isNotBlank(oldPassword) && !oldPassword.equals(newPassword)) {
                String big5 = env.getRequiredProperty("bw.password.encoding");
                channel.setLoginPassWord(EncryptionUtils.getMD5(newPassword, big5));
            } else if (StringUtils.isBlank(oldPassword)) {
                String big5 = env.getRequiredProperty("bw.password.encoding");
                channel.setLoginPassWord(EncryptionUtils.getMD5(channel.getLoginPassWord(), big5));
            }
        }
    }

    public Date stringToDate(String effectDate, String effectHour, String effectMinute) {
        Date effectTime = null;
        try {
            effectTime = new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(effectDate + " " + effectHour + ":" + effectMinute);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return effectTime;
    }

    public boolean isCodeDuplicated(String code) {
        return channelDao.isDuplicatedByCode(code);
    }

    public boolean isCodeDuplicated(Channel channel) {
        Channel updatedChannel = null;
        updatedChannel = getById(channel.getId());
        String oldCode = updatedChannel.getCode();
        return channelDao.isDuplicatedByCode(channel.getCode().trim()) && !oldCode.equals(channel.getCode());

    }

    public List<Channel> findMainChannels(String code, Page page) {
        List<Channel> channels = channelDao.findMainChannels(code, page);
        if (!channels.isEmpty()) {
            findRelateAccessChannelInfo(channels);
        }
        return channels;
    }

    public List<Channel> findChannelsByTxnId(String id) {
        List<TxnChannel> txnChannels = txnChannelDao.findByTxnId(id);
        List<Channel> channels = new ArrayList<>();
        if (!txnChannels.isEmpty()) {
            for (TxnChannel txnChannel : txnChannels) {
                Channel channel = channelDao.get(txnChannel.getChannelId());
                if (StringUtils.isNotBlank(channel.getAccessChannelId())) {
                    AccessChannel ac = accessChannelDao.getAccessChannelById(channel.getAccessChannelId());
                    channel.setData(ac.getCode());
                }
                channels.add(channel);
            }
        }
        return channels;
    }

    @Transactional
    public void deleteChannel(String id) {
        channelDao.updateStatus(id);
    }

    public boolean isRelatedChannel(String id, StringBuilder message) {
        List<Channel> channels = channelDao.isChannelRelatedAccessChannel(id);
        List<TxnChannel> txnChannels = channelDao.isChannelRelatedTxn(id);
        if (!txnChannels.isEmpty()) {
            for (TxnChannel txnChannel : txnChannels) {
                message.append(txnDao.getTxnById(txnChannel.getTxnId()).getCode()).append(",");
            }
        }
        return !channels.isEmpty() || !txnChannels.isEmpty();
    }
}
