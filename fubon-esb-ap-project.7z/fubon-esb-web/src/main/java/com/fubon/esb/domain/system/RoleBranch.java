package com.fubon.esb.domain.system;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 分行角色
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_ROLE_BRANCH")
public class RoleBranch implements Serializable {

    /** 所屬角色 */
    @Id
    @Column(name = "ROLE_ID")
    private String roleId;

    /** 分行代號 */
    @Id
    @Column(name = "BRANCH_CODE")
    private String branchCode;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public RoleBranch(String roleId, String branchCode) {
        this.roleId = roleId;
        this.branchCode = branchCode;
    }

    public RoleBranch() {
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((branchCode == null) ? 0 : branchCode.hashCode());
        result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RoleBranch other = (RoleBranch) obj;
        if (branchCode == null) {
            if (other.branchCode != null)
                return false;
        } else if (!branchCode.equals(other.branchCode))
            return false;
        if (roleId == null) {
            if (other.roleId != null)
                return false;
        } else if (!roleId.equals(other.roleId))
            return false;
        return true;
    }
    
}
