package com.fubon.esb.domain.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 交易設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */
@Entity(name = "CFG_TXN")
public class Txn extends ConfigBaseEntity {

    /** 代號 */
    @NotEmpty
    @Column(name = "TXN_CODE")
    private String code;

    /** 名稱 */
    @Column(name = "TXN_NAME")
    @NotEmpty
    private String name;

    /** 使用狀態 **/
    @Column(name = "TXN_STATUS")
    @Enumerated(EnumType.STRING)
    @NotNull
    private ConfigActiveStatus status;

    /** 所屬業務群組 */
    @Column(name = "GROUP_ID")
    private String groupId;

    /** 關聯Service **/
    @Column(name = "SERVICE_ID")
    private String serviceId;

    /** HostDriverQueue */
    @Column(name = "HOST_DRIVE_QUEUE")
    private String hostDriveQueue;

    /** 轉換TxId */
    @Column(name = "TRANS_TXN_CODE")
    private String transTxnCode;

    /** ToQueue */
    @Column(name = "TO_QUEUE")
    private String toQueue;

    /** 交易Timeout */
    @Column(name = "TIMEOUT")
    private Integer timeout;

    /** 交易優先權 */
    @Column(name = "PRIORITY")
    @Enumerated(EnumType.STRING)
    private PriorityType priority;

    /** 交易Connector */
    @Column(name = "CONNECTOR_ID")
    private String connectorId;

    /** 應用系統代號 */
    @Column(name = "APP_CODE")
    private String appCode;

    /** 應用系統簡稱 */
    @Column(name = "APP_NAME")
    private String appName;

    /** BG Group */
    @Column(name = "BG_GROUP")
    private String bgGroup;

    /** 櫃員代號 **/
    @Column(name = "TELLER_CODE")
    private String tellerCode;

    /** AdaptId **/
    @Column(name = "ADAPTER_ID")
    private String adapterId;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getTransTxnCode() {
        return transTxnCode;
    }

    public void setTransTxnCode(String transTxnCode) {
        this.transTxnCode = transTxnCode;
    }

    public String getToQueue() {
        return toQueue;
    }

    public void setToQueue(String toQueue) {
        this.toQueue = toQueue;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    public PriorityType getPriority() {
        return priority;
    }

    public void setPriority(PriorityType priority) {
        this.priority = priority;
    }

    public String getHostDriveQueue() {
        return hostDriveQueue;
    }

    public void setHostDriveQueue(String hostDriveQueue) {
        this.hostDriveQueue = hostDriveQueue;
    }

    public String getConnectorId() {
        return connectorId;
    }

    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(ConfigActiveStatus status) {
        this.status = status;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getBgGroup() {
        return bgGroup;
    }

    public void setBgGroup(String bgGroup) {
        this.bgGroup = bgGroup;
    }

    public ConfigActiveStatus getStatus() {
        return status;
    }

    public String getTellerCode() {
        return tellerCode;
    }

    public void setTellerCode(String tellerCode) {
        this.tellerCode = tellerCode;
    }

    public String getAdapterId() {
        return adapterId;
    }

    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

}
