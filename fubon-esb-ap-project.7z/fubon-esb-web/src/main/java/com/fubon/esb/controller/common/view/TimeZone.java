package com.fubon.esb.controller.common.view;

/**
 * @author james
 * @createdDate 2014-11-28
 */
public class TimeZone {

    private String name;
    private String zone;
    private String select;

    public String getSelect() {
        return select;
    }

    public void setSelect(String select) {
        this.select = select;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }
}