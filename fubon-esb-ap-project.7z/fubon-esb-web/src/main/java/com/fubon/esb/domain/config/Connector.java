package com.fubon.esb.domain.config;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fubon.esb.domain.system.Adapter;

/**
 * Connector設定
 * 
 * @author Shelly
 * @createdDate Oct 23, 2014
 */

@Entity(name = "CFG_CONNECTOR")
public class Connector implements Serializable {

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** CONNECTOR 代號 */
    @Column(name = "CONNECTOR_CODE")
    private String code;

    /** Connector 名稱 */
    @Column(name = "CONNECTOR_NAME")
    private String name;

    /** 更新人 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 備註 */
    @Column(name = "MEMO")
    private String memo;

    /** 建立者 */
    @Column(name = "CREATED_USER")
    private String createdUser;

    /** 建立時間 */
    @Column(name = "CREATED_TIME")
    private Date createdTime;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    @Transient
    private Adapter[] adapterArray;

    @Transient
    private boolean isAdd;

    @Transient
    private Adapter[] deleteArray;

    public Adapter[] getDeleteArray() {
        return deleteArray;
    }

    public void setDeleteArray(Adapter[] deleteArray) {
        this.deleteArray = deleteArray;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Adapter[] getAdapterArray() {
        return adapterArray;
    }

    public void setAdapterArray(Adapter[] adapterArray) {
        this.adapterArray = adapterArray;
    }

    public boolean isAdd() {
        return isAdd;
    }

    public void setAdd(boolean isAdd) {
        this.isAdd = isAdd;
    }

}
