package com.fubon.esb.controller.query;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.OrderBy;
import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.query.view.TxnHisRecordDetailExcel;
import com.fubon.esb.controller.query.view.TxnHisRecordExcelVO;
import com.fubon.esb.controller.query.view.TxnHisRecordsVO;
import com.fubon.esb.domain.log.TxnHisRecord;
import com.fubon.esb.domain.log.TxnHisRecordMsg;
import com.fubon.esb.service.log.TxnHisRecordServive;

/**
 * @author Qigers
 * @createdDate 2014-11-14
 */
@Controller
@RequestMapping(value = "/txnHisRecord")
public class TxnHisRecordController extends BaseController {

    @Inject
    private TxnHisRecordServive txnHisRecordServive;

    @RequirePermission(value = "030201")
    @RequestMapping(value = "/viewTxnHisRecordList", method = RequestMethod.GET)
    public String viewTxnHisRecordList(Model model, @RequestParam(required = false) String message, OrderBy orderBy, TxnHisRecordsVO vo) {
        Page page = new Page(1);
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(calendar.DATE, -1);
        date = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String today = sdf.format(date);
        vo.setStartDate(today);
        model.addAttribute("page", page);
        model.addAttribute("txnHisRecordlist", null);
        model.addAttribute("vo", vo);
        model.addAttribute("txnCodePicUrl", txnCodeImgUrl(orderBy));
        model.addAttribute("durationPicUrl", durationImgUrl(orderBy));
        model.addAttribute("startTimePicUrl", startTimeImgUrl(orderBy));
        model.addAttribute("orderBy", orderBy);
        return "/query/viewTxnHisRecordList";
    }

    @RequirePermission(value = "030201")
    @RequestMapping(value = "/viewTxnHisRecordList", method = RequestMethod.POST)
    public String viewTxnHisRecordList(Model model, OrderBy orderBy, @RequestParam(required = false, defaultValue = "1") Integer currentPage, TxnHisRecordsVO vo,
            @RequestParam(required = false) Boolean isSearch) {
        String message = vo.getMessage();
        Page page = new Page(currentPage);
        page.setPageSize(50);
        @SuppressWarnings("unchecked")
        List<TxnHisRecord> txnHisRecordlist = (List<TxnHisRecord>) txnHisRecordServive.findTxnHisRecordPageList(vo, orderBy, page, isSearch);
        model.addAttribute("txnHisRecordlist", txnHisRecordlist); // 分頁查詢信息
        model.addAttribute("page", page);
        vo.setTempCurrentPage(currentPage);
        model.addAttribute("vo", vo);
        model.addAttribute("message", message);
        model.addAttribute("txnCodePicUrl", txnCodeImgUrl(orderBy));
        model.addAttribute("durationPicUrl", durationImgUrl(orderBy));
        model.addAttribute("startTimePicUrl", startTimeImgUrl(orderBy));
        model.addAttribute("orderBy", orderBy);
        return "/query/viewTxnHisRecordList";
    }

    @RequestMapping(value = "/viewTxnHisRecordDetailList", method = RequestMethod.POST)
    public String viewTxnHisRecordDetailList(Model model, OrderBy orderBy, String hisRecordId, @RequestParam(required = false, defaultValue = "1") Integer currentPage, TxnHisRecordsVO vo) {
        String trackingId = vo.getTrackingId();
        Page page = new Page(currentPage);
        if (vo.getSonOrderBy() == null) {
            vo.setSonOrderBy(new OrderBy("", true));
        }
        TxnHisRecord txnHisRecord = txnHisRecordServive.findTxnHisRecordDetail(hisRecordId);
        List<TxnHisRecordMsg> txnHisRecordMsgDetailList = (List<TxnHisRecordMsg>) txnHisRecordServive.findTxnRecordDetailPageList(vo, page, trackingId);
        model.addAttribute("txnHisRecord", txnHisRecord);
        model.addAttribute("txnHisRecordMsgDetailList", txnHisRecordMsgDetailList);
        model.addAttribute("page", page);
        model.addAttribute("orderBy", orderBy);
        model.addAttribute("vo", vo);
        model.addAttribute("hisTxnCodePicUrl", hisTxnCodePicUrl(vo.getSonOrderBy()));
        model.addAttribute("hisLayerPicUrl", hisLayerPicUrl(vo.getSonOrderBy()));
        model.addAttribute("trackingId", trackingId);
        model.addAttribute("hisRecordId", hisRecordId);
        return "/query/viewTxnHisRecordDetailList";
    }

    /**
     * @param model
     * @param projectId
     * @param request
     * @return
     */
    @RequestMapping(value = "/reportTxnHisRecordDetailExcel", method = RequestMethod.GET)
    public ModelAndView reportTxnHisRecordDetailExcel(ModelMap model, String trackingId, String hisRecordId, HttpServletRequest request, HttpServletResponse response) {
        TxnHisRecord txnHisRecord = txnHisRecordServive.findTxnHisRecordDetail(hisRecordId);
        List<TxnHisRecordMsg> txnHisRecordMsgDetailExcelList = (List<TxnHisRecordMsg>) txnHisRecordServive.findTxnRecordDetailList(trackingId);
        model.put("txnHisRecordMsgDetailExcelList", txnHisRecordMsgDetailExcelList);
        model.put("txnHisRecord", txnHisRecord);
        TxnHisRecordDetailExcel txnHisRecordDetailExcel = new TxnHisRecordDetailExcel();
        return new ModelAndView(txnHisRecordDetailExcel, model);
    }

    @RequestMapping(value = "/viewTxnHisMessageContent", method = RequestMethod.GET)
    public String viewTxnHisMessageContent(Model model, String messageId) throws DocumentException, IOException{

        TxnHisRecordMsg txnHisRecordMsg = txnHisRecordServive.findTxnHisRecordMsg(messageId); // 查詢消息

		String tempStr = txnHisRecordMsg.getMessage();
		tempStr = tempStr.replaceAll("&", "&amp;");
		if (tempStr.contains( "<?xml" )) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			Document document = DocumentHelper.parseText( tempStr );
			String original_encoding = document.getXMLEncoding();
			XMLWriter writer;
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setTrimText(false);
			writer = new XMLWriter( baos, format );
			writer.write( document );
			writer.close();
			txnHisRecordMsg.setMessage( baos.toString( "UTF-8" ).replaceAll("&amp;", "&").replaceFirst("UTF-8", original_encoding) );
			baos.close();
		}
        model.addAttribute("txnHisRecordMsg", txnHisRecordMsg);
        return "/query/viewTxnHisMessageContent";
    }

    @ResponseBody
    @RequestMapping({"/search/serviceCodes"})
    public Object searchServiceCodes(@RequestParam String key) {
        return txnHisRecordServive.searchServiceCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/search/groupCodes"})
    public Object searchGroupCodes(@RequestParam String key) {
        return txnHisRecordServive.searchGroupCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/search/hostCodes"})
    public Object searchHostCodes(@RequestParam String key) {
        return txnHisRecordServive.searchHostCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/search/channelCodes"})
    public Object searchChannelCodes(@RequestParam String key) {
        return txnHisRecordServive.searchChannelCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/search/txnCodes"})
    public Object searchTxnCodes(@RequestParam String key) {
        return txnHisRecordServive.searchTxnCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/search/uuids"})
    public Object searchUUIDs(@RequestParam String key) {
        return txnHisRecordServive.searchUUIDs(key);
    }

    /**
     * Export Excel
     * 
     * @param model
     * @param projectId
     * @param request
     * @return
     */
    @RequirePermission(value = "030202")
    @RequestMapping(value = "/reportTxnHisRecordExcel")
    public ModelAndView writeToRecordExcel(ModelMap model, TxnHisRecordsVO vo, HttpServletRequest request, HttpServletResponse response) {
        List<TxnHisRecord> txnHisRecordExcelList = (List<TxnHisRecord>) txnHisRecordServive.findHisRecords(vo);
        model.put("txnHisRecordExcelList", txnHisRecordExcelList);
        TxnHisRecordExcelVO txnHisRecordExcelVO = new TxnHisRecordExcelVO();
        return new ModelAndView(txnHisRecordExcelVO, model);
    }

    public String durationImgUrl(OrderBy orderBy) {
        String url = "normal.gif";
        if ((StringUtils.isNotBlank(orderBy.getField())) && ("duration".equals(orderBy.getField()))) {
            if (orderBy.isAsc()) {
                url = "up.gif";
            } else {
                url = "down.gif";
            }
        } else {
            url = "normal.gif";
        }
        return url;
    }

    public String txnCodeImgUrl(OrderBy orderBy) {
        String url = "normal.gif";
        if ((StringUtils.isNotBlank(orderBy.getField())) && ("txnCode".equals(orderBy.getField()))) {
            if (orderBy.isAsc()) {
                url = "up.gif";
            } else {
                url = "down.gif";
            }
        } else {
            url = "normal.gif";
        }
        return url;
    }

    public String startTimeImgUrl(OrderBy orderBy) {
        String url = "normal.gif";
        if ((StringUtils.isNotBlank(orderBy.getField())) && ("startTime".equals(orderBy.getField()))) {
            if (orderBy.isAsc()) {
                url = "up.gif";
            } else {
                url = "down.gif";
            }
        } else {
            url = "normal.gif";
        }
        return url;
    }

    public String hisTxnCodePicUrl(OrderBy orderBy) {
        String url = "normal.gif";
        if ((StringUtils.isNotBlank(orderBy.getField())) && ("tm.txnCode".equals(orderBy.getField()))) {
            if (orderBy.isAsc()) {
                url = "up.gif";
            } else {
                url = "down.gif";
            }
        } else {
            url = "normal.gif";
        }
        return url;
    }

    public String hisLayerPicUrl(OrderBy orderBy) {
        String url = "normal.gif";
        if ((StringUtils.isNotBlank(orderBy.getField())) && ("tm.layer".equals(orderBy.getField()))) {
            if (orderBy.isAsc()) {
                url = "up.gif";
            } else {
                url = "down.gif";
            }
        } else {
            url = "normal.gif";
        }
        return url;
    }
}
