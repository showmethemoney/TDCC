package com.fubon.esb.service.log;

import com.comwave.core.log.filter.LogMessageFilter;

/**
 * @author Robin
 * @createdDate Sep 18, 2014
 */
public class AppLogMessageFilter extends LogMessageFilter {

    @Override
    public String filter(String loggerName, String message) {
        return message;
    }

}
