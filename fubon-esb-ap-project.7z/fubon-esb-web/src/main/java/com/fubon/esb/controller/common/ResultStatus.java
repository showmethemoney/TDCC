package com.fubon.esb.controller.common;

/**
 * @author james
 * @createdDate 2014-11-6
 */
public enum ResultStatus {

    SUCCESS, ERROR

}
