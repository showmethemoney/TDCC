package com.fubon.esb.domain.system;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fubon.esb.domain.ActiveStatus;

/**
 * 權限群組
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_GROUP")
public class Group {
    
    public static final String DEFAULTADGROUP = "DEFAULT_ADGROUP";

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 對應群組正本 */
    @Column(name = "MAIN_ID")
    private String mainId;

    /** 群組名稱 */
    @Column(name = "SYS_NAME")
    private String name;

    /** 群組AD代號 */
    @Column(name = "AD_GROUP")
    private String adGroup;

    /** 使用狀態: A:Active啟用,I:Inactive停用 */
    @Enumerated(EnumType.STRING)
    @Column(name = "SYS_STATUS")
    private ActiveStatus status;

    /** 顯示順序 */
    @Column(name = "ORDER_NO")
    private Integer orderNo;

    /** 群組描述 */
    @Column(name = "DESCZ")
    private String desc;

    /** 更新者 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTime;

    /** 修改內容標志 */
    @Column(name = "MODIFY_FLAG")
    private Integer modifyFlag;

    /** 群組下的角色列表 */
    @Transient
    private List<Role> roles;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdGroup() {
        return adGroup;
    }

    public void setAdGroup(String adGroup) {
        this.adGroup = adGroup;
    }

    public ActiveStatus getStatus() {
        return status;
    }

    public void setStatus(ActiveStatus status) {
        this.status = status;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
    
    public Boolean getEditable() {
        return mainId == null;
    }

}
