package com.fubon.esb.controller.txn.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @author nice
 * @createdDate 2014-11-18
 */
public class ZipCompressor {

    public static final String ZIP_EXCEL_TEMP_DIR = System.getProperty("java.io.tmpdir") + "\\fubonEsb\\Excels";

    private static final String ZIP_EXTENSION = ".zip";

    public static String getJVMEncodeing() {
        return System.getProperty("file.encoding");
    }

    public static String compressDirection(String baseDir) throws Exception {
        ZipOutputStream zipOs = new ZipOutputStream(new FileOutputStream(new File(baseDir + ZIP_EXTENSION)), Charset.forName(getJVMEncodeing()));
        File[] files = new File(baseDir).listFiles();
        InputStream is = null;
        ZipEntry zipEntry = null;
        if (files != null && files.length != 0) {
            for (File file : files) {
                zipEntry = new ZipEntry(file.getName());
                zipEntry.setSize(file.length());
                zipEntry.setTime(file.lastModified());
                zipOs.setMethod(ZipOutputStream.DEFLATED);
                zipOs.putNextEntry(zipEntry);
                is = new FileInputStream(file);
                IOUtils.copy(is, zipOs);
                is.close();
                zipOs.closeEntry();
            }
        }
        zipOs.close();
        return baseDir + ZIP_EXTENSION;
    }

    public static void clearZipDirection(String baseDir) {
        if (StringUtils.isBlank(baseDir))
            return;
        removeFileAndChildrenFiles(new File(baseDir + ZIP_EXTENSION));
        removeFileAndChildrenFiles(new File(baseDir));
    }

    public static void removeFileAndChildrenFiles(File file) {
        if (file == null)
            return;
        if (!file.exists()) {
            return;
        }
        if (file.isFile()) {
            file.delete();
        }
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; files != null && i < files.length; i++) {
                removeFileAndChildrenFiles(files[i]);
            }
            file.delete();
        }
    }
}
