package com.fubon.esb.domain.job;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.GenericGenerator;

import com.comwave.core.domain.Holder;

/**
 * 
 * @author Shelly
 * @createdDate 2014-12-11
 */
@MappedSuperclass
public abstract class JobConfigBaseEntity extends Holder {

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    @Column(name = "JOB_CODE")
    private String code;

    @Column(name = "JOB_NAME")
    private String name;

//    @Column(name = "BRANCH_CODE")
//    private String branchCode;

    @Column(name = "QUEUE_NAME")
    private String queueName;

    @Column(name = "DAY_TYPE")
    @Enumerated(EnumType.STRING)
    private DayType dayType;

    @Column(name = "DAY")
    private Integer day;

    @Column(name = "START_HOUR")
    private Integer startHour;

    @Column(name = "START_MINUTE")
    private Integer startMinute;

    @Column(name = "END_HOUR")
    private Integer endHour;

    @Column(name = "END_MINUTE")
    private Integer endMinute;

    @Column(name = "DURATION")
    private Integer duration;

    /** 關聯前項排程代號 */
    @Column(name = "DEPEND_CODES")
    private String dependCodes;

    @Column(name = "PARAMS")
    private String params;

    @Column(name = "MAX_TIME")
    private Integer maxTime;

    @Column(name = "JOB_STATUS")
    @Enumerated(EnumType.STRING)
    private JobStatus status;

    /** 建立者 */
    @Column(name = "CREATED_USER")
    private String createdUser;

    /** 建立時間 */
    @Column(name = "CREATED_TIME")
    private Date createdTime;

    /** 更新人 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

//    public String getBranchCode() {
//        return branchCode;
//    }
//
//    public void setBranchCode(String branchCode) {
//        this.branchCode = branchCode;
//    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public DayType getDayType() {
        return dayType;
    }

    public void setDayType(DayType dayType) {
        this.dayType = dayType;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getStartHour() {
        return startHour;
    }

    public void setStartHour(Integer startHour) {
        this.startHour = startHour;
    }

    public Integer getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(Integer startMinute) {
        this.startMinute = startMinute;
    }

    public Integer getEndHour() {
        return endHour;
    }

    public void setEndHour(Integer endHour) {
        this.endHour = endHour;
    }

    public Integer getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(Integer endMinute) {
        this.endMinute = endMinute;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getDependCodes() {
        return dependCodes;
    }

    public void setDependCodes(String dependCodes) {
        this.dependCodes = dependCodes;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public Integer getMaxTime() {
        return maxTime;
    }

    public void setMaxTime(Integer maxTime) {
        this.maxTime = maxTime;
    }

    public JobStatus getStatus() {
        return status;
    }

    public void setStatus(JobStatus status) {
        this.status = status;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

}
