package com.fubon.esb.controller.txn.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.service.txn.TxnHeaderExcelReadServcie;
import com.fubon.esb.service.txn.TxnHeaderExcelWriteService;
import com.fubon.esb.service.txn.TxnService;

/**
 * @author Qigers
 * @createdDate 2015-03-26
 */
public class TxnHeaderExcelView extends AbstractExcelView {

    private String tempZipDir;

    private final TxnService txnService;

    private final TxnHeaderExcelReadServcie txnHeaderExcelReadServcie;

    private final TxnHeaderExcelWriteService txnHeaderExcelWriteService;

    public TxnHeaderExcelView(TxnService txnService, TxnHeaderExcelReadServcie txnHeaderExcelReadServcie, TxnHeaderExcelWriteService txnHeaderExcelWriteService) {
        this.txnHeaderExcelWriteService = txnHeaderExcelWriteService;
        this.txnService = txnService;
        this.txnHeaderExcelReadServcie = txnHeaderExcelReadServcie;
    }

    @Override
    protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
        super.prepareResponse(request, response);
    }

    @Override
    protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        TxnVO txnVO = (TxnVO) model.get("txnExcelVO");
        String fileExcelName = null;
        if (txnVO != null) {
            txnHeaderExcelWriteService.fillWorkbookByTxn(workbook, txnVO);
            fileExcelName = txnVO.getHeadDirection().getName() + ".xls";
            fileExcelName = URLEncoder.encode(fileExcelName, "utf-8");
            fileExcelName = StringUtils.replace(fileExcelName, "+", "%20");
            response.addHeader("Content-Disposition", "attachment;filename=" + fileExcelName);
        }
    }

    private void createTempHeaderZipDir() {
        String tempDir = ZipCompressor.ZIP_EXCEL_TEMP_DIR + "\\" + System.currentTimeMillis();
        File newFile = null;
        newFile = new File(tempDir);
        newFile.mkdirs();
        tempZipDir = tempDir;
    }

    public void writeZipFileToResponse(List<TxnVO> txnVOs, HttpServletRequest request, HttpServletResponse response) {
        prepareResponse(request, response);
        InputStream is = null;
        try {
            createHeaderExcelsInTempZipDir(txnVOs);
            File zipHeaderFile = new File(ZipCompressor.compressDirection(tempZipDir));
            response.addHeader("Content-Disposition", "attachment;filename=" + zipHeaderFile.getName());
            is = new FileInputStream(zipHeaderFile);
            IOUtils.copy(is, response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeQuietly(is);
            ZipCompressor.clearZipDirection(tempZipDir);
        }
    }

    private String createExcelInTempZipDir(String excelFileName) {
        Assert.notNull(tempZipDir, "tempZipDir can not be null before create new excel");
        return tempZipDir + "\\" + excelFileName + ".xls";
    }

    public void createHeaderExcelsInTempZipDir(List<TxnVO> txnVOs) throws Exception {
        if (txnVOs == null || txnVOs.isEmpty())
            return;
        createTempHeaderZipDir();
        File file = null;
        OutputStream os = null;
        for (TxnVO txnVO : txnVOs) {
            Workbook workbook = txnHeaderExcelWriteService.createTxnWorkbook(txnVO);
            if (workbook != null) {
                file = new File(createExcelInTempZipDir(txnVO.getHeadDirection().getName()));
                os = new FileOutputStream(file);
                workbook.write(os);
            }
        }
    }

    /** import Header **/
    @Transactional
    public Map<String, Object> saveTxnHeadsFromUploadedFile(TxnDirection txnDirec, File file, boolean isCompress) throws Exception {
        Map<String, List<String>> errorMsgs = new HashMap<String, List<String>>(1);
        List<TxnExcelVO> txnExcelVOs = txnHeaderExcelReadServcie.readTxnHeaderVOsFromExcel(txnDirec, file, isCompress);
        List<String> savedTxnDirecIds = new ArrayList<String>(1);
        if (txnExcelVOs != null && !txnExcelVOs.isEmpty()) {
            for (TxnExcelVO excelVO : txnExcelVOs) {
                if (excelVO.isValid()) {
                    txnService.saveFromTxnHeaderExcelVO(excelVO);
                    savedTxnDirecIds.add(excelVO.getHeadDirection().getId());
                } else {
                    errorMsgs.put(excelVO.getExcelName(), excelVO.getExcelErrors());
                }
            }
        }
        Map<String, Object> results = new HashMap<String, Object>(1);
        results.put("returnDefIds", savedTxnDirecIds);
        results.put("errorMsgs", errorMsgs);
        return results;
    }

}
