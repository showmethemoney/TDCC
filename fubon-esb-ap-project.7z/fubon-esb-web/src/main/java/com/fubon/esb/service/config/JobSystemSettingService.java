package com.fubon.esb.service.config;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.dao.config.JobSysMailDao;
import com.fubon.esb.dao.config.JobSystemSettingDao;
import com.fubon.esb.dao.job.JobConfigDao;
import com.fubon.esb.domain.config.JobSysMail;
import com.fubon.esb.domain.config.JobSystemSetting;
import com.fubon.esb.domain.config.JobSystemSettingStatus;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.job.JobRecordService;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Qigers
 * @createdDate 2014-12-11
 */

@Service
public class JobSystemSettingService {

    @Inject
    private JobSystemSettingDao jobSystemSettingDao;

    @Inject
    private JobSysMailDao jobSysMailDao;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private Messages messages;

    @Inject
    private JobConfigDao jobConfigDao;

    @Inject
    private ConfigChangeService configChangeService;

    @Inject
    private JobRecordService jobRecordService;

    public List<JobSystemSetting> findJobSystemSettings(String systemCode, String systemName, Page page, String systemStatus) {
        return jobSystemSettingDao.findJobSystemSettings(systemCode, systemName, page, systemStatus, jobRecordService.isAdminGroup() ? null : jobRecordService.findUserBranchCodeList());
    }

    public JobSystemSetting getById(String id) {
        return jobSystemSettingDao.getlById(id);
    }

    @Transactional
    public void removeJobSystemSetting(String id) {
        JobSystemSetting jsc = getById(id);
        // jobSystemSettingDao.removeJobSystemSetting(id);
        JobSystemSetting jobSystemSetting = jobSystemSettingDao.getlById(id);
        jobSystemSetting.setStatus(JobSystemSettingStatus.D);
        jobSystemSettingDao.updateJobSystemSetting(jobSystemSetting);
        // jobSysMailDao.removeById(id);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.JobSystemSetting.delete"));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(jsc, messageStr), LogType.JOB_SYSTEM_SETTING);
    }

    public boolean searchJSSIdRelated(String id) {
        return jobConfigDao.searchJSSIdRelated(id);
    }

    @Transactional
    public String sendChangeStatus(String id) {
        JobSystemSetting jobSystemSetting = getById(id);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.JobSystemSetting.changestatus"));
        String status = emumStatusToString(jobSystemSetting.getStatus());
        if ("Active".equals(status)) {
            jobSystemSetting.setStatus(JobSystemSettingStatus.I);
            messageStr.append(messages.getMessage("log.JobSystemSetting.to.inactive"));
        } else if ("Inactive".equals(status)) {
            jobSystemSetting.setStatus(JobSystemSettingStatus.A);
            messageStr.append(messages.getMessage("log.JobSystemSetting.to.active"));
        }
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(jobSystemSetting, messageStr), LogType.JOB_SYSTEM_SETTING);
        jobSystemSettingDao.sendChangeStatus(jobSystemSetting);
        return emumStatusToString(jobSystemSetting.getStatus());
    }

    @Transactional
    public void removeQueueMsg(String id) {
        JobSystemSetting jsc = getById(id);
        configChangeService.cleanEMSQueue(id);
        StringBuilder messageStr = new StringBuilder();
        messageStr.append(messages.getMessage("log.JobSystemSetting.remove.queue"));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(jsc, messageStr), LogType.JOB_SYSTEM_SETTING);
    }

    private String emumStatusToString(JobSystemSettingStatus as) {
        String sas = null;
        for (JobSystemSettingStatus s : JobSystemSettingStatus.values()) {
            if (null != as && s.equals(as)) {
                sas = as.toString();
            }
        }
        return sas;
    }

    @Transactional
    public void saveOrUpdate(JobSystemSetting jobSystemSetting, String currentUser, String[] mails) {
        String jobSystemSettingId = jobSystemSetting.getId();
        if (StringUtils.isNotBlank(jobSystemSettingId)) {
            JobSystemSetting oldJobSystemSetting = getById(jobSystemSettingId);
            jobSystemSetting.setCreatedTime(oldJobSystemSetting.getCreatedTime());
            jobSystemSetting.setUpdatedTime(new Date());
            jobSystemSetting.setUpdatedUser(currentUser);
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.JobSystemSetting.update"));
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(oldJobSystemSetting, messageStr), LogType.JOB_SYSTEM_SETTING);
            jobSystemSettingDao.updateJobSystemSetting(jobSystemSetting);
            jobSysMailDao.updateJobSysMailList(jobSystemSettingId, mails);
        } else {
            if (validCodeDuplicate(jobSystemSetting.getSystemCode())) {
                throw new DuplicatedException(messages.getMessage("config_valid_code_exist"));
            }
            jobSystemSetting.setCreatedTime(new Date());
            jobSystemSettingDao.addJobSystemSetting(jobSystemSetting);
            StringBuilder messageStr = new StringBuilder();
            messageStr.append(messages.getMessage("log.JobSystemSetting.add"));
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, createStr(jobSystemSetting, messageStr), LogType.JOB_SYSTEM_SETTING);
            jobSysMailDao.saveJobSysMails(jobSystemSetting.getId(), mails);
        }
    }

    public List<JobSysMail> findJobSysMails(String id) {
        return jobSysMailDao.findJobSysMails(id);
    }

    private String createStr(JobSystemSetting jobSystemSetting, StringBuilder messageStr) {
        if (StringUtils.isNotBlank(jobSystemSetting.getSystemCode())) {
            messageStr.append(messages.getMessage("log.JobSystemSetting.syscode") + jobSystemSetting.getSystemCode());
        }
        if (StringUtils.isNotBlank(jobSystemSetting.getSystemName())) {
            messageStr.append(messages.getMessage("log.JobSystemSetting.sysname") + jobSystemSetting.getSystemName());
        }
        return messageStr.toString();
    }

    public boolean validIdDuplicate(String id) {
        return jobSystemSettingDao.idDuplicate(id);
    }

    public boolean validCodeDuplicate(String systemCode) {
        return jobSystemSettingDao.codeDuplicate(systemCode);
    }

    public List<String> searchSystemCodes(String key) {
        if (StringUtils.isBlank(key)) {
            return null;
        }
        return jobSystemSettingDao.searchSystemCodes(key);
    }
}
