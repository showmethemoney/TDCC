package com.fubon.esb.service.log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.controller.log.view.ApprovalLogSearchVO;
import com.fubon.esb.dao.log.ApprovalLogDao;
import com.fubon.esb.dao.system.GroupDao;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.domain.log.ApprovalLog;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.TimeZoneService;
import com.fubon.esb.service.system.GroupService;
import com.fubon.esb.service.system.RoleService;

/**
 * @author Blue
 * @createdDate 2014-11-10
 */
@Service
public class ApprovalLogService {

    @Inject
    protected Messages messages;

    @Inject
    private ApprovalLogDao approvalLogDao;

    @Inject
    private RoleDao roleDao;

    @Inject
    private GroupDao groupDao;

    @Inject
    private LoginContext loginContext;

    @Inject
    private RoleService roleService;

    @Inject
    private GroupService groupService;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private TimeZoneService timeZoneService;

    /**
     * 查詢ApprovalLog集合
     * 
     * @param page
     * @param isAddLog
     * 
     * */
    @Transactional
    public List<ApprovalLog> findAllApprovalLogList(ApprovalLogSearchVO vo, Page page, Boolean isAddLog) {
        List<ApprovalLog> findAllApprovalLog = null;
        Date startDate = null;
        Date endDate = null;
        if (vo.getStartDate() != null) {
            startDate = timeZoneService.getTZDateByService(vo.getStartDate());
        }
        if (vo.getEndDate() != null) {
            endDate = timeZoneService.getTZDateByService(vo.getEndDate());
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (vo.getRoleName() != null && !"".equals(vo.getRoleName())) {
            findAllApprovalLog = approvalLogDao.findAllApprovalLogR(vo, page, startDate, endDate);
        } else if (vo.getGroupName() != null && !"".equals(vo.getGroupName()) && "".equalsIgnoreCase(vo.getRoleName())) {
            findAllApprovalLog = approvalLogDao.findAllApprovalLogG(vo, page, startDate, endDate);
        } else {
            findAllApprovalLog = approvalLogDao.findAllApprovalLog(vo, page, startDate, endDate);
        }
        for (ApprovalLog log : findAllApprovalLog) {
            String roleId = log.getRoleId();
            if (roleId != null) {
                log.setRole(roleDao.getRoleById(roleId));
            }
            String groupId = log.getGroupId();
            if (groupId != null) {
                log.setGroup(groupDao.getGroupById(groupId));
            }
        }
        if (isAddLog != null && isAddLog) {
            stringBuilder = addCheckLog(vo, stringBuilder);
            operationLogService.addOperationLog(OperationLog.LEVEL_INFO, stringBuilder.toString(), LogType.SYS_APPROVAL_LOG);
        }
        return findAllApprovalLog;
    }

    /**
     * 查詢ApprovalLog明細
     * */
    public ApprovalLog getApprovalLogDetail(String id) {
        ApprovalLog approvalLogDetail = approvalLogDao.getApprovalLogDetail(id);
        String roleId = approvalLogDetail.getRoleId();
        if (roleId != null) {
            approvalLogDetail.setRole(roleDao.getRoleById(roleId));
        }
        String groupId = approvalLogDetail.getGroupId();
        if (groupId != null) {
            approvalLogDetail.setGroup(groupDao.getGroupById(groupId));
        }
        return approvalLogDetail;
    }

    /**
     * 新增群組覆核日誌
     */
    public void addGroupApprovalLog(Group group, String modifyContent, Integer modifyFlag) {
        ApprovalLog approvalLog = new ApprovalLog();
        approvalLog.setGroupId(groupService.getGroupOriginId(group));
        approvalLog.setModifyFlag(modifyFlag);
        approvalLog.setModifyDetail(modifyContent);
        approvalLog.setUpdatedUser(group.getUpdatedUser());
        approvalLog.setUpdatedTime(group.getUpdatedTime());
        approvalLog.setApprovedUser(loginContext.loginedUserId());
        approvalLog.setApprovedTime(new Date());
        approvalLogDao.save(approvalLog);
    }

    /**
     * 新增角色覆核日誌
     */
    public void addRoleApprovalLog(Role role, String modifyContent, Integer modifyFlag) {
        ApprovalLog approvalLog = new ApprovalLog();
        approvalLog.setGroupId(role.getGroupId());
        approvalLog.setRoleId(roleService.getRoleOriginId(role));
        approvalLog.setModifyFlag(modifyFlag);
        approvalLog.setModifyDetail(modifyContent);
        approvalLog.setUpdatedUser(role.getUpdatedUser());
        approvalLog.setUpdatedTime(role.getUpdatedTime());
        approvalLog.setApprovedUser(loginContext.loginedUserId());
        approvalLog.setApprovedTime(new Date());
        approvalLogDao.save(approvalLog);
    }

    public void addUserConfigApprovalLog(UserConfig userConfig, String modifyContent, Integer modifyFlag) {
        ApprovalLog approvalLog = new ApprovalLog();
        approvalLog.setGroupId(null);
        approvalLog.setRoleId(null);
        approvalLog.setModifyFlag(modifyFlag);
        approvalLog.setModifyDetail(modifyContent);
        approvalLog.setUpdatedUser(userConfig.getUpdatedUser());
        approvalLog.setUpdatedTime(userConfig.getUpdatedTime());
        approvalLog.setApprovedUser(loginContext.loginedUserId());
        approvalLog.setApprovedTime(new Date());
        approvalLogDao.save(approvalLog);
    }

    /**
     * 添加日志消息
     */
    private StringBuilder addCheckLog(ApprovalLogSearchVO vo, StringBuilder stringBuilder) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 1) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.operation1"));
        }
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 2) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.operation2"));
        }
        if (vo.getModifyFlag() != null && vo.getModifyFlag() == 3) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.operation3"));
        }
        if (StringUtils.isNotBlank(vo.getUpdatedUser())) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.updateuser", vo.getUpdatedUser()));
        }
        if (vo.getGroupName() != null && !"".equals(vo.getGroupName())) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.groupname", vo.getGroupName()));
        }
        if (vo.getRoleName() != null && !"".equals(vo.getRoleName())) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.rolename", vo.getRoleName()));
        }
        if (vo.getStartDate() != null) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.starttime", sdf.format(vo.getStartDate())));
        }
        if (vo.getEndDate() != null) {
            stringBuilder.append(messages.getMessage("log.approvallog.check.sendtime", sdf.format(vo.getEndDate())));
        }
        return stringBuilder;
    }

}
