package com.fubon.esb.controller.common.view;

import java.util.ArrayList;
import java.util.List;

/**
 * @author james
 * @createdDate 2014-11-28
 */
public class TimeZoneSet {

    private List<TimeZone> timezones = new ArrayList<>();

    public List<TimeZone> getTimezones() {
        return timezones;
    }

    public void setTimezones(List<TimeZone> timezones) {
        this.timezones = timezones;
    }
}

