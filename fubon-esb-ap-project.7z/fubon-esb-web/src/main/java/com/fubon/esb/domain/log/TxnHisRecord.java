package com.fubon.esb.domain.log;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Qigers
 * @createdDate 2014-11-14
 */
@Entity(name = "TXN_HIS_RECORD")
public class TxnHisRecord implements Serializable {
    /** ID **/
    @Id
    @Column(name = "ID")
    private String id;

    /** Tracking ID **/
    @Column(name = "TRACKING_ID")
    private String trackingId;

    /** 工作站代號 **/
    @Column(name = "WORKSTATION_CODE")
    private String workstationCode;

    /** 起始時間 **/
    @Column(name = "START_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startTime;

    /** 結束時間 **/
    @Column(name = "END_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endTime;

    /** 處理時間 **/
    @Column(name = "DURATION")
    private String duration;

    /** 主機代號 **/
    @Column(name = "HOST_CODE")
    private String hostCode;

    /** 業務群組代號 **/
    @Column(name = "GROUP_CODE")
    private String groupCode;

    /** Service代號 **/
    @Column(name = "SERVICE_CODE")
    private String serviceCode;

    /** 系統日期(電文) **/
    @Column(name = "SYS_DATE")
    private String sysDate;

    /** 系統時間(電文) **/
    @Column(name = "SYS_TIME")
    private String sysTime;

    /** 交易代號 **/
    @Column(name = "TXN_CODE")
    private String txnCode;

    /** 交易序號 **/
    @Column(name = "SEQUENCE")
    private String sequence;

    /** 櫃員代號 **/
    @Column(name = "TELLER")
    private String teller;

    /** Channel代號 **/
    @Column(name = "CHANNEL_CODE")
    private String channelCode;

    /** 交易回應碼 **/
    @Column(name = "RETURN_CODE")
    private String returnCode;

    /** TXN_UUID **/
    @Column(name = "TXN_UUID")
    private String uuid;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getWorkstationCode() {
        return workstationCode;
    }

    public void setWorkstationCode(String workstationCode) {
        this.workstationCode = workstationCode;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getHostCode() {
        return hostCode;
    }

    public void setHostCode(String hostCode) {
        this.hostCode = hostCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getSysDate() {
        return sysDate;
    }

    public void setSysDate(String sysDate) {
        this.sysDate = sysDate;
    }

    public String getSysTime() {
        return sysTime;
    }

    public void setSysTime(String sysTime) {
        this.sysTime = sysTime;
    }

    public String getTxnCode() {
        return txnCode;
    }

    public void setTxnCode(String txnCode) {
        this.txnCode = txnCode;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getTeller() {
        return teller;
    }

    public void setTeller(String teller) {
        this.teller = teller;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

}
