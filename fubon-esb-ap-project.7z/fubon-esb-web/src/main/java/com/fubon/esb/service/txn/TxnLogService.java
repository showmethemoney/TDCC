package com.fubon.esb.service.txn;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.comwave.core.platform.i18n.Messages;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author nice
 * @createdDate 2014-11-28
 */
@Service
public class TxnLogService {

    @Inject
    protected Messages messages;

    @Inject
    protected OperationLogService operationLogService;

    private static final String LOG_LEVER = OperationLog.LEVEL_INFO;

    private static final LogType LOG_TYPE = LogType.TXN_EDIT;

    protected void logToDB(String message) {
        operationLogService.addOperationLog(LOG_LEVER, message, LOG_TYPE);
    }

    protected void logToDB(String message, String logLever) {
        operationLogService.addOperationLog(logLever, message, LOG_TYPE);
    }

    protected void logToDB(String message, LogType logType) {
        operationLogService.addOperationLog(LOG_LEVER, message, logType);
    }

    protected void logToDB(String message, String logLever, LogType logType) {
        operationLogService.addOperationLog(logLever, message, logType);
    }
}
