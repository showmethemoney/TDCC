package com.fubon.esb.controller.config.view;

/**
 * edit channel submit params
 * 
 * @author Shelly
 * @createdDate 2014-10-30
 */
public class EditChannelView {

    private String effectDate;
    private String effectHour;
    private String effectMinute;
    private String[] branchIps;
    private String[] workstationCodes;

    public String getEffectDate() {
        return effectDate;
    }

    public void setEffectDate(String effectDate) {
        this.effectDate = effectDate;
    }

    public String getEffectHour() {
        return effectHour;
    }

    public void setEffectHour(String effectHour) {
        this.effectHour = effectHour;
    }

    public String getEffectMinute() {
        return effectMinute;
    }

    public void setEffectMinute(String effectMinute) {
        this.effectMinute = effectMinute;
    }

    public String[] getBranchIps() {
        return branchIps;
    }

    public void setBranchIps(String[] branchIps) {
        this.branchIps = branchIps;
    }

    public String[] getWorkstationCodes() {
        return workstationCodes;
    }

    public void setWorkstationCodes(String[] workstationCodes) {
        this.workstationCodes = workstationCodes;
    }

}
