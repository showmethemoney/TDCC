package com.fubon.esb.dao;

import javax.inject.Inject;
import javax.inject.Named;

import com.comwave.core.database.JPAAccess;
import com.comwave.core.database.JPADaoSupport;
import com.fubon.esb.LogDBConfig;

/**
 * @author Robin
 * @createdDate Nov 17, 2014
 */
public abstract class LogDBJPADaoSupport<T> extends JPADaoSupport<T> {

    @Override
    @Inject
    @Named(value = LogDBConfig.LOG_DB_JPA_ACCESS)
    public void setJpaAccess(JPAAccess jpaAccess) {
        super.setJpaAccess(jpaAccess);
    }

}
