package com.fubon.esb.domain.config;

public enum JobSystemSettingStatus {
    
    A("Active"), I("Inactive"), D("Delete");

    private final String desc;

    private JobSystemSettingStatus(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }
}
