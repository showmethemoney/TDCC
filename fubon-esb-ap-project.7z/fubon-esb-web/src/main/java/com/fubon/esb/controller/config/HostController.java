package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.config.exception.DuplicatedException;
import com.fubon.esb.domain.config.ConfigActiveStatus;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.EffectType;
import com.fubon.esb.domain.config.Host;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.HostService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-6
 */
@Controller
@RequestMapping("/host")
public class HostController extends BaseController {

    @Inject
    private HostService hostService;
    @Inject
    private LoginContext loginContext;
    @Inject
    private AutoQueryService autoQueryService;
    @Inject
    private ConfigChangeService configChangeService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewSerachHost")
    public String viewHostList(Model model) {
        return "/config/viewHostList";
    }

    @RequirePermission(value = "050501")
    @RequestMapping("/viewHostList")
    public String viewHostList(Model model, String code, String name, ConfigActiveStatus status, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Host> hosts = hostService.findLatestHosts(code, name, status, page);
        if (page.getTotalPage() != 0 && currentPage > page.getTotalPage()) {
            page.setCurrentPage(page.getTotalPage());
            hosts = hostService.findLatestHosts(code, name, status, page);
        }
        model.addAttribute("hosts", hosts);
        model.addAttribute("code", code);
        model.addAttribute("name", name);
        model.addAttribute("status", status);
        model.addAttribute("page", page);
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        return "/config/viewHostList";
    }

    @RequestMapping("/viewHost")
    @RequirePermission(value = {"050502", "050503"})
    public String viewHost(Model model, @RequestParam(required = false) String id) {
        boolean isAdd = true;
        if (StringUtils.isNotBlank(id)) { // 修改
            isAdd = false;
            Host host = hostService.getHostById(id);
            String txnCodes = hostService.findTxnCodes(id);
            model.addAttribute("host", host);
            model.addAttribute("txnCodes", txnCodes);
        }
        model.addAttribute("isAdd", isAdd);
        model.addAttribute("currUser", loginContext.loginedUserId());
        model.addAttribute("currDate", new Date());
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewHost";
    }
    
    
    @RequestMapping("/refreshHost")
    @ResponseBody
    public Object refreshHost(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true; 
    	
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_HOST, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    

    @RequestMapping("saveOrUpdateHost")
    @ResponseBody
    public Map<String, Object> saveOrUpdateHost(@Valid Host host, String effectDate, String effectHour, String effectMinute) {
        Map<String, Object> result = new HashMap<String, Object>();
        try {
            String hostId = hostService.saveOrUpdateHost(host, effectDate, effectHour, effectMinute);
            configChangeService.sendChangeEvent(ConfigType.CFG_HOST, hostId);
            result.put("flag", true);
        } catch (DuplicatedException e) {
            result.put("message", e.getMessage());
            result.put("flag", false);
        }
        return result;
    }

    @ResponseBody
    @RequestMapping({"/findMainHostCodes"})
    public Object findMainHostCodes(@RequestParam String key) {
        return autoQueryService.searchMainHostCodes(key);
    }

    @ResponseBody
    @RequestMapping({"/findHostCodes"})
    public Object findHostCodes(@RequestParam String key) {
        return autoQueryService.searchHostCodes(key);
    }

    @RequestMapping("/viewHostDetail")
    @RequirePermission(value = "050501")
    public String viewHostDetail(Model model, @RequestParam String id) {
        if (StringUtils.isNotBlank(id)) {
            Host host = hostService.getHostById(id);
            String txnCodes = hostService.findTxnCodes(id);
            model.addAttribute("host", host);
            model.addAttribute("txnCodes", txnCodes);
        }
        model.addAttribute("STATUS_ACTIVE", ConfigActiveStatus.A);
        model.addAttribute("STATUS_INACTIVE", ConfigActiveStatus.I);
        model.addAttribute("STATUS_DELETE", ConfigActiveStatus.D);
        model.addAttribute("EFFECTTYPE_IMMEDIAT", EffectType.I);
        model.addAttribute("EFFECTTYPE_BOOKED", EffectType.B);
        return "/config/viewHostDetail";
    }

    // 刪除
    @RequestMapping("/deleteHost")
    @ResponseBody
    public Object deleteHost(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        StringBuilder message = new StringBuilder();
        boolean isDel = hostService.isRelatedHost(id, message);
        String relateMessage = "";
        if (!message.toString().isEmpty())
            relateMessage = message.toString().substring(0, message.toString().length() - 1);
        boolean flag = false;
        if (isDel) {
            result.put("flag", flag);
            result.put("message", messages.getMessage("config.error.delete") + "，與以下業務群組相關聯" + relateMessage);
        } else {
            hostService.deleteHost(id);
            flag = true;
            result.put("flag", flag);
        }
        return result;
    }
}
