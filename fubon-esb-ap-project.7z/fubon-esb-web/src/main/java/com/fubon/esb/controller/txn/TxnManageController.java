package com.fubon.esb.controller.txn;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.controller.txn.view.TxnManageExcelView;
import com.fubon.esb.controller.txn.view.TxnManageVo;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.txn.TxnManageCategoryType;
import com.fubon.esb.service.log.OperationLogService;
import com.fubon.esb.service.txn.TxnManageService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-18
 */
@Controller
@RequestMapping("/txnManage")
public class TxnManageController extends BaseController {

    @Inject
    private TxnManageService txnManagerService;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private Messages messages;

    @RequestMapping("/viewManage")
    public String viewQuery(Model model) {
        Page page = new Page(1, 50);
        List<TxnManageVo> txnVos = txnManagerService.findTxnAll(page, false);
        model.addAttribute("txnVos", txnVos);
        model.addAttribute("queryType", TxnManageCategoryType.ALL);
        model.addAttribute("page", page);
        return "/txn/viewTxnManagerList";
    }

    @RequestMapping("/query/all")
    @RequirePermission(value = "0201")
    public String findTxnByTypeAll(Model model, TxnManageCategoryType queryType, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        List<TxnManageVo> txnVos = txnManagerService.findTxnAll(page, isSearch);
        model.addAttribute("txnVos", txnVos);
        model.addAttribute("queryType", TxnManageCategoryType.ALL);
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByAllList";
    }

    @RequestMapping("/query/txn")
    @RequirePermission(value = "0201")
    public String findTxnByTxn(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        List<TxnManageVo> txnVos = txnManagerService.findTxnByTxn(page, isSearch);
        model.addAttribute("txnVos", txnVos);
        model.addAttribute("queryType", TxnManageCategoryType.TXN.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByTxnList";
    }

    @RequestMapping("/query/channel")
    @RequirePermission(value = "0201")
    public String findTxnByTypeChannel(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByChannel(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.CHANNEL.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByChannelList";
    }

    @RequestMapping("/query/accessChannel")
    @RequirePermission(value = "0201")
    public String findTxnByTypeAccessChannel(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByAccessChannel(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.ACCESSCHANNEL.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByAccessChannelList";
    }

    @RequestMapping("/query/host")
    @RequirePermission(value = "0201")
    public String findTxnByTypeHost(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByHost(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.HOST.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByHostList";
    }

    @RequestMapping("/query/txnGroup")
    @RequirePermission(value = "0201")
    public String findTxnByTxnGroup(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByTxnGroup(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.TXNGROUP.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByTxnGroupList";
    }

    @RequestMapping("/query/service")
    @RequirePermission(value = "0201")
    public String findTxnByService(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByService(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.SERVICE.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByServiceList";
    }

    @RequestMapping("/query/serviceVersion")
    @RequirePermission(value = "0201")
    public String findTxnByServiceVersion(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        List<TxnManageVo> txnVos = txnManagerService.findTxnByServiceVersion(page, isSearch);
        model.addAttribute("txnVos", txnVos);
        model.addAttribute("queryType", TxnManageCategoryType.SERVICEVERSION.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByServiceVersionList";
    }

    @RequestMapping("/query/connector")
    @RequirePermission(value = "0201")
    public String findTxnByConnector(Model model, @RequestParam(required = false, defaultValue = "1") Integer currentPage, @RequestParam(required = false) Boolean isSearch) {
        Page page = new Page(currentPage, 50);
        Map<String, List<TxnManageVo>> txnManageMap = txnManagerService.findTxnByConnector(page, isSearch);
        model.addAttribute("txnManageMap", txnManageMap);
        model.addAttribute("queryType", TxnManageCategoryType.CONNECTOR.toString());
        model.addAttribute("page", page);
        return "/txn/include/query/viewTxnByConnectorList";
    }

    @RequirePermission(value = "0202")
    @RequestMapping("exportTxnManage")
    public ModelAndView exportTxnManage(ModelMap model, TxnManageCategoryType queryType) {
        TxnManageExcelView txnManageExcelView = new TxnManageExcelView();
        model.put("queryType", queryType);
        model.put("txnManageVos", txnManagerService.findTxnByType(queryType));
        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, String.format(messages.getMessage("txn.manage.log.export." + queryType.toString().toLowerCase())), LogType.TXN_MANAGE);
        return new ModelAndView(txnManageExcelView, model);
    }

}
