package com.fubon.esb.service.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comwave.core.database.Page;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.login.LoginContext;
import com.fubon.esb.dao.system.RoleDao;
import com.fubon.esb.dao.system.RoleFunctionDao;
import com.fubon.esb.dao.system.RoleUserDao;
import com.fubon.esb.dao.system.UserConfigDao;
import com.fubon.esb.domain.log.LogType;
import com.fubon.esb.domain.log.OperationLog;
import com.fubon.esb.domain.system.Branch;
import com.fubon.esb.domain.system.Group;
import com.fubon.esb.domain.system.Role;
import com.fubon.esb.domain.system.RoleFunction;
import com.fubon.esb.domain.system.RoleUser;
import com.fubon.esb.domain.system.UserConfig;
import com.fubon.esb.service.log.OperationLogService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-28
 */
@Service
public class RoleService {

    @Inject
    private RoleDao roleDao;

    @Inject
    private RoleUserDao roleUserDao;

    @Inject
    private LoginContext loginContext;

    @Inject
    private RoleFunctionDao roleFunctionDao;

    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private UserConfigDao userConfigDao;

    @Inject
    private Messages messages;

    /**
     * 根據role id 查詢可以修改的role
     */
    public Role getRoleById(String id) {
        if (StringUtils.isBlank(id)) {
            return null;
        }

        Role role = roleDao.getRoleByMainId(id);
        if (role == null) {
            // 沒有修改暫存記錄
            role = roleDao.getRoleById(id);
        }

        return role;
    }

    /**
     * 新增或修改角色
     * 
     * @param role 頁面傳回的角色信息 {@link Role}
     * @param userIds 需要加入角色的用戶ID {@link UserConfig}
     */
    @Transactional
    public void saveOrUpdateRole(Role role, String[] userIds) {
        role.setUpdatedUser(loginContext.loginedUserId()); // 修改人員
        role.setUpdatedTime(new Date()); // 修改時間
        role.setName(role.getName().trim());
        Role oldRole = null;
        StringBuilder logMessage = new StringBuilder();

        if (StringUtils.isBlank(role.getId())) {
            role.setMainId("0");
            role.setModifyFlag(getModifyFlagByRole(role, oldRole));
            roleDao.saveRole(role);
            logMessage.append(getMessage("system_log_role_add")).append(": " + role.getName());
        } else {
            oldRole = roleDao.getRoleById(role.getId());
            logMessage.append(getMessage("system_log_role_edit")).append(": " + oldRole.getName());
            role.setModifyFlag(getModifyFlagByRole(role, oldRole));
            if (StringUtils.isNotBlank(role.getMainId())) {
                roleDao.update(role); // 已修改過
            } else {
                role.setMainId(role.getId());
                role.setId(null);
                roleDao.saveRole(role);
                copyFunctionFromSourceRole(role, oldRole);
            }
        }

        operationLogService.addOperationLog(OperationLog.LEVEL_INFO, logMessage.toString(), LogType.SYS_FUNC_MANAGE);

        String[] userIdsCopy;
        if (userIds == null) {
            userIdsCopy = new String[]{};
        } else {
            userIdsCopy = userIds.clone();
        }
        String id = role.getId();
        List<RoleUser> newList = new ArrayList<>();
        for (String userId : userIdsCopy) {
            newList.add(new RoleUser(id, userId));
        }
        List<RoleUser> oldList = roleUserDao.findRoleUserByRoleId(id);
        compareUserIds(newList, oldList);
    }

    private void copyFunctionFromSourceRole(Role newRole, Role oldRole) {
        List<String> functions = roleFunctionDao.findFunctionListByRoleId(oldRole.getId());
        List<RoleFunction> roleFunctions = new ArrayList<>();
        for (String function : functions) {
            roleFunctions.add(new RoleFunction(newRole.getId(), function));
        }
        roleFunctionDao.saveRoleFunctionList(roleFunctions);
    }

    /**
     * 比較頁面傳回的RoleUser list {@link RoleUser} ,和數據庫里原有的值 oldList 做比較<br />
     * 新增的插入表中，刪除取消的數據<br />
     */
    @SuppressWarnings("unchecked")
    private void compareUserIds(List<RoleUser> newList, List<RoleUser> oldList) {
        if (!CollectionUtils.isEqualCollection(oldList, newList)) {
            List<RoleUser> sameList = (List<RoleUser>) CollectionUtils.retainAll(oldList, newList);
            newList.removeAll(sameList);
            oldList.removeAll(sameList);
            roleUserDao.removeRoleUsers(oldList); // 刪除取消的分行
            roleUserDao.saveRoleUsers(newList); // 插入新增的分行
        }
    }

    /**
     * 角色選擇分行,分頁顯示
     */
    public List<UserConfig> findUserList(String userId, Page page) {
        return userConfigDao.findUserList(userId, page);
    }

    /**
     * 查詢角色關聯對所有用戶
     */
    public List<UserConfig> findUserListByRole(String roleId) {
        return userConfigDao.findUserListByRole(roleId);
    }

    /**
     * 獲取Role最初對ID
     */
    public String getRoleOriginId(String roleId) {
        return getRoleOriginId(roleDao.getRoleById(roleId));
    }

    /**
     * 獲取Role最初對ID
     */
    public String getRoleOriginId(Role role) {
        if (StringUtils.isBlank(role.getMainId()) || "0".equals(role.getMainId())) {
            return role.getId();
        }

        return role.getMainId();
    }

    /**
     * 修改Role後的內容標誌
     */
    public Integer getModifyFlagByRole(Role newRole, Role oldRole) {
        Integer modifyFlag = 1;
        if (newRole.getModifyFlag() == null) {
            return modifyFlag;
        }
        return newRole.getModifyFlag() | modifyFlag;
    }

    public boolean isModifyFlagMatch(Role role, Integer modifyFlag) {
        return (role.getModifyFlag() & modifyFlag) > 0;
    }

    /**
     * 角色覆核
     */
    public void approvalRole(Role origin, Role tmp) {
        if (isModifyFlagMatch(tmp, 1)) {
            roleUserDao.batchDeleteByRole(origin.getId());
            List<String> userIds = roleUserDao.findUserIdsByRole(tmp.getId());
            if (userIds != null && !userIds.isEmpty()) {
                List<RoleUser> roleUsers = new ArrayList<>();
                for (String userId : userIds) {
                    roleUsers.add(new RoleUser(origin.getId(), userId));
                }
                roleUserDao.batchDeleteByRole(tmp.getId());
                roleUserDao.saveRoleUsers(roleUsers);
            }
        }

        if (isModifyFlagMatch(tmp, 2)) {
            roleFunctionDao.batchDeleteByRole(origin.getId());
            // List<RoleFunction> roleFunctions = roleFunctionDao.findRoleFuncListByRoleId(tmp.getId());
            List<String> funcCodes = roleFunctionDao.findFunctionListByRoleId(tmp.getId());
            if (funcCodes != null && !funcCodes.isEmpty()) {
                List<RoleFunction> roleFunctions = new ArrayList<>();
                for (String funcCode : funcCodes) {
                    roleFunctions.add(new RoleFunction(origin.getId(), funcCode));
                }
                roleFunctionDao.batchDeleteByRole(tmp.getId());
                roleFunctionDao.saveRoleFunctionList(roleFunctions);
            }
        }

        roleDao.delete(tmp);
        roleDao.update(origin);
    }

    @Deprecated
    public List<Role> findRolesByGroupBranch(List<Group> groups, Branch branch) {
        if (groups == null || groups.isEmpty() || branch == null) {
            return null;
        }
        List<String> groupIds = new ArrayList<>();
        for (Group group : groups) {
            groupIds.add(group.getId());
        }
        return roleDao.findRolesByGroupBranch(groupIds, branch.getCode());
    }

    private String getMessage(String key) {
        return messages.getMessage(key);
    }

}
