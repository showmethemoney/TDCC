package com.fubon.esb.service.txn;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fubon.esb.domain.txn.FieldType;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;
import com.fubon.esb.domain.txn.TxnFieldTestValue;

/**
 * @author nice
 * @createdDate 2015-1-16
 */
@Service
public class TxnTestXmlService extends AbstracTxnXmlService {

    @Override
    public void prepareXml(String xmlStr, String dirId) throws Exception {
        setDocument(DocumentHelper.parseText(xmlStr));
        getNormalFieldValues().clear();
        if (visitFMPConnElement() == null) {
            throw new IllegalArgumentException("格式錯誤:無FMPConnectionString節點!");
        }
        if (visitHeaderElement() == null) {
            throw new IllegalArgumentException("格式錯誤:無TxHead節點!");
        }
        if (visitBodyElement() == null) {
            throw new IllegalArgumentException("格式錯誤:無TxBody節點!");
        }
        setCurDirectionId(dirId);
        fillMainNormalFieldValues();
    }

    @Override
    @Transactional
    public void saveTxTestValues(String xmlStr, String dirId) throws Exception {
        prepareXml(xmlStr, dirId);
        TxnDirection dir = txnDirectionService.getById(dirId);
        List<Integer> rootIndex = increaseDegree(null, false, 1);
        saveFieldsValues(txnFieldService.findMainsByDirId(dir.getHeadRefId()), visitHeaderElement(), null, rootIndex);
        saveFieldsValues(txnFieldService.findMainsByDirId(dirId), visitBodyElement(), null, rootIndex);
    }

    public void throwNodeDetailError(String expireQname, Element root, List<Integer> nodeDegree) throws IllegalArgumentException {
        if (root == null || nodeDegree == null) {
            throw new IllegalArgumentException("格式錯誤！");
        }
        StringBuffer errorMsg = new StringBuffer(1024);
        errorMsg.append(root.getName()).append("節點");
        for (int i = 0; i < nodeDegree.size() - 1; i++) {
            errorMsg.append("的第[").append(nodeDegree.get(i)).append("]個節點");
        }
        errorMsg.append("中未找到必輸節點[").append(expireQname).append("]或該節點未輸入值！");
        throw new IllegalArgumentException(errorMsg.toString());
    }

    public void saveNormalFieldValue(TxnFieldDefinition field, Element root, List<Integer> degree, List<Integer> pIndex) throws Exception {
        String fieldCode = field.getCode();
        Element elment = getElementByDegree(fieldCode, root, degree);
        String testValue = null;
        if (elment != null) {
            testValue = elment.getText();
        } else {
            testValue = findNormalFieldValue(fieldCode);
        }
        if (field.getOptional() != 1 && StringUtils.isBlank(testValue)) {
            throwNodeDetailError(fieldCode, root, degree);
        }
        addNormalFieldValue(new NormalFieldValue(fieldCode, testValue));
        testValueService.saveOrUpdateTestValue(new TxnFieldTestValue(null, field.getId(), getCurDirectionId(), testValue, converToOrderNo(pIndex)));
    }

    public void saveRepeatFieldValue(TxnFieldDefinition field, Element root, List<Integer> degree, List<Integer> pIndex) throws Exception {
        List<TxnFieldDefinition> cFields = txnFieldService.findChildren(field.getId());
        saveFieldsValues(cFields, root, degree, pIndex);
    }

    public void saveFieldValue(TxnFieldDefinition field, Element root, List<Integer> degree, List<Integer> pIndex) throws Exception {
        if (FieldType.F.equals(field.getFieldType())) {
            saveNormalFieldValue(field, root, degree, pIndex);

        } else if (FieldType.R.equals(field.getFieldType())) {
            saveRepeatFieldValue(field, root, degree, pIndex);
        }
    }

    public String findRefFieldValue(TxnFieldDefinition switchOrRepeat) {
        String refValue = "";
        if (FieldType.S.equals(switchOrRepeat.getFieldType()) || "C".equals(switchOrRepeat.getRepeatType())) {
            refValue = findNormalFieldValue(switchOrRepeat.getValue());
        } else if ("9".equals(switchOrRepeat.getRepeatType())) {
            refValue = switchOrRepeat.getValue();
        }
        if (StringUtils.isBlank(refValue)) {
            refValue = "1";
        }
        return refValue;
    }

    public int findRepeatTime(TxnFieldDefinition repeatField) {
        int repeateTime = 1;
        try {
            repeateTime = Integer.parseInt(findRefFieldValue(repeatField));
        } catch (NumberFormatException nfx) {
            repeateTime = 1;
        }
        return repeateTime;
    }

    public void saveFieldsValues(List<TxnFieldDefinition> fields, Element root, List<Integer> degree, List<Integer> pIndex) throws Exception {
        List<TxnFieldDefinition> noSCFields = convertSwitchCaseFields(fields);
        List<Integer> curPIndex = pIndex;
        for (int i = 0, index = 0; noSCFields != null && i < noSCFields.size(); i++) {
            TxnFieldDefinition field = noSCFields.get(i);
            TxnFieldDefinition pField = txnFieldService.getById(field.getParentId());
            if (pField != null && FieldType.C.equals(pField.getFieldType())) {
                curPIndex = increaseDegree(pIndex, true, 1, 1);
            } else {
                curPIndex = pIndex;
            }
            if (FieldType.F.equals(field.getFieldType())) {
                index++;
                saveFieldValue(field, root, increaseDegree(degree, false, index), curPIndex);
            } else if (FieldType.R.equals(field.getFieldType())) {
                testValueService.saveOrUpdateTestValue(new TxnFieldTestValue(null, field.getId(), getCurDirectionId(), findRefFieldValue(field), converToOrderNo(curPIndex)));
                for (int j = 0; j < findRepeatTime(field); j++) {
                    index++;
                    saveFieldValue(field, root, increaseDegree(degree, false, index), increaseDegree(curPIndex, false, 1 + j));
                }
            }
        }
    }

    public List<TxnFieldDefinition> convertSwitchCaseFields(List<TxnFieldDefinition> fields) {
        List<TxnFieldDefinition> reBuildFields = new ArrayList<TxnFieldDefinition>(1);
        for (TxnFieldDefinition field : fields) {
            if (FieldType.S.equals(field.getFieldType())) {
                List<TxnFieldDefinition> caseChildren = txnFieldService.findCaseFieldsByChoice(field.getId(), findRefFieldValue(field));
                if (caseChildren != null)
                    for (TxnFieldDefinition caseChild : caseChildren) {
                        reBuildFields.add(caseChild);
                    }
            } else {
                reBuildFields.add(field);
            }
        }
        return reBuildFields;
    }

}
