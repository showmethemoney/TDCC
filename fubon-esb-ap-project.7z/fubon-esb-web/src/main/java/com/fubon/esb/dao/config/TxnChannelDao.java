package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.TxnChannel;

/**
 * 
 * @author Shelly
 * @createdDate 2014-10-31
 */
@Repository
public class TxnChannelDao extends JPADaoSupport<TxnChannel> {

    public List<TxnChannel> findByChannelIds(List<String> channelIds) {
        Query query = Query.from(TxnChannel.class).where("channelId in (:channelIds)").param("channelIds", channelIds);
        return jpaAccess.find(query);
    }

    public List<TxnChannel> findByChannelId(String channelId) {
        Query query = Query.from(TxnChannel.class).where("channelId = :channelId").param("channelId", channelId);
        return jpaAccess.find(query);
    }

    public List<TxnChannel> findByTxnId(String txnId) {
        Query query = Query.from(TxnChannel.class).where("txnId = :txnId").param("txnId", txnId);
        return jpaAccess.find(query);
    }

    public void saveTxnChannels(String txnId, String channelIds) {
        if (channelIds != null && !channelIds.isEmpty()) {
            String ids[] = channelIds.split(",");
            for (String id : ids) {
                if (StringUtils.isNotBlank(id)) {
                    TxnChannel txnChannel = new TxnChannel(txnId, id);
                    jpaAccess.save(txnChannel);
                }
            }
        }
    }

    public void addTxnChannelList(List<TxnChannel> txnChannels) {
        for (TxnChannel txnChannel : txnChannels) {
            jpaAccess.save(txnChannel);
        }
    }

    public void removeTxnChannelList(List<TxnChannel> txnChannels) {
        for (TxnChannel txnChannel : txnChannels) {
            jpaAccess.delete(txnChannel);
        }
    }

    public void deleteByTxnId(String txnId) {
        jpaAccess.update(Query.create("delete from " + TxnChannel.class.getName() + " where txnId=:txnId").param("txnId", txnId));
    }
}
