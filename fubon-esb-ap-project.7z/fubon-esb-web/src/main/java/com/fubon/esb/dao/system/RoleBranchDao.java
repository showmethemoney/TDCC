package com.fubon.esb.dao.system;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.system.RoleBranch;

/**
 * @author Leckie Zhang
 * @createdDate 2014-10-29
 */
@Repository
public class RoleBranchDao extends JPADaoSupport<RoleBranch> {

    public void addRoleBranchList(List<RoleBranch> list) {
        for (RoleBranch rb : list) {
            jpaAccess.save(rb);
        }
    }

    public void removeRoleBranchList(List<RoleBranch> list) {
        for (RoleBranch rb : list) {
            jpaAccess.delete(rb);
        }
    }

    public List<RoleBranch> findRoleBranchByRoleId(String roleId) {
        return jpaAccess.find(Query.from(RoleBranch.class).where("roleId = :id").param("id", roleId));
    }

    public void batchDeleteByRole(String roleId) {
        jpaAccess.update(Query.create("delete " + RoleBranch.class.getName() + " where roleId=:roleId").param("roleId", roleId));
    }

    public List<String> findBranchCodesByRole(String roleId) {
        return jpaAccess.find(Query.create("select branchCode from " + RoleBranch.class.getName() + " where roleId=:roleId").param("roleId", roleId));
    }

}
