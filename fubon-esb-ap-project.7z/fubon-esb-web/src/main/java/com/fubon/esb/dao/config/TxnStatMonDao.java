package com.fubon.esb.dao.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.Query;
import com.fubon.esb.controller.query.view.TxnStatSearchVO;
import com.fubon.esb.dao.LogDBJPADaoSupport;
import com.fubon.esb.domain.config.TxnStatCategoryType;
import com.fubon.esb.domain.config.TxnStatMon;
import com.fubon.esb.service.TimeZoneService;

/**
 * @author Leckie Zhang
 * @createdDate 2014-12-1
 */
@Repository
public class TxnStatMonDao extends LogDBJPADaoSupport<TxnStatMon> {

    @Inject
    private TimeZoneService timeZoneService;

    public List<TxnStatMon> findTxnStats(TxnStatSearchVO vo) {

        Map<String, Object> params = new HashMap<String, Object>();

        StringBuilder jql = new StringBuilder(getJql(vo, params));
        if (vo.getOrder() == null) {
            if (vo.getCategory() == TxnStatCategoryType.D) {
                jql.append(" order by CAST(value as int) ");
            } else {
                jql.append(" order by day ");   
            }
        } else {
            jql.append(" order by ").append(vo.getOrder().getClause());
        }
        Query query = Query.create(jql.toString());
        query.putParams(params);
        if (vo.getPage() != null) {
            query.page(vo.getPage());
        }

        return jpaAccess.findPage(query);
    }

    private String getJql(TxnStatSearchVO vo, Map<String, Object> params) {
        StringBuilder commonJql = new StringBuilder();
        commonJql.append("  from ").append(TxnStatMon.class.getName()).append(" where 1=1 ").append(" and month between :start and :end ");
        params.put("start", formatDate(getDateByYearMonth(vo.getStartYear(), vo.getStartMonth(), true)));
        params.put("end", formatDate(getDateByYearMonth(vo.getEndYear(), vo.getEndMonth(), false)));
        
        if (vo.getCategory() == TxnStatCategoryType.D && StringUtils.isNotBlank(vo.getValueD())) {
            commonJql.append(" and value = :value ");
            params.put("value", vo.getValueD().replace("D", ""));
        } else if (vo.getCategory() != TxnStatCategoryType.A && StringUtils.isNotBlank(vo.getValue1())) {
            commonJql.append(" and value like :value ");
            params.put("value", "%" + vo.getValue1() + "%");
        }
        if (vo.getCategory() == TxnStatCategoryType.CT && StringUtils.isNotBlank(vo.getValue2ct())) {
            commonJql.append(" and value2 like :value2 ");
            params.put("value2", "%" + vo.getValue2ct() + "%");
        }

        commonJql.append(" and type = :type ");
        params.put("type", vo.getType());

        commonJql.append(" and category = :category ");
        params.put("category", vo.getCategory());

        return commonJql.toString();
    }

    public Date getDateByYearMonth(Integer year, Integer month, boolean isStart) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMM").parse(year.toString() + month);
        } catch (ParseException e) {
            return null;
        }

        if (isStart) {
            return timeZoneService.getTZDateByService(date);
        } else {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.MONTH, 1);
            cal.add(Calendar.SECOND, -60);
            return timeZoneService.getTZDateByService(cal.getTime());
        }
    }

    public Integer formatDate(Date date) {
        if (date == null) {
            return null;
        }

        return Integer.parseInt(DateFormatUtils.format(date, "yyyyMM"));
    }

}
