package com.fubon.esb.controller.txn.view;

import java.util.List;

import com.fubon.esb.domain.txn.TxnDefinition;
import com.fubon.esb.domain.txn.TxnDirection;
import com.fubon.esb.domain.txn.TxnFieldDefinition;

/**
 * @author nice
 * @createdDate 2014-11-14
 */
public class TxnVO {

    private TxnDefinition definition;

    private TxnDirection upDirection;

    private TxnDirection headDirection;

    private TxnDirection downDirection;

    private List<TxnFieldDefinition> upFields;

    private List<TxnFieldDefinition> headFields;

    private List<TxnFieldDefinition> downFields;

    public TxnVO() {

    }

    public TxnVO(TxnDefinition definition, TxnDirection upDirection, TxnDirection downDirection, List<TxnFieldDefinition> upFields, List<TxnFieldDefinition> downFields) {
        this.definition = definition;
        this.upDirection = upDirection;
        this.downDirection = downDirection;
        this.upFields = upFields;
        this.downFields = downFields;
    }

    // public TxnVO(TxnDefinition definition, TxnDirection upDirection, TxnDirection downDirection, List<TxnFieldDefinition> upFields, List<TxnFieldDefinition> downFields, TxnDirection headDirection,
    // List<TxnFieldDefinition> headFields) {
    // this.definition = definition;
    // this.upDirection = upDirection;
    // this.downDirection = downDirection;
    // this.upFields = upFields;
    // this.downFields = downFields;
    // this.headDirection = headDirection;
    // this.headFields = headFields;
    // }

    public TxnVO(TxnDirection headDirection, List<TxnFieldDefinition> headFields) {
        this.headDirection = headDirection;
        this.headFields = headFields;
    }

    protected boolean isValid() {
        return true;
    };

    public TxnDefinition getDefinition() {
        return definition;
    }

    public void setDefinition(TxnDefinition definition) {
        this.definition = definition;
    }

    public TxnDirection getUpDirection() {
        return upDirection;
    }

    public void setUpDirection(TxnDirection upDirection) {
        this.upDirection = upDirection;
    }

    public TxnDirection getDownDirection() {
        return downDirection;
    }

    public void setDownDirection(TxnDirection downDirection) {
        this.downDirection = downDirection;
    }

    public List<TxnFieldDefinition> getUpFields() {
        return upFields;
    }

    public void setUpFields(List<TxnFieldDefinition> upFields) {
        this.upFields = upFields;
    }

    public List<TxnFieldDefinition> getDownFields() {
        return downFields;
    }

    public void setDownFields(List<TxnFieldDefinition> downFields) {
        this.downFields = downFields;
    }

    public TxnDirection getHeadDirection() {
        return headDirection;
    }

    public void setHeadDirection(TxnDirection headDirection) {
        this.headDirection = headDirection;
    }

    public List<TxnFieldDefinition> getHeadFields() {
        return headFields;
    }

    public void setHeadFields(List<TxnFieldDefinition> headFields) {
        this.headFields = headFields;
    }
}
