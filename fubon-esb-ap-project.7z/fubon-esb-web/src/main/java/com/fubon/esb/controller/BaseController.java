package com.fubon.esb.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import com.comwave.core.platform.cookie.RequireCookie;
import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.login.RequireLogin;
import com.comwave.core.platform.model.RequireExtraModel;
import com.comwave.core.platform.session.RequireSession;
import com.fubon.esb.domain.system.User;
import com.fubon.esb.exception.ValidationException;
import com.google.common.collect.Lists;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
@RequireCookie
@RequireSession
@RequireLogin
@RequireExtraModel
public abstract class BaseController {

    private final ThreadLocal<List<String>> errorMessages = new ThreadLocal<>();

    @Inject
    private LoginContext loginContext;

    public String loginedUserId() {
        return loginContext.loginedUserId();
    }

    public User loginedUser() {
        return loginContext.loginedUser(User.class);
    }

    public void addError(String message) {
        List<String> errorMsgs = errorMessages.get();
        if (errorMsgs == null) {
            errorMsgs = new ArrayList<String>();
            errorMessages.set(errorMsgs);
        }
        errorMsgs.add(message);
    }

    public void validate() {
        List<String> errorMsgs = errorMessages.get();
        if (errorMsgs != null && !errorMsgs.isEmpty()) {
            List<String> copiedMsgs = Lists.newArrayList(errorMsgs);
            errorMsgs.clear();
            throw new ValidationException(copiedMsgs);
        }
    }

}
