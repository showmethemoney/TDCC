package com.fubon.esb.domain.config;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.GenericGenerator;

import com.comwave.core.domain.Holder;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
@MappedSuperclass
public abstract class ConfigBaseEntity extends Holder {

    /** ID */
    @Id
    @Column(name = "ID")
    @GenericGenerator(name = "uuidGenerator", strategy = "uuid2")
    @GeneratedValue(generator = "uuidGenerator")
    private String id;

    /** 對應的正本 */
    @Column(name = "MAIN_ID")
    private String mainId;

    /** 生效類型 */
    @Column(name = "EFFECT_TYPE")
    @Enumerated(EnumType.STRING)
    private EffectType effectType;

    /** 生效時間 */
    @Column(name = "EFFECT_TIME")
    private Date effectTime;

    /** 備注 */
    @Column(name = "MEMO")
    private String memo;

    /** 建立者 */
    @Column(name = "CREATED_USER")
    private String createdUser;

    /** 建立時間 */
    @Column(name = "CREATED_TIME")
    private Date createdTime;

    /** 更新人 */
    @Column(name = "UPDATED_USER")
    private String updatedUser;

    /** 更新時間 */
    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    public EffectType getEffectType() {
        return effectType;
    }

    public void setEffectType(EffectType effectType) {
        this.effectType = effectType;
    }

    public Date getEffectTime() {
        return effectTime;
    }

    public void setEffectTime(Date effectTime) {
        this.effectTime = effectTime;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getUpdatedUser() {
        return updatedUser;
    }

    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
