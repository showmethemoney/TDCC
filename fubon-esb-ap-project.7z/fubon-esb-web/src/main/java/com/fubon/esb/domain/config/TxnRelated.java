package com.fubon.esb.domain.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 交易關聯交易
 * 
 * @author Shelly
 * @createdDate 2014-10-31
 */
@Entity(name = "CFG_TXN_RELATED")
public class TxnRelated implements Serializable {

    /** 交易ID **/
    @Id
    @Column(name = "TXN_ID")
    private String txnId;

    /** 關聯交易ID **/
    @Id
    @Column(name = "RELATED_TXN_ID")
    private String relatedTxnId;

    public TxnRelated() {
        super();
    }

    public TxnRelated(String txnId, String relatedTxnId) {
        super();
        this.txnId = txnId;
        this.relatedTxnId = relatedTxnId;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getRelatedTxnId() {
        return relatedTxnId;
    }

    public void setRelatedTxnId(String relatedTxnId) {
        this.relatedTxnId = relatedTxnId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((relatedTxnId == null) ? 0 : relatedTxnId.hashCode());
        result = prime * result + ((txnId == null) ? 0 : txnId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TxnRelated other = (TxnRelated) obj;
        if (relatedTxnId == null) {
            if (other.relatedTxnId != null)
                return false;
        } else if (!relatedTxnId.equals(other.relatedTxnId))
            return false;
        if (txnId == null) {
            if (other.txnId != null)
                return false;
        } else if (!txnId.equals(other.txnId))
            return false;
        return true;
    }

}
