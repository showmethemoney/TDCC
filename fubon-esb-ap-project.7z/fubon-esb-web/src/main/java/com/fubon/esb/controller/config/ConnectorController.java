package com.fubon.esb.controller.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.comwave.core.database.Page;
import com.comwave.core.platform.permission.RequirePermission;
import com.fubon.esb.controller.BaseController;
import com.fubon.esb.domain.config.ConfigType;
import com.fubon.esb.domain.config.Connector;
import com.fubon.esb.domain.config.Txn;
import com.fubon.esb.domain.system.Adapter;
import com.fubon.esb.service.config.AutoQueryService;
import com.fubon.esb.service.config.ConfigChangeService;
import com.fubon.esb.service.config.ConnectorService;

/**
 * 
 * @author Shelly
 * @createdDate 2014-11-10
 */
@Controller
@RequestMapping("/connector")
public class ConnectorController extends BaseController {

    @Inject
    private ConnectorService connectorService;

    @Inject
    private AutoQueryService autoQueryService;

    @Inject
    private ConfigChangeService configChangeService;

    @RequestMapping("/findConnectors")
    public String findConnectors(Model model, String code, @RequestParam(required = false, defaultValue = "1") int currentPage) {
        Page page = new Page(currentPage);
        List<Connector> connectors = connectorService.findConnectors(code, page);
        model.addAttribute("code", code);
        model.addAttribute("page", page);
        loginedUserId();
        model.addAttribute("connectors", connectors);
        return "/config/include/viewConnectors";
    }

    @RequestMapping("/viewConnectorSetting")
    @RequirePermission(value = "050701")
    public String findConnectorsList(Model model, String connectorCode, String connectorName, Boolean isSearch, @RequestParam(required = false, defaultValue = "1") Integer currentPage) {
        Page page = new Page(currentPage);
        String connectorCodeTrim = "";
        if (StringUtils.isNoneBlank(connectorCode)) {
            connectorCodeTrim = connectorCode.trim();
        }
        String connectorNameTrim = "";
        if (StringUtils.isNoneBlank(connectorName)) {
            connectorNameTrim = connectorName.trim();
        }
        model.addAttribute("page", page);
        model.addAttribute("connectors", connectorService.findConnectors(connectorCodeTrim, page, connectorNameTrim));
        if (isSearch != null && isSearch) {
            model.addAttribute("isSearch", isSearch);
            model.addAttribute("connectorCode", connectorCode);
            model.addAttribute("connectorName", connectorName);
            if (currentPage > page.getTotalPage() && page.getTotalPage() != 0) {
                page.setCurrentPage(page.getTotalPage());
                model.addAttribute("connectors", connectorService.findConnectors(connectorCodeTrim, page, connectorNameTrim));
            }
        }
        return "/config/viewConnectorSetting";
    }

    
    @RequestMapping("/refreshConnector")
    @ResponseBody
    public Object refreshConnector(Model model, @RequestParam(required = true) String id){	
         boolean send_status=true;
    	
    	 if (StringUtils.isNotBlank(id))
        	 send_status=configChangeService.sendChangeEvent(ConfigType.CFG_CONNECTOR, id);

         Map<String, Object> result = new HashMap<String, Object>();
         result.put("flag", send_status);
         return result;
    }
    
    
    @RequestMapping("/viewAddConnector")
    @RequirePermission({"050702", "050703"})
    public String viewAddConnector(Model model, Boolean isAdd, String id) {
        String userId = loginedUser().getUserId();
        Boolean flag = false;
        if (isAdd != null) {
            Connector connector = connectorService.findConnectorById(id);
            String txnCodes = connectorService.getTxnCodes(id);
            model.addAttribute("connector", connector);
            model.addAttribute("txnCodes", txnCodes);
            model.addAttribute("adapterList", connectorService.findAdapter(id));
        } else {
            flag = true;
        }
        model.addAttribute("isAdd", flag);
        model.addAttribute("currUser", userId);
        model.addAttribute("currDate", new Date());
        return "/config/viewAddConnector";
    }

    @RequestMapping(value = "/saveOrUpdateConnector", method = RequestMethod.POST)
    public String saveOrUpdateConnector(Model model, @RequestBody Connector connector) {
        Boolean isAdd = connector.isAdd();
        connector.setCode(connector.getCode().trim());
        String userId = loginedUser().getUserId();
        if (StringUtils.isNoneBlank(connector.getId()) && !isAdd) {
            connector.setUpdatedUser(userId);
            connector.setUpdatedTime(new Date());
        } else {
            connector.setId(null);
            connector.setCreatedUser(userId);
            connector.setCreatedTime(new Date());
        }
        connectorService.saveOrUpdateConnector(connector);
        configChangeService.sendChangeEvent(ConfigType.CFG_CONNECTOR, connector.getId());
        Page page = new Page(1);
        model.addAttribute("connectors", connectorService.findConnectors(null, page));
        model.addAttribute("page", page);
        model.addAttribute("isSearch", false);
        return "/config/viewConnectorSetting";
    }

    @RequestMapping("/findTxns")
    @ResponseBody
    public Map<String, Object> findTxns(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Txn> txns = connectorService.findTxns(id);
        result.put("txns", txns);
        return result;
    }

    @RequestMapping("/findAdapter")
    @ResponseBody
    public Map<String, Object> findAdapter(String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Adapter> adapter = connectorService.findAdapter(id);
        result.put("adapter", adapter);
        return result;
    }

    /**
     * 判斷是否有相同的code
     */
    @RequestMapping("/findConnector")
    @ResponseBody
    public Map<String, Object> findConnector(String code, String id) {
        Map<String, Object> result = new HashMap<String, Object>();
        String codeTrim = code.trim();
        List<Connector> connector = connectorService.findConnectorByCode(codeTrim);
        Connector findConnectorById = null;
        if (StringUtils.isNotBlank(id)) {
            findConnectorById = connectorService.findConnectorById(id);
        }
        if (!connector.isEmpty()) {
            result.put("flag", false);
            if (findConnectorById != null && codeTrim.equals(findConnectorById.getCode().trim())) {
                result.put("flag", true);
            }
        } else {
            result.put("flag", true);
        }
        return result;
    }

    @ResponseBody
    @RequestMapping({"/findConnectorCodes"})
    public Object findConnectorCodes(@RequestParam String key) {
        return autoQueryService.searchConnectorCodes(key);
    }

    @RequestMapping("/viewConnectorDetail")
    public String viewConnectorDetail(Model model, String id) {
        Connector connector = connectorService.findConnectorById(id);
        String txnCodes = connectorService.getTxnCodes(id);
        model.addAttribute("connector", connector);
        model.addAttribute("txnCodes", txnCodes);
        model.addAttribute("adapterList", connectorService.findAdapter(id));
        return "/config/viewConnectorDetail";
    }

    @RequestMapping(value = "isDeleteAdapter")
    @ResponseBody
    public Map<String, Object> isDeleteAdapter(Model model, String adapterId) {
        Map<String, Object> map = new HashMap<String, Object>();
        boolean message = connectorService.isDeleteAdapter(adapterId);
        map.put("message", message);
        return map;
    }

}
