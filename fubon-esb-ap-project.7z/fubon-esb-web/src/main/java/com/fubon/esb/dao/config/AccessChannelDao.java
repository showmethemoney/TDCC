package com.fubon.esb.dao.config;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.comwave.core.database.JPADaoSupport;
import com.comwave.core.database.Page;
import com.comwave.core.database.Query;
import com.fubon.esb.domain.config.AccessChannel;
import com.fubon.esb.domain.config.Channel;
import com.fubon.esb.domain.config.ConfigActiveStatus;

/**
 * @author Shelly
 * @createdDate 2014-10-30
 */
@Repository
public class AccessChannelDao extends JPADaoSupport<AccessChannel> {

    public List<AccessChannel> findLatestAccessChannels(String code, String name, ConfigActiveStatus status, Page page) {
        Query query = Query.from(AccessChannel.class).append(" ac where not exists(select t from ").append(AccessChannel.class).append(" t where t.mainId=ac.id) ");
        if (StringUtils.isNotBlank(code)) {
            query.append(" and ac.code = :code ");
            query.setParam("code", code.trim());
        }
        if (StringUtils.isNotBlank(name)) {
            query.append(" and ac.name like :name");
            query.setParam("name", "%" + name + "%");
        }
        // if (status == null) {
        // query.append(" and ac.status != :status ");
        // query.setParam("status", ConfigActiveStatus.D);
        // }
        if (status != null) {
            query.append(" and ac.status = :status ");
            query.setParam("status", status);
        }
        query.orderBy("createdTime").page(page);
        return jpaAccess.findPage(query);
    }

    public AccessChannel getAccessChannelById(String id) {
        return jpaAccess.get(AccessChannel.class, id);
    }

    public void deleteAccessChannelById(String id) {
        AccessChannel accessChannel = jpaAccess.get(AccessChannel.class, id);
        if (accessChannel != null)
            jpaAccess.delete(accessChannel);
    }

    public List<AccessChannel> findMainAccessChannels(String accessChannelCode, Page page) {
        Query query = Query.from(AccessChannel.class).append(" ac where ac.mainId is null and ac.status = :status ").param("status", ConfigActiveStatus.A);
        if (StringUtils.isNotBlank(accessChannelCode)) {
            query.append(" and ac.code = :code ");
            query.setParam("code", accessChannelCode.trim());
        }
        query.orderBy("ac.code").page(page);
        return jpaAccess.findPage(query);
    }

    public boolean isDuplicatedByCode(String code) {
        Query query =
                Query.from(AccessChannel.class).append(" ac where not exists(select t from ").append(AccessChannel.class).append(" t where t.mainId=ac.id) ").append(" and ac.code=:code")
                        .param("code", code).append(" and ac.status != :status").param("status", ConfigActiveStatus.D);
        return !jpaAccess.find(query).isEmpty();

    }

    public List<String> searchAccessChannelCodes(String key) {
        Query query = Query.create("select distinct code from " + AccessChannel.class.getName() + " accessChannel");
        query.append(" where not exists(select ac from ").append(AccessChannel.class).append(" ac where ac.mainId = accessChannel.id)");
        query.append(" and code like :code").param("code", key + "%");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    public List<String> searchMainAccessChannelCodes(String key) {
        Query query = Query.create("select distinct code from " + AccessChannel.class.getName());
        query.where(" code like :code").param("code", key + "%");
        query.append(" and mainId is null");
        query.orderBy("code");
        return jpaAccess.find(query);
    }

    // 更新狀態
    public void updateStatus(String id) {
        AccessChannel accessChannel = jpaAccess.get(AccessChannel.class, id);
        if (StringUtils.isNotBlank(accessChannel.getMainId()) && !"0".equals(accessChannel.getMainId())) { // 如果是帶有正本的副本
            jpaAccess.delete(accessChannel); // 刪掉副本
            jpaAccess.update(Query.create("update ").append(AccessChannel.class).append(" accessChannel set accessChannel.status = :status").param("status", ConfigActiveStatus.D)
                    .append(" where id = :id").param("id", accessChannel.getMainId()));
        } else {
            jpaAccess.update(Query.create("update ").append(AccessChannel.class).append(" accessChannel set accessChannel.status = :status").param("status", ConfigActiveStatus.D)
                    .append(" where id = :id").param("id", id));
        }
    }

    // 刪除時判斷是否有被設置為相關設定(關聯AccessChannel)
    public List<Channel> isRelatedAccessChannel(String id) {
        Query query = Query.create("select channel  from " + Channel.class.getName() + " channel");
        query.append(" where channel.accessChannelId = :accessChannelId ").param("accessChannelId", id);
        return jpaAccess.find(query);
    }
}
