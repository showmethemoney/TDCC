package com.fubon.esb.domain.log;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

/**
 * 系統日誌
 * 
 * @author Robin
 * @createdDate Oct 23, 2014
 */
@Entity(name = "SYS_LOG")
public class OperationLog {

    // private static final ResourceBundle RB = ResourceBundle.getBundle("appSetting", Locale.getDefault(), OperationLog.class.getClassLoader());

    /** 日志級別 : DEBUG */
    public static final String LEVEL_DEBUG = "DEBUG";

    /** 日志級別 : INFO */
    public static final String LEVEL_INFO = "INFO";

    /** 日志級別 : WARN */
    public static final String LEVEL_WARN = "WARN";

    /** 日志級別 : ERROR */
    public static final String LEVEL_ERROR = "ERROR";

    /** 主鍵 */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "paymentableGenerator")
    @GenericGenerator(name = "paymentableGenerator", strategy = "identity")
    private BigInteger id;

    /** 功能類別 */
    @Column(name = "MODULE")
    private String module;

    /** 功能 */
    @Column(name = "FUCTION")
    private String function;

    /** 日志級別:DEBUG/INFO/WARN/ERROR */
    @Column(name = "LEVEL")
    private String level;

    /** 日志消息 */
    @Column(name = "MESSAGE")
    private String message;

    /** 操作者 */
    @Column(name = "OP_USER")
    private String opUser;

    /** 操作時間 */
    @Column(name = "OP_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date opTime;

    // /** 功能類別名稱 */
    // @Transient
    // private String moduleName;
    //
    // /** 功能名稱 */
    // @Transient
    // private String functionName;

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getModule() {
        return module;

    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getOpUser() {
        return opUser;
    }

    public void setOpUser(String opUser) {
        this.opUser = opUser;
    }

    public Date getOpTime() {
        return opTime;
    }

    public void setOpTime(Date opTime) {
        this.opTime = opTime;
    }

    // public String getModuleName() {
    // return getText(module);
    // }
    //
    // public String getFunctionName() {
    // String functionName = getText(function);
    // if (StringUtils.isNotBlank(functionName)) {
    // return " - " + functionName;
    // }
    // return functionName;
    // }
    //
    // private String getText(String key) {
    // if (StringUtils.isBlank(key)) {
    // return null;
    // }
    // try {
    // return RB.getString(key);
    // } catch (Exception e) {
    // return null;
    // }
    // }

}
