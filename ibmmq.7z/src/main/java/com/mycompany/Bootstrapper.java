package com.mycompany;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mycompany.config.IBMMessageQueueConfig;
import com.mycompany.mq.MessageSender;


public class Bootstrapper
{
	protected static final Logger logger = LoggerFactory.getLogger( Bootstrapper.class );

	public static void main(String[] args) {
		try {
			ApplicationContext context = new AnnotationConfigApplicationContext( IBMMessageQueueConfig.class );

			MessageSender sender = (MessageSender) context.getBean( "messageSender" );

			while (true) {
				long timeInMillis = Calendar.getInstance().getTimeInMillis();
				logger.info( "will send : {}", timeInMillis );
				sender.send( Long.toString( timeInMillis ) );
				Thread.sleep( 10 * 1000 );
			}
		} catch (Throwable cause) {
			logger.error( cause.getMessage(), cause );
		}
	}
}
