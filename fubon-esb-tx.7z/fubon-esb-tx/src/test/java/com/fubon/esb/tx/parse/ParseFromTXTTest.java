package com.fubon.esb.tx.parse;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Mar 4, 2015
 */
public class ParseFromTXTTest {

    private ParseFromTXT parseFromTXT = new ParseFromTXT();

    @Test
    public void testParse() throws Exception {
        String directionDefStr =
                "<?xml version = \"1.0\" encoding = \"UTF-8\"?>\r\n"
                        + "<DirectionDef Direction = \"U\" xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition ../../../../SharedResources/Schemas/Txn/TxnDefinition.xsd\">\r\n"
                        + "    <HeaderDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H1</Name>\r\n" + "            <CName>H1</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>10</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H2</Name>\r\n" + "            <CName>H2</CName>\r\n" + "            <Type>9</Type>\r\n"
                        + "            <Length>2</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n"
                        + "            <Default>0</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H3</Name>\r\n" + "            <CName>-Zs_Extend_BH3</CName>\r\n" + "            <Type>H</Type>\r\n"
                        + "            <Length>1</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar> </PadChar>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H4</Name>\r\n" + "            <CName>H4</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>5</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default>0001</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H5</Name>\r\n" + "            <CName>H5</CName>\r\n" + "            <Type>H</Type>\r\n"
                        + "            <Length>1</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar> </PadChar>\r\n"
                        + "            <Default>0x43</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>false</Optional>\r\n"
                        + "        </FieldDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H6</Name>\r\n" + "            <CName>H6</CName>\r\n"
                        + "            <Type>9</Type>\r\n" + "            <Length>1</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n"
                        + "            <PadChar>0</PadChar>\r\n" + "            <Default>GetSetting('BodyLength')</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n"
                        + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n" + "    </HeaderDef>\r\n" + "    <BodyDef>\r\n" + "        <FieldDef Type = \"F\">\r\n"
                        + "            <Name>L11</Name>\r\n" + "            <CName>L11</CName>\r\n" + "            <Type>9</Type>\r\n" + "            <Length>10</Length>\r\n"
                        + "            <Scale>2</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n" + "            <Default>0</Default>\r\n"
                        + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"R\" Value = \"1\">\r\n" + "            <FieldDef Type = \"F\">\r\n" + "                <Name>L21</Name>\r\n"
                        + "                <CName>L21</CName>\r\n" + "                <Type>X</Type>\r\n" + "                <Length>10</Length>\r\n" + "                <Scale>0</Scale>\r\n"
                        + "                <Justify>L</Justify>\r\n" + "                <PadChar/>\r\n" + "                <Default> </Default>\r\n"
                        + "                <IncludeChinese>true</IncludeChinese>\r\n" + "                <Optional>true</Optional>\r\n" + "            </FieldDef>\r\n"
                        + "            <FieldDef Type = \"F\">\r\n" + "                <Name>L22</Name>\r\n" + "                <CName>L22</CName>\r\n" + "                <Type>9</Type>\r\n"
                        + "                <Length>1</Length>\r\n" + "                <Scale>0</Scale>\r\n" + "                <Justify>R</Justify>\r\n" + "                <PadChar> </PadChar>\r\n"
                        + "                <Default> </Default>\r\n" + "                <IncludeChinese>true</IncludeChinese>\r\n" + "                <Optional>true</Optional>\r\n"
                        + "            </FieldDef>\r\n" + "            <FieldDef Type = \"R\" Value = \"L22\">\r\n" + "                <FieldDef Type = \"F\">\r\n"
                        + "                    <Name>L31</Name>\r\n" + "                    <CName>L31</CName>\r\n" + "                    <Type>X</Type>\r\n"
                        + "                    <Length>10</Length>\r\n" + "                    <Scale>0</Scale>\r\n" + "                    <Justify>L</Justify>\r\n"
                        + "                    <PadChar/>\r\n" + "                    <Default> </Default>\r\n" + "                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                    <Optional>true</Optional>\r\n" + "                </FieldDef>\r\n" + "                <FieldDef Type = \"R\" Value = \"2\">\r\n"
                        + "                    <FieldDef Type = \"F\">\r\n" + "                        <Name>L41</Name>\r\n" + "                        <CName>L41</CName>\r\n"
                        + "                        <Type>X</Type>\r\n" + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n"
                        + "                        <Justify>L</Justify>\r\n" + "                        <PadChar/>\r\n" + "                        <Default> </Default>\r\n"
                        + "                        <IncludeChinese>true</IncludeChinese>\r\n" + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n"
                        + "                    <FieldDef Type = \"F\">\r\n" + "                        <Name>L42</Name>\r\n" + "                        <CName>L42</CName>\r\n"
                        + "                        <Type>X</Type>\r\n" + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n"
                        + "                        <Justify>L</Justify>\r\n" + "                        <PadChar/>\r\n" + "                        <Default> </Default>\r\n"
                        + "                        <IncludeChinese>true</IncludeChinese>\r\n" + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n"
                        + "                </FieldDef>\r\n" + "                <FieldDef Type = \"F\">\r\n" + "                    <Name>L32</Name>\r\n" + "                    <CName>L32</CName>\r\n"
                        + "                    <Type>X</Type>\r\n" + "                    <Length>10</Length>\r\n" + "                    <Scale>0</Scale>\r\n"
                        + "                    <Justify>L</Justify>\r\n" + "                    <PadChar/>\r\n" + "                    <Default> </Default>\r\n"
                        + "                    <IncludeChinese>true</IncludeChinese>\r\n" + "                    <Optional>true</Optional>\r\n" + "                </FieldDef>\r\n"
                        + "            </FieldDef>\r\n" + "            <FieldDef Type = \"F\">\r\n" + "                <Name>L23</Name>\r\n" + "                <CName>L23</CName>\r\n"
                        + "                <Type>X</Type>\r\n" + "                <Length>10</Length>\r\n" + "                <Scale>0</Scale>\r\n" + "                <Justify>L</Justify>\r\n"
                        + "                <PadChar/>\r\n" + "                <Default> </Default>\r\n" + "                <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                <Optional>true</Optional>\r\n" + "            </FieldDef>\r\n" + "        </FieldDef>\r\n" + "        <FieldDef Type = \"F\">\r\n"
                        + "            <Name>L12</Name>\r\n" + "            <CName>L12</CName>\r\n" + "            <Type>9</Type>\r\n" + "            <Length>10</Length>\r\n"
                        + "            <Scale>2</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n" + "            <Default>0</Default>\r\n"
                        + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Field = \"H4\" Type = \"S\">\r\n" + "            <FieldDef Type = \"C\" Value = \"0001\">\r\n" + "                <FieldDef Type = \"F\">\r\n"
                        + "                    <Name>L221</Name>\r\n" + "                    <CName>L221</CName>\r\n" + "                    <Type>X</Type>\r\n"
                        + "                    <Length>10</Length>\r\n" + "                    <Scale>0</Scale>\r\n" + "                    <Justify>L</Justify>\r\n"
                        + "                    <PadChar/>\r\n" + "                    <Default> </Default>\r\n" + "                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                    <Optional>true</Optional>\r\n" + "                </FieldDef>\r\n" + "                <FieldDef Type = \"R\" Value = \"2\">\r\n"
                        + "                    <FieldDef Type = \"F\">\r\n" + "                        <Name>L321</Name>\r\n" + "                        <CName>L321</CName>\r\n"
                        + "                        <Type>X</Type>\r\n" + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n"
                        + "                        <Justify>L</Justify>\r\n" + "                        <PadChar/>\r\n" + "                        <Default> </Default>\r\n"
                        + "                        <IncludeChinese>true</IncludeChinese>\r\n" + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n"
                        + "                </FieldDef>\r\n" + "            </FieldDef>\r\n" + "            <FieldDef Type = \"C\" Value = \"0002\">\r\n"
                        + "                <FieldDef Type = \"R\" Value = \"2\">\r\n" + "                    <FieldDef Type = \"F\">\r\n" + "                        <Name>L221</Name>\r\n"
                        + "                        <CName>L221</CName>\r\n" + "                        <Type>X</Type>\r\n" + "                        <Length>10</Length>\r\n"
                        + "                        <Scale>0</Scale>\r\n" + "                        <Justify>L</Justify>\r\n" + "                        <PadChar/>\r\n"
                        + "                        <Default> </Default>\r\n" + "                        <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n" + "                    <FieldDef Type = \"F\">\r\n"
                        + "                        <Name>L222</Name>\r\n" + "                        <CName>L222</CName>\r\n" + "                        <Type>9</Type>\r\n"
                        + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n" + "                        <Justify>R</Justify>\r\n"
                        + "                        <PadChar>0</PadChar>\r\n" + "                        <Default>0</Default>\r\n" + "                        <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n" + "                    <FieldDef Type = \"R\" Value = \"L222\">\r\n"
                        + "                        <FieldDef Type = \"F\">\r\n" + "                            <Name>L321</Name>\r\n" + "                            <CName>L321</CName>\r\n"
                        + "                            <Type>X</Type>\r\n" + "                            <Length>10</Length>\r\n" + "                            <Scale>0</Scale>\r\n"
                        + "                            <Justify>L</Justify>\r\n" + "                            <PadChar/>\r\n" + "                            <Default> </Default>\r\n"
                        + "                            <IncludeChinese>true</IncludeChinese>\r\n" + "                            <Optional>true</Optional>\r\n"
                        + "                        </FieldDef>\r\n" + "                        <FieldDef Type = \"F\">\r\n" + "                            <Name>L322</Name>\r\n"
                        + "                            <CName>L322</CName>\r\n" + "                            <Type>X</Type>\r\n" + "                            <Length>10</Length>\r\n"
                        + "                            <Scale>0</Scale>\r\n" + "                            <Justify>L</Justify>\r\n" + "                            <PadChar/>\r\n"
                        + "                            <Default> </Default>\r\n" + "                            <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                            <Optional>true</Optional>\r\n" + "                        </FieldDef>\r\n" + "                    </FieldDef>\r\n"
                        + "                </FieldDef>\r\n" + "            </FieldDef>\r\n" + "        </FieldDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>L13</Name>\r\n"
                        + "            <CName>L13</CName>\r\n" + "            <Type>9</Type>\r\n" + "            <Length>10</Length>\r\n" + "            <Scale>2</Scale>\r\n"
                        + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n" + "            <Default>0</Default>\r\n"
                        + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"R\" Value = \"1\">\r\n" + "            <FieldDef Type = \"F\">\r\n" + "                <Name>L24</Name>\r\n"
                        + "                <CName>L24</CName>\r\n" + "                <Type>X</Type>\r\n" + "                <Length>10</Length>\r\n" + "                <Scale>0</Scale>\r\n"
                        + "                <Justify>L</Justify>\r\n" + "                <PadChar/>\r\n" + "                <Default> </Default>\r\n"
                        + "                <IncludeChinese>true</IncludeChinese>\r\n" + "                <Optional>true</Optional>\r\n" + "            </FieldDef>\r\n"
                        + "            <FieldDef Type = \"R\" Value = \"2\">\r\n" + "                <FieldDef Type = \"F\">\r\n" + "                    <Name>L324</Name>\r\n"
                        + "                    <CName>L324</CName>\r\n" + "                    <Type>X</Type>\r\n" + "                    <Length>10</Length>\r\n"
                        + "                    <Scale>0</Scale>\r\n" + "                    <Justify>L</Justify>\r\n" + "                    <PadChar/>\r\n"
                        + "                    <Default> </Default>\r\n" + "                    <IncludeChinese>true</IncludeChinese>\r\n" + "                    <Optional>true</Optional>\r\n"
                        + "                </FieldDef>\r\n" + "            </FieldDef>\r\n" + "        </FieldDef>\r\n" + "    </BodyDef>\r\n" + "</DirectionDef>";

        String txtString =
                "5648312020202020202032304D3030303220433031312E323030303030305632312020202020202032563331202020202020205634312D3120202020205634322D3120202020205634312D3220202020205634322D322020202020563332202020202020205633312D3220202020205634312D3320202020205634322D3320202020205634312D3420202020205634322D3420202020205633322D3220202020205632332020202020202031322E323030303030305632323120202020202030303030303030303032563332312D3120202020563332322D3120202020563332312D3220202020563332322D3220202020563232312D322020202030303030303030303032563332312D3320202020563332322D3320202020563332312D3420202020563332322D342020202031332E3230303030303056323420202020202020563332342D3120202020563332342D3220202020";

        String encoding = "Big5";

        String result = parseFromTXT.parse(directionDefStr, txtString, false, "", "", encoding);
        System.out.println(result);

        String expected =
                "@@<?xml version = \"1.0\" encoding = \"UTF-8\"?><TxnData xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnData\"><Header><Field Type=\"F\"><Name>H1</Name><Value>VH1</Value></Field><Field Type=\"F\"><Name>H2</Name><Value>20</Value></Field><Field Type=\"F\"><Name>H3</Name><Value>0X4D</Value></Field><Field Type=\"F\"><Name>H4</Name><Value>0002</Value></Field><Field Type=\"F\"><Name>H5</Name><Value>0X43</Value></Field><Field Type=\"F\"><Name>H6</Name><Value>0</Value></Field></Header><Body><Field Type=\"F\"><Name>L11</Name><Value>11.2000000</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L21</Name><Value>V21</Value></Field><Field Type=\"F\"><Name>L22</Name><Value>2</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L31</Name><Value>V31</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L41</Name><Value>V41-1</Value></Field><Field Type=\"F\"><Name>L42</Name><Value>V42-1</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L41</Name><Value>V41-2</Value></Field><Field Type=\"F\"><Name>L42</Name><Value>V42-2</Value></Field></Field><Field Type=\"F\"><Name>L32</Name><Value>V32</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L31</Name><Value>V31-2</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L41</Name><Value>V41-3</Value></Field><Field Type=\"F\"><Name>L42</Name><Value>V42-3</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L41</Name><Value>V41-4</Value></Field><Field Type=\"F\"><Name>L42</Name><Value>V42-4</Value></Field></Field><Field Type=\"F\"><Name>L32</Name><Value>V32-2</Value></Field></Field><Field Type=\"F\"><Name>L23</Name><Value>V23</Value></Field></Field><Field Type=\"F\"><Name>L12</Name><Value>12.2000000</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L221</Name><Value>V221</Value></Field><Field Type=\"F\"><Name>L222</Name><Value>2</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L321</Name><Value>V321-1</Value></Field><Field Type=\"F\"><Name>L322</Name><Value>V322-1</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L321</Name><Value>V321-2</Value></Field><Field Type=\"F\"><Name>L322</Name><Value>V322-2</Value></Field></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L221</Name><Value>V221-2</Value></Field><Field Type=\"F\"><Name>L222</Name><Value>2</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L321</Name><Value>V321-3</Value></Field><Field Type=\"F\"><Name>L322</Name><Value>V322-3</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L321</Name><Value>V321-4</Value></Field><Field Type=\"F\"><Name>L322</Name><Value>V322-4</Value></Field></Field></Field><Field Type=\"F\"><Name>L13</Name><Value>13.2000000</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L24</Name><Value>V24</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L324</Name><Value>V324-1</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L324</Name><Value>V324-2</Value></Field></Field></Field></Body></TxnData>";
        Assert.assertEquals(expected, result);
    }

    @Test
    public void testParseNoCaseForSwitch() throws Exception {
        String directionDefStr =
                "<?xml version = \"1.0\" encoding = \"UTF-8\"?>\r\n"
                        + "<DirectionDef Direction = \"U\" xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition ../../../../SharedResources/Schemas/Txn/TxnDefinition.xsd\">\r\n"
                        + "    <HeaderDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H1</Name>\r\n" + "            <CName>H1</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>10</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H2</Name>\r\n" + "            <CName>H2</CName>\r\n" + "            <Type>9</Type>\r\n"
                        + "            <Length>2</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n"
                        + "            <Default>0</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H3</Name>\r\n" + "            <CName>-Zs_Extend_BH3</CName>\r\n" + "            <Type>H</Type>\r\n"
                        + "            <Length>1</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar> </PadChar>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H4</Name>\r\n" + "            <CName>H4</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>5</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default>0001</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "    </HeaderDef>\r\n" + "    <BodyDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>L11</Name>\r\n" + "            <CName>L11</CName>\r\n"
                        + "            <Type>9</Type>\r\n" + "            <Length>10</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>R</Justify>\r\n"
                        + "            <PadChar>0</PadChar>\r\n" + "            <Default>0</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n"
                        + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n" + "        <FieldDef Type = \"R\" Value = \"1\">\r\n" + "            <FieldDef Type = \"F\">\r\n"
                        + "                <Name>L21</Name>\r\n" + "                <CName>L21</CName>\r\n" + "                <Type>X</Type>\r\n" + "                <Length>10</Length>\r\n"
                        + "                <Scale>0</Scale>\r\n" + "                <Justify>L</Justify>\r\n" + "                <PadChar/>\r\n" + "                <Default> </Default>\r\n"
                        + "                <IncludeChinese>true</IncludeChinese>\r\n" + "                <Optional>true</Optional>\r\n" + "            </FieldDef>\r\n"
                        + "            <FieldDef Field = \"H4\" Type = \"S\">\r\n" + "                <FieldDef Type = \"C\" Value = \"0001\">\r\n" + "                    <FieldDef Type = \"F\">\r\n"
                        + "                        <Name>L221</Name>\r\n" + "                        <CName>L221</CName>\r\n" + "                        <Type>X</Type>\r\n"
                        + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n" + "                        <Justify>L</Justify>\r\n"
                        + "                        <PadChar/>\r\n" + "                        <Default> </Default>\r\n" + "                        <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n" + "                    <FieldDef Type = \"R\" Value = \"2\">\r\n"
                        + "                        <FieldDef Type = \"F\">\r\n" + "                            <Name>L321</Name>\r\n" + "                            <CName>L321</CName>\r\n"
                        + "                            <Type>X</Type>\r\n" + "                            <Length>10</Length>\r\n" + "                            <Scale>0</Scale>\r\n"
                        + "                            <Justify>L</Justify>\r\n" + "                            <PadChar/>\r\n" + "                            <Default> </Default>\r\n"
                        + "                            <IncludeChinese>true</IncludeChinese>\r\n" + "                            <Optional>true</Optional>\r\n"
                        + "                        </FieldDef>\r\n" + "                    </FieldDef>\r\n" + "                </FieldDef>\r\n"
                        + "                <FieldDef Type = \"C\" Value = \"0002\">\r\n" + "                    <FieldDef Field = \"L11\" Type = \"S\">\r\n"
                        + "                        <FieldDef Type = \"C\" Value = \"2\">\r\n" + "                            <FieldDef Type = \"R\" Value = \"L11\">\r\n"
                        + "                                <FieldDef Type = \"F\">\r\n" + "                                    <Name>L221</Name>\r\n"
                        + "                                    <CName>L221</CName>\r\n" + "                                    <Type>X</Type>\r\n"
                        + "                                    <Length>10</Length>\r\n" + "                                    <Scale>0</Scale>\r\n"
                        + "                                    <Justify>L</Justify>\r\n" + "                                    <PadChar/>\r\n"
                        + "                                    <Default> </Default>\r\n" + "                                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                                    <Optional>true</Optional>\r\n" + "                                </FieldDef>\r\n"
                        + "                                <FieldDef Type = \"F\">\r\n" + "                                    <Name>L222</Name>\r\n"
                        + "                                    <CName>L222</CName>\r\n" + "                                    <Type>X</Type>\r\n"
                        + "                                    <Length>10</Length>\r\n" + "                                    <Scale>0</Scale>\r\n"
                        + "                                    <Justify>R</Justify>\r\n" + "                                    <PadChar>0</PadChar>\r\n"
                        + "                                    <Default>0</Default>\r\n" + "                                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                                    <Optional>true</Optional>\r\n" + "                                </FieldDef>\r\n" + "                            </FieldDef>\r\n"
                        + "                        </FieldDef>\r\n" + "                        <FieldDef Type = \"C\" Value = \"21\">\r\n" + "                            <FieldDef Type = \"F\">\r\n"
                        + "                                <Name>L325</Name>\r\n" + "                                <CName>L325</CName>\r\n" + "                                <Type>X</Type>\r\n"
                        + "                                <Length>10</Length>\r\n" + "                                <Scale>0</Scale>\r\n"
                        + "                                <Justify>L</Justify>\r\n" + "                                <PadChar/>\r\n" + "                                <Default> </Default>\r\n"
                        + "                                <IncludeChinese>true</IncludeChinese>\r\n" + "                                <Optional>true</Optional>\r\n"
                        + "                            </FieldDef>\r\n" + "                        </FieldDef>\r\n" + "                    </FieldDef>\r\n" + "                </FieldDef>\r\n"
                        + "            </FieldDef>\r\n" + "        </FieldDef>\r\n" + "    </BodyDef>\r\n" + "</DirectionDef>";

        String txtString = "5648312020202020202032304D30303032203030303030303030303356323120202020202020563232312D312020202030303030563232322D31";

        String encoding = "Big5";

        String result = parseFromTXT.parse(directionDefStr, txtString, false, "", "", encoding);
        System.out.println(result);

        String expected = "##S302##case definition for switch value (3) not found";
        Assert.assertEquals(expected, result);
    }

    @Test
    public void testParseNestedSwitch() throws Exception {
        String directionDefStr =
                "<?xml version = \"1.0\" encoding = \"UTF-8\"?>\r\n"
                        + "<DirectionDef Direction = \"U\" xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation = \"http://fubon.com.tw/XSD/ESB/Txn/TxnDefinition ../../../../SharedResources/Schemas/Txn/TxnDefinition.xsd\">\r\n"
                        + "    <HeaderDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H1</Name>\r\n" + "            <CName>H1</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>10</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H2</Name>\r\n" + "            <CName>H2</CName>\r\n" + "            <Type>9</Type>\r\n"
                        + "            <Length>2</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar>0</PadChar>\r\n"
                        + "            <Default>0</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H3</Name>\r\n" + "            <CName>-Zs_Extend_BH3</CName>\r\n" + "            <Type>H</Type>\r\n"
                        + "            <Length>1</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar> </PadChar>\r\n"
                        + "            <Default> </Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "        <FieldDef Type = \"F\">\r\n" + "            <Name>H4</Name>\r\n" + "            <CName>H4</CName>\r\n" + "            <Type>X</Type>\r\n"
                        + "            <Length>5</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>L</Justify>\r\n" + "            <PadChar/>\r\n"
                        + "            <Default>0001</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n" + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n"
                        + "    </HeaderDef>\r\n" + "    <BodyDef>\r\n" + "        <FieldDef Type = \"F\">\r\n" + "            <Name>L11</Name>\r\n" + "            <CName>L11</CName>\r\n"
                        + "            <Type>9</Type>\r\n" + "            <Length>10</Length>\r\n" + "            <Scale>0</Scale>\r\n" + "            <Justify>R</Justify>\r\n"
                        + "            <PadChar>0</PadChar>\r\n" + "            <Default>0</Default>\r\n" + "            <IncludeChinese>true</IncludeChinese>\r\n"
                        + "            <Optional>true</Optional>\r\n" + "        </FieldDef>\r\n" + "        <FieldDef Type = \"R\" Value = \"1\">\r\n" + "            <FieldDef Type = \"F\">\r\n"
                        + "                <Name>L21</Name>\r\n" + "                <CName>L21</CName>\r\n" + "                <Type>X</Type>\r\n" + "                <Length>10</Length>\r\n"
                        + "                <Scale>0</Scale>\r\n" + "                <Justify>L</Justify>\r\n" + "                <PadChar/>\r\n" + "                <Default> </Default>\r\n"
                        + "                <IncludeChinese>true</IncludeChinese>\r\n" + "                <Optional>true</Optional>\r\n" + "            </FieldDef>\r\n"
                        + "            <FieldDef Field = \"H4\" Type = \"S\">\r\n" + "                <FieldDef Type = \"C\" Value = \"0001\">\r\n" + "                    <FieldDef Type = \"F\">\r\n"
                        + "                        <Name>L221</Name>\r\n" + "                        <CName>L221</CName>\r\n" + "                        <Type>X</Type>\r\n"
                        + "                        <Length>10</Length>\r\n" + "                        <Scale>0</Scale>\r\n" + "                        <Justify>L</Justify>\r\n"
                        + "                        <PadChar/>\r\n" + "                        <Default> </Default>\r\n" + "                        <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                        <Optional>true</Optional>\r\n" + "                    </FieldDef>\r\n" + "                    <FieldDef Type = \"R\" Value = \"2\">\r\n"
                        + "                        <FieldDef Type = \"F\">\r\n" + "                            <Name>L321</Name>\r\n" + "                            <CName>L321</CName>\r\n"
                        + "                            <Type>X</Type>\r\n" + "                            <Length>10</Length>\r\n" + "                            <Scale>0</Scale>\r\n"
                        + "                            <Justify>L</Justify>\r\n" + "                            <PadChar/>\r\n" + "                            <Default> </Default>\r\n"
                        + "                            <IncludeChinese>true</IncludeChinese>\r\n" + "                            <Optional>true</Optional>\r\n"
                        + "                        </FieldDef>\r\n" + "                    </FieldDef>\r\n" + "                </FieldDef>\r\n"
                        + "                <FieldDef Type = \"C\" Value = \"0002\">\r\n" + "                    <FieldDef Field = \"L11\" Type = \"S\">\r\n"
                        + "                        <FieldDef Type = \"C\" Value = \"2\">\r\n" + "                            <FieldDef Type = \"R\" Value = \"L11\">\r\n"
                        + "                                <FieldDef Type = \"F\">\r\n" + "                                    <Name>L221</Name>\r\n"
                        + "                                    <CName>L221</CName>\r\n" + "                                    <Type>X</Type>\r\n"
                        + "                                    <Length>10</Length>\r\n" + "                                    <Scale>0</Scale>\r\n"
                        + "                                    <Justify>L</Justify>\r\n" + "                                    <PadChar/>\r\n"
                        + "                                    <Default> </Default>\r\n" + "                                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                                    <Optional>true</Optional>\r\n" + "                                </FieldDef>\r\n"
                        + "                                <FieldDef Type = \"F\">\r\n" + "                                    <Name>L222</Name>\r\n"
                        + "                                    <CName>L222</CName>\r\n" + "                                    <Type>X</Type>\r\n"
                        + "                                    <Length>10</Length>\r\n" + "                                    <Scale>0</Scale>\r\n"
                        + "                                    <Justify>R</Justify>\r\n" + "                                    <PadChar>0</PadChar>\r\n"
                        + "                                    <Default>0</Default>\r\n" + "                                    <IncludeChinese>true</IncludeChinese>\r\n"
                        + "                                    <Optional>true</Optional>\r\n" + "                                </FieldDef>\r\n" + "                            </FieldDef>\r\n"
                        + "                        </FieldDef>\r\n" + "                        <FieldDef Type = \"C\" Value = \"21\">\r\n" + "                            <FieldDef Type = \"F\">\r\n"
                        + "                                <Name>L325</Name>\r\n" + "                                <CName>L325</CName>\r\n" + "                                <Type>X</Type>\r\n"
                        + "                                <Length>10</Length>\r\n" + "                                <Scale>0</Scale>\r\n"
                        + "                                <Justify>L</Justify>\r\n" + "                                <PadChar/>\r\n" + "                                <Default> </Default>\r\n"
                        + "                                <IncludeChinese>true</IncludeChinese>\r\n" + "                                <Optional>true</Optional>\r\n"
                        + "                            </FieldDef>\r\n" + "                        </FieldDef>\r\n" + "                    </FieldDef>\r\n" + "                </FieldDef>\r\n"
                        + "            </FieldDef>\r\n" + "        </FieldDef>\r\n" + "    </BodyDef>\r\n" + "</DirectionDef>";

        String txtString = "5648312020202020202032304D30303032203030303030303030303256323120202020202020563232312D312020202030303030563232322D31";

        String encoding = "Big5";

        String result = parseFromTXT.parse(directionDefStr, txtString, false, "", "", encoding);
        System.out.println(result);

        String expected =
                "@@<?xml version = \"1.0\" encoding = \"UTF-8\"?><TxnData xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnData\"><Header><Field Type=\"F\"><Name>H1</Name><Value>VH1</Value></Field><Field Type=\"F\"><Name>H2</Name><Value>20</Value></Field><Field Type=\"F\"><Name>H3</Name><Value>0X4D</Value></Field><Field Type=\"F\"><Name>H4</Name><Value>0002</Value></Field></Header><Body><Field Type=\"F\"><Name>L11</Name><Value>2</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L21</Name><Value>V21</Value></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L221</Name><Value>V221-1</Value></Field><Field Type=\"F\"><Name>L222</Name><Value>0000V222-1</Value></Field></Field><Field Type=\"R\"><Field Type=\"F\"><Name>L221</Name><Value></Value></Field><Field Type=\"F\"><Name>L222</Name><Value></Value></Field></Field></Field></Body></TxnData>";
        Assert.assertEquals(expected, result);
    }

}
