package com.fubon.esb.tx.util;

import org.junit.Test;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.Header;
import com.fubon.esb.tx.data.TxnData;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
public class XMLBinderTest {

    @Test
    public void testToXML() throws Exception {
        Field field = new Field();
        field.setType("R");

        Field sub1 = new Field();
        sub1.setType("F");
        sub1.setName("F1");
        sub1.setValue("V1");
        field.addField(sub1);

        Field sub2 = new Field();
        sub2.setType("F");
        sub2.setName("F2");
        field.addField(sub2);

        Field sub3 = new Field();
        sub3.setType("R");
        field.addField(sub3);

        sub3.addField(sub1);

        System.out.println(XMLBinder.toXML(field));

        TxnData txnData = new TxnData();
        Header header = new Header();
        header.addField(field);
        txnData.setHeader(header);

        System.out.println(XMLBinder.toXML(txnData));
    }

    @Test
    public void testFromXML() throws Exception {
        String xml =
                "<Field Type=\"R\"><Field Type=\"F\"><Name>F1</Name><Value>V1</Value></Field><Field Type=\"F\"><Name>F2</Name></Field><Field Type=\"R\"><Field Type=\"F\"><Name>F1</Name><Value>V1</Value></Field></Field></Field>";

        Field field = XMLBinder.fromXML(Field.class, xml, "UTF-8");

        System.out.println("type: " + field.getType() + ", size: " + field.getFields().size());
        Field field0 = field.getFields().get(0);
        System.out.println("sub type: " + field0.getType() + ", name: " + field0.getName() + ", value: " + field0.getValue() + ", size: " + field0.getFields().size());
        Field field1 = field.getFields().get(1);
        System.out.println("sub type: " + field1.getType() + ", name: " + field1.getName() + ", value: " + field1.getValue() + ", size: " + field1.getFields().size());

        Field field2 = field.getFields().get(2);
        System.out.println("sub type: " + field2.getType() + ", name: " + field2.getName() + ", value: " + field2.getValue() + ", size: " + field2.getFields().size());

        System.out.println(field2.getFields().get(0).getName());
    }

    @Test
    public void testFromXML2() throws Exception {
        String xml =
                "<?xml version = \"1.0\" encoding = \"UTF-8\"?>\r\n"
                        + "<TxnData xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation = \"http://fubon.com.tw/XSD/ESB/Txn/TxnData ../../../../SharedResources/Schemas/Txn/TxnData.xsd\">\r\n"
                        + "    <Header>\r\n" + "        <Field Type = \"F\">\r\n" + "            <Name>H1</Name>\r\n" + "            <Value>VH1</Value>\r\n" + "        </Field>\r\n"
                        + "        <Field Type = \"F\">\r\n" + "            <Name>H2</Name>\r\n" + "            <Value>20</Value>\r\n" + "        </Field>\r\n" + "        <Field Type = \"F\">\r\n"
                        + "            <Name>H3</Name>\r\n" + "            <Value>0X4D</Value>\r\n" + "        </Field>\r\n" + "        <Field Type = \"F\">\r\n" + "            <Name>H4</Name>\r\n"
                        + "            <Value>0002</Value>\r\n" + "        </Field>\r\n" + "    </Header>\r\n" + "    <Body>\r\n" + "        <Field Type = \"F\">\r\n"
                        + "            <Name>L11</Name>\r\n" + "            <Value>11.2000000</Value>\r\n" + "        </Field>\r\n" + "        <Field Type = \"R\">\r\n"
                        + "            <Field Type = \"F\">\r\n" + "                <Name>L21</Name>\r\n" + "                <Value>V21</Value>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"F\">\r\n" + "                <Name>L22</Name>\r\n" + "                <Value>2</Value>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L31</Name>\r\n"
                        + "                    <Value>V31</Value>\r\n" + "                </Field>\r\n" + "                <Field Type = \"R\">\r\n" + "                    <Field Type = \"F\">\r\n"
                        + "                        <Name>L41</Name>\r\n" + "                        <Value>V41-1</Value>\r\n" + "                    </Field>\r\n"
                        + "                    <Field Type = \"F\">\r\n" + "                        <Name>L42</Name>\r\n" + "                        <Value>V42-1</Value>\r\n"
                        + "                    </Field>\r\n" + "                </Field>\r\n" + "                <Field Type = \"R\">\r\n" + "                    <Field Type = \"F\">\r\n"
                        + "                        <Name>L41</Name>\r\n" + "                        <Value>V41-2</Value>\r\n" + "                    </Field>\r\n"
                        + "                    <Field Type = \"F\">\r\n" + "                        <Name>L42</Name>\r\n" + "                        <Value>V42-2</Value>\r\n"
                        + "                    </Field>\r\n" + "                </Field>\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L32</Name>\r\n"
                        + "                    <Value>V32</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n" + "            <Field Type = \"R\">\r\n"
                        + "                <Field Type = \"F\">\r\n" + "                    <Name>L31</Name>\r\n" + "                    <Value>V31-2</Value>\r\n" + "                </Field>\r\n"
                        + "                <Field Type = \"R\">\r\n" + "                    <Field Type = \"F\">\r\n" + "                        <Name>L41</Name>\r\n"
                        + "                        <Value>V41-3</Value>\r\n" + "                    </Field>\r\n" + "                    <Field Type = \"F\">\r\n"
                        + "                        <Name>L42</Name>\r\n" + "                        <Value>V42-3</Value>\r\n" + "                    </Field>\r\n" + "                </Field>\r\n"
                        + "                <Field Type = \"R\">\r\n" + "                    <Field Type = \"F\">\r\n" + "                        <Name>L41</Name>\r\n"
                        + "                        <Value>V41-4</Value>\r\n" + "                    </Field>\r\n" + "                    <Field Type = \"F\">\r\n"
                        + "                        <Name>L42</Name>\r\n" + "                        <Value>V42-4</Value>\r\n" + "                    </Field>\r\n" + "                </Field>\r\n"
                        + "                <Field Type = \"F\">\r\n" + "                    <Name>L32</Name>\r\n" + "                    <Value>V32-2</Value>\r\n" + "                </Field>\r\n"
                        + "            </Field>\r\n" + "            <Field Type = \"F\">\r\n" + "                <Name>L23</Name>\r\n" + "                <Value>V23</Value>\r\n"
                        + "            </Field>\r\n" + "        </Field>\r\n" + "        <Field Type = \"F\">\r\n" + "            <Name>L12</Name>\r\n" + "            <Value>12.2000000</Value>\r\n"
                        + "        </Field>\r\n" + "        <Field Type = \"R\">\r\n" + "            <Field Type = \"F\">\r\n" + "                <Name>L221</Name>\r\n"
                        + "                <Value>V221</Value>\r\n" + "            </Field>\r\n" + "            <Field Type = \"F\">\r\n" + "                <Name>L222</Name>\r\n"
                        + "                <Value>2</Value>\r\n" + "            </Field>\r\n" + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n"
                        + "                    <Name>L321</Name>\r\n" + "                    <Value>V321-1</Value>\r\n" + "                </Field>\r\n" + "                <Field Type = \"F\">\r\n"
                        + "                    <Name>L322</Name>\r\n" + "                    <Value>V322-1</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L321</Name>\r\n"
                        + "                    <Value>V321-2</Value>\r\n" + "                </Field>\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L322</Name>\r\n"
                        + "                    <Value>V322-2</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n" + "        </Field>\r\n" + "        <Field Type = \"R\">\r\n"
                        + "            <Field Type = \"F\">\r\n" + "                <Name>L221</Name>\r\n" + "                <Value>V221-2</Value>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"F\">\r\n" + "                <Name>L222</Name>\r\n" + "                <Value>2</Value>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L321</Name>\r\n"
                        + "                    <Value>V321-3</Value>\r\n" + "                </Field>\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L322</Name>\r\n"
                        + "                    <Value>V322-3</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n" + "            <Field Type = \"R\">\r\n"
                        + "                <Field Type = \"F\">\r\n" + "                    <Name>L321</Name>\r\n" + "                    <Value>V321-4</Value>\r\n" + "                </Field>\r\n"
                        + "                <Field Type = \"F\">\r\n" + "                    <Name>L322</Name>\r\n" + "                    <Value>V322-4</Value>\r\n" + "                </Field>\r\n"
                        + "            </Field>\r\n" + "        </Field>\r\n" + "        <Field Type = \"F\">\r\n" + "            <Name>L13</Name>\r\n" + "            <Value>13.2000000</Value>\r\n"
                        + "        </Field>\r\n" + "        <Field Type = \"R\">\r\n" + "            <Field Type = \"F\">\r\n" + "                <Name>L24</Name>\r\n"
                        + "                <Value>V24</Value>\r\n" + "            </Field>\r\n" + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n"
                        + "                    <Name>L324</Name>\r\n" + "                    <Value>V324-1</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n"
                        + "            <Field Type = \"R\">\r\n" + "                <Field Type = \"F\">\r\n" + "                    <Name>L324</Name>\r\n"
                        + "                    <Value>V324-2</Value>\r\n" + "                </Field>\r\n" + "            </Field>\r\n" + "        </Field>\r\n" + "    </Body>\r\n" + "</TxnData>";

        TxnData txnData = XMLBinder.fromXML(TxnData.class, xml, "UTF-8");

        System.out.println(txnData.getHeader().getFields().size());
        System.out.println(txnData.getBody().getFields().size());
    }

    @Test
    public void testFromXML3() throws Exception {
        String xml =
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <TxnData xmlns:ns0=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\"><Header><Field Type=\"F\"><Name>HSYDAY</Name><Value>1040303</Value></Field><Field Type=\"F\"><Name>HSYTIME</Name><Value>143835</Value></Field><Field Type=\"F\"><Name>HRETRN</Name><Value/></Field><Field xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" Type=\"F\"><Name>HTXTID</Name><Value>EB012656</Value></Field><Field xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" Type=\"F\"><Name>HWSID</Name><Value>eBANK</Value></Field><Field xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" Type=\"F\"><Name>HTLID</Name><Value>2004011</Value></Field><Field xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" Type=\"F\"><Name>HSTANO</Name><Value>5078641</Value></Field><Field xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\" Type=\"F\"><Name>TXMSRN</Name><Value/></Field></Header><Body xmlns=\"http://fubon.com.tw/XSD/ESB/Txn/TxnData\"><Field Type=\"F\"><Name>FUNC</Name><Value>1</Value></Field><Field Type=\"F\"><Name>STR_DATE</Name><Value>20121120</Value></Field><Field Type=\"F\"><Name>END_DATE</Name><Value>20141119</Value></Field><Field Type=\"F\"><Name>BNK_COD</Name><Value/></Field><Field Type=\"F\"><Name>INT_CATG</Name><Value/></Field><Field Type=\"F\"><Name>INT_TYP</Name><Value>114</Value></Field></Body></TxnData>";

        TxnData txnData = XMLBinder.fromXML(TxnData.class, xml, "UTF-8");

        System.out.println(txnData.getHeader().getFields().size());
        System.out.println(txnData.getBody().getFields().size());
    }

}
