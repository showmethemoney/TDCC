package com.fubon.esb.tx.render.xml;

import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.DirectionDef;
import com.fubon.esb.tx.def.FieldDef;

/**
 * @author Robin
 * @createdDate Mar 5, 2015
 */
public class RenderBodyFields {

    private final RenderXMLField renderXMLField = new RenderXMLField();
 
    /* 
     * modified by Leo@Comwave 2015.08.31
     * 1. Add parameter "direcitonDef" and passed it to function - "render" and "renderFields". 
     * 2. ignore field rendering when CName of field starts with "-" (XML format only)
     * 
     * modified by Leo@Comwave 2015.10.15
     * 1. Add parameter directionDef.getBodyDef().getFieldDefs() and pass it to function "renderXMLField.render"
     * 
     */      
    public StringBuilder render(DirectionDef directionDef, List<Field> fields) {
        StringBuilder result = new StringBuilder();

        result.append("<TxBody>");

        result.append(renderFields(directionDef, fields, 2, null));

        result.append("</TxBody>");
        return result;
    }


    /* 
     * modified by Leo@Comwave 2015.09.21
     * 1. Add parameter "renderType" and passed it to function - "renderFields". 
     */      
    public StringBuilder render(DirectionDef directionDef, List<Field> fields, String renderType) {
        StringBuilder result = new StringBuilder();

        result.append("<TxBody>");

        result.append(renderFields(directionDef, fields, 2, renderType));

        result.append("</TxBody>");
        return result;
    }    
    
   
    
    
    private StringBuilder renderFields(DirectionDef directionDef, List<Field> fields, int level, String renderType) {
        StringBuilder result = new StringBuilder(128);
        //cancel indent function and makes level unused

        for (Field field : fields) {
        	if(directionDef.getDirectionAttr().equals("D")){
	        	List<FieldDef> fieldDefs = directionDef.getBodyDef().getFieldDefs();
	        	boolean ignore=false;
        
	        	ignore=checkShouldIgnoreTag(fieldDefs, field.getName());
	        	if(ignore==true)
	        		continue;
        	}
        	
        	
            if (Field.TYPE_R.equals(field.getType())) {
                result.append("<TxRepeat>");

                result.append(renderFields(directionDef, field.getFields(), level + 1, renderType));

                result.append("</TxRepeat>");

            } else {
                result.append(renderXMLField.render(directionDef.getBodyDef().getFieldDefs(), field, renderType));
            }
        }
        return result;
    }

    
    private boolean checkShouldIgnoreTag(List<FieldDef> fieldDefs, String fieldName){
        	boolean should_ignore=false;
    
        	for(int i=0; i<fieldDefs.size();i++){//if Cname field starts with '-', ignore this field definition	
        		FieldDef fieldDef=fieldDefs.get(i);

        		if(  (fieldDef.getName()!=null && fieldDef.getName().equals(fieldName)) && 
        			 (fieldDef.getCname()!=null && fieldDef.getCname().length()>0 && fieldDef.getCname().startsWith("-")) &&
        			 (fieldDef.getType()!=null && fieldDef.getTypeAttr().equals(FieldDef.TYPE_ATTR_F))){
        		    
        			should_ignore=true;
        		}
        		
        		if(should_ignore==false && fieldDef.getFieldDefs()!=null && fieldDef.getFieldDefs().size()>0)
        			should_ignore=checkShouldIgnoreTag(fieldDef.getFieldDefs(), fieldName);
        		
        		if(should_ignore==true)
        			break;
        	}
        	
        	return should_ignore;
    }
    
}
