package com.fubon.esb.tx.parse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.FieldUtils;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class ParseField {

    private final ParseFieldValue parseFieldValue = new ParseFieldValue();

    public List<Field> parse(List<FieldDef> fieldDefs, String txtString, String switchFieldValue, Integer repeatFieldValue, boolean topLevel, String encoding, TxnData parsedTxnData,
            String[] outTxtString, String parseType) {
        List<Field> result = new ArrayList<Field>();

        int loopCount = 1;
        if (repeatFieldValue != null)
            loopCount = repeatFieldValue;

        String remainTxtString = txtString;
        for (int i = 0; i < loopCount; i++) {
            List<Field> fields = parseFieldList(fieldDefs, remainTxtString, switchFieldValue, topLevel, encoding, parsedTxnData, outTxtString, parseType);
            remainTxtString = outTxtString[0];

            if (repeatFieldValue != null) {
                Field repeatField = new Field(Field.TYPE_R);
                repeatField.setFields(fields);
                result.add(repeatField);
            } else {
                result.addAll(fields);
            }
        }

        outTxtString[0] = remainTxtString;
        return result;
    }

    private List<Field> parseFieldList(List<FieldDef> fieldDefs, String txtString, String switchFieldValue, boolean topLevel, String encoding, TxnData parsedTxnData, String[] outTxtString, String parseType) {
        String remainTxtString = txtString;
        List<Field> sameLevelFields = new ArrayList<Field>();

        for (FieldDef fieldDef : fieldDefs) {
            List<Field> fields = parseField(fieldDef, remainTxtString, switchFieldValue, sameLevelFields, topLevel, encoding, parsedTxnData, outTxtString, parseType);
            remainTxtString = outTxtString[0];
            sameLevelFields.addAll(fields);
        }

        outTxtString[0] = remainTxtString;
        return sameLevelFields;
    }

    private List<Field> parseField(FieldDef fieldDef, String txtString, String switchFieldValue, List<Field> sameLevelFields, boolean topLevel, String encoding, TxnData parsedTxnData,
            String[] outTxtString, String parseType) {
        switch (fieldDef.getTypeAttr()) {
            case FieldDef.TYPE_ATTR_F:
                Field field = parseFieldValue.parse(fieldDef, txtString, encoding, outTxtString, parseType);
                if (topLevel)
                    parsedTxnData.getBody().addField(field);
                return Arrays.asList(field);

            case FieldDef.TYPE_ATTR_R:
                Integer repeatValue = getRepeatFieldValue(fieldDef, sameLevelFields, parsedTxnData);
                return parse(fieldDef.getFieldDefs(), txtString, null, repeatValue, false, encoding, parsedTxnData, outTxtString, parseType);

            case FieldDef.TYPE_ATTR_S:
                String switchValue = getSwitchFieldValue(fieldDef, sameLevelFields, parsedTxnData);
                return parse(fieldDef.getFieldDefs(), txtString, switchValue, null, true, encoding, parsedTxnData, outTxtString, parseType);

            case FieldDef.TYPE_ATTR_C:
                String caseValue = fieldDef.getValueAttr();
                if (switchFieldValue != null && caseValue != null && switchFieldValue.trim().equals(caseValue.trim())) {
                    return parse(fieldDef.getFieldDefs(), txtString, null, null, true, encoding, parsedTxnData, outTxtString, parseType);
                }
                break;

            default:
                break;
        }

        outTxtString[0] = txtString;
        return new ArrayList<Field>();
    }

    private String getSwitchFieldValue(FieldDef fieldDef, List<Field> sameLevelFields, TxnData parsedTxnData) {
        String fieldAttr = fieldDef.getFieldAttr();

        Field field = FieldUtils.getFieldByName(parsedTxnData.getHeader().getFields(), fieldAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(sameLevelFields, fieldAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(parsedTxnData.getBody().getFields(), fieldAttr);

        if (field == null || field.getValue() == null)
            throw new ParserException("S302", "can't find switch value for field name(" + fieldAttr + ")");

        boolean hit = false;
        for (FieldDef sub : fieldDef.getFieldDefs()) {
            if (sub.getValueAttr() != null && field.getValue().trim().equals(sub.getValueAttr().trim())) {
                hit = true;
                break;
            }
        }
        if (!hit)
            throw new ParserException("S302", "case definition for switch value (" + field.getValue() + ") not found");

        return field.getValue();
    }

    private Integer getRepeatFieldValue(FieldDef fieldDef, List<Field> sameLevelFields, TxnData parsedTxnData) {
        String valueAttr = fieldDef.getValueAttr();

        boolean continueFlag = false; // can be removed, just for PMD check
        try {
            return Integer.parseInt(valueAttr);
        } catch (Exception e) {
            continueFlag = true;
        }
        if (!continueFlag)
            return 1; // never hit

        Field field = FieldUtils.getFieldByName(sameLevelFields, valueAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(parsedTxnData.getHeader().getFields(), valueAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(parsedTxnData.getBody().getFields(), valueAttr);

        if (field == null || field.getValue() == null)
            return 1;

        try {
            return Integer.parseInt(field.getValue());
        } catch (Exception e) {
            return 1;
        }
    }

}
