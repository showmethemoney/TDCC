package com.fubon.esb.tx.def;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "BodyDef")
public class BodyDef implements Serializable {
	
    @XmlElement(name = "FieldDef")
    private List<FieldDef> fieldDefs = new ArrayList<FieldDef>();

    public List<FieldDef> getFieldDefs() {
        return fieldDefs;
    }

    public void setFieldDefs(List<FieldDef> fieldDefs) {
        this.fieldDefs = fieldDefs;
    }

}
