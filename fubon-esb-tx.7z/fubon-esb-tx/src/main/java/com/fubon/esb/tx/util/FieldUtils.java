package com.fubon.esb.tx.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fubon.esb.tx.data.Field;

/**
 * @author Robin
 * @createdDate Mar 4, 2015
 */
public class FieldUtils {

    public static Field getFieldByName(List<Field> fields, String name) {
        Field target = null;
        for (Field field : fields) {
            if (name.equals(field.getName())) {
                return field;
            }
        }
        return target;
    }

    public static List<Field> getRepeatChildren(List<Field> fields, int index) {
        int hit = 0;
        for (Field field : fields) {
            if (Field.TYPE_R.equals(field.getType())) {
                hit++;
                if (hit == index)
                    return field.getFields();
            }
        }
        return new ArrayList<Field>();
    }

    public static Map<String, Field> convert(List<Field> fields) {
        Map<String, Field> fieldMap = new HashMap<String, Field>();
        for (Field field : fields) {
            if (Field.TYPE_F.equals(field.getType()))
                fieldMap.put(field.getName(), field);
        }
        return fieldMap;
    }

}
