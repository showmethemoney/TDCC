package com.fubon.esb.tx.render.xml;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.regex.Pattern;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.HexUtils;

/**
 * @author Robin
 * @createdDate Mar 5, 2015
 * edit by Leo Chiu@Comwave 2015.09.21
 * Purpose: add overriding function-"render" and add a parameter "renderType" in order to fit different render type
 * 
 * edit by Leo Chiu@Comwave 2015.10.15
 * Purpose: add parameter DirectionDef and pass it to function "render"
 */
public class RenderXMLField {

    private final Pattern ampPattern = Pattern.compile("&");
    private final Pattern ltPattern = Pattern.compile("<");

    
    public StringBuilder render(List<FieldDef> fieldDefs, Field field, String renderType){
        StringBuilder result = new StringBuilder(64);

        String value = field.getValue();
        
        if(renderType!=null && renderType.toUpperCase().contains(FieldDef.ParseChineseWith0E0F)){
	        	if (value == null) 
		            value = "";
		        else {
		        	value = value.replaceAll("&amp;", "&");			//replace &amp;	with &
		        }
        }else{
		        if (value == null) 
		            value = "";
		        else {
		            value = ampPattern.matcher(value).replaceAll("&amp;");
		            value = ltPattern.matcher(value).replaceAll("&lt;");
		        }
	    }
	                      	
        if(renderType!= null && renderType.toUpperCase().contains(FieldDef.TrimAndPad)) {        
	        String padChar="";
	        int padCount=0;
	        FieldDef fd=retrieveFieldDef(fieldDefs, field);
	        
	        if(fd!=null && fd.getPadChar()!=null && fd.getPadChar().length()>0){
	    		padChar=fd.getPadChar();
	    		
	    		try{
	        		if(padChar.toUpperCase().startsWith("0X"))
	        			padChar=new String( HexUtils.hexToBytes(padChar.substring(2)), "cp950");
	        		
	        		if(fd.getLength()!=null)
	        			padCount=((fd.getLength()- value.getBytes("cp950").length) / padChar.getBytes("cp950").length);
	        		
	    		} catch (UnsupportedEncodingException e) {
	    			throw new IllegalArgumentException(e);
	    		}
	        }
	        String padValue="";
			for(int i=0;i<padCount;i++)
				padValue+=padChar;
			
	        if (fd!=null && fd.getJustify()!=null && fd.getJustify().equals(FieldDef.JUSTIFY_L))
	            value=value+padValue;
	        
	        if (fd!=null && fd.getJustify()!=null && fd.getJustify().equals(FieldDef.JUSTIFY_R))
	            value=padValue+value;
    	}
        
    
        if (value.isEmpty()) {      	
        	result.append("<").append(field.getName()).append("/>");
        } else {
            result.append("<").append(field.getName()).append(">");
            result.append(value);
            result.append("</").append(field.getName()).append(">");
        }
        
        return result;
    }


    public FieldDef retrieveFieldDef(List<FieldDef> fieldDefs, Field field){
    	if(fieldDefs==null || field==null)
    		return null;
    	
    	for(int i=0;i<fieldDefs.size();i++){
    		FieldDef fd=fieldDefs.get(i);
    		
    		if(fd.getFieldDefs()!=null && fd.getFieldDefs().size()>0){
    			FieldDef inner_fd=retrieveFieldDef(fd.getFieldDefs(), field);
    			
    			if(inner_fd!=null)
    				return inner_fd;
    		}
    		
    		if(fd.getName()!=null && field.getName()!=null && fd.getName().equals(field.getName()))
    			return fd;
    	}
    	
    	return null;
    }
    
    
    
    
    
}
