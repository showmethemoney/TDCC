package com.fubon.esb.tx.render.txt;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Hex;

/**
 * @author Ethan Lee
 * @version $2016年6月17日 上午11:36:18
 */
public class ReplaceXMLSpecialChar
{	
	static List<String> xmlSpecialChars = new ArrayList<String>();
	
	static {
		try {
			xmlSpecialChars.add( new String( Hex.decodeHex( "00".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "01".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "02".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "03".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "04".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "05".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "06".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "07".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "08".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "0B".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "0C".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "0E".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "0F".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "10".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "11".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "12".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "13".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "14".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "15".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "16".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "17".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "18".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "19".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1A".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1B".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1C".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1D".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1E".toCharArray() ), "utf-8" ) );
			xmlSpecialChars.add( new String( Hex.decodeHex( "1F".toCharArray() ), "utf-8" ) );
		} catch (Throwable cause) {
		}
	}
	
	public String replace(String xmlString) {
		String result = xmlString; 

		for(String xmlSpecialChar : xmlSpecialChars) {
			result = result.replaceAll( xmlSpecialChar, " " );
		}
		
		return result;
	}
}
