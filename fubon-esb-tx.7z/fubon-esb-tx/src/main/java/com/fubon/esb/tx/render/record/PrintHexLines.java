package com.fubon.esb.tx.render.record;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

import com.google.common.base.Splitter;


/**
 * @author Ethan Lee
 */
public class PrintHexLines
{
	public static final String NEW_LINE = "\r\n";
	public static final String HEX_CHAR_SPLITTER = " ";
	public static final String HEX_8_CHAR_SPLITTER = "-";
	public static final String NON_PRINTABLE_CHAR = ".";
	public static String MIN_CHAR_HEX = null;
	public static String MAX_CHAR_HEX = null;
	public static Map<String, String> PRINTABLE_CHAR_MAP = new HashMap<String, String>();

	interface EncodingCharacterTransform
	{
		String transform(String hexChar) throws Throwable;
	}

	class EBCDICCharacterTransform implements EncodingCharacterTransform
	{

		public String transform(String hexChar) {
			return PRINTABLE_CHAR_MAP.containsKey( hexChar ) ? PRINTABLE_CHAR_MAP.get( hexChar ) : NON_PRINTABLE_CHAR;
		}
	}

	class NonEBCDICCharacterTransform implements EncodingCharacterTransform
	{
		private Integer minCharHex = null;
		private Integer maxCharHex = null;
		private String encoding = null;

		public NonEBCDICCharacterTransform(String encoding) {
			try {
				this.minCharHex = hexToNumber( Hex.encodeHexString( MIN_CHAR_HEX.getBytes( encoding ) ) );
				this.maxCharHex = hexToNumber( Hex.encodeHexString( MAX_CHAR_HEX.getBytes( encoding ) ) );
				this.encoding = encoding;
			} catch (Throwable cause) {
				throw new RuntimeException( cause.getMessage(), cause );
			}
		}

		public String transform(String hexChar) throws Throwable {
			Integer hex = hexToNumber( hexChar );

			return (hex >= minCharHex) && (hex <= maxCharHex) ? new String( Hex.decodeHex( hexChar.toCharArray() ), encoding ) : NON_PRINTABLE_CHAR;
		}

		private Integer hexToNumber(String hex) {
			String uhex = hex.trim();

			if (uhex.startsWith( "0X" )) {
				uhex = uhex.substring( 2 );
			}

			return Integer.parseInt( uhex, 16 );
		}
	}

	public String transfer(String hexString, String encoding) throws Throwable {
		StringBuilder result = new StringBuilder();
		String hexChar = null;
		Iterator<String> hexRecords = Splitter.fixedLength( 32 ).split( hexString ).iterator();

		EncodingCharacterTransform transfer = null;
		if ("EBCDIC".equalsIgnoreCase( encoding ) || "CP937".equalsIgnoreCase( encoding )) {
			transfer = new EBCDICCharacterTransform();
		} else {
			transfer = new NonEBCDICCharacterTransform( encoding );
		}

		int rowIndex = 0;
		while (hexRecords.hasNext()) {
			StringBuilder charBuilder = new StringBuilder();
			StringBuilder hexBuilder = new StringBuilder();

			Iterator<String> hexChars = Splitter.fixedLength( 2 ).split( hexRecords.next() ).iterator();

			int i = 1;
			while (hexChars.hasNext()) {
				hexChar = hexChars.next().toUpperCase();
				charBuilder.append( transfer.transform( hexChar ) );
				hexBuilder.append( hexChar ).append( i == 8 ? HEX_8_CHAR_SPLITTER : hexChars.hasNext() ? HEX_CHAR_SPLITTER : "" );
				i++;
			}

			result.append( StringUtils.leftPad( Integer.toHexString( rowIndex * 16 ).toUpperCase(), 8, "0" ) ).append( " : " )
			        .append( StringUtils.rightPad( hexBuilder.toString(), 47, " " ) ).append( " : " ).append( charBuilder.toString() ).append( NEW_LINE );

			rowIndex++;
		}

		return result.toString();
	}

	static {
			try {
				MIN_CHAR_HEX = new String( Hex.decodeHex( Integer.toHexString( 32 ).toUpperCase().toCharArray() ), "UTF-8" );
				MAX_CHAR_HEX = new String( Hex.decodeHex( Integer.toHexString( 126 ).toUpperCase().toCharArray() ), "UTF-8" );
			} catch (Throwable cause) {
				throw new RuntimeException( cause.getMessage(), cause );
			}

			PRINTABLE_CHAR_MAP.put( "40", " " );
			PRINTABLE_CHAR_MAP.put( "5A", "!" );
			PRINTABLE_CHAR_MAP.put( "7F", "\"" );
			PRINTABLE_CHAR_MAP.put( "7B", "#" );
			PRINTABLE_CHAR_MAP.put( "5B", "$" );
			PRINTABLE_CHAR_MAP.put( "6C", "%" );
			PRINTABLE_CHAR_MAP.put( "50", "&" );
			PRINTABLE_CHAR_MAP.put( "7D", "'" );
			PRINTABLE_CHAR_MAP.put( "4D", "(" );
			PRINTABLE_CHAR_MAP.put( "5D", ")" );
			PRINTABLE_CHAR_MAP.put( "5C", "*" );
			PRINTABLE_CHAR_MAP.put( "4E", "+" );
			PRINTABLE_CHAR_MAP.put( "6B", "," );
			PRINTABLE_CHAR_MAP.put( "60", "-" );
			PRINTABLE_CHAR_MAP.put( "4B", "." );
			PRINTABLE_CHAR_MAP.put( "61", "/" );
			PRINTABLE_CHAR_MAP.put( "F0", "0" );
			PRINTABLE_CHAR_MAP.put( "F1", "1" );
			PRINTABLE_CHAR_MAP.put( "F2", "2" );
			PRINTABLE_CHAR_MAP.put( "F3", "3" );
			PRINTABLE_CHAR_MAP.put( "F4", "4" );
			PRINTABLE_CHAR_MAP.put( "F5", "5" );
			PRINTABLE_CHAR_MAP.put( "F6", "6" );
			PRINTABLE_CHAR_MAP.put( "F7", "7" );
			PRINTABLE_CHAR_MAP.put( "F8", "8" );
			PRINTABLE_CHAR_MAP.put( "F9", "9" );
			PRINTABLE_CHAR_MAP.put( "7A", ":" );
			PRINTABLE_CHAR_MAP.put( "5E", ";" );
			PRINTABLE_CHAR_MAP.put( "4C", "<" );
			PRINTABLE_CHAR_MAP.put( "7E", "=" );
			PRINTABLE_CHAR_MAP.put( "6E", ">" );
			PRINTABLE_CHAR_MAP.put( "6F", "?" );
			PRINTABLE_CHAR_MAP.put( "7C", "@" );
			PRINTABLE_CHAR_MAP.put( "C1", "A" );
			PRINTABLE_CHAR_MAP.put( "C2", "B" );
			PRINTABLE_CHAR_MAP.put( "C3", "C" );
			PRINTABLE_CHAR_MAP.put( "C4", "D" );
			PRINTABLE_CHAR_MAP.put( "C5", "E" );
			PRINTABLE_CHAR_MAP.put( "C6", "F" );
			PRINTABLE_CHAR_MAP.put( "C7", "G" );
			PRINTABLE_CHAR_MAP.put( "C8", "H" );
			PRINTABLE_CHAR_MAP.put( "C9", "I" );
			PRINTABLE_CHAR_MAP.put( "D1", "J" );
			PRINTABLE_CHAR_MAP.put( "D2", "K" );
			PRINTABLE_CHAR_MAP.put( "D3", "L" );
			PRINTABLE_CHAR_MAP.put( "D4", "M" );
			PRINTABLE_CHAR_MAP.put( "D5", "N" );
			PRINTABLE_CHAR_MAP.put( "D6", "O" );
			PRINTABLE_CHAR_MAP.put( "D7", "P" );
			PRINTABLE_CHAR_MAP.put( "D8", "Q" );
			PRINTABLE_CHAR_MAP.put( "D9", "R" );
			PRINTABLE_CHAR_MAP.put( "E2", "S" );
			PRINTABLE_CHAR_MAP.put( "E3", "T" );
			PRINTABLE_CHAR_MAP.put( "E4", "U" );
			PRINTABLE_CHAR_MAP.put( "E5", "V" );
			PRINTABLE_CHAR_MAP.put( "E6", "W" );
			PRINTABLE_CHAR_MAP.put( "E7", "X" );
			PRINTABLE_CHAR_MAP.put( "E8", "Y" );
			PRINTABLE_CHAR_MAP.put( "E9", "Z" );
			PRINTABLE_CHAR_MAP.put( "BA", "[" );
			PRINTABLE_CHAR_MAP.put( "E0", "\\" );
			PRINTABLE_CHAR_MAP.put( "BB", "]" );
			PRINTABLE_CHAR_MAP.put( "B0", "^" );
			PRINTABLE_CHAR_MAP.put( "6D", "_" );
			PRINTABLE_CHAR_MAP.put( "79", "`" );
			PRINTABLE_CHAR_MAP.put( "81", "a" );
			PRINTABLE_CHAR_MAP.put( "82", "b" );
			PRINTABLE_CHAR_MAP.put( "83", "c" );
			PRINTABLE_CHAR_MAP.put( "84", "d" );
			PRINTABLE_CHAR_MAP.put( "85", "e" );
			PRINTABLE_CHAR_MAP.put( "86", "f" );
			PRINTABLE_CHAR_MAP.put( "87", "g" );
			PRINTABLE_CHAR_MAP.put( "88", "h" );
			PRINTABLE_CHAR_MAP.put( "89", "i" );
			PRINTABLE_CHAR_MAP.put( "91", "j" );
			PRINTABLE_CHAR_MAP.put( "92", "k" );
			PRINTABLE_CHAR_MAP.put( "93", "l" );
			PRINTABLE_CHAR_MAP.put( "94", "m" );
			PRINTABLE_CHAR_MAP.put( "95", "n" );
			PRINTABLE_CHAR_MAP.put( "96", "o" );
			PRINTABLE_CHAR_MAP.put( "97", "p" );
			PRINTABLE_CHAR_MAP.put( "98", "q" );
			PRINTABLE_CHAR_MAP.put( "99", "r" );
			PRINTABLE_CHAR_MAP.put( "A2", "s" );
			PRINTABLE_CHAR_MAP.put( "A3", "t" );
			PRINTABLE_CHAR_MAP.put( "A4", "u" );
			PRINTABLE_CHAR_MAP.put( "A5", "v" );
			PRINTABLE_CHAR_MAP.put( "A6", "w" );
			PRINTABLE_CHAR_MAP.put( "A7", "x" );
			PRINTABLE_CHAR_MAP.put( "A8", "y" );
			PRINTABLE_CHAR_MAP.put( "A9", "z" );
			PRINTABLE_CHAR_MAP.put( "C0", "{" );
			PRINTABLE_CHAR_MAP.put( "4F", "|" );
			PRINTABLE_CHAR_MAP.put( "D0", "}" );
			PRINTABLE_CHAR_MAP.put( "A1", "~" );
		}
}