package com.fubon.esb.tx.validate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.HexUtils;

/**
 * @author Robin
 * @createdDate Mar 4, 2015
 * 
 * Modified by Leo Chiu@Comwave 2015.11.17
 * Content: Optional flag has been changed to determine whether or not to render txt string when XML tag is empty or not existed
 * 
 */
public class ValidateFieldValue {

    public List<ValidateMessage> validate(FieldDef fieldDef, Field field) {
        ValidateMessage validateMessage = validateField(fieldDef, field);
        if (validateMessage != null)
            return Arrays.asList(validateMessage);
        return new ArrayList<ValidateMessage>();
    }

    private ValidateMessage validateField(FieldDef fieldDef, Field field) {
        ValidateMessage validateMessage = validateType(fieldDef);
        if (validateMessage != null)
            return validateMessage;
        
        // cancel to validate Optional (this optinal flag has been changed to another function, no longer to use this validation)
        /*
        	validateMessage = validateOptional(fieldDef, field);
        	if (validateMessage != null || field == null || field.getValue() == null)
            	return validateMessage;
        */   	
        //
        switch (fieldDef.getType()) {
            case FieldDef.TYPE_H:
                return validateHexType(fieldDef, field);

            case FieldDef.TYPE_9:
                return validateNumberType(fieldDef, field);

            case FieldDef.TYPE_X:
                return validateStringType(fieldDef, field);

            default:
                break;
        }
        return null;
    }

    private ValidateMessage validateHexType(FieldDef fieldDef, Field field) {
               
        if(field==null || field.getValue()==null)
        	return null;
        
        int length = fieldDef.getLength();
        
        String value = field.getValue();
        int len = value.length();

        if (value.toUpperCase().startsWith("0X")) {
            len = (value.length() - 2) / 2;

            if (!validHexString(value.toUpperCase().substring(2)))
                return newValidateMessage(fieldDef, field, "U105", "Value (" + value + ") is not a valid hexadecimal number");
        }

        if (len > length && length > 0)
            return newValidateMessage(fieldDef, field, "U104", "Value (" + value + ") is too long, max length: " + length);
        return null;
    }

    private boolean validHexString(String hexString) {
        for (int i = 0, length = hexString.length(); i < length; i++) {
            if (!HexUtils.isHexDigit(hexString.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private ValidateMessage validateNumberType(FieldDef fieldDef, Field field) {
              
        if(field==null || field.getValue()==null)
        	return null;
        
        String value = field.getValue();
        
        try {
            BigDecimal bd = new BigDecimal(value);
            bd = bd.setScale(fieldDef.getScale(), RoundingMode.HALF_UP);

            if (bd.toString().length() > fieldDef.getLength() && fieldDef.getLength() > 0)
                return newValidateMessage(fieldDef, field, "U104", "Value (" + value + ") is too long, max length: " + fieldDef.getLength());
        } catch (Exception e) {
            return newValidateMessage(fieldDef, field, "U106", "Value (" + value + ") is not a number");
        }
        return null;
    }

    private ValidateMessage validateStringType(FieldDef fieldDef, Field field) {        
        if(field==null || field.getValue()==null)
        	return null;
        
        Integer length = fieldDef.getLength();
        
        String value = field.getValue();
        if (value.length() > length && length > 0)
            return newValidateMessage(fieldDef, field, "U104", "Value (" + value + ") is too long, max length: " + length);
        return null;
    }

    private ValidateMessage validateOptional(FieldDef fieldDef, Field field) {
        if ((field == null || field.getValue() == null) && Boolean.FALSE.equals(fieldDef.getOptional()))
            return newValidateMessage(fieldDef, field, "U102", "Value of (" + fieldDef.getName() + ") not found");
        return null;
    }

    private ValidateMessage validateType(FieldDef fieldDef) {
        boolean supported = false;
        switch (fieldDef.getType()) {
            case FieldDef.TYPE_H:
            case FieldDef.TYPE_9:
            case FieldDef.TYPE_X:
                supported = true;
                break;

            default:
                supported = false;
        }

        if (!supported)
            return newValidateMessage(fieldDef, null, "U103", "Type (" + fieldDef.getType() + ") not supported");
        return null;
    }

    private ValidateMessage newValidateMessage(FieldDef fieldDef, Field field, String errorCode, String errorMessage) {
        ValidateMessage validateMessage = new ValidateMessage();
        validateMessage.setFieldName(fieldDef.getName());
        validateMessage.setFieldValue(field == null ? null : field.getValue());
        validateMessage.setErrorCode(errorCode);
        validateMessage.setErrorMessage(errorMessage);
        return validateMessage;
    }

}
