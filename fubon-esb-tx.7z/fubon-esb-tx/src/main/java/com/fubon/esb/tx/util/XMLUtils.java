package com.fubon.esb.tx.util;

import java.util.regex.Pattern;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class XMLUtils {

    private static Pattern xmlStartTagPattern = Pattern.compile("<[^/> ]+:");
    private static Pattern xmlEndTagPattern = Pattern.compile("</[^>]+:");

    // TODO can be refined
    public static String removeNamespace(String xml) {
        String result = xmlStartTagPattern.matcher(xml).replaceAll("<");
        return xmlEndTagPattern.matcher(result).replaceAll("</");
    }

}
