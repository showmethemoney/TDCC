package com.fubon.esb.tx.parse;

import java.math.BigDecimal;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.HexUtils;
import com.fubon.esb.tx.util.UnicodeHandler;

/**
 * @createdDate Mar 4, 2015
 */
/* updated by Leo@comwave Jul 22, 2015
 * Modify function-"decodeHex" to add unicodeHandler
 * 
 * updated by Leo@comwave Sep 18, 2015
 * Modify function-"decodeHex" to add remedyChineseWith0E0F   (replace 0x0E and 0x0F with "&#xE;" and "&#xF;")
 * Modify function-"parseValue" to add condition-"renderType(ParseChineseWith0E0F)" which will remain all space without trim
 *
 */

public class ParseFieldValue {

    public Field parse(FieldDef fieldDef, String txtString, String encoding, String[] outTxtString, String parseType) {
        if (txtString == null || txtString.isEmpty()) {
            outTxtString[0] = txtString;
            return new Field(Field.TYPE_F, fieldDef.getName(), "");
        }

        int length = fieldDef.getLength() * 2;
        int txtLength = txtString.length();
        length = (length > txtLength) ? txtLength : length;
        length = (length == 0) ? txtLength : length;

        String hexValue = txtString.substring(0, length);
        if (length < txtLength)
            outTxtString[0] = txtString.substring(length);
        else
            outTxtString[0] = "";

        String value = parseValue(fieldDef, hexValue, encoding, parseType);

        return new Field(Field.TYPE_F, fieldDef.getName(), value == null ? "" : value);
    }

    private String parseValue(FieldDef fieldDef, String hexValue, String encoding, String parseType) {
        switch (fieldDef.getType()) {
            case FieldDef.TYPE_H:
                return "0X" + hexValue;

            case FieldDef.TYPE_9:
                String num = decodeHex(hexValue, encoding, parseType);
                return new BigDecimal(num).toString();

            case FieldDef.TYPE_X:
                String value = decodeHex(hexValue, encoding, parseType);
                
                if(parseType!=null && encoding.toUpperCase().equals("CP937") && parseType.contains(FieldDef.ParseChineseWith0E0F)){
    	    		return value;
    	    	
                }else if (fieldDef.getPadChar() != null && !fieldDef.getPadChar().isEmpty()) {
                    if (value.trim().isEmpty())
                        return "";
                    return value;
                } else {
                    return value.trim();
                }

            default:
                break;
        }
        return null;
    }

    private String decodeHex(String hexValue, String encoding, String parseType) {
    	String tmpHexValue=hexValue;
    	String resultStr="";
    	
    	if(parseType!=null)
    		parseType=parseType.toUpperCase();
    	
        try{
	    	if(parseType!=null && encoding.toUpperCase().equals("CP937") && parseType.contains(FieldDef.ParseChineseWithSpace)){
		    	tmpHexValue=remedyChineseHex(hexValue);		    	
	    	}else if(parseType!=null && encoding.toUpperCase().equals("CP937") && parseType.contains(FieldDef.ParseChineseWith0E0F)){
	    		tmpHexValue=remedyChineseWith0E0F(hexValue);
	    	}
	    	
	    	if(parseType!=null && encoding.toUpperCase().equals("CP937") && parseType.contains(FieldDef.UnicodeData)){
		    	String encoding_file="";
		    	int pos = parseType.lastIndexOf("_");
		    	if (pos > 0) {
		    	    encoding_file = parseType.substring(pos+1, parseType.length());
		    	}
		    	
		    	resultStr = UnicodeHandler.ebcdicHex_to_unicodeStr(tmpHexValue, null, encoding_file);
		    }else{

	    		byte[] bytes = HexUtils.hexToBytes(tmpHexValue);
	            resultStr= new String(bytes, encoding);
		    }
    	}catch (Exception e) {
    		throw new IllegalArgumentException(e);
    	}
    	
    	return resultStr;
    }
    

    private String remedyChineseHex(String hexValue){
    	StringBuffer sb=new StringBuffer();
    
    	for(int i=0;i<hexValue.length()/2;i++){
    		String tmp=hexValue.substring(i*2, i*2+2).toUpperCase();
    		if(tmp.equals("0E"))
    			sb.append("40"+tmp);
    		else if(tmp.equals("0F"))
    			sb.append(tmp+"40");
    		else
    			sb.append(tmp);
    	}
    	return sb.toString();
    }
    
    private String remedyChineseWith0E0F(String hexValue){
    	StringBuffer sb= new StringBuffer();
    	
    	for(int i=0;i<hexValue.length()/2;i++){
    		String tmp=hexValue.substring(i*2, i*2+2).toUpperCase();
    		if(tmp.equals("0E"))
    			sb.append("507BA7C55E"+tmp);	//replace 0x0E with &#xE; 
    		else if(tmp.equals("0F"))
    			sb.append(tmp+"507BA7C65E");	//replace 0x0F with &#xF;
    		else 
    			sb.append(tmp);			
    	}
    	return sb.toString();	
    	
    }
    
/*    
    public static void main(String[] args) {
    	ParseFieldValue pfv=new ParseFieldValue();
    	String temp=pfv.decodeHex("D7F0F0F0F0F1F0F4F0F6F2F5F1F5F4F2F4F5E3C2D26DC9E5D9F0F0E6F0F0F5F6F5F6F5F1F9F1F940404040404040404040404040404040404040404040404040404040404040404040404040404040F0F0F0F1404040404040F0F0F0F0F0F0F0F4F3F1F5F0F0F1404040E3D7F8F5F2F7F5F54040C4F0F0F140C340F0F04040400E64CB42E742E742E742E742E742E742E742E742E742E742E742E742E742E742E742E742E742E70FF140C1F1F0F3F3F7F7F9F9F240F2F0F0F2F2F1F1F5F7F8F2F5F1F0F0F0F6F0F1F1F0F4F1F1F0F1F1F0F2F0F3F2F5F0F2F1F0F5F0404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F0F8F8F1F0F040404040404040404040F0F3F2F54040F1F0F2F0F4F2F5F0F3F0F5F1F3404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F1F2F5F8F0F040404040404040404040F0F4F2F54040F1F0F2F0F5F2F7F0F3F2F1F3F4404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F1F6F3F5F0F040404040404040404040F0F5F2F74040F1F0F2F0F6F2F1F0F4F0F3F1F1404040404040400E4EB254C9404040400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F0F1F0F0F04EF0F0F0F0F0F0F1F1F6F4F5F0F040404040404040404040F0F6F2F14040F1F0F2F0F6F2F5F0F4F4F5F0F2404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F2F0F2F2F0F040404040404040404040F0F6F2F54040F1F0F2F0F7F2F5F0F4F1F7F2F7404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F2F3F9F9F0F040404040404040404040F0F7F2F54040F1F0F2F0F8F2F6F0F3F0F5F4F0404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F2F7F7F6F0F040404040404040404040F0F8F2F64040F1F0F2F0F9F2F5F0F3F4F1F2F2404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F3F1F5F3F0F040404040404040404040F0F9F2F54040F1F0F2F1F0F2F5F0F3F3F4F2F6404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F3F5F3F0F0F040404040404040404040F1F0F2F54040F1F0F2F1F1F2F5F0F2F1F9F3F1404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F3F9F0F7F0F040404040404040404040F1F1F2F54040F1F0F2F1F2F2F1F0F2F5F8F0F1404040404040400E4EB254C9404040400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F0F1F6F0F04EF0F0F0F0F0F0F1F3F9F2F3F0F040404040404040404040F1F2F2F34040F1F0F2F1F2F2F5F0F3F2F1F5F1404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F4F3F0F0F0F040404040404040404040F1F2F2F54040F1F0F3F0F1F2F7F0F5F5F3F0F9404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F4F6F7F7F0F040404040404040404040F0F1F2F74040F1F0F3F0F2F2F5F0F3F0F1F3F2404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F5F0F5F4F0F040404040404040404040F0F2F2F54040F1F0F3F0F3F2F5F0F3F2F9F5F8404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F5F4F3F1F0F040404040404040404040F0F3F2F54040F1F0F3F0F4F2F5F0F3F0F5F3F9404040404040400E509A4DF354C940400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F0F3F7F7F0F04EF0F0F0F0F0F0F1F5F8F0F8F0F040404040404040404040F0F4F2F54040F1F0F3F0F6F2F5F1F2F0F2F4F1404040404040400E65CA4E4D404040400FF7F3F5F2F2F1F0F3F0F15C5C40404040404EF0F0F0F0F0F0F0F0F1F0F0F0F0F04EF0F0F0F0F0F1F0F1F0F0F0F0F00E528F5149404040400FF0F6F2F54040F1F0F3F0F6F2F5F1F2F0F2F4F1404040404040400E58DF4CC454C963DB0F404EF0F0F0F0F0F0F0F0F0F0F0F1F0F0F1F0F3F0F6F1F160F1F0F3F0F6F1F1404EF0F0F0F0F0F1F0F0F9F9F9F0F00E528F5149404040400FF0F6F2F54040F1F0F3F0F6F2F5F1F4F1F0F4F6404040404040400E65CA4E4D404040400FF7F3F5F1F6F8F0F1F4F25C5C40404040404EF0F0F0F0F0F0F0F0F1F0F0F0F0F04EF0F0F0F0F0F1F0F1F9F9F9F0F00E528F5149404040400FF0F6F2F54040F1F0F3F0F6F2F5F1F5F1F8F1F2404040404040400E65CA4E4D404040400F40404040404040404040404040404040404EF0F0F0F0F0F0F0F0F5F0F0F0F0F04EF0F0F0F0F0F1F0F6F9F9F9F0F00E528F5149404040400FF0F6F2F54040", "CP937", "Parse_Chinese_With_Space");
    	
    	System.out.println( temp );
    	byte[] b = temp.getBytes();
    	System.out.println(HexUtils.bytesToHex(b));
    	
	}
*/    
      
    
}
