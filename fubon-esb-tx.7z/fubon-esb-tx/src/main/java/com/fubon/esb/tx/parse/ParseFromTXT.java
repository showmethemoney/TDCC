package com.fubon.esb.tx.parse;

import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.DirectionDef;
import com.fubon.esb.tx.util.XMLBinder;
import com.fubon.esb.tx.util.XMLUtils;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class ParseFromTXT {
    private static final String UTF_8 = "UTF-8";

    private static final String TXN_SPLIT = "@@";
    private static final String ERROR_SPLIT = "##";

    private final ParseField parseField = new ParseField();

    public String parse(String directionDefStr, String txtString, boolean onlyParseHeader, String bodyTxtString, String parsedTxnDataStr, String encoding) {
        DirectionDef directionDef = new DirectionDef();
        if (directionDefStr != null && !directionDefStr.isEmpty())
            directionDef = XMLBinder.fromXML(DirectionDef.class, XMLUtils.removeNamespace(directionDefStr), UTF_8);
        return parse(directionDef, txtString, onlyParseHeader, bodyTxtString, parsedTxnDataStr, encoding);
    }

    public String parse(DirectionDef directionDef, String txtString, boolean onlyParseHeader, String bodyTxtString, String parsedTxnDataStr, String encoding) {
        TxnData parsedTxnData = new TxnData();
        if (parsedTxnDataStr != null && !parsedTxnDataStr.isEmpty())
            parsedTxnData = XMLBinder.fromXML(TxnData.class, parsedTxnDataStr, UTF_8);

        try {
            return parse(directionDef, txtString, onlyParseHeader, bodyTxtString, parsedTxnData, encoding);
        } catch (ParserException e) {
            return ERROR_SPLIT + e.getCode() + ERROR_SPLIT + e.getMessage();
        } catch (Throwable cause) {
        	return cause.getMessage();
        }
    }

    public String parse(DirectionDef directionDef, String txtString, boolean onlyParseHeader, String bodyTxtString, TxnData parsedTxnData, String encoding) {
        String[] outTxtString = new String[] {null};
        String remainTxtString = bodyTxtString;
        // parse header
        if (parsedTxnData.getHeader().getFields().isEmpty()) {
        	System.out.println(parsedTxnData.getHeader().getFields().isEmpty());
            List<Field> headerFields = parseField.parse(directionDef.getHeaderDef().getFieldDefs(), txtString, null, null, false, encoding, null, outTxtString, null);
            remainTxtString = outTxtString[0];

            parsedTxnData.getHeader().setFields(headerFields);
            parsedTxnData.getBody().getFields().clear();
        }

        // only parse header
        if (onlyParseHeader || remainTxtString == null || remainTxtString.isEmpty())
            return composeResult(parsedTxnData, remainTxtString);

        // parse body
        List<Field> bodyFields = parseField.parse(directionDef.getBodyDef().getFieldDefs(), remainTxtString, null, null, true, encoding, parsedTxnData, outTxtString, null);
        parsedTxnData.getBody().setFields(bodyFields);

        remainTxtString = outTxtString[0];
        return composeResult(parsedTxnData, remainTxtString);
    }

    
    //override the original function, add one parameter to indicate whether to replace 0x0E and 0x0F with space
    
    public String parse(String directionDefStr, String txtString, boolean onlyParseHeader, String bodyTxtString, String parsedTxnDataStr, String encoding, String parseType) {
        DirectionDef directionDef = new DirectionDef();
        if (directionDefStr != null && !directionDefStr.isEmpty())
            directionDef = XMLBinder.fromXML(DirectionDef.class, XMLUtils.removeNamespace(directionDefStr), UTF_8);
        return parse(directionDef, txtString, onlyParseHeader, bodyTxtString, parsedTxnDataStr, encoding, parseType);
    }

    public String parse(DirectionDef directionDef, String txtString, boolean onlyParseHeader, String bodyTxtString, String parsedTxnDataStr, String encoding, String parseType) {
        TxnData parsedTxnData = new TxnData();
        if (parsedTxnDataStr != null && !parsedTxnDataStr.isEmpty())
            parsedTxnData = XMLBinder.fromXML(TxnData.class, parsedTxnDataStr, UTF_8);

        try {
            return parse(directionDef, txtString, onlyParseHeader, bodyTxtString, parsedTxnData, encoding, parseType);
        } catch (ParserException e) {
            return ERROR_SPLIT + e.getCode() + ERROR_SPLIT + e.getMessage();
        } catch (Throwable cause) {
        	return cause.getMessage();
        }
    }

    public String parse(DirectionDef directionDef, String txtString, boolean onlyParseHeader, String bodyTxtString, TxnData parsedTxnData, String encoding, String parseType) {
        String[] outTxtString = new String[] {null};
        String remainTxtString = bodyTxtString;
        // parse header
        if (parsedTxnData.getHeader().getFields().isEmpty()) {
        	System.out.println(parsedTxnData.getHeader().getFields().isEmpty());
            List<Field> headerFields = parseField.parse(directionDef.getHeaderDef().getFieldDefs(), txtString, null, null, false, encoding, null, outTxtString, parseType);
            remainTxtString = outTxtString[0];

            parsedTxnData.getHeader().setFields(headerFields);
            parsedTxnData.getBody().getFields().clear();
        }

        // only parse header
        if (onlyParseHeader || remainTxtString == null || remainTxtString.isEmpty())
            return composeResult(parsedTxnData, remainTxtString);

        // parse body
        List<Field> bodyFields = parseField.parse(directionDef.getBodyDef().getFieldDefs(), remainTxtString, null, null, true, encoding, parsedTxnData, outTxtString, parseType);
        parsedTxnData.getBody().setFields(bodyFields);

        remainTxtString = outTxtString[0];
        return composeResult(parsedTxnData, remainTxtString);
    }    
    
    
    
    
    
    private String composeResult(TxnData txnData, String remainTxtString) {
        String xml = toXML(txnData);
        return remainTxtString + TXN_SPLIT + xml;
    }

    private String toXML(TxnData txnData) {
        String xml = XMLBinder.toXML(txnData);
        return "<?xml version = \"1.0\" encoding = \"UTF-8\"?>" + xml.replaceFirst("<TxnData>", "<TxnData xmlns = \"http://fubon.com.tw/XSD/ESB/Txn/TxnData\">");
    }

}
