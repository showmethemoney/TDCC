package com.fubon.esb.tx.validate;

import java.util.ArrayList;
import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.FieldUtils;

/**
 * @author Robin
 * @createdDate Mar 4, 2015
 */
public class ValidateField {

    private final ValidateFieldValue validateFieldValue = new ValidateFieldValue();

    public List<ValidateMessage> validate(List<FieldDef> fieldDefs, List<Field> fields, TxnData txnData, boolean topLevel) {
        Integer[] outSwitchLevelRepeatIndex = new Integer[] {null};
        return validate(fieldDefs, fields, txnData, null, null, topLevel, outSwitchLevelRepeatIndex);
    }

    private List<ValidateMessage> validate(List<FieldDef> fieldDefs, List<Field> fields, TxnData txnData, String currentSwitchValue, Integer switchLevelRepeatIndex, boolean topLevel,
            Integer[] outSwitchLevelRepeatIndex) {
        List<ValidateMessage> validateMessages = new ArrayList<ValidateMessage>();

        int repeatIndex = 0;
        if (topLevel && switchLevelRepeatIndex != null)
            repeatIndex = switchLevelRepeatIndex;

        for (FieldDef fieldDef : fieldDefs) {
            if (FieldDef.TYPE_ATTR_R.equals(fieldDef.getTypeAttr())) {
                int repeatValue = getRepeatFieldValue(fieldDef.getValueAttr(), fields, txnData);

                for (int i = 1; i <= repeatValue; i++) {
                    List<Field> repeatChildren;
                    if (topLevel)
                        repeatChildren = FieldUtils.getRepeatChildren(fields, repeatIndex + i);
                    else
                        repeatChildren = FieldUtils.getRepeatChildren(fields, i);

                    validateMessages.addAll(validate(fieldDef, repeatChildren, txnData, null, null, outSwitchLevelRepeatIndex));
                }

                if (topLevel)
                    repeatIndex += repeatValue;

            } else {
                validateMessages.addAll(validate(fieldDef, fields, txnData, currentSwitchValue, switchLevelRepeatIndex, outSwitchLevelRepeatIndex));

                if (outSwitchLevelRepeatIndex[0] != null)
                    repeatIndex = outSwitchLevelRepeatIndex[0];
            }
        }

        outSwitchLevelRepeatIndex[0] = repeatIndex;
        return validateMessages;
    }

    private List<ValidateMessage> validate(FieldDef fieldDef, List<Field> fields, TxnData txnData, String currentSwitchValue, Integer switchLevelRepeatIndex, Integer[] outSwitchLevelRepeatIndex) {
        switch (fieldDef.getTypeAttr()) {
            case FieldDef.TYPE_ATTR_F:
                outSwitchLevelRepeatIndex[0] = null;
                return validateFieldValue.validate(fieldDef, FieldUtils.getFieldByName(fields, fieldDef.getName()));

            case FieldDef.TYPE_ATTR_R:
                return validate(fieldDef.getFieldDefs(), fields, txnData, null, null, false, outSwitchLevelRepeatIndex);

            case FieldDef.TYPE_ATTR_S:
                String switchValue = getSwitchFieldValue(fieldDef.getFieldAttr(), txnData);
                return validate(fieldDef.getFieldDefs(), fields, txnData, switchValue, switchLevelRepeatIndex, true, outSwitchLevelRepeatIndex);

            case FieldDef.TYPE_ATTR_C:
                String caseValue = fieldDef.getValueAttr();
                if (currentSwitchValue != null && caseValue != null && currentSwitchValue.trim().equals(caseValue.trim())) {
                    return validate(fieldDef.getFieldDefs(), fields, txnData, currentSwitchValue, switchLevelRepeatIndex, true, outSwitchLevelRepeatIndex);
                }
                break;

            default:
                break;
        }

        outSwitchLevelRepeatIndex[0] = null;
        return new ArrayList<ValidateMessage>();
    }

    private String getSwitchFieldValue(String fieldAttr, TxnData txnData) {
        Field field = FieldUtils.getFieldByName(txnData.getHeader().getFields(), fieldAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(txnData.getBody().getFields(), fieldAttr);

        if (field == null)
            return null;
        return field.getValue();
    }

    private int getRepeatFieldValue(String valueAttr, List<Field> fields, TxnData txnData) {
        boolean continueFlag = false; // can be removed, just for PMD check
        try {
            return Integer.parseInt(valueAttr);
        } catch (Exception e) {
            continueFlag = true;
        }
        if (!continueFlag)
            return 1; // never hit

        Field field = FieldUtils.getFieldByName(fields, valueAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(txnData.getHeader().getFields(), valueAttr);

        if (field == null || field.getValue() == null)
            return 1;

        try {
            return Integer.parseInt(field.getValue());
        } catch (Exception e) {
            return 1;
        }
    }

}
