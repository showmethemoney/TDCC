package com.fubon.esb.tx.def;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
/* updated by Leo@comwave Jul 22, 2015
 * Add static variable UnicodeData to identify if parser should follow unicode_mapping_files of ASTAR to do the transformation
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "FieldDef")
public class FieldDef implements Serializable {
	/* 
	 * RenderType 
	*/
    public static final String TrimAndPad = "TRIMANDPAD";  //TrimAndPad, : for transaction like CCSCORE which comes from AS400 as txt format and is going to trim and padding if padding char has been setup 
	public static final String ParseChineseWithSpace = "PARSE_CHINESE_WITH_SPACE";  //0x0E & 0x0F will be replaced with space
	public static final String ParseChineseWith0E0F = "PARSE_CHINESE_WITH_0E0F";   //0x0E & 0x0F will be replaced with "&#xE;" & "&#xF;"
	public static final String UnicodeData ="UNICODE";	// parse or render data using UNICODE (UCS2)
	
    public static final String TYPE_H = "H";
    public static final String TYPE_9 = "9";
    public static final String TYPE_X = "X";

    public static final String TYPE_ATTR_F = "F";
    public static final String TYPE_ATTR_R = "R";
    public static final String TYPE_ATTR_S = "S";
    public static final String TYPE_ATTR_C = "C";

    public static final String JUSTIFY_L = "L";
    public static final String JUSTIFY_R = "R";

    @XmlAttribute(name = "Type")
    private String typeAttr;

    @XmlAttribute(name = "Field")
    private String fieldAttr;

    @XmlAttribute(name = "Value")
    private String valueAttr;

    @XmlElement(name = "Name")
    private String name;

    @XmlElement(name = "CName")
    private String cname;

    @XmlElement(name = "Type")
    private String type;

    @XmlElement(name = "Length")
    private Integer length;

    @XmlElement(name = "Scale")
    private Integer scale;

    @XmlElement(name = "Justify")
    private String justify;

    @XmlElement(name = "PadChar")
    private String padChar;

    @XmlElement(name = "Default")
    private String defaultValue;

    @XmlElement(name = "IncludeChinese")
    private Boolean includeChinese;

    @XmlElement(name = "Optional")
    private Boolean optional;

    @XmlElement(name = "FieldDef")
    private List<FieldDef> fieldDefs = new ArrayList<FieldDef>();

    public String getTypeAttr() {
        return typeAttr;
    }

    public void setTypeAttr(String typeAttr) {
        this.typeAttr = typeAttr;
    }

    public String getFieldAttr() {
        return fieldAttr;
    }

    public void setFieldAttr(String fieldAttr) {
        this.fieldAttr = fieldAttr;
    }

    public String getValueAttr() {
        return valueAttr;
    }

    public void setValueAttr(String valueAttr) {
        this.valueAttr = valueAttr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getScale() {
        return scale;
    }

    public void setScale(Integer scale) {
        this.scale = scale;
    }

    public String getJustify() {
        return justify;
    }

    public void setJustify(String justify) {
        this.justify = justify;
    }

    public String getPadChar() {
        return padChar;
    }

    public void setPadChar(String padChar) {
        this.padChar = padChar;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Boolean getIncludeChinese() {
        return includeChinese;
    }

    public void setIncludeChinese(Boolean includeChinese) {
        this.includeChinese = includeChinese;
    }

    public Boolean getOptional() {
        return optional;
    }

    public void setOptional(Boolean optional) {
        this.optional = optional;
    }

    public List<FieldDef> getFieldDefs() {
        return fieldDefs;
    }

    public void setFieldDefs(List<FieldDef> fieldDefs) {
        this.fieldDefs = fieldDefs;
    }

}
