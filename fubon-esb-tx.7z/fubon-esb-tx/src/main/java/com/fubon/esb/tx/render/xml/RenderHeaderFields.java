package com.fubon.esb.tx.render.xml;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.DirectionDef;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.render.txt.CollectedValue;
import com.fubon.esb.tx.render.txt.RenderField;
import com.fubon.esb.tx.render.txt.RenderToTXT;
import com.fubon.esb.tx.util.FieldUtils;
import com.fubon.esb.tx.util.StringUtils;

/**
 * @author Robin
 * @createdDate Mar 5, 2015
 */

public class RenderHeaderFields {

    private static final String HDTLEN = "HDTLEN";

    private final RenderToTXT renderToTXT = new RenderToTXT();
    private final com.fubon.esb.tx.render.txt.RenderBodyFields renderBodyFields = new com.fubon.esb.tx.render.txt.RenderBodyFields();
    private final RenderField renderField = new RenderField();

    private final RenderXMLField renderXMLField = new RenderXMLField();

   
    public StringBuilder render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode) {
        List<FieldDef> fieldDefs = directionDef.getHeaderDef().getFieldDefs();
        Map<String, Field> fieldMap = FieldUtils.convert(txnData.getHeader().getFields());
        List<Field> allFields = new ArrayList<Field>();

        // compose default header value
        for (FieldDef fieldDef : fieldDefs) {     	
            Field field = fieldMap.get(fieldDef.getName());

            if (!(field != null && (StringUtils.notEmpty(field.getValue()) || StringUtils.isEmpty(fieldDef.getDefaultValue())))) {
                String defaultValue = renderField.calDefaultValue(fieldDef, toQueue, hostDriveQueue, tellerCode);
                field = new Field(Field.TYPE_F, fieldDef.getName(), defaultValue);
            }
            allFields.add(field);
        }

        // HDTLEN
        int bodyLength = 0;
        Field lenField = fieldMap.get(HDTLEN);
        if (lenField != null && StringUtils.notEmpty(lenField.getValue()))
            bodyLength = Integer.parseInt(lenField.getValue());
        else
            bodyLength = getBodyLength(directionDef, txnData, encoding);

        StringBuilder result = new StringBuilder(512);

        result.append("<TxHead>");
        result.append(renderFields(directionDef, allFields, bodyLength, null));
        result.append("</TxHead>");
        return result;
    }
    
    
    /*
     * edit by Leo Chiu@Comwave 2015.07.23
     * Purpose: add overriding function-"render" and add a parameter "transformTxId" in order to forcedly change TxID field
     * 
     */
    public StringBuilder render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId) {
        List<FieldDef> fieldDefs = directionDef.getHeaderDef().getFieldDefs();
        Map<String, Field> fieldMap = FieldUtils.convert(txnData.getHeader().getFields());
        List<Field> allFields = new ArrayList<Field>();

        // compose default header value
        for (FieldDef fieldDef : fieldDefs) {      	
            Field field = fieldMap.get(fieldDef.getName());
            
            //if transformId is set, forcedly change the txnId 
            if(field!=null && StringUtils.notEmpty(field.getValue()) && fieldDef.getName().equals("HTXTID") && transformTxId!=null && transformTxId.trim().length()>0)
            	field.setValue(transformTxId);
            
            if (!(field != null && (StringUtils.notEmpty(field.getValue()) || StringUtils.isEmpty(fieldDef.getDefaultValue())))) {
                String defaultValue = renderField.calDefaultValue(fieldDef, toQueue, hostDriveQueue, tellerCode);
                field = new Field(Field.TYPE_F, fieldDef.getName(), defaultValue);
            }
            allFields.add(field);
        }

        // HDTLEN
        int bodyLength = 0;
        Field lenField = fieldMap.get(HDTLEN);
        if (lenField != null && StringUtils.notEmpty(lenField.getValue()))
            bodyLength = Integer.parseInt(lenField.getValue());
        else
            bodyLength = getBodyLength(directionDef, txnData, encoding);

        StringBuilder result = new StringBuilder(512);

        result.append("<TxHead>");
        result.append(renderFields(directionDef, allFields, bodyLength, null));
        result.append("</TxHead>");
        return result;
    }
    

    /*
     * edit by Leo Chiu@Comwave 2015.09.21
     * Purpose: add overriding function-"render" and add a parameter "renderType" in order to fit different render type
     * 
     */
    public StringBuilder render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId, String renderType) {
        List<FieldDef> fieldDefs = directionDef.getHeaderDef().getFieldDefs();
        Map<String, Field> fieldMap = FieldUtils.convert(txnData.getHeader().getFields());
        List<Field> allFields = new ArrayList<Field>();

        // compose default header value
        for (FieldDef fieldDef : fieldDefs) {      	
            Field field = fieldMap.get(fieldDef.getName());
            
            //if transformId is set, forcedly change the txnId 
            if(field!=null && StringUtils.notEmpty(field.getValue()) && fieldDef.getName().equals("HTXTID") && transformTxId!=null && transformTxId.trim().length()>0)
            	field.setValue(transformTxId);
            
            if (!(field != null && (StringUtils.notEmpty(field.getValue()) || StringUtils.isEmpty(fieldDef.getDefaultValue())))) {
                String defaultValue = renderField.calDefaultValue(fieldDef, toQueue, hostDriveQueue, tellerCode);
                field = new Field(Field.TYPE_F, fieldDef.getName(), defaultValue);
            }
            allFields.add(field);
        }

        // HDTLEN
        int bodyLength = 0;
        Field lenField = fieldMap.get(HDTLEN);
        if (lenField != null && StringUtils.notEmpty(lenField.getValue()))
            bodyLength = Integer.parseInt(lenField.getValue());
        else
            bodyLength = getBodyLength(directionDef, txnData, encoding);

        StringBuilder result = new StringBuilder(512);

        result.append("<TxHead>");
        result.append(renderFields(directionDef, allFields, bodyLength, renderType));
        result.append("</TxHead>");
        return result;
    }    
    
    
    /* modified by Leo@Comwave 2015.10.15
     *  1. Add parameter "direcitonDef.getHeaderDef().getFieldDefs()" and passed it to function - "renderXMLFields.render". 
     *
     *
    */
    private StringBuilder renderFields(DirectionDef directionDef, List<Field> fields, int bodyLength, String renderType) {
        StringBuilder result = new StringBuilder();

        for (Field field : fields) {
            if (HDTLEN.equals(field.getName())) {
                String value = "0000" + bodyLength;
                field.setValue(value.substring(value.length() - 4));
            }

            result.append(renderXMLField.render(directionDef.getHeaderDef().getFieldDefs(), field, renderType)); 
        }
        return result;
    }

    private int getBodyLength(DirectionDef directionDef, TxnData txnData, String encoding) {
        List<CollectedValue> collectedBodyValues = renderBodyFields.render(directionDef.getBodyDef().getFieldDefs(), txnData);
        String bodyTx = renderToTXT.renderBody(collectedBodyValues, encoding, null);
        return bodyTx.length() / 2;
    }

}
