package com.fubon.esb.tx.render.txt;

import java.util.Date;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.DateUtils;


/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
/*
 * edit by Leo Chiu@Comwave 2015.07.23 Purpose: 1. rewrite original function-"renderHeaderField" and add a null parameter when calling renderField function 2.
 * add overriding function-"renderHeaderField" and add parameter "transformTxId" in order to forcedly change TxID field 3. rewrite function-"renderField" in
 * order to forcedly change field "txId" if transformTxId has value 4. rewrite function-"renderBodyField" and add a null parameter in order to fit the
 * renderField function
 * 
 */

public class RenderField
{

	public CollectedValue renderHeaderField(FieldDef fieldDef, Field field, String toQueue, String hostDriveQueue, String tellerCode) {
		String defaultValue = calDefaultValue( fieldDef, toQueue, hostDriveQueue, tellerCode );
		return renderField( fieldDef, field, defaultValue, null );
	}

	public CollectedValue renderHeaderField(FieldDef fieldDef, Field field, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId) {
		String defaultValue = calDefaultValue( fieldDef, toQueue, hostDriveQueue, tellerCode );
		return renderField( fieldDef, field, defaultValue, transformTxId );
	}

	public CollectedValue renderBodyField(FieldDef fieldDef, Field field) {
		return renderField( fieldDef, field, fieldDef.getDefaultValue(), null );
	}

	private CollectedValue renderField(FieldDef fieldDef, Field field, String defaultValue, String transformTxId) {
		CollectedValue collectedValue = new CollectedValue( fieldDef );

		if (field != null && field.getName() != null && field.getName().equals( "HTXTID" ) && transformTxId != null && transformTxId.trim().length() > 0) {
			collectedValue.setValue( transformTxId );
		} else if (field != null && field.getValue() != null && !field.getValue().isEmpty()) {
			collectedValue.setValue( field.getValue() );
		} else {
			collectedValue.setValue( defaultValue );
		}

		if (FieldDef.TYPE_H.equals( fieldDef.getType() )) {
			if ((field == null || field.getValue() == null) && (defaultValue != null && defaultValue.toUpperCase().startsWith( "0X" )))
				collectedValue.setHexValue( defaultValue );
			if (field != null && field.getValue() != null && field.getValue().toUpperCase().startsWith( "0X" ))
				collectedValue.setHexValue( field.getValue() );
		}
		return collectedValue;
	}

	public String calDefaultValue(FieldDef fieldDef, String toQueue, String hostDriveQueue, String tellerCode) {
		if ("HTLID".equalsIgnoreCase( fieldDef.getName() ))
			return tellerCode;

		switch (fieldDef.getDefaultValue()) {

		case "GetDateTime('rrrMMdd')":
		case "GetSoftwareDate()":
			String today = DateUtils.formatTWDate( new Date(), DateUtils.YYYYMMDD );
			return today.substring( 1 );

		case "GetDateTime('HHmmss')":
			return DateUtils.format( new Date(), DateUtils.HHmmss );

		case "GetSetting('ToQueue')":
			return toQueue;

		case "GetSetting('HostDriveQueue')":
			return hostDriveQueue;

		case "GetSetting('BodyLength')":
		case "GetTotalLength()-256":
			return "0";

		default:
			break;
		}
		return fieldDef.getDefaultValue();
	}
}
