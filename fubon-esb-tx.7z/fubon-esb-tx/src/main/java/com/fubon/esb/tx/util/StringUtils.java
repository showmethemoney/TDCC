package com.fubon.esb.tx.util;

/**
 * @author Robin
 * @createdDate Mar 5, 2015
 */
public class StringUtils {

    public static boolean notEmpty(String str) {
        return str != null && !str.isEmpty();
    }

    public static boolean isEmpty(String str) {
        return str == null || str.isEmpty();
    }

}
