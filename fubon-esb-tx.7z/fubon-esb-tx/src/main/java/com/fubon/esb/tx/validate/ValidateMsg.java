package com.fubon.esb.tx.validate;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Mar 4, 2015
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ValidateMsg")
public class ValidateMsg {

    @XmlElement(name = "Message")
    private List<ValidateMessage> validateMessages = new ArrayList<ValidateMessage>();

    public List<ValidateMessage> getValidateMessages() {
        return validateMessages;
    }

    public void setValidateMessages(List<ValidateMessage> validateMessages) {
        this.validateMessages = validateMessages;
    }

}
