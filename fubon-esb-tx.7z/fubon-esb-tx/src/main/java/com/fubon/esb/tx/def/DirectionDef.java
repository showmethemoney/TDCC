package com.fubon.esb.tx.def;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DirectionDef")
public class DirectionDef implements Serializable {

    @XmlAttribute(name = "Direction")
    private String directionAttr;

    @XmlAttribute(name = "Type")
    private String typeAttr;

    @XmlAttribute(name = "OutType")
    private String outTypeAttr;

    @XmlAttribute(name = "Encoding")
    private String encodingAttr;

    @XmlElement(name = "ID")
    private String id;

    @XmlElement(name = "Name")
    private String name;

    @XmlElement(name = "HeaderDef")
    private HeaderDef headerDef = new HeaderDef();

    @XmlElement(name = "BodyDef")
    private BodyDef bodyDef = new BodyDef();

    public String getDirectionAttr() {
        return directionAttr;
    }

    public void setDirectionAttr(String directionAttr) {
        this.directionAttr = directionAttr;
    }

    public String getTypeAttr() {
        return typeAttr;
    }

    public void setTypeAttr(String typeAttr) {
        this.typeAttr = typeAttr;
    }

    public String getOutTypeAttr() {
        return outTypeAttr;
    }

    public void setOutTypeAttr(String outTypeAttr) {
        this.outTypeAttr = outTypeAttr;
    }

    public String getEncodingAttr() {
        return encodingAttr;
    }

    public void setEncodingAttr(String encodingAttr) {
        this.encodingAttr = encodingAttr;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public HeaderDef getHeaderDef() {
        return headerDef;
    }

    public void setHeaderDef(HeaderDef headerDef) {
        this.headerDef = headerDef;
    }

    public BodyDef getBodyDef() {
        return bodyDef;
    }

    public void setBodyDef(BodyDef bodyDef) {
        this.bodyDef = bodyDef;
    }

}
