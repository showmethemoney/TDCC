package com.fubon.esb.tx.render.txt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.FieldUtils;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class RenderBodyFields {

    private final RenderField renderField = new RenderField();

    public List<CollectedValue> render(List<FieldDef> fieldDefs, TxnData txnData) {
        Integer[] outSwitchLevelRepeatIndex = new Integer[] {null};
        return renderFields(fieldDefs, txnData.getBody().getFields(), txnData, null, null, true, outSwitchLevelRepeatIndex);
    }

    public List<CollectedValue> renderFields(List<FieldDef> fieldDefs, List<Field> fields, TxnData txnData, String currentSwitchValue, Integer switchLevelRepeatIndex, boolean topLevel,
            Integer[] outSwitchLevelRepeatIndex) {
        List<CollectedValue> result = new ArrayList<CollectedValue>();

        int repeatIndex = 0;
        if (topLevel && switchLevelRepeatIndex != null)
            repeatIndex = switchLevelRepeatIndex;

        for (FieldDef fieldDef : fieldDefs) {
            if (FieldDef.TYPE_ATTR_R.equals(fieldDef.getTypeAttr())) {
                int repeatValue = getRepeatFieldValue(fieldDef.getValueAttr(), txnData, fields);

                for (int i = 1; i <= repeatValue; i++) {
                    List<Field> repeatChildren;
                    if (topLevel)
                        repeatChildren = FieldUtils.getRepeatChildren(fields, repeatIndex + i);
                    else
                        repeatChildren = FieldUtils.getRepeatChildren(fields, i);

                    result.addAll(renderField(fieldDef, repeatChildren, txnData, null, null, outSwitchLevelRepeatIndex));
                }

                if (topLevel)
                    repeatIndex += repeatValue;

            } else {
                result.addAll(renderField(fieldDef, fields, txnData, currentSwitchValue, repeatIndex, outSwitchLevelRepeatIndex));

                if (outSwitchLevelRepeatIndex[0] != null)
                    repeatIndex = outSwitchLevelRepeatIndex[0];
            }
        }

        outSwitchLevelRepeatIndex[0] = repeatIndex;
        return result;
    }

    private List<CollectedValue> renderField(FieldDef fieldDef, List<Field> fields, TxnData txnData, String currentSwitchValue, Integer switchLevelRepeatIndex, Integer[] outSwitchLevelRepeatIndex) {
        switch (fieldDef.getTypeAttr()) {
            case FieldDef.TYPE_ATTR_F:
                outSwitchLevelRepeatIndex[0] = null;
                return renderField(fieldDef, fields);

            case FieldDef.TYPE_ATTR_R:
                return renderFields(fieldDef.getFieldDefs(), fields, txnData, null, null, false, outSwitchLevelRepeatIndex);

            case FieldDef.TYPE_ATTR_S:
                String switchValue = getSwitchFieldValue(fieldDef.getFieldAttr(), txnData);
                return renderFields(fieldDef.getFieldDefs(), fields, txnData, switchValue, switchLevelRepeatIndex, true, outSwitchLevelRepeatIndex);

            case FieldDef.TYPE_ATTR_C:
                String caseValue = fieldDef.getValueAttr();
                if (currentSwitchValue != null && caseValue != null && currentSwitchValue.trim().equals(caseValue.trim())) {
                    return renderFields(fieldDef.getFieldDefs(), fields, txnData, null, switchLevelRepeatIndex, true, outSwitchLevelRepeatIndex);
                }
                break;

            default:
                break;
        }

        outSwitchLevelRepeatIndex[0] = null;
        return new ArrayList<CollectedValue>();
    }

    private List<CollectedValue> renderField(FieldDef fieldDef, List<Field> fields) {
        Field target = null;
        for (Field field : fields) {
            if (fieldDef.getName().equals(field.getName())) {
                target = field;
                break;
            }
        }

        CollectedValue collectedValue = renderField.renderBodyField(fieldDef, target);
        return Arrays.asList(collectedValue);
    }

    private int getRepeatFieldValue(String valueAttr, TxnData txnData, List<Field> sameLevelFields) {
        boolean continueFlag = false; // can be removed, just for PMD check
        try {
            return Integer.parseInt(valueAttr);
        } catch (Exception e) {
            continueFlag = true;
        }
        if (!continueFlag)
            return 1; // never hit

        Field field = FieldUtils.getFieldByName(sameLevelFields, valueAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(txnData.getHeader().getFields(), valueAttr);

        if (field == null || field.getValue() == null)
            return 1;

        try {
            return Integer.parseInt(field.getValue());
        } catch (Exception e) {
            return 1;
        }
    }

    private String getSwitchFieldValue(String fieldAttr, TxnData txnData) {
        Field field = FieldUtils.getFieldByName(txnData.getHeader().getFields(), fieldAttr);
        if (field == null)
            field = FieldUtils.getFieldByName(txnData.getBody().getFields(), fieldAttr);

        if (field == null)
            return null;
        return field.getValue();
    }

}
