package com.fubon.esb.tx.render.xml;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.fubon.esb.tx.data.Body;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.DirectionDef;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.XMLBinder;
import com.fubon.esb.tx.util.XMLUtils;


/**
 * @author Robin
 * @createdDate Mar 5, 2015
 */
public class RenderToXML
{
	private static final String UTF_8 = "UTF-8";
	private final Pattern ampPattern = Pattern.compile( "&" );

	private final RenderHeaderFields renderHeaderFields = new RenderHeaderFields();
	private final RenderBodyFields renderBodyFields = new RenderBodyFields();

	public String render(String directionDefStr, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode)
	        throws Exception {
		DirectionDef directionDef = new DirectionDef();
		if (directionDefStr != null && !directionDefStr.isEmpty())
			directionDef = XMLBinder.fromXML( DirectionDef.class, XMLUtils.removeNamespace( directionDefStr ), UTF_8 );

		return render( directionDef, txnDataStr, encoding, toQueue, hostDriveQueue, tellerCode );
	}

	public String render(DirectionDef directionDef, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode)
	        throws Exception {
		try {
			TxnData txnData = new TxnData();
			if (txnDataStr != null && !txnDataStr.isEmpty())
				txnData = XMLBinder.fromXML( TxnData.class, XMLUtils.removeNamespace( txnDataStr ), UTF_8 );

			return render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode );
		} catch (Throwable cause) {
			throw cause;
		}
	}

	/*
	 * modified by Leo@Comwave 2015.08.31 Add parameter "direcitonDef" and passed it to function - "renderBodyFields.render". Purpose: when rendering TOTA XML
	 * format and the Cname of the tag starts with "-", do not render this tag in XML
	 * 
	 */
	public String render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode)
	        throws Exception {
		StringBuilder tx = new StringBuilder( 512 );
		tx.append( "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" );
		tx.append( "<Tx>" );

		tx.append( renderHeaderFields.render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode ) );
		for (Body body : txnData.getBodies()) {
			tx.append( renderBodyFields.render( directionDef, body.getFields() ) );
		}

		tx.append( "</Tx>" );
		return fixMissingTag( directionDef, tx.toString() );
		// return tx.toString();
	}

	/*
	 * edit by Leo Chiu@Comwave 2015.07.23 Purpose: overriding 3 function-"render" and add a parameter "transformTxId" in order to forcedly change TxID field
	 * 
	 * 
	 */
	public String render(String directionDefStr, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId) throws Exception {
		DirectionDef directionDef = new DirectionDef();
		if (directionDefStr != null && !directionDefStr.isEmpty())
			directionDef = XMLBinder.fromXML( DirectionDef.class, XMLUtils.removeNamespace( directionDefStr ), UTF_8 );

		return render( directionDef, txnDataStr, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId );
	}

	public String render(DirectionDef directionDef, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId) throws Exception {
		try {
			TxnData txnData = new TxnData();
			if (txnDataStr != null && !txnDataStr.isEmpty())
				txnData = XMLBinder.fromXML( TxnData.class, XMLUtils.removeNamespace( txnDataStr ), UTF_8 );

			return render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId );
		} catch (Throwable cause) {
			throw cause;
		}
	}

	/*
	 * modified by Leo@Comwave 2015.08.31 Add parameter "direcitonDef" and passed it to function - "renderBodyFields.render". Purpose: when rendering TOTA XML
	 * format and the Cname of the tag starts with "-", do not render this tag in XML
	 * 
	 */
	public String render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId) throws Exception {
		StringBuilder tx = new StringBuilder( 512 );
		tx.append( "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" );
		tx.append( "<Tx>" );

		tx.append( renderHeaderFields.render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId ) );

		for (Body body : txnData.getBodies()) {
			tx.append( renderBodyFields.render( directionDef, body.getFields() ) );
		}

		tx.append( "</Tx>" );
		return fixMissingTag( directionDef, tx.toString() );
		// return tx.toString();
	}

	/*
	 * edit by Leo Chiu@Comwave 2015.09.21 Purpose: overriding 3 function-"render" and add a parameter "renderType" in order to fit different render function
	 * 
	 * 
	 */
	public String render(String directionDefStr, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId, String renderType) throws Exception {
		DirectionDef directionDef = new DirectionDef();
		if (directionDefStr != null && !directionDefStr.isEmpty())
			directionDef = XMLBinder.fromXML( DirectionDef.class, XMLUtils.removeNamespace( directionDefStr ), UTF_8 );

		return render( directionDef, txnDataStr, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId, renderType );
	}

	public String render(DirectionDef directionDef, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId, String renderType) throws Exception {
		try {
			TxnData txnData = new TxnData();
			if (txnDataStr != null && !txnDataStr.isEmpty())
				txnData = XMLBinder.fromXML( TxnData.class, XMLUtils.removeNamespace( txnDataStr ), UTF_8 );

			return render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId, renderType );
		} catch (Throwable cause) {
			throw cause;
		}
	}

	/*
	 * modified by Leo@Comwave 2015.08.31 Add parameter "direcitonDef" and passed it to function - "renderBodyFields.render". Purpose: when rendering TOTA XML
	 * format and the Cname of the tag starts with "-", do not render this tag in XML
	 * 
	 */
	public String render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId, String renderType) throws Exception {
		StringBuilder tx = new StringBuilder( 512 );
		tx.append( "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" );
		tx.append( "<Tx>" );

		tx.append( renderHeaderFields.render( directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId, renderType ) );

		for (Body body : txnData.getBodies()) {
			tx.append( renderBodyFields.render( directionDef, body.getFields(), renderType ) );
		}

		tx.append( "</Tx>" );

		return fixMissingTag( directionDef, tx.toString() );
		// return tx.toString();
	}

	/*
	 * edit by taylerlee@Comwave 2015.12.07 Purpose: render all tag except TxRepeat according to directionDef by U and D xml
	 * 
	 */
	private String fixMissingTag(DirectionDef directionDef, String OrgXml) throws Exception {
		Matcher matcher = ampPattern.matcher( OrgXml );
		boolean isFound = matcher.find();
		if (isFound) {
			OrgXml = matcher.replaceAll( "&amp;" );
		}

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource( new StringReader( OrgXml ) );
		Document doc = db.parse( is );
		doc.getDocumentElement().normalize();

		fixMissingTag_body( directionDef.getDirectionAttr(), directionDef.getBodyDef().getFieldDefs(), doc, "", null );

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty( OutputKeys.OMIT_XML_DECLARATION, "yes" );
		StringWriter writer = new StringWriter();
		transformer.transform( new DOMSource( doc ), new StreamResult( writer ) );
		String result = writer.getBuffer().toString();

		if (isFound) {
			result = result.replaceAll( "&amp;", "&" );
		}

		return "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" + result;
	}

	private void fixMissingTag_body(String direction, List<FieldDef> fieldDefs, Document doc, String sField, Node prev_node) throws Exception {
		XPath xPath = XPathFactory.newInstance().newXPath();
		
//		XPath xPath = XPathFactory.newInstance( XPathFactory.DEFAULT_OBJECT_MODEL_URI, "net.sf.saxon.xpath.XPathFactoryImpl", ClassLoader.getSystemClassLoader() ).newXPath();
		
		String body_expression = "/*[local-name(.)='Tx']/*[local-name(.)='TxBody']";
		Node body_node = (Node) xPath.compile( body_expression ).evaluate( doc, XPathConstants.NODE );

		for (FieldDef fd : fieldDefs) {
			if ((direction.equals( "U" ) && fd.getTypeAttr().equals( FieldDef.TYPE_ATTR_F ))
			        || (direction.equals( "D" ) && (fd.getCname() != null && fd.getCname().length() > 0 && !fd.getCname().startsWith( "-" ))
			                && fd.getTypeAttr().equals( FieldDef.TYPE_ATTR_F ))) {

				String expression = body_expression + "/*[local-name(.)='" + fd.getName() + "']";
				Node temp_node = (Node) xPath.compile( expression ).evaluate( doc, XPathConstants.NODE );
				if (temp_node != null) {
					prev_node = temp_node;
				} else {
					Node new_node = doc.createElement( fd.getName() );
					if (prev_node == null) {
						body_node.insertBefore( new_node, body_node.getFirstChild() );
					} else {
						body_node.insertBefore( new_node, prev_node.getNextSibling() );
					}
					prev_node = new_node;
				}
			} else if (fd.getTypeAttr().equals( FieldDef.TYPE_ATTR_C ) && isThisCase( doc, sField, fd.getValueAttr() )) {
				fixMissingTag_body( direction, fd.getFieldDefs(), doc, "", prev_node );
			} else if (fd.getTypeAttr().equals( FieldDef.TYPE_ATTR_S )) {
				fixMissingTag_body( direction, fd.getFieldDefs(), doc, fd.getFieldAttr(), prev_node );
			} else {
				continue;
			}
		}
	}

	private boolean isThisCase(Document doc, String sField, String cValue) throws Exception {
		XPath xPath = XPathFactory.newInstance().newXPath();
		
//		XPath xPath = XPathFactory.newInstance( XPathFactory.DEFAULT_OBJECT_MODEL_URI, "net.sf.saxon.xpath.XPathFactoryImpl", ClassLoader.getSystemClassLoader() ).newXPath();
		
		String expression = "//*[local-name(.)='" + sField + "']";
		Node node = (Node) xPath.compile( expression ).evaluate( doc, XPathConstants.NODE );
		if (node.getTextContent().trim().equals( cValue ))
			return true;
		return false;
	}

}
