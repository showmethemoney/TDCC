package com.fubon.esb.tx.render.txt;

import com.fubon.esb.tx.def.FieldDef;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class CollectedValue {

    private String name;

    private String type;

    private Integer length;

    private Integer scale;

    private String justify;

    private String padChar;

    private String value;

    private String hexValue;

    private Boolean optional;
    
    private Boolean include_chinese;
    
    public CollectedValue() {
    }

    public CollectedValue(String name, String type, Integer length, Integer scale, String justify, String padChar, Boolean optional, Boolean include_chinese) {
        this.name = name;
        this.type = type;
        this.length = length;
        this.scale = scale;
        this.justify = justify;
        this.padChar = padChar;
        this.optional = optional;
        this.include_chinese = include_chinese;
    }

    public CollectedValue(FieldDef fieldDef) {
        this(fieldDef.getName(), fieldDef.getType(), fieldDef.getLength(), fieldDef.getScale(), fieldDef.getJustify(), fieldDef.getPadChar(), fieldDef.getOptional(), fieldDef.getIncludeChinese());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getJustify() {
        return justify;
    }

    public void setJustify(String justify) {
        this.justify = justify;
    }

    public Integer getScale() {
        return scale;
    }

    public void setScale(Integer scale) {
        this.scale = scale;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getPadChar() {
        return padChar;
    }

    public void setPadChar(String padChar) {
        this.padChar = padChar;
    }

    public String getHexValue() {
        return hexValue;
    }

    public void setHexValue(String hexValue) {
        this.hexValue = hexValue;
    }

    public Boolean getOptional(){
    	return optional;
    }
    
    public void setOptional(Boolean optional) {
    	this.optional = optional;
    }    
    
    public Boolean getInclude_Chinese(){
    	return include_chinese;
    }
    
    public void setInclude_chinese(Boolean include_chinese){
    	this.include_chinese = include_chinese;
    }
}
