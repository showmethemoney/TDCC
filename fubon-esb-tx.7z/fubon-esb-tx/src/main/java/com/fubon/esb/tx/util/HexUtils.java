package com.fubon.esb.tx.util;

/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class HexUtils {

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            byte b = bytes[i];
            sb.append(byteToHex(b));
        }
        return sb.toString();
    }

    public static String byteToHex(byte b) {
        String s = "" + toHexChar(b >>> 4 & 0xF);
        s = s + toHexChar(b & 0xF);
        return s;
    }

    private static char toHexChar(int j) {
        if ((0 <= j) && (j <= 9))
            return (char) (j + 48);
        return (char) (j + 97 - 10);
    }

    public static byte[] hexToBytes(String hexString) {
        if (hexString == null)
            throw new IllegalArgumentException("hex string is null");
        int length = hexString.length();
        int byteLen = length / 2;
        if (length != byteLen * 2) {
            throw new IllegalArgumentException("illegal length of the input String");
        }

        for (int i = 0; i < hexString.length(); i++) {
            if (!isHexDigit(hexString.charAt(i))) {
                throw new IllegalArgumentException("hex string is not valid");
            }
        }
        byte[] bytes = new byte[byteLen];

        char[] hex = hexString.toCharArray();

        for (int i = 0; i < byteLen; i++) {
            byte hi = (byte) Character.digit(hex[2 * i], 16);
            byte lo = (byte) Character.digit(hex[2 * i + 1], 16);
            bytes[i] = (byte) (hi << 4 & 0xF0 | lo & 0xF);
        }
        return bytes;
    }

    public static boolean isHexDigit(char c) {
        return (('0' <= c) && (c <= '9')) || (('A' <= c) && (c <= 'F')) || (('a' <= c) && (c <= 'f'));
    }

}
