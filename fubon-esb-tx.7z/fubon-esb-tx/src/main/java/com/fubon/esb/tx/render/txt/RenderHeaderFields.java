package com.fubon.esb.tx.render.txt;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.FieldUtils;


/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
public class RenderHeaderFields
{

	private final RenderField renderField = new RenderField();

	public List<CollectedValue> render(List<FieldDef> fieldDefs, List<Field> fields, String toQueue, String hostDriveQueue, String tellerCode) {
		List<CollectedValue> collectedValues = new ArrayList<CollectedValue>();
		Map<String, Field> fieldMap = FieldUtils.convert( fields );

		for (FieldDef fieldDef : fieldDefs) {
			CollectedValue collectedValue = renderField.renderHeaderField( fieldDef, fieldMap.get( fieldDef.getName() ), toQueue, hostDriveQueue, tellerCode );
			collectedValues.add( collectedValue );
		}
		return collectedValues;
	}

	/*
	 * edit by Leo Chiu@Comwave 2015.07.23 Purpose: add overriding function-"render" and add a parameter "transformTxId" in order to forcedly change TxID field
	 * 
	 */
	public List<CollectedValue> render(List<FieldDef> fieldDefs, List<Field> fields, String toQueue, String hostDriveQueue, String tellerCode,
	        String transformTxId) {
		List<CollectedValue> collectedValues = new ArrayList<CollectedValue>();
		Map<String, Field> fieldMap = FieldUtils.convert( fields );

		for (FieldDef fieldDef : fieldDefs) {
			CollectedValue collectedValue = renderField.renderHeaderField( fieldDef, fieldMap.get( fieldDef.getName() ), toQueue, hostDriveQueue, tellerCode,
			        transformTxId );
			collectedValues.add( collectedValue );
		}
		return collectedValues;
	}

}
