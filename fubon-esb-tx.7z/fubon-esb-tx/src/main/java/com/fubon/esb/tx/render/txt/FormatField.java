package com.fubon.esb.tx.render.txt;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Pattern;

import com.fubon.esb.tx.def.FieldDef;
import com.fubon.esb.tx.util.HexUtils;
import com.fubon.esb.tx.util.UnicodeHandler;


/**
 * @author Robin
 * @createdDate Mar 3, 2015
 */
/*
 * updated by Leo@comwave Jul 22, 2015
 * modify function-"getFieldValue" to add unicode data transformation Handler
 * 
 * updated by Leo@comwave Sep 22, 2015
 * modify function-"encodeToHex" to replace "&amp;" and "&lt;" with '&' and '<'
 * 
 * updated by Leo@comwave Nov 11, 2015
 * modify function-"format" to add checkChineseCompleteness function when the data is too long and need to be cropped (the include_chinese flag should be TRUE)
 */

public class FormatField {
	private final static Pattern LTRIM = Pattern.compile("^\\s+");
	private final static Pattern RTRIM = Pattern.compile("\\s+$");
	
    public String format(CollectedValue collectedValue, String encoding, String renderType) {
        if (collectedValue.getType() == null)
            return "";

        int length = collectedValue.getLength() * 2;
        String fieldValue = getFieldValue(collectedValue, encoding, renderType);

        
        if (fieldValue.length() == length)
            return fieldValue;

        
        if (length == 0)
            return fieldValue;

        if (fieldValue.length() > length) {
        	String remainValue="", trimValue="";
            if (FieldDef.JUSTIFY_R.equals(collectedValue.getJustify())){
                remainValue = fieldValue.substring(fieldValue.length() - length);
                trimValue = fieldValue.substring(0, fieldValue.length() - length);            
            }else{
                remainValue = fieldValue.substring(0, length);
                trimValue = fieldValue.substring(length);   
            }
            
            //if include_chinese flag is "ON" and it's encoding is "CP937", do the chineseCompleteness check ; otherwise return remainValue as data
            if(collectedValue.getInclude_Chinese().equals(Boolean.TRUE) && encoding.toUpperCase().equals("CP937"))
            	return makeChineseCompleteness(remainValue, trimValue, collectedValue.getJustify(), getPadValue(collectedValue, encoding));   //use pad char when we need to fill the byte 
            else
            	return remainValue;	
        }

        
        // fieldValue.length() < length

        StringBuilder sb = new StringBuilder(64);
        if (FieldDef.JUSTIFY_L.equals(collectedValue.getJustify()))
            sb.append(fieldValue);

        //if optional flag is FALSE(by default) or Value is not empty, do the padding function; otherwise remains empty
        if(collectedValue.getOptional().equals(Boolean.FALSE) || (collectedValue.getValue()!=null && collectedValue.getValue().isEmpty()==false) ){
	        int padCount = (length - fieldValue.length()) / 2;
	        String padValue = getPadValue(collectedValue, encoding);
	        for (int i = 0; i < padCount; i++) {
	            sb.append(padValue);
	        }
        }
        
        if (FieldDef.JUSTIFY_R.equals(collectedValue.getJustify()))
            sb.append(fieldValue);
        return sb.toString();
        
          
    }

    
    
    
    private String getFieldValue(CollectedValue collectedValue, String encoding, String renderType) {
        String hv = "";
        if (collectedValue.getHexValue() != null && !collectedValue.getHexValue().isEmpty()) { 
            hv = collectedValue.getHexValue();
            
        } else {	
            String v = "";
            
            
            if (FieldDef.TYPE_9.equals(collectedValue.getType())) {
                if (collectedValue.getValue() != null && !collectedValue.getValue().trim().isEmpty()) {
                    BigDecimal bd = new BigDecimal(collectedValue.getValue());
                    bd = bd.setScale(collectedValue.getScale(), RoundingMode.HALF_UP);
                    v = bd.toString();
                } else {
                	//if optional flag is true, remains empty; otherwise pad "0" to this field 
                	if(collectedValue.getOptional().equals(Boolean.TRUE))
                		v="";
                	else
                		v = "0";
                }
            } else {
                v = collectedValue.getValue();
                
                /*add by Leo Chiu@Comwave 20150528
                 * 
                 * if the render type has different setting, then do the transformation here
                 * 
                 */
                if(renderType!=null && renderType.contains(FieldDef.TrimAndPad)){
	                if(collectedValue.getLength()!=0 && collectedValue.getPadChar()!=null && !collectedValue.getPadChar().isEmpty()){ //trim data and padding when padding is not null 
	                	 if(collectedValue.getJustify()!=null && collectedValue.getJustify().equals(FieldDef.JUSTIFY_R))
	                		 v=LTrim(v);
	                	 else if(collectedValue.getJustify()!=null && collectedValue.getJustify().equals(FieldDef.JUSTIFY_L))
	                		 v=RTrim(v);              	    	 
	                }          
                } 
                
                
            }

            if (v != null) {
                if (FieldDef.TYPE_H.equals(collectedValue.getType()) && v.toUpperCase().startsWith("0X")) {
                    hv = v;
                } else {
                	//if encoding is cp937 and renderType starts with "unicode", then use mapping
                	if (renderType!=null && encoding.toUpperCase().equals("CP937") && renderType.contains(FieldDef.UnicodeData)){
                    	String encoding_file="";
        		    	int pos = renderType.lastIndexOf("_");
        		    	if (pos > 0) {
        		    	    encoding_file = renderType.substring(pos+1, renderType.length());
        		    	}		
        		    	try {
        		    		hv = UnicodeHandler.unicodeStr_to_ebcdicHex(v, null, encoding_file);
        		    	}catch(Exception e){
        		    		throw new IllegalArgumentException(e);
        		    	}
                    }else{
                    	//if not unicode, do the common encoding transformation
                    	hv = encodeToHex(v, encoding);
                    }
               }
            }
        }

        if (hv == null || hv.isEmpty())
            return "";

        hv = hv.toUpperCase();
        if (hv.startsWith("0X"))
            return hv.substring(2);
        return hv;
    }

    private String getPadValue(CollectedValue collectedValue, String encoding) {
        String hv = null;
        String padChar = collectedValue.getPadChar();

        if (FieldDef.TYPE_H.equals(collectedValue.getType()) && padChar != null && padChar.toUpperCase().startsWith("0X")) {
            hv = padChar.substring(2);

        } else {
            String v = null;
            if (padChar != null && !padChar.isEmpty())
                v = padChar;
            else
                v = "";
            hv = encodeToHex(v, encoding);
        }

        if (hv == null || hv.isEmpty())
            return encodeToHex("", encoding);

        return hv.toUpperCase();
    }

    private String encodeToHex(String value, String encoding) {
        try {
        	if(value!=null){
        		value=value.replaceAll("&amp;", "&");
        		value=value.replaceAll("&lt;", "<");
        	}
        				
            return HexUtils.bytesToHex(value.getBytes(encoding));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    private String LTrim(String inStr){
    	return LTRIM.matcher(inStr).replaceAll("");
    }

    private String RTrim(String inStr){
	    return RTRIM.matcher(inStr).replaceAll("");
    }    

    private String makeChineseCompleteness(String remainHex, String trimHex, String justify, String padCharHex){	
    	if(trimHex==null || trimHex.isEmpty())
    		return remainHex;
    	
    	int count0E=0, count0F=0;
    	for(int i=0;i<trimHex.length()/2;i++){
    		String tmp=trimHex.substring(i*2, i*2+2).toUpperCase();
    		if(tmp.equals("0E"))
    			count0E++;
    		else if(tmp.equals("0F"))
    			count0F++;
    	}
    	
    	String output="";
    	if(count0E==count0F)
    		return remainHex;	// Chinese words are all matched well or no chinese word
    	else{
    		if(justify.equals(FieldDef.JUSTIFY_L)){	 //0x0F has been cropped by substring function, need to put it back to the remainString
    			if(remainHex!=null && remainHex.endsWith("0E"))
    				return remainHex.substring(0, remainHex.length()-2).concat(padCharHex);	//if remainValue ends with 0x0E, replace this byte with padCharHex
    			
    			Boolean check_result=checkHalfChinese(remainHex, justify);

    			if(check_result==false)
    				output=remainHex.substring(0, remainHex.length()-2).concat("0F");
    			else 
    				output=remainHex.substring(0, remainHex.length()-4).concat("0F").concat(padCharHex);
    		}else if(justify.equals(FieldDef.JUSTIFY_R)){	 //0x0E has been cropped by substring function, need to put it back to the remainString
    			if(remainHex!=null && remainHex.startsWith("0F"))
    				return padCharHex+remainHex.substring(2);	//if remainValue starts with 0x0F, replace this byte with padCharHex
    			
    			Boolean check_result=checkHalfChinese(remainHex, justify);
    			if(check_result==false)
    				output="0E"+remainHex.substring(2);
    			else 
    				output=padCharHex+"0E"+remainHex.substring(4);
    		}
    	
    	}
    	return output;
    }

    private boolean checkHalfChinese(String remainHex, String justify){
    	if(remainHex==null || remainHex.isEmpty())
    		return true;	
    	
    	int byteCount=0;
    	    	
    	if(justify.equals(FieldDef.JUSTIFY_L)){
    		  StringBuilder tmpBuilder = new StringBuilder();
    		  tmpBuilder.append(remainHex);
    		  tmpBuilder=tmpBuilder.reverse(); 
    		  
    		  for(int i=0;i<tmpBuilder.length()/2;i++){
    	    		String tmp=tmpBuilder.substring(i*2, i*2+2).toUpperCase();
    	    		if(tmp.equals("E0"))	//break when matching the start of Chinese word (because of the reverse function, 0x0E becomes 0xE0)
    	    			break;
    	    		else
    	    			byteCount++;
    	      } 
    	}else if(justify.equals(FieldDef.JUSTIFY_R)){
    		 StringBuilder tmpBuilder = new StringBuilder();
   		  	 tmpBuilder.append(remainHex);
   		  
	   		  for(int i=0;i<tmpBuilder.length()/2;i++){
	   	    		String tmp=tmpBuilder.substring(i*2, i*2+2).toUpperCase();
	   	    		if(tmp.equals("0F"))	//break when matching end of Chinese word
	   	    			break;			
	   	    		else
	   	    			byteCount++;
	   	      } 
    	}
  
    	return (byteCount%2)==0?true:false;	//if byteCount is odd, replace only 1 byte; otherwise replace 2 bytes
    	
    }


}
