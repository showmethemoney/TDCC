package com.fubon.esb.tx.render.txt;

import java.util.List;

import com.fubon.esb.tx.data.Body;
import com.fubon.esb.tx.data.Field;
import com.fubon.esb.tx.data.TxnData;
import com.fubon.esb.tx.def.DirectionDef;
import com.fubon.esb.tx.util.XMLBinder;
import com.fubon.esb.tx.util.XMLUtils;

/**
 * @author Robin
 * @createdDate Mar 2, 2015
 */
public class RenderToTXT {
    private static final String UTF_8 = "UTF-8";
    private static final String HDTLEN = "HDTLEN";

    private final RenderHeaderFields renderHeaderFields = new RenderHeaderFields();
    private final RenderBodyFields renderBodyFields = new RenderBodyFields();
    private final FormatField formatField = new FormatField();

    public String renderHeaderTXT(String txnDataStr) {
    	StringBuilder result = new StringBuilder();
    	
    	try {
    		TxnData txnData = new TxnData();
	    	
	    	if (txnDataStr != null && !txnDataStr.isEmpty()) {
	    		txnData = XMLBinder.fromXML(TxnData.class, XMLUtils.removeNamespace(txnDataStr), UTF_8);
		    }
	    	 
    		for (Field field : txnData.getHeader().getFields()) {
    			result = recurvieRenderContent( result, field );
			}
	    	
	    	return result.toString();
	    } catch (Throwable cause) {
	    	throw cause;
	    }
    }
    
    public String renderBodyTXT(String txnDataStr) {
    	StringBuilder result = new StringBuilder();
    	
    	try {
	    	TxnData txnData = new TxnData();
	    	
	    	if (txnDataStr != null && !txnDataStr.isEmpty()) {
	    		txnData = XMLBinder.fromXML(TxnData.class, XMLUtils.removeNamespace(txnDataStr), UTF_8);
		    }
	    	 
	    	for (Body body : txnData.getBodies()) {
	    		for (Field field : body.getFields()) {
	    			result = recurvieRenderContent( result, field );
				}
			}
	    	
	    	return result.toString();
	    } catch (Throwable cause) {
	    	throw cause;
	    }
    }
    
    public String render(DirectionDef directionDef, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String bodyRenderType) {
        try {
	    	TxnData txnData = new TxnData();
	        if (txnDataStr != null && !txnDataStr.isEmpty())
	            txnData = XMLBinder.fromXML(TxnData.class, XMLUtils.removeNamespace(txnDataStr), UTF_8);
	
	        return render(directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, bodyRenderType);
	    } catch (Throwable cause) {
	    	throw cause;
	    }
    }

    public String render(String directionDefStr, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String bodyRenderType) {
		DirectionDef directionDef = new DirectionDef();

        if (directionDefStr != null && !directionDefStr.isEmpty())
            directionDef = XMLBinder.fromXML(DirectionDef.class, XMLUtils.removeNamespace(directionDefStr), UTF_8);

        return render(directionDef, txnDataStr, encoding, toQueue, hostDriveQueue, tellerCode, bodyRenderType);
    }

    public String render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String bodyRenderType) {
        List<CollectedValue> collectedHeaderValues = renderHeaderFields.render(directionDef.getHeaderDef().getFieldDefs(), txnData.getHeader().getFields(), toQueue, hostDriveQueue, tellerCode);
        List<CollectedValue> collectedBodyValues = renderBodyFields.render(directionDef.getBodyDef().getFieldDefs(), txnData);


        String bodyTx=null;
        String headerTx=null;
        
        bodyTx = renderBody(collectedBodyValues, encoding, bodyRenderType);
        headerTx = renderHeader(collectedHeaderValues, encoding, bodyTx.length() / 2);
        
        return headerTx + bodyTx;
    }

    /*
     * edit by Leo Chiu@Comwave 2015.07.23
     * Purpose: overriding 3 function-"render" and add a parameter "transformTxId" in order to forcedly change TxID field
     * 
     */
    
    public String render(DirectionDef directionDef, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId, String bodyRenderType) {
    	 try {
	    	TxnData txnData = new TxnData();
	        if (txnDataStr != null && !txnDataStr.isEmpty())
	            txnData = XMLBinder.fromXML(TxnData.class, XMLUtils.removeNamespace(txnDataStr), UTF_8);
	
	        return render(directionDef, txnData, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId, bodyRenderType);
	    } catch (Throwable cause) {
	    	throw cause;
	    }
    }

    public String render(String directionDefStr, String txnDataStr, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId, String bodyRenderType) {
    	DirectionDef directionDef = new DirectionDef();

    	if (directionDefStr != null && !directionDefStr.isEmpty())
    		directionDef = XMLBinder.fromXML(DirectionDef.class, XMLUtils.removeNamespace(directionDefStr), UTF_8);
    
    	return render(directionDef, txnDataStr, encoding, toQueue, hostDriveQueue, tellerCode, transformTxId, bodyRenderType);
    }

    public String render(DirectionDef directionDef, TxnData txnData, String encoding, String toQueue, String hostDriveQueue, String tellerCode, String transformTxId, String bodyRenderType) {
        List<CollectedValue> collectedHeaderValues = renderHeaderFields.render(directionDef.getHeaderDef().getFieldDefs(), txnData.getHeader().getFields(), toQueue, hostDriveQueue, tellerCode, transformTxId);
        List<CollectedValue> collectedBodyValues = renderBodyFields.render(directionDef.getBodyDef().getFieldDefs(), txnData);


        String bodyTx=null;
        String headerTx=null;
        
        bodyTx = renderBody(collectedBodyValues, encoding, bodyRenderType);
        headerTx = renderHeader(collectedHeaderValues, encoding, bodyTx.length() / 2);
        
        return headerTx + bodyTx;
    }
    
    
    
    
    public String renderBody(List<CollectedValue> collectedValues, String encoding, String bodyRenderType) {
        StringBuilder sb = new StringBuilder(512);
        
        if(bodyRenderType!=null && bodyRenderType.length()>0)
        	bodyRenderType=bodyRenderType.toUpperCase();
        
        for (CollectedValue collectedValue : collectedValues) {
            String value = formatField.format(collectedValue, encoding, bodyRenderType);
            sb.append(value);
        }
        return sb.toString();
    }

    protected StringBuilder recurvieRenderContent(StringBuilder builder, Field field) {
    	if (Field.TYPE_F.equalsIgnoreCase( field.getType() )) {
			builder.append( field.getValue() );
		} else {
			for (Field child : field.getFields()) {
				builder.append( recurvieRenderContent( new StringBuilder(), child ) );
			}
		}
    	
    	return builder;
    }
    
    private String renderHeader(List<CollectedValue> collectedValues, String encoding, int bodyLength) {
        StringBuilder sb = new StringBuilder(512);
        for (CollectedValue collectedValue : collectedValues) {
            if (HDTLEN.equals(collectedValue.getName())) {
                collectedValue.setValue(String.valueOf(bodyLength));
            }
            sb.append(formatField.format(collectedValue, encoding, null));
        }
        return sb.toString();
    }

}
