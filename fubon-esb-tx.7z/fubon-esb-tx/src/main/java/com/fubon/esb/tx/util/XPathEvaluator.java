package com.fubon.esb.tx.util;

import javax.xml.namespace.QName;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Node;


/**
 * @author Ethan Lee
 */
public class XPathEvaluator
{
	private static final String DTM_MANAGER_NAME = "com.sun.org.apache.xml.internal.dtm.DTMManager";
	private static final String DTM_MANAGER_VALUE = "com.sun.org.apache.xml.internal.dtm.ref.DTMManagerDefault";
	static {
		// performance improvement: https://issues.apache.org/jira/browse/XALANJ-2540
		System.setProperty( DTM_MANAGER_NAME, DTM_MANAGER_VALUE );
	}

	private static final ThreadLocal<XPathFactory> XPATH_FACTORY = new ThreadLocal<XPathFactory>() {
		@Override
		protected XPathFactory initialValue() {
			return XPathFactory.newInstance();
		}
	};

	public static Object query(String xPathExpression, Node document, QName resultType) {
		try {
			XPath xpath = XPATH_FACTORY.get().newXPath();
			XPathExpression expression = xpath.compile( xPathExpression );
			return expression.evaluate( document, resultType );
		} catch (XPathExpressionException cause) {
			throw new IllegalStateException( "Error while executing XPath evaluation!", cause );
		}
	}

}
