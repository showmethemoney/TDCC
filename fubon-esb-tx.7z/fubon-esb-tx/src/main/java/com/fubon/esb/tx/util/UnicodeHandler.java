package com.fubon.esb.tx.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;


/**
 * @author Leo@comwave
 * @createdDate Jul 22, 2015
 */
public class UnicodeHandler
{
	private static final String baseDir = "/opt/tibco/encoding_files";
	private static Map<String, byte[]> EncodingData = new HashMap<String, byte[]>();

	static {
		update_encoding_files();
	}

	static public void update_encoding_files() {
		try {
			File dir = new File( baseDir );
			File[] directoryListing = dir.listFiles();

			if (directoryListing != null) {
				for (File child : directoryListing) {
					FileInputStream fileInputStream = null;
					byte[] bFile = new byte[(int) child.length()];

					fileInputStream = new FileInputStream( child );
					fileInputStream.read( bFile );
					fileInputStream.close();

					String fileName = child.getName();
					int pos = fileName.lastIndexOf( "." );
					if (pos > 0) {
						fileName = fileName.substring( 0, pos );
					}

					EncodingData.put( fileName, bFile );
				}
			} else {
				// Handle the case where dir is not really a directory.
				// Checking dir.isDirectory() above would not be sufficient
				// to avoid race conditions with another process that deletes
				// directories.
				throw new Exception( "The baseDir is empty or not a directory!" );
			}

		} catch (Exception e) {
			System.out.println( "Error while initializing and loading the encoding mapping data! Caused by:" + e.toString() );
		}
	}

	static public String unicodeStr_to_ebcdicHex(String unicode_str, Boolean is_bigEndian, String mapping_file) throws Exception {
		String output = "";
		boolean isBigEndian = true;

		if (unicode_str == null || unicode_str.length() == 0)
			return "";

		if (mapping_file == null || mapping_file.equals( "" )) // if mapping_file not specified, use default
			mapping_file = "U01";

		byte[] binary = unicode_str.getBytes( "UTF-16" );
		if (binary[0] == 0xFE && binary[1] == 0xFF) {
			isBigEndian = true;
		} else if (binary[0] == 0xFF && binary[1] == 0xFE) {
			isBigEndian = false;
		} else if (is_bigEndian != null) {
			isBigEndian = is_bigEndian;
		}

		/*
		 * String showHex= String.format("UTF-16\t%h%h %h%h\n", binary[0] & 0x00FF, binary[1] & 0x00FF, binary[2] & 0x00FF, binary[3] & 0x00FF);
		 */

		output = mapping_ucs2_to_ebcdic( binary, isBigEndian, mapping_file );
		// output="HAHA:"+bFile1.length;

		return output.toUpperCase();
	}

	static private String mapping_ucs2_to_ebcdic(byte[] byteArray, Boolean isBigEndian, String mapping_file) throws Exception {
		String output = "";
		int startInd = 0;
		byte[] bFile = null;

		if ((byteArray.length % 2) != 0)
			throw new Exception( "Not a valid unicode(UCS2) byte size! Must be even" );

		if (byteArray == null || byteArray.length == 0)
			return "";

		if (EncodingData.isEmpty() || EncodingData.containsKey( mapping_file ) == false) {
			throw new Exception( "The specified encoding mapping file is not found!!" );
		} else {
			bFile = EncodingData.get( mapping_file );
		}

		if ((byteArray[0] == (byte) 0xFE && byteArray[1] == (byte) 0xFF) || (byteArray[0] == (byte) 0xFF && byteArray[1] == (byte) 0xFE))
			startInd = 2;

		boolean isSemi = true;
		for (int i = startInd; i < byteArray.length; i += 2) {

			if ((isBigEndian == true && byteArray[i] == (byte) 0x00) || (isBigEndian == false && byteArray[i + 1] == (byte) 0x00)) {
				// this is for semi-character
				if (isSemi == false)
					output += "0F";

				byte[] tmp = new byte[2];
				String tmpCharacter;

				if (isBigEndian == true) {
					tmp[0] = byteArray[i];
					tmp[1] = byteArray[i + 1];
					tmpCharacter = new String( tmp, "utf-16" );
				} else {
					tmp[0] = byteArray[i + 1];
					tmp[1] = byteArray[i];
					tmpCharacter = new String( tmp, "utf-16" );
				}

				output += encodeToHex( tmpCharacter, "cp937" );

				isSemi = true;
			} else {
				// for full-character (ex: chinese)
				if (isSemi == true)
					output += "0E";

				int refAddr = -1;

				if (isBigEndian == true)
					refAddr = ((byteArray[i + 1] & 0xff) << 8) | (byteArray[i] & 0xff);
				else
					refAddr = ((byteArray[i] & 0xff) << 8) | (byteArray[i + 1] & 0xff);

				System.out.printf( "UTF-16\t%2h%2h\n", byteArray[i] & 0x00FF, byteArray[i + 1] & 0x00FF );
				System.out.println( "refAddr=" + refAddr );

				byte[] tmp = new byte[2];
				tmp[0] = bFile[refAddr * 2];
				tmp[1] = bFile[refAddr * 2 + 1];

				output += HexUtils.bytesToHex( tmp );

				isSemi = false;
			}

		}

		if (isSemi == false)
			output += "0F";

		return output;
	}

	static public String ebcdicHex_to_unicodeStr(String ebcdic_hex, Boolean is_bigEndian, String mapping_file) throws Exception {
		StringBuffer sb = new StringBuffer();
		String outHex = "";
		boolean isBigEndian = true;

		if (ebcdic_hex == null || ebcdic_hex.length() == 0)
			return "";

		if (mapping_file == null || mapping_file.equals( "" )) // if mapping_file not specified, use default
			mapping_file = "E01";

		ebcdic_hex = ebcdic_hex.toUpperCase();

		if (is_bigEndian != null)
			isBigEndian = is_bigEndian;

		/*
		 * //set a space before 0x0E and after 0x0F for(int i=0;i<ebcdic_hex.length()/2;i++){ String tmp=ebcdic_hex.substring(i*2, i*2+2);
		 * 
		 * if(tmp.equals("0E")) sb.append("40"+tmp); else if(tmp.equals("0F")) sb.append(tmp+"40"); else sb.append(tmp); } byte[] binary =
		 * toByteArray(sb.toString());
		 */

		byte[] binary = toByteArray( ebcdic_hex );

		for (int i = 0; i < binary.length; i++) {
			byte[] tmpArray = null;

			if (binary[i] == (byte) 0x0E) {
				int j = getChineseEndInd( binary, i );
				tmpArray = Arrays.copyOfRange( binary, i, j + 1 );

				outHex += mapping_ebcdic_to_ucs2( tmpArray, isBigEndian, mapping_file );

				i = j; // jump to the end of the Chinese byte index
			} else {
				tmpArray = Arrays.copyOfRange( binary, i, i + 1 );
				byte[] temp = (new String( tmpArray, "cp937" )).getBytes( "UTF-16" );
				if (temp.length > 0) {
					tmpArray = Arrays.copyOfRange( temp, 2, 4 ); // skip 0xFF 0xFE or 0xFE 0xFF
				}
				outHex += HexUtils.bytesToHex( tmpArray );
			}

		}

		if (isBigEndian == true) {
			outHex = "FEFF" + outHex;
		} else {
			outHex = "FFFE" + outHex;
		}

		return new String( toByteArray( outHex ), "UTF-16" );
	}

	static private String mapping_ebcdic_to_ucs2(byte[] byteArray, Boolean isBigEndian, String mapping_file) throws Exception {
		String output = "";
		int startInd = 0, endInd = byteArray.length - 1;
		int refAddr = -1;
		byte[] bFile = null;

		if (byteArray == null || byteArray.length == 0)
			return "";

		if (EncodingData.isEmpty() || EncodingData.containsKey( mapping_file ) == false) {
			throw new Exception( "The specified encoding mapping file is not found!!" );
		} else {
			bFile = EncodingData.get( mapping_file );
		}

		if (byteArray[startInd] == (byte) 0x0E)
			startInd = 1;

		if (byteArray[endInd] == (byte) 0x0F)
			endInd = byteArray.length - 2;

		for (int i = startInd; i < endInd;) {
			byte hi, low;
			if (i + 1 > endInd) {
				hi = byteArray[i];
				low = (byte) 0x00;
			} else {
				hi = byteArray[i];
				low = byteArray[i + 1];
			}

			refAddr = ((hi & 0xff) << 8) | (low & 0xff);
			System.out.println( "refAddr=" + refAddr );

			byte[] tmp = new byte[2];
			if (isBigEndian == true) {
				tmp[0] = bFile[refAddr * 2 + 1];
				tmp[1] = bFile[refAddr * 2];
			} else {
				tmp[0] = bFile[refAddr * 2];
				tmp[1] = bFile[refAddr * 2 + 1];
			}

			output += HexUtils.bytesToHex( tmp );

			i += 2;
		}

		return output;
	}

	static private int getChineseEndInd(byte[] byteData, int startInd) {

		for (int i = startInd; i < byteData.length; i++) {
			if (byteData[i] == (byte) 0x0F)
				return i;
		}

		return (byteData.length - 1);
	}

	static private String encodeToHex(String value, String encoding) {
		try {
			return HexUtils.bytesToHex( value.getBytes( encoding ) );
		} catch (UnsupportedEncodingException e) {
			throw new IllegalArgumentException( e );
		}
	}

	static private byte[] toByteArray(String s) {
		return DatatypeConverter.parseHexBinary( s );
	}

	/*
	 * public static void main( String[] args ) throws Exception { UnicodeHandler uhch=new UnicodeHandler();
	 * 
	 * 
	 * //byte[] byteTmp = uhch.toByteArray("8178"); //byte[] byteTmp = uhch.toByteArray("0358"); //String test = new String(byteTmp,"utf-16"); String test =
	 * "убЂ"; String test_hex=uhch.unicodeStr_to_ebcdicHex(test, null, "U00"); System.out.println("OUT="+test); System.out.println("OUT_Hex="+test_hex);
	 * 
	 * System.out.println("=================="); String test_return=uhch.ebcdicHex_to_unicodeStr(test_hex, null, "E00"); //String
	 * test_return=uhch.ebcdicHex_to_unicodeStr(test_hex, null); System.out.println("RETURN="+test_return);
	 * 
	 * 
	 * }
	 */

}
