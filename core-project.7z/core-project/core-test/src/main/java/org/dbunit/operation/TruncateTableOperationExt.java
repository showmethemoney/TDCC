package org.dbunit.operation;

import org.dbunit.database.IDatabaseConnection;

import com.comware.core.dbunit.QuotedNameUtils;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public class TruncateTableOperationExt extends TruncateTableOperation
{

	@Override
	protected String getQualifiedName(String prefix, String name, IDatabaseConnection connection) {
		String result = super.getQualifiedName( prefix, name, connection );
		return QuotedNameUtils.getQuotedName( connection, result );
	}

}
