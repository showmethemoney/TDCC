package org.dbunit.operation;

/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public abstract class DatabaseOperationExt
{

	public static final DatabaseOperation UPDATE = new UpdateOperationExt();

	public static final DatabaseOperation INSERT = new InsertOperationExt();

	public static final DatabaseOperation REFRESH = new RefreshOperationExt();

	public static final DatabaseOperation DELETE = new DeleteOperationExt();

	public static final DatabaseOperation DELETE_ALL = new DeleteAllOperationExt();

	public static final DatabaseOperation TRUNCATE_TABLE = new TruncateTableOperationExt();

	public static final DatabaseOperation CLEAN_INSERT = new CompositeOperation( DELETE_ALL, INSERT );

	// for MSSQL identity column
	public static final DatabaseOperation IDENTITY_INSERT = new InsertIdentityOperationExt( INSERT );

	public static final DatabaseOperation IDENTITY_REFRESH = new InsertIdentityOperationExt( REFRESH );

	public static final DatabaseOperation IDENTITY_CLEAN_INSERT = new CompositeOperation( DELETE_ALL, IDENTITY_INSERT );

}
