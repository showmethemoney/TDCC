package com.comware.core.test.common;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
class EnvPropertiesValidator
{

	private String environment;
	private List<String> envPropertyFiles;

	public EnvPropertiesValidator(String envResourcesDir) {
		this.environment = envResourcesDir;
		envPropertyFiles = new ResourceFolderScanner( envResourcesDir ).getPropertyFiles();
	}

	public List<String> compareToMainProperties() throws Exception {
		List<String> inconsistentPropertyFiles = new ArrayList<String>();
		for (String envPropertyFile : envPropertyFiles) {
			String envPropertyPath = environment + "/" + envPropertyFile;
			Properties envProperties = loadProperties( envPropertyPath );

			File propsFile = new File( ConfResourcesTest.MAIN_RESOURCE_DIR + "/" + envPropertyFile );
			if (!propsFile.exists())
				continue;
			Properties mainProperties = loadProperties( propsFile.getPath() );

			if (propertiesNotEqual( envProperties, mainProperties )) {
				inconsistentPropertyFiles.add( envPropertyPath );
			}
		}
		return inconsistentPropertyFiles;
	}

	private boolean propertiesNotEqual(Properties properties1, Properties properties2) {
		List<Object> keys1 = Collections.list( properties1.keys() );
		List<Object> keys2 = Collections.list( properties2.keys() );

		List<Object> keys1Copy = new ArrayList<>( keys1 );
		keys1.removeAll( keys2 );
		keys2.removeAll( keys1Copy );

		return !keys1.isEmpty() || !keys2.isEmpty();
	}

	private Properties loadProperties(String propertiesPath) throws Exception {
		Properties properties = new Properties();
		properties.load( new FileInputStream( propertiesPath ) );
		return properties;
	}

}
