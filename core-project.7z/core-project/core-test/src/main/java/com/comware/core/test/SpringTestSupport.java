package com.comware.core.test;

import javax.inject.Inject;
import javax.xml.xpath.XPathExpressionException;

import org.hamcrest.Matcher;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.JsonPathResultMatchers;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.result.StatusResultMatchers;
import org.springframework.test.web.servlet.result.XpathResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.comwave.core.platform.request.PlatformFilter;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
@TransactionConfiguration
@WebAppConfiguration
public abstract class SpringTestSupport
{

	@Inject
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void createMockMVC() {
		mockMvc = MockMvcBuilders.webAppContextSetup( webApplicationContext ).addFilter( new PlatformFilter() ).build();
	}

	protected ResultActions perform(RequestBuilder requestBuilder) throws Exception {
		return mockMvc.perform( requestBuilder );
	}

	protected MockHttpServletRequestBuilder get(String url) {
		return MockMvcRequestBuilders.get( url );
	}

	protected MockHttpServletRequestBuilder post(String url) {
		return MockMvcRequestBuilders.post( url );
	}

	protected MockHttpServletRequestBuilder put(String url) {
		return MockMvcRequestBuilders.put( url );
	}

	protected MockHttpServletRequestBuilder delete(String url) {
		return MockMvcRequestBuilders.delete( url );
	}

	protected StatusResultMatchers status() {
		return MockMvcResultMatchers.status();
	}

	protected ResultHandler print() {
		return MockMvcResultHandlers.print();
	}

	protected JsonPathResultMatchers jsonPath(String expression) {
		return MockMvcResultMatchers.jsonPath( expression );
	}

	protected <T> ResultMatcher jsonPath(String expression, Matcher<T> matcher) {
		return MockMvcResultMatchers.jsonPath( expression, matcher );
	}

	protected XpathResultMatchers xpath(String expression) throws XPathExpressionException {
		return MockMvcResultMatchers.xpath( expression );
	}

}
