package com.comware.core.test.common;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
class ResourceFolderScanner
{

	private final String path;

	public ResourceFolderScanner(String path) {
		this.path = path;
	}

	public List<String> getFiles() {
		List<String> results = new ArrayList<String>();
		getFilesRecursively( path, results, null );
		return removePathPrefix( results );
	}

	public List<String> getPropertyFiles() {
		List<String> results = new ArrayList<String>();
		getFilesRecursively( path, results, new FileFilter() {
			public boolean accept(File file) {
				return file.isDirectory() || file.getName().endsWith( ".properties" );
			}
		} );
		return removePathPrefix( results );
	}

	private void getFilesRecursively(String dirPath, List<String> result, FileFilter filter) {
		File dir = new File( dirPath );
		if (!dir.exists() || ConfResourcesTest.IGNORED_DIRS.contains( dir.getName() ))
			return;

		File[] fileList = dir.listFiles( filter );
		for (File file : fileList) {
			if (file.isDirectory()) {
				getFilesRecursively( dirPath + "/" + file.getName(), result, filter );
			} else if (file.isFile()) {
				result.add( dirPath + "/" + file.getName() );
			}
		}
	}

	private List<String> removePathPrefix(List<String> paths) {
		List<String> result = new ArrayList<String>();
		for (String p : paths) {
			result.add( p.substring( path.length() + 1, p.length() ) );
		}
		return result;
	}

}
