package com.comware.core.test.common;

import java.util.ArrayList;
import java.util.List;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
class EnvResourcesValidator
{

	private List<String> envResources;
	private List<String> mainResources;

	public EnvResourcesValidator(String envResourcesDir) {
		envResources = new ResourceFolderScanner( envResourcesDir ).getFiles();
		mainResources = new ResourceFolderScanner( ConfResourcesTest.MAIN_RESOURCE_DIR ).getFiles();
	}

	public List<String> getUnnecessaryResources() {
		return getUnnecessaryResources( mainResources, envResources );
	}

	private List<String> getUnnecessaryResources(List<String> mainResources, List<String> envResources) {
		List<String> tempEnvResources = new ArrayList<String>( envResources );
		tempEnvResources.removeAll( mainResources );
		return tempEnvResources;
	}

}
