package com.comware.core.test.common;

import org.springframework.context.ApplicationContext;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public class ContainerTest
{

	private ApplicationContext applicationContext;

	public ContainerTest(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public void verifyBeanConfiguration() {
		String[] beanNames = applicationContext.getBeanDefinitionNames();
		for (String beanName : beanNames) {
			applicationContext.getBean( beanName );
		}
	}

}
