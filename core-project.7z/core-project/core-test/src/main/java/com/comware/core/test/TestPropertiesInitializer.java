package com.comware.core.test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.comwave.core.exception.RuntimeIOException;
import com.comwave.core.platform.config.PropertiesInitializer;
import com.comwave.core.platform.config.PropertyLoader;


/**
 * @author Robin
 * @createdDate Sep 25, 2014
 */
public class TestPropertiesInitializer extends PropertiesInitializer
{

	private final Logger logger = LoggerFactory.getLogger( TestPropertiesInitializer.class );

	private static final String TEST_DIR = File.separator + "test-classes" + File.separator;

	@Override
	public void initialize(ConfigurableApplicationContext applicationContext) {
		logger.info( "start to load properties from classpath*:*.properties" );
		try {
			Resource[] resources = new PathMatchingResourcePatternResolver().getResources( "classpath*:*.properties" );
			List<Resource> mainResources = new ArrayList<>();
			List<Resource> testResources = new ArrayList<>();
			for (Resource resource : resources) {
				if (resource.getFile().getAbsolutePath().contains( TEST_DIR ))
					testResources.add( resource );
				else
					mainResources.add( resource );
			}

			if (!testResources.isEmpty())
				initialize( applicationContext, "testProperties", testResources );
			if (!mainResources.isEmpty())
				initialize( applicationContext, "properties", mainResources );
		} catch (IOException e) {
			throw new RuntimeIOException( e );
		}
	}

	private void initialize(ConfigurableApplicationContext applicationContext, String propertySourceName, List<Resource> resources) throws IOException {
		ConfigurableEnvironment environment = applicationContext.getEnvironment();
		PropertyLoader propertyLoader = new PropertyLoader();
		propertyLoader.setLocations( resources.toArray( new Resource[0] ) );
		environment.setIgnoreUnresolvableNestedPlaceholders( true );
		environment.getPropertySources().addLast( new PropertiesPropertySource( propertySourceName, propertyLoader.loadProperties() ) );
	}

}
