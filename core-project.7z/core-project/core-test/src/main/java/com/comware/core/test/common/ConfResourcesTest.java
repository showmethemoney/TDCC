package com.comware.core.test.common;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;


/**
 * @author Robin
 * @createdDate Sep 17, 2014
 */
public class ConfResourcesTest
{

	private static final String ENV_ROOT_DIR = "conf";
	private static final String RESOURCE_DIR = "resources";
	static final String MAIN_RESOURCE_DIR = "src/main/resources";
	private static final String TEST_RESOURCE_DIR = "src/test/resources";

	static final List<String> IGNORED_DIRS = Arrays.asList( "CVS", ".svn" );

	private List<String> envResourceDirs;

	public void initializeEnvResourceDirs() {
		File envRootDir = new File( ENV_ROOT_DIR );
		Assert.assertTrue( "env root directory does not exist, please check: " + envRootDir.getAbsolutePath(), envRootDir.exists() );
		Assert.assertTrue( "env root directory is not a directory, please check: " + envRootDir.getAbsolutePath(), envRootDir.isDirectory() );

		File[] envDirs = envRootDir.listFiles( new FileFilter() {
			public boolean accept(File file) {
				return file.isDirectory() && !IGNORED_DIRS.contains( file.getName() );
			}
		} );

		envResourceDirs = new ArrayList<String>();
		for (File dir : envDirs) {
			// like: /conf/{env}/resources/
			envResourceDirs.add( String.format( "%s/%s/%s", ENV_ROOT_DIR, dir.getName(), RESOURCE_DIR ) );
		}
	}

	public void validateEnvConfigFiles() {
		boolean foundError = false;
		StringBuilder errorMessage = new StringBuilder( "unnecessary resources found:\n" );
		for (String envResourceDir : envResourceDirs) {
			EnvResourcesValidator validator = new EnvResourcesValidator( envResourceDir );
			List<String> unnecessaryResources = validator.getUnnecessaryResources();
			if (!unnecessaryResources.isEmpty()) {
				foundError = true;
				errorMessage.append( createUnnecessaryResourcesErrorMessage( unnecessaryResources, envResourceDir ) );
			}
		}

		Assert.assertFalse( errorMessage.toString(), foundError );
	}

	private String createUnnecessaryResourcesErrorMessage(List<String> envResources, String envResourceDir) {
		StringBuilder builder = new StringBuilder();
		for (String resource : envResources) {
			builder.append( "\t" );
			builder.append( envResourceDir ).append( "/" ).append( resource );
			builder.append( "\n" );
		}
		return builder.toString();
	}

	public void validateEnvPropertyFiles() throws Exception {
		List<String> inconsistentPropertyFiles = new ArrayList<String>();
		for (String envResourceDir : envResourceDirs) {
			EnvPropertiesValidator validator = new EnvPropertiesValidator( envResourceDir );
			List<String> envInconsistentPropertyFiles = validator.compareToMainProperties();
			inconsistentPropertyFiles.addAll( envInconsistentPropertyFiles );
		}

		Assert.assertTrue( buildInconsistentPropertiesErrorMessage( inconsistentPropertyFiles ), inconsistentPropertyFiles.isEmpty() );
	}

	public void validateTestPropertyFiles() throws Exception {
		EnvPropertiesValidator validator = new EnvPropertiesValidator( TEST_RESOURCE_DIR );
		List<String> testInconsistentPropertyFiles = validator.compareToMainProperties();

		Assert.assertTrue( buildInconsistentPropertiesErrorMessage( testInconsistentPropertyFiles ), testInconsistentPropertyFiles.isEmpty() );
	}

	private String buildInconsistentPropertiesErrorMessage(List<String> inconsistentPropertyFiles) {
		StringBuilder builder = new StringBuilder( "inconsistent property files found:\n" );
		for (String resource : inconsistentPropertyFiles) {
			builder.append( "\t" );
			builder.append( resource );
			builder.append( "\n" );
		}
		return builder.toString();
	}

}
