TODO:
- to customize freemarker if tag, to simple null judge
- to support CSV/Excel/PDF view, also provide some excel/pdf/csv common utilities (can consider to build a new sub project)
- to support db-migration
- implement @Protected for API
- implement @Track, default will log debug infos if > 5s, can override this behavior by @Track


-------------------------------
History:
1.0.2
- add Query.empty(), and Query.putParams(Map) 

1.0.1
- add Page and OrderBy utility
- add JPAAccess.findPage(Query) to support pagable query, and return total count and pages in page info
- add Holder utility, to hold extra infos for domain objects, to simple pass values from controller to page

1.0.0
- initial version, built on SpringMVC
