package com.comwave.core.domain;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Transient;

/**
 * @author Robin
 * @createdDate Oct 27, 2014
 */
@SuppressWarnings("unchecked")
public class Holder {

    private static final String KEY_EXT1 = "ext1";
    private static final String KEY_EXT2 = "ext2";
    private static final String KEY_EXT3 = "ext3";

    @Transient
    private Object data;
    @Transient
    private final Map<String, Object> exts = new HashMap<String, Object>();

    public Holder() {
    }

    public Holder(Object data) {
        this.data = data;
    }

    public <T> T getData() {
        return (T) data;
    }

    public <T> T setData(T data) {
        Object old = this.data;
        this.data = data;
        return (T) old;
    }

    public <T> T getExt1() {
        return (T) exts.get(KEY_EXT1);
    }

    public <T> T setExt1(T ext1) {
        return (T) exts.put(KEY_EXT1, ext1);
    }

    public <T> T getExt2() {
        return (T) exts.get(KEY_EXT2);
    }

    public <T> T setExt2(T ext2) {
        return (T) exts.put(KEY_EXT2, ext2);
    }

    public <T> T getExt3() {
        return (T) exts.get(KEY_EXT3);
    }

    public <T> T setExt3(T ext3) {
        return (T) exts.put(KEY_EXT3, ext3);
    }

    public <T> T setExt(String key, T ext) {
        return (T) exts.put(key, ext);
    }

    public <T> T getExt(String key) {
        return (T) exts.get(key);
    }

    public Map<String, Object> getExts() {
        return exts;
    }

}
