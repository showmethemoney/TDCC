package com.comwave.core.database;

import java.util.Map;

import javax.persistence.EntityManager;

import com.google.common.collect.Maps;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class Query {

    final StringBuilder queryString;
    final Map<String, Object> params = Maps.newHashMap();
    private Page page;
    Integer from;
    Integer size;

    private Query(String queryString) {
        this.queryString = new StringBuilder(512);
        this.queryString.append(queryString);
    }

    public static Query empty() {
        return new Query("");
    }

    public static Query create(String queryString) {
        return new Query(queryString);
    }

    public static Query from(Class<?> entityClass) {
        return new Query("from ").append(entityClass);
    }

    public Query append(String queryString) {
        this.queryString.append(queryString);
        return this;
    }

    public Query append(Class<?> entityClass) {
        this.queryString.append(entityClass.getName());
        return this;
    }

    public Query where(String whereClause) {
        return append(" where ").append(whereClause);
    }

    public Query orderBy(String orderByClause) {
        return append(" order by ").append(orderByClause);
    }

    public Query orderBy(OrderBy orderBy) {
        return orderBy(orderBy.getClause());
    }

    public Query param(String key, Object value) {
        params.put(key, value);
        return this;
    }

    public void setParam(String key, Object value) {
        param(key, value);
    }

    public void putParams(Map<String, Object> params) {
        this.params.putAll(params);
    }

    public Query page(Page page) {
        this.page = page;
        if (page == null)
            return this;

        this.from(page.getFirstResult()).fetch(page.getPageSize());
        return this;
    }

    public Page page() {
        if (page != null)
            return page;

        if (from != null && size != null) {
            page = new Page(from / size + 1, size); // indicates that: from % size == 0
            return page;
        }
        return null;
    }

    public Query from(int from) {
        this.from = from;
        return this;
    }

    public Query fetch(int size) {
        this.size = size;
        return this;
    }

    javax.persistence.Query query(EntityManager entityManager) {
        javax.persistence.Query query = entityManager.createQuery(queryString.toString());
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }

        if (from != null && size != null) {
            query.setFirstResult(from);
            query.setMaxResults(size);
        }
        return query;
    }

    Query pageQuery() {
        String pqs = " " + queryString.toString();
        int start = pqs.toLowerCase().indexOf(" from ");
        if (start < 0)
            throw new IllegalStateException("query string is not valid");

        StringBuilder pageQueryString = new StringBuilder("select count(1)");

        int end = pqs.toLowerCase().indexOf(" order by ");
        if (end < 0)
            pageQueryString.append(pqs.substring(start));
        else
            pageQueryString.append(pqs.substring(start, end));

        Query pageQuery = Query.create(pageQueryString.toString());
        pageQuery.params.putAll(params);
        return pageQuery;
    }

    @Override
    public String toString() {
        return String.format("{queryString='%s', params=%s, from=%d, size=%d}", queryString, params, from, size);
    }

}
