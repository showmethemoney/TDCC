package com.comwave.core.database;

import javax.inject.Inject;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
public abstract class CompositeDaoSupport<T> extends JPADaoSupport<T> {

    protected JDBCAccess jdbcAccess;

    protected final RowMapper<T> rowMapper;

    public CompositeDaoSupport() {
        super();
        rowMapper = EntityRowMapper.rowMapper(entityClass);
    }

    // just to skip Findbugs plugin validation
    protected JDBCAccess getJdbcAccess() {
        return jdbcAccess;
    }

    @Inject
    public void setJdbcAccess(JDBCAccess jdbcAccess) {
        this.jdbcAccess = jdbcAccess;
    }

}
