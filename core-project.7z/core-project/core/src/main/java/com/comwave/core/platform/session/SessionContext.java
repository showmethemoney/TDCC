package com.comwave.core.platform.session;

import java.util.HashMap;
import java.util.Map;

import com.comwave.core.json.JSONBinder;
import com.comwave.core.util.ReadOnly;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class SessionContext {

    private final ReadOnly<String> sessionId = new ReadOnly<>();
    private final Map<String, String> datas = new HashMap<>();
    private boolean changed;
    private boolean invalidated;

    public <T> void set(SessionKey<T> key, T value) {
        datas.put(key.name(), JSONBinder.toJSON(value));
        changed = true;
    }

    public <T> T get(SessionKey<T> key) {
        String value = datas.get(key.name());
        if (value == null)
            return null;
        return JSONBinder.fromJSON(key.type(), value);
    }

    public void invalidate() {
        datas.clear();
        changed = true;
        invalidated = true;
    }

    boolean changed() {
        return changed;
    }

    boolean invalidated() {
        return invalidated;
    }

    String sessionId() {
        return sessionId.value();
    }

    void setSessionId(String sessionId) {
        this.sessionId.set(sessionId);
    }

    void putSessionData(Map<String, String> sessionData) {
        datas.putAll(sessionData);
    }

    Map<String, String> sessionData() {
        return datas;
    }

    void markSaved() {
        changed = false;
    }

    void requireNewSessionId() {
        changed = true;
    }

}
