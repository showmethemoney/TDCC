package com.comwave.core.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class ClasspathResource {

    private byte[] bytes;
    private final String resourcePath;

    private ClasspathResource(String resourcePath) {
        this.resourcePath = resourcePath;
        InputStream stream = null;
        try {
            stream = ClasspathResource.class.getClassLoader().getResourceAsStream(resourcePath);
            if (stream == null)
                throw new IllegalArgumentException("can not load resource, path=" + resourcePath);
            bytes = IOUtils.bytes(stream);
        } finally {
            IOUtils.close(stream);
        }
    }

    public static ClasspathResource resource(String resourcePath) {
        return new ClasspathResource(resourcePath);
    }

    public InputStream inputStream() {
        return new ByteArrayInputStream(bytes);
    }

    public String text() {
        return text(Charset.defaultCharset());
    }

    public String text(Charset charset) {
        return new String(bytes, charset);
    }

    public byte[] bytes() {
        return bytes;
    }

    public String resourcePath() {
        return resourcePath;
    }

}
