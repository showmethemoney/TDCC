package com.comwave.core.platform.handler;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.handler.AbstractHandlerMapping;

import com.comwave.core.exception.ResourceNotFoundException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ResourceNotFoundHandlerMapping extends AbstractHandlerMapping {

    public ResourceNotFoundHandlerMapping() {
        setOrder(LOWEST_PRECEDENCE);
    }

    @Override
    protected Object getHandlerInternal(HttpServletRequest request) throws Exception {
        throw new ResourceNotFoundException(request.getServletPath() + " not found");
    }

}
