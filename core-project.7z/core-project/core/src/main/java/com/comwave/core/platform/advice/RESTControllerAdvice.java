package com.comwave.core.platform.advice;

import java.util.Locale;

import javax.inject.Inject;

import org.springframework.beans.TypeMismatchException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.comwave.core.exception.InvalidRequestException;
import com.comwave.core.exception.ResourceNotFoundException;
import com.comwave.core.exception.UserAuthorizationException;
import com.comwave.core.platform.error.ErrorResponse;
import com.comwave.core.platform.error.ErrorResponseBuilder;
import com.comwave.core.platform.error.FieldError;
import com.comwave.core.platform.error.ValidationErrorResponse;
import com.comwave.core.platform.i18n.Messages;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@ControllerAdvice(annotations = RestController.class)
public class RESTControllerAdvice {

    @Inject
    Messages messages;
    @Inject
    ErrorResponseBuilder errorResponseBuilder;

    @ExceptionHandler
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponse error(Throwable e) {
        return errorResponseBuilder.createErrorResponse(e);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ErrorResponse notFound(ResourceNotFoundException e) {
        return errorResponseBuilder.createErrorResponse(e);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ErrorResponse unauthorized(UserAuthorizationException e) {
        return errorResponseBuilder.createErrorResponse(e);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorResponse validationError(HttpMessageNotReadableException e) {
        return createValidationResponse(e);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorResponse validationError(TypeMismatchException e) {
        return createValidationResponse(e);
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorResponse validationError(BindException e) {
        return createValidationResponse(e.getBindingResult());
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorResponse validationError(MethodArgumentNotValidException e) {
        return createValidationResponse(e.getBindingResult());
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorResponse validationError(InvalidRequestException e) {
        Locale locale = LocaleContextHolder.getLocale();
        ValidationErrorResponse response = new ValidationErrorResponse();
        FieldError error = new FieldError();
        error.setField(e.field());
        error.setMessage(messages.getMessage(e.getMessage(), locale));
        response.getFieldErrors().add(error);
        return response;
    }

    private ValidationErrorResponse createValidationResponse(Exception e) {
        ValidationErrorResponse response = new ValidationErrorResponse();
        FieldError error = new FieldError();
        error.setMessage(e.getMessage());
        response.getFieldErrors().add(error);
        return response;
    }

    private ValidationErrorResponse createValidationResponse(BindingResult bindingResult) {
        Locale locale = LocaleContextHolder.getLocale();
        ValidationErrorResponse response = new ValidationErrorResponse();
        for (org.springframework.validation.FieldError fieldError : bindingResult.getFieldErrors()) {
            FieldError error = new FieldError();
            error.setField(fieldError.getField());
            error.setMessage(messages.getMessage(fieldError, locale));
            response.getFieldErrors().add(error);
        }
        return response;
    }

}
