package com.comwave.core.database;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.GenericTypeResolver;

import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
public abstract class JPADaoSupport<T> {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    protected JPAAccess jpaAccess;

    protected final Class<T> entityClass;

    @SuppressWarnings("unchecked")
    public JPADaoSupport() {
        Class<?>[] arguments = GenericTypeResolver.resolveTypeArguments(getClass(), JPADaoSupport.class);
        AssertUtils.assertTrue(arguments != null && arguments.length == 1, "repository must extend with generic type like JPADaoSupport<T>, class={}", getClass());
        entityClass = (Class<T>) arguments[0];
    }

    public T get(Object id) {
        return jpaAccess.get(entityClass, id);
    }

    public void save(T entity) {
        jpaAccess.save(entity);
    }

    public void update(T entity) {
        jpaAccess.update(entity);
    }

    public void delete(T entity) {
        jpaAccess.delete(entity);
    }

    @Inject
    public void setJpaAccess(JPAAccess jpaAccess) {
        this.jpaAccess = jpaAccess;
    }

}
