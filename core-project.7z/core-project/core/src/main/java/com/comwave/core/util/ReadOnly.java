package com.comwave.core.util;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class ReadOnly<T> {

    private T value;
    private boolean assigned;

    public boolean assigned() {
        return assigned;
    }

    public T value() {
        return value;
    }

    public void set(T value) {
        if (assigned)
            throw new IllegalStateException("value has been assigned, oldValue=" + this.value + ", newValue=" + value);

        this.value = value;
        assigned = true;
    }

    public boolean valueEquals(T otherValue) {
        return value == null && otherValue == null || otherValue != null && otherValue.equals(value);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

}
