package com.comwave.core.scheduler;

import java.util.UUID;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.error.ErrorHandler;
import com.comwave.core.log.trace.TraceLogger;
import com.comwave.core.util.ClassUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class JobProxy implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(JobProxy.class);

    @Inject
    private TraceLogger traceLogger;
    @Inject
    private ErrorHandler errorHandler;

    private final Job job;

    public JobProxy(Job job) {
        this.job = job;
    }

    @Override
    public void run() {
        try {
            traceLogger.initialize();
            traceLogger.setRequestId(UUID.randomUUID().toString());
            traceLogger.setAction(ClassUtils.getSimpleOriginalClassName(job));
            traceLogger.logContext("job_class", job.getClass().getName());

            logger.debug("=== start job execution ===");
            job.execute();
        } catch (Throwable e) {
            errorHandler.handle(e);
        } finally {
            logger.debug("=== finish job execution ===");
            traceLogger.cleanup();
        }
    }

    @Override
    public String toString() {
        return String.format("JobProxy{job=%s}", job);
    }

}
