package com.comwave.core.platform.error;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import com.comwave.core.platform.model.ModelContext;
import com.comwave.core.platform.request.RequestContext;
import com.comwave.core.platform.setting.RuntimeEnvironment;
import com.comwave.core.platform.setting.RuntimeSettings;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ErrorPageModelBuilder {

    private static final String ERROR_MESSAGE_NULL_POINTER_EXCEPTION = "null pointer exception";

    @Inject
    RuntimeSettings runtimeSettings;
    @Inject
    RequestContext requestContext;
    @Inject
    ModelContext modelContext;

    public Map<String, Object> buildErrorPageModel(Throwable exception) {
        return buildErrorPageModel(getErrorMessage(exception), exception);
    }

    private String getErrorMessage(Throwable exception) {
        if (exception instanceof NullPointerException)
            return ERROR_MESSAGE_NULL_POINTER_EXCEPTION;
        return exception.getMessage();
    }

    public Map<String, Object> buildErrorPageModel(String errorMessage, Throwable exception) {
        Map<String, Object> model = new HashMap<>();
        if (RuntimeEnvironment.DEV.equals(runtimeSettings.environment())) {
            model.put("exception", new ExceptionInfo(errorMessage, exception));
        }

        model.put("requestContext", requestContext);
        modelContext.mergeTo(model);
        return model;
    }

}
