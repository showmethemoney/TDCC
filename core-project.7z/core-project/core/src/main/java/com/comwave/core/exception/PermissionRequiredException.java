package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@WarningException
public class PermissionRequiredException extends RuntimeException {

    private String[] permissions;

    public PermissionRequiredException(String message) {
        super(message);
    }

    public PermissionRequiredException(String message, String[] permissions) {
        super(message);
        this.permissions = permissions;
    }

    public PermissionRequiredException(String message, Throwable cause) {
        super(message, cause);
    }

    public String[] getPermissions() {
        return permissions;
    }

}
