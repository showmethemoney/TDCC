package com.comwave.core.platform.session;

import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.platform.cookie.CookieContext;
import com.comwave.core.platform.cookie.CookieInterceptor;
import com.comwave.core.platform.cookie.CookieSpec;
import com.comwave.core.platform.helper.ControllerHelper;
import com.comwave.core.platform.session.provider.SessionProviderRegister;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class SessionInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(SessionInterceptor.class);

    private static final CookieSpec<String> SESSION_ID = CookieSpec.stringKey("SessionId").withPath("/").inSessionScope().withHttpOnly();
    private static final CookieSpec<String> SECURE_SESSION_ID = CookieSpec.stringKey("SecureSessionId").withPath("/").inSessionScope().withHttpOnly().withSecure();

    private static final String CONTEXT_INITIALIZED = SessionInterceptor.class.getName() + ".CONTEXT_INITIALIZED";

    @Inject
    private CookieContext cookieContext;
    @Inject
    private SessionContext sessionContext;
    @Inject
    private SecureSessionContext secureSessionContext;
    @Inject
    private CookieInterceptor cookieInterceptor;

    @Inject
    private SpringObjectFactory springObjectFactory;
    @Inject
    private SiteSettings siteSettings;

    private SessionProvider sessionProvider;

    @PostConstruct
    public void initialize() {
        sessionProvider = SessionProviderRegister.register(springObjectFactory, siteSettings);
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", SessionInterceptor.class.getName());

        // if not annotated @RequiredSession, will NOT populate session values
        if (!requireSession(handler))
            return true;

        // only process non-forwarded request, to make sure only init once per request
        if (!initialized(request)) {
            logger.debug("populate session context");
            AssertUtils.assertTrue(cookieInterceptor.initialized(request), "sessionInterceptor depends on cookieInterceptor, please check WebConfig");

            loadSessionData(sessionContext, SESSION_ID);
            if (request.isSecure()) {
                secureSessionContext.underSecure();
                loadSessionData(secureSessionContext, SECURE_SESSION_ID);
            }

            request.setAttribute(CONTEXT_INITIALIZED, Boolean.TRUE);
        }
        return true;
    }

    private boolean initialized(HttpServletRequest request) {
        Boolean initialized = (Boolean) request.getAttribute(CONTEXT_INITIALIZED);
        return Boolean.TRUE.equals(initialized);
    }

    private boolean requireSession(Object handler) {
        return ControllerHelper.findMethodOrClassLevelAnnotation(handler, RequireSession.class) != null;
    }

    private void loadSessionData(SessionContext sessionContext, CookieSpec<String> sessionCookie) {
        String sessionId = cookieContext.getCookie(sessionCookie);
        if (sessionId != null) {
            Map<String, String> sessionData = sessionProvider.getAndRefresh(sessionId);
            if (sessionData != null) {
                sessionContext.setSessionId(sessionId);
                sessionContext.putSessionData(sessionData);
                logger.debug("loaded session datas for session id:{}", sessionId);

            } else {
                sessionContext.requireNewSessionId();
                logger.debug("can not find session, generate new session id to replace old one:{}", sessionId);
            }
        } else {
            logger.debug("can not find session id");
        }
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        logger.debug("post, {}", SessionInterceptor.class.getName());
        saveSessionData(request);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        logger.debug("after, {}", SessionInterceptor.class.getName());
        // 1. if some interceptor break the preHandle by returning false, all postHandle will be skipped, to try to save session on completion if possible
        // 2. due to setCookies only works before view is rendered
        saveSessionData(request);
    }

    private void saveSessionData(HttpServletRequest request) {
        saveSessionData(sessionContext, SESSION_ID);
        if (request.isSecure()) {
            saveSessionData(secureSessionContext, SECURE_SESSION_ID);
        }
    }

    private void saveSessionData(SessionContext sessionContext, CookieSpec<String> sessionCookie) {
        if (sessionContext.changed()) {
            if (sessionContext.invalidated()) {
                deleteSession(sessionContext, sessionCookie);
            } else {
                persistSession(sessionContext, sessionCookie);
            }
            sessionContext.markSaved();
        }
    }

    private void deleteSession(SessionContext sessionContext, CookieSpec<String> sessionCookie) {
        String sessionId = sessionContext.sessionId();
        if (sessionId == null)
            return;

        sessionProvider.clear(sessionId);
        cookieContext.deleteCookie(sessionCookie);
        logger.debug("delete session:{}", sessionId);
    }

    private void persistSession(SessionContext sessionContext, CookieSpec<String> sessionCookie) {
        String sessionId = sessionContext.sessionId();
        if (sessionId == null) {
            sessionId = UUID.randomUUID().toString();
            sessionContext.setSessionId(sessionId);
            cookieContext.setCookie(sessionCookie, sessionId);
            logger.debug("generate new session id:{}", sessionId);
        }

        sessionProvider.save(sessionId, sessionContext.sessionData());
        logger.debug("saved session datas for session id:{}", sessionId);
    }

}
