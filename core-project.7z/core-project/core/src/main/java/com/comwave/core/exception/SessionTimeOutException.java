package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@WarningException
public class SessionTimeOutException extends RuntimeException {

    public SessionTimeOutException(String message) {
        super(message);
    }

    public SessionTimeOutException(String message, Throwable cause) {
        super(message, cause);
    }

}
