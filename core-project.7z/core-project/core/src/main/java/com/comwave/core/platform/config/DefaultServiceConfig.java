package com.comwave.core.platform.config;

import org.springframework.context.annotation.Bean;

import com.comwave.core.platform.advice.RESTErrorControllerAdvice;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class DefaultServiceConfig extends DefaultConfig {

    @Bean
    RESTErrorControllerAdvice restErrorControllerAdvice() {
        return new RESTErrorControllerAdvice();
    }

}
