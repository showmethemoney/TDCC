package com.comwave.core.platform.tag;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;

import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CSSTag extends ResourceTagSupport implements TemplateDirectiveModel {

    public static final String TAG_NAME = "css";
    private static final String CSS_TAG_TEMPLATE = "<link type=\"text/css\" rel=\"stylesheet\" href=\"%s\"%s/>";

    public CSSTag(HttpServletRequest request, RuntimeSettings runtimeSettings, SiteSettings siteSettings) {
        super(request, runtimeSettings, siteSettings);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    protected String buildResourceTag(Map params) throws TemplateException, IOException {
        return buildMultipleResourceTags("href", siteSettings.cssDir(), CSS_TAG_TEMPLATE, params);
    }

}
