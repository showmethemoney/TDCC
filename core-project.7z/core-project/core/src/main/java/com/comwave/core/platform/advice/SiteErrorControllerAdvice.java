package com.comwave.core.platform.advice;

import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.comwave.core.exception.LoginRequiredException;
import com.comwave.core.exception.PermissionRequiredException;
import com.comwave.core.exception.ResourceNotFoundException;
import com.comwave.core.exception.SessionTimeOutException;
import com.comwave.core.platform.error.ErrorPageModelBuilder;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.request.RequestContext;
import com.comwave.core.platform.setting.SiteSettings;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@ControllerAdvice
public class SiteErrorControllerAdvice {

    @Inject
    Messages messages;
    @Inject
    ErrorPageModelBuilder errorPageModelBuilder;
    @Inject
    RequestContext requestContext;
    @Inject
    SiteSettings siteSettings;

    @ModelAttribute("requestContext")
    public RequestContext requestContext() {
        return requestContext;
    }

    @ExceptionHandler
    public ModelAndView error(Throwable exception, HttpServletResponse response) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        String errorPage = siteSettings.errorPage();
        setStatus(errorPage, response, HttpStatus.INTERNAL_SERVER_ERROR);
        return new ModelAndView(errorPage, model);
    }

    @ExceptionHandler
    public ModelAndView methodNotAllowed(HttpRequestMethodNotSupportedException exception, HttpServletResponse response) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        String resourceNotFoundPage = siteSettings.resourceNotFoundPage();
        setStatus(resourceNotFoundPage, response, HttpStatus.METHOD_NOT_ALLOWED);
        return new ModelAndView(resourceNotFoundPage, model);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ModelAndView notFound(ResourceNotFoundException exception, HttpServletResponse response) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        String resourceNotFoundPage = siteSettings.resourceNotFoundPage();
        setStatus(resourceNotFoundPage, response, HttpStatus.NOT_FOUND);
        return new ModelAndView(resourceNotFoundPage, model);
    }

    // due to spring RedirectView use @ResponseStatus with http10Compatible=false, set status code explicitly
    private void setStatus(String view, HttpServletResponse response, HttpStatus status) {
        if (view != null && view.startsWith("redirect:"))
            response.setStatus(HttpStatus.SEE_OTHER.value());
        else
            response.setStatus(status.value());
    }

    @ExceptionHandler
    public ModelAndView loginRequired(LoginRequiredException exception) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        return new ModelAndView(siteSettings.loginPage(), model);
    }

    @ExceptionHandler
    public ModelAndView permissionRequired(PermissionRequiredException exception) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        return new ModelAndView(siteSettings.permissionNotAllowedPage(), model);
    }

    @ExceptionHandler
    public ModelAndView sessionTimeOut(SessionTimeOutException exception) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(exception);
        return new ModelAndView(siteSettings.sessionTimeOutPage(), model);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ModelAndView validationError(MethodArgumentNotValidException exception, HttpServletResponse response) {
        return validationErrorPage(exception, exception.getBindingResult(), response);
    }

    @ExceptionHandler(BindException.class)
    public ModelAndView validationError(BindException exception, HttpServletResponse response) {
        return validationErrorPage(exception, exception.getBindingResult(), response);
    }

    private ModelAndView validationErrorPage(Exception exception, BindingResult bindingResult, HttpServletResponse response) {
        Map<String, Object> model = errorPageModelBuilder.buildErrorPageModel(buildValidationErrorMessage(bindingResult), exception);
        String errorPage = siteSettings.errorPage();
        setStatus(errorPage, response, HttpStatus.BAD_REQUEST);
        return new ModelAndView(errorPage, model);
    }

    private String buildValidationErrorMessage(BindingResult bindingResult) {
        Locale locale = LocaleContextHolder.getLocale();
        StringBuilder builder = new StringBuilder(120);
        for (FieldError fieldError : bindingResult.getFieldErrors()) {
            builder.append(fieldError.getObjectName()).append('.').append(fieldError.getField()).append(" => ").append(messages.getMessage(fieldError, locale)).append(", rejectedValue=")
                    .append(fieldError.getRejectedValue()).append('\n');
        }
        return builder.toString();
    }

}
