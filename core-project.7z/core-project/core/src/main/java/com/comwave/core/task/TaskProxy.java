package com.comwave.core.task;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.error.ErrorHandler;
import com.comwave.core.log.trace.TraceLogger;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class TaskProxy<T> implements Callable<T> {

    private final Logger logger = LoggerFactory.getLogger(TaskProxy.class);

    private final TraceLogger traceLogger;
    private final ErrorHandler errorHandler;

    private final Callable<T> delegate;
    private final String requestId;
    private final String action;

    public TaskProxy(Callable<T> delegate, TraceLogger traceLogger, ErrorHandler errorHandler) {
        this.traceLogger = traceLogger;
        this.errorHandler = errorHandler;

        this.delegate = delegate;

        action = traceLogger.action() + "/" + delegate.getClass().getName();
        requestId = traceLogger.requestId();
    }

    @Override
    public T call() throws Exception {
        try {
            traceLogger.initialize();
            traceLogger.setRequestId(requestId);
            traceLogger.setAction(action);

            logger.debug("start task, task={}, currentThreadId={}", delegate, Thread.currentThread().getId());
            return delegate.call();
        } catch (Exception e) {
            errorHandler.handle(e);
            throw e;
        } finally {
            logger.debug("finish task, task={}, currentThreadId={}", delegate, Thread.currentThread().getId());
            traceLogger.cleanup();
        }
    }

}
