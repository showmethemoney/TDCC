package com.comwave.core.template;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class TemplateException extends RuntimeException {

    public TemplateException(Throwable cause) {
        super(cause);
    }

}
