package com.comwave.core.platform.view;

import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class DefaultFreeMarkerViewResolver extends FreeMarkerViewResolver {

    public String buildFullTemplatePath(String template) {
        return String.format("%s%s%s", getPrefix(), template, getSuffix());
    }

}
