package com.comwave.core.platform.tag;

import java.io.IOException;
import java.util.Map;

import freemarker.core.Environment;
import freemarker.template.Template;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class MasterTag extends TagSupport implements TemplateDirectiveModel {

    public static final String TAG_NAME = "master";

    private final Map<String, Object> model;
    private final MasterTemplateLoader templateLoader;

    public MasterTag(Map<String, Object> model, MasterTemplateLoader templateLoader) {
        this.model = model;
        this.templateLoader = templateLoader;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        assertHasBody(body);

        model.putAll(params);
        model.put(BodyTag.BODY_TEMPLATE, body);

        String template = getRequiredStringParam(params, "template");
        Template masterTemplate = templateLoader.loadTemplate(template);
        masterTemplate.process(model, env.getOut());
    }

}
