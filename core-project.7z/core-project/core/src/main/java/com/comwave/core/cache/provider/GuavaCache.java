package com.comwave.core.cache.provider;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class GuavaCache extends AbstractCache {

    private final com.google.common.cache.Cache<Object, Object> cache;

    public GuavaCache(String name, com.google.common.cache.Cache<Object, Object> cache) {
        super(name, null);
        this.cache = cache;
    }

    @Override
    public Object getNativeCache() {
        return cache;
    }

    @Override
    public void putValue(String key, String value) {
        cache.put(key, value);
    }

    @Override
    public String getValue(String key) {
        return (String) cache.getIfPresent(key);
    }

    @Override
    public void evictValue(String key) {
        cache.invalidate(key);
    }

    @Override
    public void clearAll() {
        cache.invalidateAll();
    }

}
