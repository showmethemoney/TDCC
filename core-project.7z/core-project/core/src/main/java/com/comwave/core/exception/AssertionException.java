package com.comwave.core.exception;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class AssertionException extends RuntimeException {

    public AssertionException(String message) {
        super(message);
    }

}
