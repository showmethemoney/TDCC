package com.comwave.core.platform.interceptor;

import javax.inject.Inject;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * @author Robin
 * @createdDate Sep 26, 2014
 */
public class SetFlushModeToCommitInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(SetFlushModeToCommitInterceptor.class);

    @Inject
    private EntityManagerFactory entityManagerFactory;

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        EntityManagerHolder entityManagerHolder = (EntityManagerHolder) TransactionSynchronizationManager.getResource(entityManagerFactory);
        if (entityManagerHolder != null && entityManagerHolder.getEntityManager() != null) {
            logger.debug("before setting, flush mode is {}", entityManagerHolder.getEntityManager().getFlushMode());
            entityManagerHolder.getEntityManager().setFlushMode(FlushModeType.COMMIT);
            logger.debug("after setting, flush mode is {}", entityManagerHolder.getEntityManager().getFlushMode());
        }
        return true;
    }

}
