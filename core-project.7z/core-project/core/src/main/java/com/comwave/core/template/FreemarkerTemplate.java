package com.comwave.core.template;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;

import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.ObjectWrapper;
import freemarker.template.Template;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class FreemarkerTemplate {

    private final Configuration config;
    private final StringTemplateLoader loader;

    public FreemarkerTemplate() {
        config = new Configuration();
        loader = new StringTemplateLoader();
        config.setTemplateLoader(loader);
        config.setLocalizedLookup(false);
        config.setObjectWrapper(ObjectWrapper.DEFAULT_WRAPPER);
    }

    public void putTemplate(String name, String template) {
        loader.putTemplate(name, template);
    }

    public String transform(String templateName, Map<String, Object> context) {
        try {
            Template template = config.getTemplate(templateName);
            StringWriter writer = new StringWriter();
            template.process(context, writer);
            return writer.toString();
        } catch (IOException | freemarker.template.TemplateException e) {
            throw new TemplateException(e);
        }
    }

}
