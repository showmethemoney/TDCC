package com.comwave.core.log;

import com.comwave.core.log.filter.LogMessageFilter;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class LogSettings {

    private static final LogSettings INSTANCE = new LogSettings();

    private boolean alwaysWriteTraceLog = false;

    private LogMessageFilter logMessageFilter;

    public static LogSettings get() {
        return INSTANCE;
    }

    public boolean alwaysWriteTraceLog() {
        return alwaysWriteTraceLog;
    }

    public void setAlwaysWriteTraceLog(boolean alwaysWriteTraceLog) {
        this.alwaysWriteTraceLog = alwaysWriteTraceLog;
    }

    public LogMessageFilter logMessageFilter() {
        return logMessageFilter;
    }

    public void setLogMessageFilter(LogMessageFilter logMessageFilter) {
        this.logMessageFilter = logMessageFilter;
    }

}
