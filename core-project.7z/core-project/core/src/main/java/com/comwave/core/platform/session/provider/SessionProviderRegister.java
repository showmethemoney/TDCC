package com.comwave.core.platform.session.provider;

import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.platform.session.SessionProvider;
import com.comwave.core.platform.session.SessionProviderType;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 12, 2014
 */
public class SessionProviderRegister {

    private static final String SESSION_PROVIDER = "sessionProvider";

    public static SessionProvider register(SpringObjectFactory springObjectFactory, SiteSettings siteSettings) {
        SessionProviderType sessionProviderType = siteSettings.sessionProviderType();

        if (SessionProviderType.LOCAL.equals(sessionProviderType)) {
            springObjectFactory.registerSingletonBean(SESSION_PROVIDER, LocalSessionProvider.class);

        } else if (SessionProviderType.REDIS.equals(sessionProviderType)) {
            AssertUtils.assertHasText(siteSettings.remoteSessionServer(), "remote session server configuration is missing");
            springObjectFactory.registerSingletonBean(SESSION_PROVIDER, RedisSessionProvider.class);

        } else {
            throw new IllegalStateException("unsupported session provider type, type=" + sessionProviderType);
        }

        return springObjectFactory.bean(SessionProvider.class);
    }

}
