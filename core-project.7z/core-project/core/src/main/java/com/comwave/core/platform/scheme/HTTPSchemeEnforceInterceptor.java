package com.comwave.core.platform.scheme;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.comwave.core.platform.helper.ControllerHelper;
import com.comwave.core.platform.request.RequestContext;
import com.comwave.core.platform.request.RequestContextInterceptor;
import com.comwave.core.platform.url.UrlBuilder;
import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class HTTPSchemeEnforceInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(HTTPSchemeEnforceInterceptor.class);

    @Inject
    private RequestContextInterceptor requestContextInterceptor;
    @Inject
    private RequestContext requestContext;

    // http scheme enforce interceptor need to handle both request and forward dispatcher, because of "forward:" view
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", HTTPSchemeEnforceInterceptor.class.getName());
        AssertUtils.assertTrue(requestContextInterceptor.initialized(request), "httpSchemeEnforceInterceptor depends on requestContextInterceptor, please check WebConfig");

        HTTPOnly httpOnly = ControllerHelper.findMethodOrClassLevelAnnotation(handler, HTTPOnly.class);
        if (httpOnly != null && !HTTPScheme.HTTP.equals(request.getScheme())) {
            enforceScheme(request, response, HTTPScheme.HTTP);
            return false;
        }

        HTTPSOnly httpsOnly = ControllerHelper.findMethodOrClassLevelAnnotation(handler, HTTPSOnly.class);
        if (httpsOnly != null && !HTTPScheme.HTTPS.equals(request.getScheme())) {
            enforceScheme(request, response, HTTPScheme.HTTPS);
            return false;
        }

        return true;
    }

    private void enforceScheme(HttpServletRequest request, HttpServletResponse response, String scheme) {
        UrlBuilder builder = new UrlBuilder();
        builder.setScheme(scheme);
        builder.setContextPath(request.getContextPath());
        builder.setServerName(request.getServerName());
        builder.setLogicalUrl(requestContext.relativeUrlWithQueryString());

        String redirectUrl = builder.buildFullUrl();
        logger.debug("redirect to different scheme, redirectUrl={}", redirectUrl);

        response.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
        response.setHeader("Location", redirectUrl);
    }

}
