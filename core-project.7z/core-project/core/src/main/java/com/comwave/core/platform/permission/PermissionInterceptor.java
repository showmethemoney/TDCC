package com.comwave.core.platform.permission;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.comwave.core.exception.PermissionRequiredException;
import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.platform.helper.ControllerHelper;
import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
public class PermissionInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(PermissionInterceptor.class);

    @Inject
    private SpringObjectFactory springObjectFactory;

    private PermissionChecker permissionChecker;

    @PostConstruct
    public void initPermissionChecker() {
        permissionChecker = springObjectFactory.bean(PermissionChecker.class);
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", PermissionInterceptor.class.getName());

        RequirePermission requirePermission = permissionAnnotation(handler);
        if (requirePermission != null) {
            AssertUtils.assertNotNull(permissionChecker, "A permission checker implementation is required");
            if (!permissionChecker.checkPermission(requirePermission.value()))
                throw new PermissionRequiredException("permission required", requirePermission.value());
        }

        return true;
    }

    private RequirePermission permissionAnnotation(Object handler) {
        return ControllerHelper.findMethodOrClassLevelAnnotation(handler, RequirePermission.class);
    }

}
