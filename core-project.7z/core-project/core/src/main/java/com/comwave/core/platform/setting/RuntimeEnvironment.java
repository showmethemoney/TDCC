package com.comwave.core.platform.setting;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public enum RuntimeEnvironment {

    PROD, DEV

}
