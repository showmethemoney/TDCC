package com.comwave.core.platform.error;

import javax.inject.Inject;

import com.comwave.core.platform.setting.RuntimeEnvironment;
import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.util.ExceptionUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ErrorResponseBuilder {

    @Inject
    private RuntimeSettings runtimeSettings;

    public ErrorResponse createErrorResponse(Throwable e) {
        ErrorResponse error = new ErrorResponse();
        error.setMessage(e.getMessage());
        error.setExceptionClass(e.getClass().getName());
        if (runtimeSettings.environment() == RuntimeEnvironment.DEV) {
            error.setExceptionTrace(ExceptionUtils.stackTrace(e));
        }
        return error;
    }

}
