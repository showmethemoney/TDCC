package com.comwave.core.platform.monitor.view;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@XmlRootElement(name = "url-mappings")
@XmlAccessorType(XmlAccessType.FIELD)
public class URLMappings {

    @XmlElementWrapper(name = "mappings")
    @XmlElement(name = "mapping")
    private final List<URLMapping> mappings = new ArrayList<>();

    public List<URLMapping> getMappings() {
        return mappings;
    }

}
