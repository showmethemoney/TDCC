package com.comwave.core.util;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class StopWatch {

    private long start;

    public StopWatch() {
        reset();
    }

    public long reset() {
        long elapsedTime = elapsedTime();
        start = System.currentTimeMillis();
        return elapsedTime;
    }

    public long elapsedTime() {
        long end = System.currentTimeMillis();
        return end - start;
    }

}
