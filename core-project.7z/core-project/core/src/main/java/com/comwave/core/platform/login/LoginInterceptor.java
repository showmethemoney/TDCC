package com.comwave.core.platform.login;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.comwave.core.exception.LoginRequiredException;
import com.comwave.core.platform.helper.ControllerHelper;
import com.comwave.core.util.StringUtils;

/**
 * @author Robin
 * @createdDate Sep 12, 2014
 */
public class LoginInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(LoginInterceptor.class);

    @Inject
    private LoginContext loginContext;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", LoginInterceptor.class.getName());

        if (!(handler instanceof HandlerMethod))
            return true;

        if (!requireLogin(handler))
            return true;

        String loginedUserId = loginContext.loginedUserId();
        if (!StringUtils.hasText(loginedUserId))
            throw new LoginRequiredException("login required");

        return true;
    }

    private boolean requireLogin(Object handler) {
        return ControllerHelper.findMethodOrClassLevelAnnotation(handler, RequireLogin.class) != null;
    }

}
