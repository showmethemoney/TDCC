package com.comwave.core.platform.handler;

import static org.springframework.web.servlet.view.UrlBasedViewResolver.FORWARD_URL_PREFIX;
import static org.springframework.web.servlet.view.UrlBasedViewResolver.REDIRECT_URL_PREFIX;

import javax.servlet.DispatcherType;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.AbstractHandlerMapping;

import com.comwave.core.platform.url.UrlBuilder;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class DefaultHandlerMapping extends AbstractHandlerMapping {

    private final Logger logger = LoggerFactory.getLogger(DefaultHandlerMapping.class);

    private static final String MONITOR_URL_PREFIX = "/monitor";
    private static final String MANAGEMENT_URL_PREFIX = "/management";

    @Override
    protected final Object getHandlerInternal(HttpServletRequest request) throws Exception {
        // only handle request dispatch, not forward
        if (!DispatcherType.REQUEST.equals(request.getDispatcherType()))
            return null;
        logger.debug("process handler mapping, handlerMappingClass={}", getClass().getName());

        String path = request.getServletPath();
        if (path.startsWith(MONITOR_URL_PREFIX) || path.startsWith(MANAGEMENT_URL_PREFIX))
            return null;

        String view = getResultView(request);
        if (view == null)
            return null;

        if (view.startsWith(REDIRECT_URL_PREFIX)) {
            String redirectUrl = view.substring(REDIRECT_URL_PREFIX.length());

            UrlBuilder builder = new UrlBuilder();
            builder.setContextPath(request.getContextPath());
            builder.setLogicalUrl(redirectUrl);

            String targetRedirectUrl = builder.buildRelativeUrl();
            logger.debug("redirect, fromPath={}, toLogicalUrl={}, toUrl={}", path, redirectUrl, targetRedirectUrl);
            return new RedirectRequestHandler(targetRedirectUrl);
        }

        if (view.startsWith(FORWARD_URL_PREFIX)) {
            String forwardUrl = view.substring(FORWARD_URL_PREFIX.length());
            logger.debug("forward, from={}, to={}", path, forwardUrl);
            return new ForwardRequestHandler(forwardUrl);
        }

        throw new IllegalStateException("unknown view, view=" + view);
    }

    protected abstract String getResultView(HttpServletRequest request);

}
