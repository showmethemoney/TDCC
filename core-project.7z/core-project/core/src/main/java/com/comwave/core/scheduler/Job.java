package com.comwave.core.scheduler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface Job {

    void execute() throws Throwable;

}
