package com.comwave.core.database;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class URLSafeUUIDIdGenerator implements IdentifierGenerator {

    public static final String CLASS_NAME = "com.comwave.core.database.URLSafeUUIDIdGenerator";
    public static final int KEY_LENGTH = 22;

    @Override
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        UUID uuid = UUID.randomUUID();
        ByteBuffer buffer = ByteBuffer.wrap(new byte[16]);
        buffer.putLong(uuid.getMostSignificantBits());
        buffer.putLong(uuid.getLeastSignificantBits());
        return Base64.encodeBase64URLSafeString(buffer.array());
    }

}
