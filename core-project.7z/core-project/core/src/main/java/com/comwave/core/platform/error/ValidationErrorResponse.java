package com.comwave.core.platform.error;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.google.common.collect.Lists;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@XmlRootElement(name = "validation-error-response")
@XmlAccessorType(XmlAccessType.FIELD)
public class ValidationErrorResponse {

    @XmlElementWrapper(name = "field-errors")
    @XmlElement(name = "field-error")
    private final List<FieldError> fieldErrors = Lists.newArrayList();

    public List<FieldError> getFieldErrors() {
        return fieldErrors;
    }

}
