package com.comwave.core.platform.i18n;

import java.util.Locale;

import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class Messages extends ResourceBundleMessageSource {

    public String getMessage(String key, Object... arguments) {
        return super.getMessage(key, arguments, key, Locale.getDefault());
    }

}
