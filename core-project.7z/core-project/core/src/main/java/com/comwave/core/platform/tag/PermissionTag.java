package com.comwave.core.platform.tag;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.platform.permission.PermissionChecker;
import com.comwave.core.util.AssertUtils;
import com.comwave.core.util.StringUtils;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
public class PermissionTag extends TagSupport implements TemplateDirectiveModel {

    private final Logger logger = LoggerFactory.getLogger(PermissionTag.class);

    public static final String TAG_NAME = "permission";

    private final PermissionChecker permissionChecker;

    public PermissionTag(PermissionChecker permissionChecker) {
        this.permissionChecker = permissionChecker;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        String require = getRequiredStringParam(params, "require");
        if (!StringUtils.hasText(require))
            throw new TemplateModelException(String.format("require param is required by %s, and can be empty", getClass().getSimpleName()));

        String[] permissions = require.split(",");

        boolean allowed = false;
        try {
            AssertUtils.assertNotNull(permissionChecker, "A permission checker implementation is required");
            allowed = permissionChecker.checkPermission(permissions);
        } catch (Exception e) {
            logger.warn(e.getMessage(), e);
        }

        if (allowed) {
            Writer output = env.getOut();
            body.render(output);
        }
    }

}
