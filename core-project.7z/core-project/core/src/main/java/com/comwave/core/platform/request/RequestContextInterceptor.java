package com.comwave.core.platform.request;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.mvc.ParameterizableViewController;

import com.comwave.core.log.trace.TraceLogger;
import com.comwave.core.util.ClassUtils;
import com.comwave.core.util.StringUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RequestContextInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(RequestContextInterceptor.class);

    private static final String CONTEXT_INITIALIZED = RequestContextInterceptor.class.getName() + ".CONTEXT_INITIALIZED";
    private static final String HEADER_REQUEST_ID = "request-id";

    @Inject
    protected TraceLogger traceLogger;
    @Inject
    private RequestContextImpl requestContext;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", RequestContextInterceptor.class.getName());

        if (!initialized(request)) {
            populateRequestContext(request);
            request.setAttribute(CONTEXT_INITIALIZED, Boolean.TRUE);
        }

        assignAction(handler);

        return true;
    }

    public boolean initialized(HttpServletRequest request) {
        Boolean initialized = (Boolean) request.getAttribute(CONTEXT_INITIALIZED);
        return Boolean.TRUE.equals(initialized);
    }

    private void populateRequestContext(HttpServletRequest request) throws IOException {
        logger.debug("populate requestContext");
        if (request instanceof RequestWrapper) {
            requestContext.setHTTPRequest((RequestWrapper) request);
        } else {
            // e.g. DefaultMultipartHttpServletRequest
            RequestWrapper requestWrapper = new RequestWrapper(request);
            requestWrapper.initialize();
            requestContext.setHTTPRequest(requestWrapper);
        }
        requestContext.setRequestId(getRequestId(request));
        requestContext.setRequestDate(new Date());

        traceLogger.setRequestId(requestContext.requestId());
    }

    private String getRequestId(HttpServletRequest request) {
        String requestIdFromHeader = request.getHeader(HEADER_REQUEST_ID);
        if (StringUtils.hasText(requestIdFromHeader)) {
            RequestIdValidator.validateRequestId(requestIdFromHeader);
            return requestIdFromHeader;
        }
        logger.debug("request headers do not contain request-id, generate new one");
        return UUID.randomUUID().toString();
    }

    protected void assignAction(Object handler) {
        String currentHandler = getHandler(handler);
        logger.debug("current_handler={}", currentHandler);

        if (traceLogger.action() == null && handler instanceof HandlerMethod) {
            traceLogger.setAction(currentHandler);
        }
    }

    private String getHandler(Object handler) {
        if (handler instanceof HandlerMethod) {
            return String.format("%s-%s", ClassUtils.getSimpleOriginalClassName(((HandlerMethod) handler).getBean()), ((HandlerMethod) handler).getMethod().getName());
        } else if (handler instanceof ParameterizableViewController) {
            return ((ParameterizableViewController) handler).getViewName();
        }
        throw new IllegalStateException("unknown handler, handler=" + handler);
    }

}
