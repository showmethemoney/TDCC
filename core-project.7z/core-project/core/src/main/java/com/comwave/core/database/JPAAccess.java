package com.comwave.core.database;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.util.StopWatch;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class JPAAccess {

    private final Logger logger = LoggerFactory.getLogger(JPAAccess.class);

    private EntityManager entityManager;

    public <T> T get(Class<T> entityClass, Object id) {
        StopWatch watch = new StopWatch();
        try {
            return entityManager.find(entityClass, id);
        } finally {
            logger.debug("get, entityClass={}, id={}, elapsedTime={}", entityClass.getName(), id, watch.elapsedTime());
        }
    }

    public void save(Object entity) {
        StopWatch watch = new StopWatch();
        try {
            entityManager.persist(entity);
        } finally {
            logger.debug("save, entityClass={}, elapsedTime={}", entity.getClass().getName(), watch.elapsedTime());
        }
    }

    public void update(Object entity) {
        StopWatch watch = new StopWatch();
        try {
            entityManager.merge(entity);
        } finally {
            logger.debug("update, entityClass={}, elapsedTime={}", entity.getClass().getName(), watch.elapsedTime());
        }
    }

    public void delete(Object entity) {
        StopWatch watch = new StopWatch();
        try {
            entityManager.merge(entity);
            entityManager.remove(entity);
        } finally {
            logger.debug("delete, entityClass={}, elapsedTime={}", entity.getClass().getName(), watch.elapsedTime());
        }
    }

    public void refresh(Object entity) {
        StopWatch watch = new StopWatch();
        try {
            entityManager.refresh(entity);
        } finally {
            logger.debug("refresh, entityClass={}, elapsedTime={}", entity.getClass().getName(), watch.elapsedTime());
        }
    }

    public void detach(Object entity) {
        StopWatch watch = new StopWatch();
        try {
            entityManager.detach(entity);
        } finally {
            logger.debug("detach, entityClass={}, elapsedTime={}", entity.getClass().getName(), watch.elapsedTime());
        }
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> find(Query query) {
        StopWatch watch = new StopWatch();
        try {
            return query.query(entityManager).getResultList();
        } finally {
            logger.debug("find, query={}, params={}, from={}, size={}, elapsedTime={}", query.queryString, query.params, query.from, query.size, watch.elapsedTime());
        }
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> findPage(Query query) {
        Page page = query.page();
        if (page == null) {
            logger.debug("redirect to find, without page");
            return find(query);
        }

        StopWatch watch = new StopWatch();
        try {
            Long totalCount = findOne(query.pageQuery());
            page.setTotalCount(totalCount.intValue());

            return query.query(entityManager).getResultList();
        } finally {
            logger.debug("findPage, query={}, params={}, page size={}, current page={}, total count={}, total page={}, elapsedTime={}", query.queryString, query.params, page.getPageSize(),
                    page.getCurrentPage(), page.getTotalCount(), page.getTotalPage(), watch.elapsedTime());
        }
    }

    @SuppressWarnings("unchecked")
    public <T> T findOne(Query query) {
        StopWatch watch = new StopWatch();
        try {
            List<T> result = query.query(entityManager).getResultList();
            return getOne(result);
        } finally {
            logger.debug("findOne, query={}, params={}, elapsedTime={}", query.queryString, query.params, watch.elapsedTime());
        }
    }

    private <T> T getOne(List<T> result) {
        if (result.isEmpty())
            return null;
        if (result.size() > 1)
            throw new NonUniqueResultException("result returned more than one instance, returnedSize=" + result.size());
        return result.get(0);
    }

    public int update(Query query) {
        StopWatch watch = new StopWatch();
        try {
            return query.query(entityManager).executeUpdate();
        } finally {
            logger.debug("update, query={}, params={}, elapsedTime={}", query.queryString, query.params, watch.elapsedTime());
        }
    }

    public void flush() {
        StopWatch watch = new StopWatch();
        try {
            entityManager.flush();
        } finally {
            logger.debug("flush, elapsedTime={}", watch.elapsedTime());
        }
    }

    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

}
