package com.comwave.core.cache.provider;

import java.util.Set;

import com.comwave.core.database.RedisAccess;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RedisCache extends AbstractCache {

    private final RedisAccess redisAccess;

    public RedisCache(String name, TimeLength expirationTime, RedisAccess redisAccess) {
        super(name, expirationTime);
        this.redisAccess = redisAccess;
    }

    @Override
    public Object getNativeCache() {
        return redisAccess;
    }

    private String constructKey(String key) {
        return name + ":" + key;
    }

    @Override
    public void putValue(String key, String value) {
        String redisKey = constructKey(key);
        redisAccess.setExpire(redisKey, value, expirationTime);
    }

    @Override
    public String getValue(String key) {
        String redisKey = constructKey(key);
        return redisAccess.get(redisKey);
    }

    @Override
    public void evictValue(String key) {
        String redisKey = constructKey(key);
        redisAccess.del(redisKey);
    }

    @Override
    public void clearAll() {
        Set<String> keys = redisAccess.keys(name + ":");
        deleteInBatch(keys, 128);
    }

    protected void deleteInBatch(Set<String> keys, int batchSize) {
        String[] batch = new String[batchSize];
        int i = 0;
        for (String key : keys) {
            batch[i] = key;
            i++;
            if (i >= batchSize) {
                redisAccess.del(batch);
                i = 0;
            }
        }
        if (i > 0) {
            String[] remain = new String[i];
            System.arraycopy(batch, 0, remain, 0, i);
            redisAccess.del(remain);
        }
    }

}
