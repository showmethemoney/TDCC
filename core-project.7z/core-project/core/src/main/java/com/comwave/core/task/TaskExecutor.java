package com.comwave.core.task;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.PreDestroy;
import javax.inject.Inject;

import com.comwave.core.error.ErrorHandler;
import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.log.trace.TraceLogger;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class TaskExecutor {

    private final ExecutorService executorService;

    @Inject
    private SpringObjectFactory springObjectFactory;
    @Inject
    private TraceLogger traceLogger;
    @Inject
    private ErrorHandler errorHandler;

    private TaskExecutor(ExecutorService executorService) {
        this.executorService = executorService;
    }

    public static TaskExecutor fixedSizeExecutor(int threadPoolSize) {
        return new TaskExecutor(Executors.newFixedThreadPool(threadPoolSize));
    }

    public static TaskExecutor unlimitedExecutor() {
        return new TaskExecutor(Executors.newCachedThreadPool());
    }

    @PreDestroy
    public void shutdown() {
        executorService.shutdown();
    }

    public <T> Future<T> submit(Callable<T> task) {
        TaskProxy<T> proxy = createTaskProxy(task);
        return executorService.submit(proxy);
    }

    public <T> List<T> executeAll(List<? extends Callable<T>> tasks) {
        try {
            List<Callable<T>> proxyTasks = Lists.transform(tasks, new Function<Callable<T>, Callable<T>>() {
                @Override
                public Callable<T> apply(Callable<T> task) {
                    return createTaskProxy(task);
                }
            });
            List<Future<T>> futures = executorService.invokeAll(proxyTasks);

            List<T> results = new ArrayList<>(futures.size());
            for (Future<T> future : futures) {
                results.add(future.get());
            }
            return results;
        } catch (InterruptedException | ExecutionException e) {
            throw new TaskExecutionException(e);
        }
    }

    private <T> TaskProxy<T> createTaskProxy(Callable<T> task) {
        Callable<T> taskBean = springObjectFactory.initialize(task);
        return new TaskProxy<>(taskBean, traceLogger, errorHandler);
    }

}
