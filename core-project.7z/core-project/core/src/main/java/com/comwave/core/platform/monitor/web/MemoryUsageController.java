package com.comwave.core.platform.monitor.web;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@RestController
public class MemoryUsageController {

    @RequestMapping(value = "/monitor/memory", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
    public String memoryUsage() {
        StringBuilder builder = new StringBuilder(512);

        MemoryUsage heapUsage = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        builder.append("Heap Usage:\n").append(heapUsage);

        MemoryUsage nonHeapMemoryUsage = ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage();
        builder.append("\n\nNonHeap Usage:\n").append(nonHeapMemoryUsage);

        builder.append("\n\nMemory Pools:\n");
        List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
        for (MemoryPoolMXBean pool : pools) {
            builder.append(pool.getName()).append(" (").append(pool.getType()).append(")\n").append(pool.getUsage()).append('\n');
        }

        builder.append("\nLast Collection Usage:\n");
        for (MemoryPoolMXBean pool : pools) {
            builder.append(pool.getName()).append(" (").append(pool.getType()).append(")\n").append(pool.getCollectionUsage()).append('\n');
        }

        return builder.toString();
    }

}
