package com.comwave.core.platform.model;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.platform.helper.ControllerHelper;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ModelBuilderInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(ModelBuilderInterceptor.class);

    private static final String CONTEXT_INITIALIZED = ModelBuilderInterceptor.class.getName() + ".CONTEXT_INITIALIZED";

    @Inject
    private ModelContext modelContext;
    @Inject
    private SpringObjectFactory springObjectFactory;

    private final Map<Class<? extends Annotation>, ModelBuilder> modelBuilders = new HashMap<>();

    @PostConstruct
    public void initialize() {
        List<ModelBuilder> builders = springObjectFactory.beans(ModelBuilder.class);
        for (ModelBuilder builder : builders) {
            modelBuilders.put(builder.requireAnnotation(), builder);
        }
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", ModelBuilderInterceptor.class.getName());
        if (!(handler instanceof HandlerMethod))
            return true;

        if (!initialized(request)) {
            logger.debug("populate modelContext");
            Map<String, Object> model = modelContext.getModel();

            Class<?> controllerClass = ((HandlerMethod) handler).getBeanType();
            for (Map.Entry<Class<? extends Annotation>, ModelBuilder> entry : modelBuilders.entrySet()) {
                Class<? extends Annotation> annotationClass = entry.getKey();
                if (ControllerHelper.isAnnotationPresentInHierarchy(controllerClass, annotationClass)) {
                    ModelBuilder builder = entry.getValue();
                    logger.debug("prepare model by model builder, annotation={}, builder={}", annotationClass.getName(), builder.getClass().getName());
                    builder.mergeTo(model);
                }
            }

            request.setAttribute(CONTEXT_INITIALIZED, Boolean.TRUE);
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        if (!isTemplateView(modelAndView, handler))
            return;

        logger.debug("merge modelContext to result modelAndView");
        Map<String, Object> model = modelAndView.getModel();
        modelContext.mergeTo(model);
    }

    private boolean isTemplateView(ModelAndView modelAndView, Object handler) {
        if (modelAndView == null)
            return false; // for @ResponseBody

        String viewName = modelAndView.getViewName();
        if (viewName == null)
            return false;

        if (viewName.startsWith(UrlBasedViewResolver.FORWARD_URL_PREFIX) || viewName.startsWith(UrlBasedViewResolver.REDIRECT_URL_PREFIX))
            return false; // forward or redirect

        if (!(handler instanceof HandlerMethod) || modelAndView.getModel() == null)
            return false; // no model is injected to Controller

        return true;
    }

    private boolean initialized(HttpServletRequest request) {
        Boolean initialized = (Boolean) request.getAttribute(CONTEXT_INITIALIZED);
        return Boolean.TRUE.equals(initialized);
    }

}
