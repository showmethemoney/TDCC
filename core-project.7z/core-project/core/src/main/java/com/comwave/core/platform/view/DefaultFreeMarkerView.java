package com.comwave.core.platform.view;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerView;

import com.comwave.core.platform.permission.PermissionChecker;
import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.platform.tag.BodyTag;
import com.comwave.core.platform.tag.CSSTag;
import com.comwave.core.platform.tag.JSTag;
import com.comwave.core.platform.tag.MasterTag;
import com.comwave.core.platform.tag.MasterTemplateLoader;
import com.comwave.core.platform.tag.PermissionTag;
import com.comwave.core.platform.tag.URLTag;

import freemarker.template.Template;
import freemarker.template.TemplateModelException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class DefaultFreeMarkerView extends FreeMarkerView {

    private static final String ATTRIBUTE_CONTEXT_INITIALIZED = DefaultFreeMarkerView.class.getName() + ".CONTEXT_INITIALIZED";

    private RuntimeSettings runtimeSettings;
    private SiteSettings siteSettings;
    private DefaultFreeMarkerViewResolver viewResolver;
    private PermissionChecker permissionChecker;

    @Override
    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();

        ApplicationContext applicationContext = getApplicationContext();
        runtimeSettings = applicationContext.getBean(RuntimeSettings.class);
        siteSettings = applicationContext.getBean(SiteSettings.class);
        viewResolver = applicationContext.getBean(DefaultFreeMarkerViewResolver.class);

        try {
            permissionChecker = applicationContext.getBean(PermissionChecker.class);
        } catch (NoSuchBeanDefinitionException e) {
            permissionChecker = null;
        }
    }

    public Template loadTemplate(String fullTemplatePath, Locale locale) throws IOException {
        return getTemplate(fullTemplatePath, locale);
    }

    @Override
    protected void exposeHelpers(Map<String, Object> model, HttpServletRequest request) throws Exception {
        if (!initialized(request)) {
            registerMasterTag(model, request);
            registerURLTag(model, request);
            registerJSTag(model, request);
            registerCSSTag(model, request);
            registerPermissionTag(model);

            request.setAttribute(ATTRIBUTE_CONTEXT_INITIALIZED, Boolean.TRUE);
        }
    }

    private boolean initialized(HttpServletRequest request) {
        Boolean initialized = (Boolean) request.getAttribute(ATTRIBUTE_CONTEXT_INITIALIZED);
        return Boolean.TRUE.equals(initialized);
    }

    private void registerMasterTag(Map<String, Object> model, HttpServletRequest request) throws TemplateModelException {
        Locale locale = RequestContextUtils.getLocale(request);
        MasterTemplateLoader templateLoader = new MasterTemplateLoader(viewResolver, this, locale);
        Object previousValue = model.put(MasterTag.TAG_NAME, new MasterTag(model, templateLoader));
        assertTagNameIsAvailable(previousValue, MasterTag.TAG_NAME);

        previousValue = model.put(BodyTag.TAG_NAME, new BodyTag(model));
        assertTagNameIsAvailable(previousValue, BodyTag.TAG_NAME);
    }

    private void registerURLTag(Map<String, Object> model, HttpServletRequest request) throws TemplateModelException {
        Object previousValue = model.put(URLTag.TAG_NAME, new URLTag(request));
        assertTagNameIsAvailable(previousValue, URLTag.TAG_NAME);
    }

    private void registerJSTag(Map<String, Object> model, HttpServletRequest request) throws TemplateModelException {
        Object previousValue = model.put(JSTag.TAG_NAME, new JSTag(request, runtimeSettings, siteSettings));
        assertTagNameIsAvailable(previousValue, JSTag.TAG_NAME);
    }

    private void registerCSSTag(Map<String, Object> model, HttpServletRequest request) throws TemplateModelException {
        Object previousValue = model.put(CSSTag.TAG_NAME, new CSSTag(request, runtimeSettings, siteSettings));
        assertTagNameIsAvailable(previousValue, CSSTag.TAG_NAME);
    }

    private void registerPermissionTag(Map<String, Object> model) throws TemplateModelException {
        Object previousValue = model.put(PermissionTag.TAG_NAME, new PermissionTag(permissionChecker));
        assertTagNameIsAvailable(previousValue, PermissionTag.TAG_NAME);
    }

    private void assertTagNameIsAvailable(Object previousValue, String tagName) throws TemplateModelException {
        if (previousValue != null)
            throw new TemplateModelException(String.format("%1$s is reserved name in model as @%1$s, please use different name in model", tagName));
    }

}
