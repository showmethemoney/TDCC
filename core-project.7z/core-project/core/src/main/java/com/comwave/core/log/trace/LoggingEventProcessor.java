package com.comwave.core.log.trace;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;

import com.comwave.core.log.FilterMessagePatternLayout;
import com.comwave.core.log.action.ActionLog;
import com.comwave.core.util.IOUtils;
import com.google.common.base.Charsets;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class LoggingEventProcessor {

    private static final int MAX_HOLD_SIZE = 5000;

    private final ActionLog actionLog = new ActionLog();

    private boolean held = true;
    private final List<ILoggingEvent> heldEvents = new ArrayList<>();

    private final String logFolder;
    private Writer writer;

    public LoggingEventProcessor(String logFolder) {
        this.logFolder = logFolder;
    }

    public void process(ILoggingEvent event) throws IOException {
        if (held) {
            heldEvents.add(event);
            if (shouldFlush(event)) {
                flushTraceLogs();
                held = false;
            }
        } else {
            write(event);
        }
    }

    private boolean shouldFlush(ILoggingEvent event) {
        return event.getLevel().isGreaterOrEqual(Level.WARN) || heldEvents.size() > MAX_HOLD_SIZE;
    }

    private void flushTraceLogs() throws IOException {
        if (writer == null)
            writer = createWriter();

        for (ILoggingEvent event : heldEvents) {
            write(event);
        }
        heldEvents.clear();
    }

    private void write(ILoggingEvent event) throws IOException {
        String log = FilterMessagePatternLayout.get().doLayout(event);
        writer.write(log);
    }

    private Writer createWriter() throws FileNotFoundException {
        if (logFolder == null)
            return new BufferedWriter(new OutputStreamWriter(System.err, Charsets.UTF_8));

        String logFilePath = generateLogFilePath(actionLog.action(), actionLog.requestDate(), actionLog.requestId());
        actionLog.logContext("log_path", logFilePath);

        File logFile = new File(logFilePath);
        mkdirs(logFile);
        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(logFile, true), Charsets.UTF_8));
    }

    private void mkdirs(File logFile) {
        File folder = logFile.getParentFile();
        folder.mkdirs();
    }

    public void cleanup(boolean forceFlushTraceLog) throws IOException {
        if (forceFlushTraceLog) {
            flushTraceLogs();
        }

        if (logFolder == null) {
            IOUtils.flush(writer); // do not close System.err (when logFolder is null)
        } else {
            IOUtils.close(writer);
        }
    }

    String generateLogFilePath(String action, Date targetDate, String requestId) {
        String sequence = RandomStringUtils.randomAlphanumeric(5);
        return String.format("%1$s/%2$tY/%2$tm/%2$td/%3$s/%2$tH%2$tM.%4$s.%5$s.log", logFolder, targetDate, action == null ? "unknown" : action, requestId == null ? "unknown" : requestId, sequence);
    }

    public ActionLog actionLog() {
        return actionLog;
    }

}
