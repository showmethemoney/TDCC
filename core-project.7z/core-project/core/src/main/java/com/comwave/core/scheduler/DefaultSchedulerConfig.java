package com.comwave.core.scheduler;

import javax.inject.Inject;

import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import com.comwave.core.internal.SpringObjectFactory;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class DefaultSchedulerConfig implements SchedulingConfigurer {

    @Inject
    private SpringObjectFactory springObjectFactory;
    @Inject
    private Scheduler scheduler;
    @Inject
    private Environment env;

    @Override
    public void configureTasks(ScheduledTaskRegistrar registry) {
        registry.setScheduler(scheduler.scheduler());
        try {
            registerJobs(new JobRegistry(registry, springObjectFactory, env));
        } catch (Exception e) {
            throw new IllegalStateException("failed to configure scheduler jobs, errorMessage=" + e.getMessage(), e);
        }
    }

    protected abstract void registerJobs(JobRegistry registry) throws Exception;

}
