package com.comwave.core.platform.monitor.web;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.comwave.core.platform.monitor.view.URLMapping;
import com.comwave.core.platform.monitor.view.URLMappings;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@RestController
public class URLMappingController {

    @Inject
    private RequestMappingHandlerMapping handlerMapping;

    @RequestMapping(value = "/monitor/url-mappings", method = RequestMethod.GET)
    public URLMappings urlMappings() {
        URLMappings mappings = new URLMappings();
        Map<RequestMappingInfo, HandlerMethod> methods = handlerMapping.getHandlerMethods();

        for (Map.Entry<RequestMappingInfo, HandlerMethod> entry : methods.entrySet()) {
            RequestMappingInfo mappingInfo = entry.getKey();
            URLMapping mapping = new URLMapping();
            mapping.setPath(getPathInfo(mappingInfo));
            mapping.setControllerClass(entry.getValue().getBeanType().getName());
            mapping.setControllerMethod(getMethodInfo(entry.getValue().getMethod()));
            mappings.getMappings().add(mapping);
        }
        return mappings;
    }

    private String getPathInfo(RequestMappingInfo mappingInfo) {
        StringBuilder builder = new StringBuilder();
        builder.append(mappingInfo.getPatternsCondition());
        builder.append(", methods=").append(mappingInfo.getMethodsCondition());
        return builder.toString();
    }

    private String getMethodInfo(Method method) {
        StringBuilder builder = new StringBuilder();
        builder.append(getTypeInfo(method.getGenericReturnType())).append(' ').append(method.getName()).append('(');

        boolean first = true;
        for (Type paramType : method.getGenericParameterTypes()) {
            if (!first)
                builder.append(", ");
            first = false;
            builder.append(getTypeInfo(paramType));
        }
        builder.append(')');
        return builder.toString();
    }

    @SuppressWarnings("rawtypes")
    private String getTypeInfo(Type type) {
        if (type instanceof ParameterizedType) {
            Class<?> rawType = (Class<?>) ((ParameterizedType) type).getRawType();
            StringBuilder builder = new StringBuilder().append(rawType.getSimpleName()).append("<");

            boolean first = true;
            for (Type argumentType : ((ParameterizedType) type).getActualTypeArguments()) {
                if (!first)
                    builder.append(", ");
                first = false;
                builder.append(getTypeInfo(argumentType));
            }
            return builder.append(">").toString();

        } else if (type instanceof Class) {
            return ((Class) type).getSimpleName();

        } else {
            return type.toString();
        }
    }

}
