package com.comwave.core.platform.request;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import com.comwave.core.log.trace.TraceLogger;
import com.google.common.base.Charsets;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class PlatformFilter extends OncePerRequestFilter {

    private final Logger logger = LoggerFactory.getLogger(PlatformFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        request.setCharacterEncoding(Charsets.UTF_8.toString());

        TraceLogger traceLogger = TraceLogger.get();
        try {
            traceLogger.initialize();
            logger.debug("=== start request processing ===");

            RequestWrapper requestWrapper = new RequestWrapper(request);
            requestWrapper.initialize();
            logRequest(requestWrapper, traceLogger);

            chain.doFilter(requestWrapper, response);

        } finally {
            logResponse(response, traceLogger);
            logger.debug("=== finish request processing ===");

            traceLogger.cleanup();
        }
    }

    private void logRequest(RequestWrapper request, TraceLogger traceLogger) throws IOException {
        logger.debug("request-url={}", request.getRequestURL());
        logger.debug("server-port={}", request.getServerPort());
        logger.debug("context-path={}", request.getContextPath());
        logger.debug("dispatcher-type={}", request.getDispatcherType());
        logger.debug("local-port={}", request.getLocalPort());
        logger.debug("remote-address={}", request.getRemoteAddr());

        traceLogger.logContext("url", request.relativeUrlWithQueryString());
        traceLogger.logContext("method", request.getMethod());
        traceLogger.logContext("ip", request.clientIP());

        logHeaders(request);
        logParameters(request);

        if (request.canPreLoadBody()) {
            logger.debug("body={}", request.body());
        }
    }

    private void logHeaders(HttpServletRequest request) {
        Enumeration<?> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            String headerName = (String) headers.nextElement();
            logger.debug("[request header] {}={}", headerName, request.getHeader(headerName));
        }
    }

    private void logParameters(HttpServletRequest request) {
        Enumeration<?> paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String) paramNames.nextElement();
            logger.debug("[request param] {}={}", paramName, request.getParameter(paramName));
        }
    }

    private void logResponse(HttpServletResponse response, TraceLogger traceLogger) {
        int status = response.getStatus();
        traceLogger.logContext("status", status);
        logger.debug("response status code={}", status);

        logHeaders(response);
    }

    private void logHeaders(HttpServletResponse response) {
        for (String name : response.getHeaderNames()) {
            logger.debug("[response header] {}={}", name, response.getHeader(name));
        }
    }

    @Override
    public void destroy() {
    }

}
