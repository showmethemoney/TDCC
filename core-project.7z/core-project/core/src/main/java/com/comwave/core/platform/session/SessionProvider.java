package com.comwave.core.platform.session;

import java.util.Map;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface SessionProvider {

    Map<String, String> getAndRefresh(String sessionId);

    void save(String sessionId, Map<String, String> sessionData);

    void clear(String sessionId);

}
