package com.comwave.core.platform.setting;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RuntimeSettings {

    private RuntimeEnvironment environment = RuntimeEnvironment.DEV;
    private String version = "current";

    public RuntimeEnvironment environment() {
        return environment;
    }

    public void setEnvironment(RuntimeEnvironment environment) {
        this.environment = environment;
    }

    public String version() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

}
