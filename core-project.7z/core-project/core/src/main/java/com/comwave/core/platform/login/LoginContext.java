package com.comwave.core.platform.login;

import javax.inject.Inject;

import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.cookie.CookieContext;
import com.comwave.core.platform.request.RequestContext;
import com.comwave.core.platform.session.SecureSessionContext;
import com.comwave.core.platform.session.SessionContext;
import com.comwave.core.platform.session.SessionKey;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
public class LoginContext {

    protected static final SessionKey<String> LOGINED_USER_ID = SessionKey.stringKey("_logined_user_id_");
    protected static final SessionKey<String> LOGINED_USER = SessionKey.stringKey("_logined_user_");

    @Inject
    protected CookieContext cookieContext;
    @Inject
    protected SessionContext sessionContext;
    @Inject
    protected SecureSessionContext secureSessionContext;
    @Inject
    protected RequestContext requestContext;

    public void login(String userId) {
        sessionContext.set(LOGINED_USER_ID, userId);
        if (requestContext.secure())
            secureSessionContext.set(LOGINED_USER_ID, userId);
    }

    public String loginedUserId() {
        if (requestContext.secure())
            return secureSessionContext.get(LOGINED_USER_ID);
        return sessionContext.get(LOGINED_USER_ID);
    }

    public void login(Object user) {
        String json = JSONBinder.toJSON(user);
        sessionContext.set(LOGINED_USER, json);
        if (requestContext.secure())
            secureSessionContext.set(LOGINED_USER, json);
    }

    public <T> T loginedUser(Class<T> userClass) {
        String json = requestContext.secure() ? secureSessionContext.get(LOGINED_USER) : sessionContext.get(LOGINED_USER);
        if (json == null)
            return null;
        return JSONBinder.fromJSON(userClass, json);
    }

    public void logout() {
        sessionContext.invalidate();
        secureSessionContext.invalidate();
    }

}
