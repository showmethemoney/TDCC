package com.comwave.core.rest.client;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import org.springframework.cglib.proxy.Enhancer;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.comwave.core.http.HTTPClient;
import com.comwave.core.util.AssertUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RESTClientBuilder {

    private final String serviceUrl;
    private final HTTPClient httpClient;

    public RESTClientBuilder(String serviceUrl, HTTPClient httpClient) {
        this.serviceUrl = serviceUrl;
        this.httpClient = httpClient;
    }

    @SuppressWarnings("unchecked")
    public <T> T build(Class<T> serviceClass) {
        validateServiceClass(serviceClass);

        Map<Method, PathVariableProcessor> pathVariableProcessors = Maps.newHashMap();
        Map<Method, RequestBodyProcessor> requestBodyProcessors = Maps.newHashMap();

        for (Method method : serviceClass.getMethods()) {
            List<PathVariablePosition> positions = Lists.newArrayList();
            Annotation[][] annotations = method.getParameterAnnotations();

            for (int i = 0, length = annotations.length; i < length; i++) {
                Annotation[] paramAnnotations = annotations[i];
                PathVariable pathVariable = findPathVariable(paramAnnotations);
                if (pathVariable != null) {
                    positions.add(new PathVariablePosition(i, pathVariable.value()));
                }

                RequestBody requestBody = findRequestBody(paramAnnotations);
                if (requestBody != null) {
                    requestBodyProcessors.put(method, new RequestBodyProcessor(i));
                }
            }

            if (!positions.isEmpty())
                pathVariableProcessors.put(method, new PathVariableProcessor(positions));
        }

        return (T) Enhancer.create(serviceClass, new RESTClientInterceptor(serviceUrl, httpClient, pathVariableProcessors, requestBodyProcessors));
    }

    private PathVariable findPathVariable(Annotation[] paramAnnotations) {
        for (Annotation annotation : paramAnnotations) {
            if (PathVariable.class.equals(annotation.annotationType()))
                return (PathVariable) annotation;
        }
        return null;
    }

    private RequestBody findRequestBody(Annotation[] paramAnnotations) {
        for (Annotation annotation : paramAnnotations) {
            if (RequestBody.class.equals(annotation.annotationType()))
                return (RequestBody) annotation;
        }
        return null;
    }

    private <T> void validateServiceClass(Class<T> serviceClass) {
        AssertUtils.assertTrue(serviceClass.isInterface(), "serviceClass must be interface");
        for (Method method : serviceClass.getMethods()) {
            // TODO(Robin) may just annotated on Class level
            RequestMapping requestMapping = method.getAnnotation(RequestMapping.class);
            AssertUtils.assertNotNull(requestMapping, "@RequestMapping is required, method=%s", method);
        }
    }

}
