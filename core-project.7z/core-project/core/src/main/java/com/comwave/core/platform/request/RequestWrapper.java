package com.comwave.core.platform.request;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.springframework.http.HttpMethod;
import org.springframework.http.InvalidMediaTypeException;
import org.springframework.http.MediaType;

import com.comwave.core.platform.scheme.HTTPScheme;
import com.comwave.core.util.AssertUtils;
import com.comwave.core.util.StringUtils;
import com.google.common.io.ByteStreams;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RequestWrapper extends HttpServletRequestWrapper {

    protected static final String HEADER_X_FORWARDED_PROTO = "x-forwarded-proto";

    private String scheme;
    private String body;
    private ServletInputStream inputStream;
    private BufferedReader reader;

    public RequestWrapper(HttpServletRequest request) {
        super(request);
    }

    public void initialize() throws IOException {
        HttpServletRequest request = (HttpServletRequest) getRequest();

        if (canPreLoadBody())
            preLoadBody(request);

        scheme = parseProxyScheme(request);
    }

    private void preLoadBody(HttpServletRequest request) throws IOException {
        ServletInputStream originalInputStream = request.getInputStream();
        AssertUtils.assertNotNull(originalInputStream, "POST or PUT should have input steam as body");

        Charset charset = Charset.forName(getCharacterEncoding());
        byte[] bodyBytes = ByteStreams.toByteArray(originalInputStream);
        body = new String(bodyBytes, charset);
        inputStream = new RequestCachingInputStream(body.getBytes(charset));
    }

    protected boolean canPreLoadBody() {
        return containsBody() && !isFormSubmit();
    }

    private boolean containsBody() {
        String originalMethod = getMethod();
        return HttpMethod.POST.name().equals(originalMethod) || HttpMethod.PUT.name().equals(originalMethod);
    }

    protected boolean isFormSubmit() {
        String contentType = getContentType();
        if (contentType == null)
            return false; // invalid request may not pass content type header

        try {
            MediaType mediaType = MediaType.valueOf(contentType);
            return mediaType.isCompatibleWith(MediaType.MULTIPART_FORM_DATA) || mediaType.isCompatibleWith(MediaType.APPLICATION_FORM_URLENCODED);
        } catch (InvalidMediaTypeException e) {
            return false;
        }
    }

    private String parseProxyScheme(HttpServletRequest request) {
        String forwardedProtocol = request.getHeader(HEADER_X_FORWARDED_PROTO);
        if (StringUtils.hasText(forwardedProtocol))
            return forwardedProtocol.toLowerCase();
        return request.getScheme();
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        if (inputStream != null)
            return inputStream;
        return super.getInputStream();
    }

    protected String body() {
        return body;
    }

    @Override
    public String getScheme() {
        return scheme;
    }

    @Override
    public boolean isSecure() {
        return HTTPScheme.HTTPS.equalsIgnoreCase(scheme);
    }

    @Override
    public BufferedReader getReader() throws IOException {
        if (reader == null)
            reader = new BufferedReader(new InputStreamReader(getInputStream(), getCharacterEncoding()));
        return reader;
    }

    public String relativeUrl() {
        return requestServletPath();
    }

    public String relativeUrlWithQueryString() {
        String path = requestServletPath();
        String queryString = requestQueryString();
        if (StringUtils.hasText(queryString))
            return path + '?' + queryString;
        return path;
    }

    // path info starts with '/' and doesn't include any context (servletContext or deploymentContext)
    private String requestServletPath() {
        String forwardPath = (String) getAttribute(RequestDispatcher.FORWARD_SERVLET_PATH);
        if (forwardPath != null)
            return forwardPath;
        return getServletPath();
    }

    public String requestQueryString() {
        String forwardQueryString = (String) getAttribute(RequestDispatcher.FORWARD_QUERY_STRING);
        if (forwardQueryString != null)
            return forwardQueryString;
        return getQueryString();
    }

    public String clientIP() {
        return RemoteAddress.create(this).clientIP();
    }

}
