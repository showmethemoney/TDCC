package com.comwave.core.platform.tag;

import java.io.IOException;
import java.util.Locale;

import com.comwave.core.platform.view.DefaultFreeMarkerView;
import com.comwave.core.platform.view.DefaultFreeMarkerViewResolver;

import freemarker.template.Template;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class MasterTemplateLoader {

    private final DefaultFreeMarkerViewResolver viewResolver;
    private final DefaultFreeMarkerView view;
    private final Locale locale;

    public MasterTemplateLoader(DefaultFreeMarkerViewResolver viewResolver, DefaultFreeMarkerView view, Locale locale) {
        this.viewResolver = viewResolver;
        this.view = view;
        this.locale = locale;
    }

    public Template loadTemplate(String template) throws IOException {
        String fullTemplatePath = viewResolver.buildFullTemplatePath(template);
        return view.loadTemplate(fullTemplatePath, locale);
    }

}
