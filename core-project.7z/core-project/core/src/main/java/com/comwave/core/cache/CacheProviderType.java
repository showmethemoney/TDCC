package com.comwave.core.cache;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public enum CacheProviderType {

    LOCAL, MEMCACHED, REDIS

}
