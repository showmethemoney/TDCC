package com.comwave.core.http;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.annotation.PostConstruct;

import org.apache.http.Header;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.exception.RemoteServiceException;
import com.comwave.core.util.EncodingUtils;
import com.comwave.core.util.TimeLength;
import com.google.common.io.ByteStreams;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class HTTPClient {

    private final Logger logger = LoggerFactory.getLogger(HTTPClient.class);

    private CloseableHttpClient client;
    private boolean validateResponseStatus = false;
    private TimeLength timeOut = TimeLength.minutes(2);

    @PostConstruct
    public void shutdown() throws IOException {
        if (client != null)
            client.close();
    }

    public HTTPResponse execute(HTTPRequest request) {
        if (client == null)
            client = build();

        try (CloseableHttpResponse response = client.execute(request.build())) {
            int statusCode = response.getStatusLine().getStatusCode();
            String responseText = new String(ByteStreams.toByteArray(response.getEntity().getContent()), EncodingUtils.CHARSET_UTF_8);

            logger.debug("response status={}", statusCode);
            for (Header header : response.getAllHeaders()) {
                logger.debug("[header] {}={}", header.getName(), header.getValue());
            }
            logger.debug("response text={}", responseText);

            if (validateResponseStatus)
                validateResponseStatus(statusCode, responseText);

            return new HTTPResponse(statusCode, response.getAllHeaders(), responseText);
        } catch (IOException e) {
            throw new RemoteServiceException(e);
        }
    }

    private void validateResponseStatus(int statusCode, String responseBody) {
        // TODO(Robin) refine this
        // non 2xx
        if (statusCode < HttpStatus.SC_OK || statusCode > HttpStatus.SC_MULTI_STATUS)
            throw new RemoteServiceException("failed to call remote service, status=" + statusCode + ", response=" + responseBody);
    }

    private CloseableHttpClient build() {
        try {
            HttpClientBuilder builder = HttpClients.custom();
            builder.setHostnameVerifier(SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER).setSslcontext(new SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy()).build());
            // builder will use PoolingHttpClientConnectionManager by default
            builder.setDefaultSocketConfig(SocketConfig.custom().setSoKeepAlive(true).build());
            builder.setDefaultRequestConfig(RequestConfig.custom().setSocketTimeout((int) timeOut.toMilliseconds()).setConnectTimeout((int) timeOut.toMilliseconds()).build());
            return builder.build();
        } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
            throw new IllegalStateException(e);
        }
    }

    public void setTimeOut(TimeLength timeOut) {
        this.timeOut = timeOut;
    }

    public void setValidateResponseStatus(boolean validateResponseStatus) {
        this.validateResponseStatus = validateResponseStatus;
    }

}
