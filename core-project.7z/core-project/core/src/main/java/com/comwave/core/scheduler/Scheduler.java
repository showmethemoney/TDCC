package com.comwave.core.scheduler;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.PreDestroy;

import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class Scheduler {

    private TaskScheduler scheduler;
    private ScheduledExecutorService executor;

    @PreDestroy
    public void shutdown() {
        if (executor != null)
            executor.shutdown();
    }

    public TaskScheduler scheduler() {
        return scheduler(10);
    }

    public TaskScheduler scheduler(int threadPoolSize) {
        if (scheduler == null) {
            executor = Executors.newScheduledThreadPool(threadPoolSize);
            scheduler = new ConcurrentTaskScheduler(executor);
        }
        return scheduler;
    }

}
