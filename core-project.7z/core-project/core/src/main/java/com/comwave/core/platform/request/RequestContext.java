package com.comwave.core.platform.request;

import java.util.Date;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface RequestContext {

    String serverName();

    boolean secure();

    String clientIP();

    String requestId();

    Date requestDate();

    String header(String name);

    String contextPath();

    String relativeUrl();

    String relativeUrlWithQueryString();

}
