package com.comwave.core.cache;

import com.google.common.base.Objects;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CacheKey {

    private final String key;
    private final Class<?> type;

    CacheKey(String key, Class<?> type) {
        this.key = key;
        this.type = type;
    }

    public String key() {
        return key;
    }

    public Class<?> type() {
        return type;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("key", key).add("type", type).toString();
    }

}
