package com.comwave.core.database;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import com.comwave.core.util.StopWatch;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RedisAccess {

    private final Logger logger = LoggerFactory.getLogger(RedisAccess.class);

    private JedisPool redisPool;

    public String get(String key) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            String value = redis.get(key);
            redisPool.returnResource(redis);
            return value;
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("get, key={}, elapsedTime:{}", key, watch.elapsedTime());
        }
    }

    public void set(String key, String value) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            redis.set(key, value);
            redisPool.returnResource(redis);
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("set, key={}, value={}, elapsedTime:{}", key, value, watch.elapsedTime());
        }
    }

    public void expire(String key, TimeLength expirationTime) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            redis.expire(key, (int) expirationTime.toSeconds());
            redisPool.returnResource(redis);
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("expire, key={}, seconds={}, elapsedTime={}", key, expirationTime.toSeconds(), watch.elapsedTime());
        }
    }

    public void setExpire(String key, String value, TimeLength expirationTime) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            redis.setex(key, (int) expirationTime.toSeconds(), value);
            redisPool.returnResource(redis);
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("setExpire, key={}, value={}, seconds={}, elapsedTime={}", key, value, expirationTime.toSeconds(), watch.elapsedTime());
        }
    }

    public void del(String... keys) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            redis.del(keys);
            redisPool.returnResource(redis);
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("delete, keys={}, elapsedTime={}", keys, watch.elapsedTime());
        }
    }

    public Map<String, String> hgetAll(String key) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            Map<String, String> value = redis.hgetAll(key);
            redisPool.returnResource(redis);
            return value;
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("hgetAll, key={}, elapsedTime={}", key, watch.elapsedTime());
        }
    }

    public void hmset(String key, Map<String, String> value) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            redis.hmset(key, value);
            redisPool.returnResource(redis);
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("hmset, key={}, elapsedTime={}", key, watch.elapsedTime());
        }
    }

    public Set<String> keys(String pattern) {
        StopWatch watch = new StopWatch();
        Jedis redis = redisPool.getResource();
        try {
            Set<String> keys = redis.keys(pattern);
            redisPool.returnResource(redis);
            return keys;
        } catch (Throwable e) {
            redisPool.returnBrokenResource(redis);
            throw e;
        } finally {
            logger.debug("keys, pattern={}, elapsedTime={}", pattern, watch.elapsedTime());
        }
    }

    public void setRedisPool(JedisPool redisPool) {
        this.redisPool = redisPool;
    }

}
