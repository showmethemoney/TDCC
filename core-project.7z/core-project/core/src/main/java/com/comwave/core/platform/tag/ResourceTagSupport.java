package com.comwave.core.platform.tag;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.platform.url.UrlBuilder;
import com.comwave.core.util.AssertUtils;

import freemarker.core.Environment;
import freemarker.template.SimpleScalar;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class ResourceTagSupport extends TagSupport implements TemplateDirectiveModel {

    private final HttpServletRequest request;
    private final RuntimeSettings runtimeSettings;
    protected final SiteSettings siteSettings;

    public ResourceTagSupport(HttpServletRequest request, RuntimeSettings runtimeSettings, SiteSettings siteSettings) {
        this.request = request;
        this.runtimeSettings = runtimeSettings;
        this.siteSettings = siteSettings;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        assertNoBody(body);

        String tag = buildResourceTag(params);
        Writer output = env.getOut();
        output.write(tag);
    }

    @SuppressWarnings("rawtypes")
    protected abstract String buildResourceTag(Map params) throws TemplateException, IOException;

    protected String buildMultipleResourceTags(String srcKey, String resourceDir, String tagTemplate, Map<String, Object> params) throws IOException, TemplateModelException {
        StringBuilder builder = new StringBuilder();
        String srcValue = getRequiredStringParam(params, srcKey);
        String[] srcItems = srcValue.split(",");

        for (String srcItem : srcItems) {
            String src = srcItem.trim();
            AssertUtils.assertHasText(src, "src can not be empty");

            if (!src.startsWith("/"))
                src = String.format("%s/%s", resourceDir, src);
            src = constructLocalUrl(src);

            String code = String.format(tagTemplate, src, buildExtAttributes(params, srcKey));
            builder.append(code).append('\n');
        }

        return builder.toString();
    }

    String constructLocalUrl(String url) {
        UrlBuilder builder = new UrlBuilder();
        builder.setContextPath(request.getContextPath());
        builder.setLogicalUrl(url);
        builder.addParam("version", runtimeSettings.version());
        return builder.buildRelativeUrl();
    }

    String buildExtAttributes(Map<String, Object> params, String excludedKey) {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, Object> param : params.entrySet()) {
            String key = param.getKey();
            if (!excludedKey.equals(key)) {
                Object value = param.getValue();
                if (value instanceof SimpleScalar) {
                    builder.append(String.format(" %s=\"%s\"", key, value));
                }
            }
        }
        return builder.toString();
    }

}
