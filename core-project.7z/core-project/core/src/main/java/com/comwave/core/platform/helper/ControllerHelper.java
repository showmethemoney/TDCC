package com.comwave.core.platform.helper;

import java.lang.annotation.Annotation;

import org.springframework.web.method.HandlerMethod;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ControllerHelper {

    // find whether one annotation is marked on method or class level included parent class,
    // this pattern is used to check whether one flag is declared on controller by interceptors
    public static <A extends Annotation> A findMethodOrClassLevelAnnotation(Object handler, Class<A> annotationClass) {
        if (!(handler instanceof HandlerMethod))
            return null;

        A annotationOnMethod = ((HandlerMethod) handler).getMethodAnnotation(annotationClass);
        if (annotationOnMethod != null)
            return annotationOnMethod;

        Class<?> targetClass = ((HandlerMethod) handler).getBeanType();
        while (true) {
            A annotation = targetClass.getAnnotation(annotationClass);
            if (annotation != null)
                return annotation;

            targetClass = targetClass.getSuperclass();
            if (Object.class.equals(targetClass))
                return null;
        }
    }

    public static boolean isAnnotationPresentInHierarchy(Class<?> controllerClass, Class<? extends Annotation> annotationClass) {
        Class<?> targetClass = controllerClass;
        while (true) {
            if (targetClass.isAnnotationPresent(annotationClass))
                return true;

            targetClass = targetClass.getSuperclass();
            if (Object.class.equals(targetClass))
                return false;
        }
    }

}
