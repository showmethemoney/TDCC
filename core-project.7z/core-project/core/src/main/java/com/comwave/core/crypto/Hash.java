package com.comwave.core.crypto;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
public enum Hash {

    MD5("MD5"), SHA1("SHA1"), SHA256("SHA256"), SHA512("SHA512");

    final String value;

    Hash(String value) {
        this.value = value;
    }

}
