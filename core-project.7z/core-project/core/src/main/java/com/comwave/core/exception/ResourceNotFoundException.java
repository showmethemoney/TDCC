package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@WarningException
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }

    public ResourceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
