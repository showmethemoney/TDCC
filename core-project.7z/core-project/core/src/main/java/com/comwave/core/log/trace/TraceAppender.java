package com.comwave.core.log.trace;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.UnsynchronizedAppenderBase;

import com.comwave.core.log.FilterMessagePatternLayout;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class TraceAppender extends UnsynchronizedAppenderBase<ILoggingEvent> {

    @Override
    public void start() {
        super.start();
        FilterMessagePatternLayout.get().setContext(getContext());
        FilterMessagePatternLayout.get().start();
    }

    @Override
    public void stop() {
        super.stop();
        FilterMessagePatternLayout.get().stop();
    }

    @Override
    protected void append(ILoggingEvent event) {
        try {
            TraceLogger.get().process(event);
        } catch (Exception e) {
            addError("failed to process log event", e);
        }
    }

    // set in logback.xml
    public void setLogFolder(String logFolder) {
        TraceLogger.get().setLogFolder(logFolder);
    }

    public void setPattern(String pattern) {
        FilterMessagePatternLayout.get().setPattern(pattern);
    }

}
