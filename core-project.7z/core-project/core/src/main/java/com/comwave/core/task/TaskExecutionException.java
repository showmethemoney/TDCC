package com.comwave.core.task;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class TaskExecutionException extends RuntimeException {

    public TaskExecutionException(Throwable cause) {
        super(cause);
    }

}
