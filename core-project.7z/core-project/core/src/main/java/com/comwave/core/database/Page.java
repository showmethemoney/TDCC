package com.comwave.core.database;

/**
 * @author Robin
 * @createdDate Oct 27, 2014
 */
public class Page {

    private static final int DEFAULT_PAGE_SIZE = 10;

    private int pageSize = DEFAULT_PAGE_SIZE;

    private int currentPage = 1;

    private int totalCount = 0;

    private int totalPage = 0;

    public Page(int currentPage) {
        this(currentPage, DEFAULT_PAGE_SIZE);
    }

    public Page(int currentPage, int pageSize) {
        setCurrentPage(currentPage);
        setPageSize(pageSize);
    }

    public int getFirstResult() {
        return (currentPage - 1) * pageSize;
    }

    public int getPageSize() {
        return pageSize;
    }

    public final void setPageSize(int pageSize) {
        if (pageSize <= 0)
            throw new IllegalArgumentException("page size is not valid");
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public final void setCurrentPage(int currentPage) {
        if (currentPage <= 0)
            throw new IllegalArgumentException("current page index is not valid");
        this.currentPage = currentPage;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
        updateTotalPage(totalCount);
    }

    private void updateTotalPage(int totalCount) {
        totalPage = totalCount / pageSize;
        if (totalCount % pageSize != 0)
            totalPage++;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

}
