package com.comwave.core.http;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public enum HTTPMethod {

    GET, POST, PUT, DELETE

}
