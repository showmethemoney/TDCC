package com.comwave.core.platform.setting;

import com.comwave.core.platform.session.SessionProviderType;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class SiteSettings {

    private String loginPage;

    private String errorPage;
    private String resourceNotFoundPage;
    private String permissionNotAllowedPage;

    private TimeLength sessionTimeOut = TimeLength.minutes(15);
    private String sessionTimeOutPage;
    private SessionProviderType sessionProviderType = SessionProviderType.LOCAL;
    private String remoteSessionServer;

    private String jsDir;
    private String cssDir;

    public String errorPage() {
        return errorPage;
    }

    public void setErrorPage(String errorPage) {
        this.errorPage = errorPage;
    }

    public String resourceNotFoundPage() {
        return resourceNotFoundPage;
    }

    public void setResourceNotFoundPage(String resourceNotFoundPage) {
        this.resourceNotFoundPage = resourceNotFoundPage;
    }

    public String sessionTimeOutPage() {
        return sessionTimeOutPage;
    }

    public void setSessionTimeOutPage(String sessionTimeOutPage) {
        this.sessionTimeOutPage = sessionTimeOutPage;
    }

    public TimeLength sessionTimeOut() {
        return sessionTimeOut;
    }

    public void setSessionTimeOut(TimeLength sessionTimeOut) {
        this.sessionTimeOut = sessionTimeOut;
    }

    public SessionProviderType sessionProviderType() {
        return sessionProviderType;
    }

    public void setSessionProviderType(SessionProviderType sessionProviderType) {
        this.sessionProviderType = sessionProviderType;
    }

    public String remoteSessionServer() {
        return remoteSessionServer;
    }

    public void setRemoteSessionServer(String remoteSessionServer) {
        this.remoteSessionServer = remoteSessionServer;
    }

    public String jsDir() {
        return jsDir;
    }

    public void setJSDir(String jsDir) {
        this.jsDir = jsDir;
    }

    public String cssDir() {
        return cssDir;
    }

    public void setCSSDir(String cssDir) {
        this.cssDir = cssDir;
    }

    public String loginPage() {
        return loginPage;
    }

    public void setLoginPage(String loginPage) {
        this.loginPage = loginPage;
    }

    public String permissionNotAllowedPage() {
        return permissionNotAllowedPage;
    }

    public void setPermissionNotAllowedPage(String permissionNotAllowedPage) {
        this.permissionNotAllowedPage = permissionNotAllowedPage;
    }

}
