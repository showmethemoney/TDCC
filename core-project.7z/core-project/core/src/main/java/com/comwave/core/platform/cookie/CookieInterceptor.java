package com.comwave.core.platform.cookie;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.comwave.core.platform.helper.ControllerHelper;
import com.comwave.core.platform.session.RequireSession;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CookieInterceptor extends HandlerInterceptorAdapter {

    private final Logger logger = LoggerFactory.getLogger(CookieInterceptor.class);

    private static final String CONTEXT_INITIALIZED = CookieInterceptor.class.getName() + ".CONTEXT_INITIALIZED";

    @Inject
    private CookieContext cookieContext;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("enter {}", CookieInterceptor.class.getName());

        // if not annotated @RequiredCookie or @RequiredSession, will NOT populate cookie values
        if (!requireCookie(handler))
            return true;

        if (!initialized(request)) {
            logger.debug("populate cookie context");

            Cookie[] cookies = request.getCookies();
            if (cookies != null)
                for (Cookie cookie : cookies) {
                    cookieContext.addCookie(cookie.getName(), cookie.getValue());
                }
            cookieContext.setHttpServletResponse(response);

            request.setAttribute(CONTEXT_INITIALIZED, Boolean.TRUE);
        }
        return true;
    }

    public boolean initialized(HttpServletRequest request) {
        Boolean initialized = (Boolean) request.getAttribute(CONTEXT_INITIALIZED);
        return Boolean.TRUE.equals(initialized);
    }

    protected boolean requireCookie(Object handler) {
        // session depends on cookie
        return ControllerHelper.findMethodOrClassLevelAnnotation(handler, RequireSession.class) != null || ControllerHelper.findMethodOrClassLevelAnnotation(handler, RequireCookie.class) != null;
    }

}
