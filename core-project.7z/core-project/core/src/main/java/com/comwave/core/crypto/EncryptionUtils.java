package com.comwave.core.crypto;

import java.security.KeyPair;

import com.comwave.core.util.ClasspathResource;
import com.comwave.core.util.EncodingUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class EncryptionUtils {

    private EncryptionUtils() {
    }

    public static String encrypt(String plainText, ClasspathResource publicKey) {
        return encrypt(plainText, publicKey.text());
    }

    public static String encrypt(String plainText, String publicKey) {
        RSA rsa = new RSA().withPublicKey(PEM.fromPEM(publicKey));
        byte[] encryptedBytes = rsa.encrypt(plainText.getBytes(EncodingUtils.CHARSET_UTF_8));
        return EncodingUtils.base64(encryptedBytes);
    }

    public static String decrypt(String encryptedText, ClasspathResource privateKey) {
        return decrypt(encryptedText, privateKey.text());
    }

    public static String decrypt(String encryptedText, String privateKey) {
        RSA rsa = new RSA().withPrivateKey(PEM.fromPEM(privateKey));
        byte[] encryptedBytes = EncodingUtils.decodeBase64(encryptedText);
        byte[] plainText = rsa.decrypt(encryptedBytes);
        return new String(plainText, EncodingUtils.CHARSET_UTF_8);
    }

    public static String[] generateKeyPair() {
        RSA rsa = new RSA();
        KeyPair keyPair = rsa.generateKeyPair();

        String publicKey = PEM.toPEM("RSA PUBLIC KEY", keyPair.getPublic().getEncoded());
        System.out.println(publicKey);

        String privateKey = PEM.toPEM("RSA PRIVATE KEY", keyPair.getPrivate().getEncoded());
        System.out.println(privateKey);

        return new String[] {publicKey, privateKey};
    }

}
