package com.comwave.core.platform.monitor.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@RestController
public class HealthCheckController {

    @RequestMapping(value = "/health-check", method = {RequestMethod.HEAD, RequestMethod.GET})
    public void healthCheck() {
    }

}
