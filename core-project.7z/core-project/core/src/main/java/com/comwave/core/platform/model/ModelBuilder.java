package com.comwave.core.platform.model;

import java.lang.annotation.Annotation;
import java.util.Map;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface ModelBuilder {

    Class<? extends Annotation> requireAnnotation();

    void mergeTo(Map<String, Object> model);

}
