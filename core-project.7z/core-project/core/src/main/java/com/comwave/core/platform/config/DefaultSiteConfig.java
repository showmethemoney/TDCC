package com.comwave.core.platform.config;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import com.comwave.core.platform.advice.SiteErrorControllerAdvice;
import com.comwave.core.platform.cookie.CookieContext;
import com.comwave.core.platform.cookie.CookieInterceptor;
import com.comwave.core.platform.error.ErrorPageModelBuilder;
import com.comwave.core.platform.error.ExceptionInterceptor;
import com.comwave.core.platform.model.ModelContext;
import com.comwave.core.platform.scheme.HTTPSchemeEnforceInterceptor;
import com.comwave.core.platform.session.SecureSessionContext;
import com.comwave.core.platform.session.SessionContext;
import com.comwave.core.platform.session.SessionInterceptor;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.platform.view.DefaultFreeMarkerConfigurer;
import com.comwave.core.platform.view.DefaultFreeMarkerView;
import com.comwave.core.platform.view.DefaultFreeMarkerViewResolver;
import com.google.common.base.Charsets;

import freemarker.template.Configuration;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class DefaultSiteConfig extends DefaultConfig {

	protected static final Logger logger = LoggerFactory.getLogger( DefaultSiteConfig.class );
	
	public DefaultSiteConfig() {
		logger.info( "DefaultSiteConfig is stared..." );
	}
	
    // -------------------- site setting --------------------

    @Bean
    public SiteSettings siteSettings() {
        return new SiteSettings();
    }

    // -------------------- error handling --------------------

    @Bean
    SiteErrorControllerAdvice siteErrorControllerAdvice() {
        return new SiteErrorControllerAdvice();
    }

    @Bean
    ErrorPageModelBuilder errorPageModelBuilder() {
        return new ErrorPageModelBuilder();
    }

    // -------------------- view template --------------------

    @Bean
    public DefaultFreeMarkerConfigurer freeMarkerConfigurer() {
        DefaultFreeMarkerConfigurer config = new DefaultFreeMarkerConfigurer();
        config.setTemplateLoaderPath("/");

        Properties settings = new Properties();
        settings.setProperty(Configuration.DEFAULT_ENCODING_KEY, Charsets.UTF_8.name());
        settings.setProperty(Configuration.URL_ESCAPING_CHARSET_KEY, Charsets.UTF_8.name());
        settings.setProperty(Configuration.NUMBER_FORMAT_KEY, "0.##");
        settings.setProperty(Configuration.TEMPLATE_EXCEPTION_HANDLER_KEY, "rethrow");
        config.setFreemarkerSettings(settings);
        return config;
    }

    @Bean
    public DefaultFreeMarkerViewResolver freeMarkerViewResolver() {
        DefaultFreeMarkerViewResolver resolver = new DefaultFreeMarkerViewResolver();
        resolver.setPrefix("/WEB-INF/templates/");
        resolver.setSuffix(".ftl");
        resolver.setContentType("text/html; charset=UTF-8");
        resolver.setViewClass(freeMarkerViewClass());

        resolver.setExposeSpringMacroHelpers(false);
        resolver.setExposeRequestAttributes(true);
        resolver.setAllowRequestOverride(true);
        resolver.setRedirectHttp10Compatible(false);
        return resolver;
    }

    protected Class<?> freeMarkerViewClass() {
        return DefaultFreeMarkerView.class;
    }

    // -------------------- cookie and session --------------------

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    CookieContext cookieContext() {
        return new CookieContext();
    }

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    SessionContext sessionContext() {
        return new SessionContext();
    }

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    SecureSessionContext secureSessionContext() {
        return new SecureSessionContext();
    }

    @Bean
    public CookieInterceptor cookieInterceptor() {
        return new CookieInterceptor();
    }

    @Bean
    public SessionInterceptor sessionInterceptor() {
        return new SessionInterceptor();
    }

    // -------------------- model context --------------------

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    ModelContext modelContextContext() {
        return new ModelContext();
    }

    // -------------------- interceptor --------------------

    protected void registerDefaultInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(exceptionInterceptor());
        registry.addInterceptor(requestContextInterceptor());
        registry.addInterceptor(httpSchemeEnforceInterceptor());
        registry.addInterceptor(cookieInterceptor());
        registry.addInterceptor(sessionInterceptor());
    }

    @Bean
    public ExceptionInterceptor exceptionInterceptor() {
        return new ExceptionInterceptor();
    }

    @Bean
    public HTTPSchemeEnforceInterceptor httpSchemeEnforceInterceptor() {
        return new HTTPSchemeEnforceInterceptor();
    }

}
