package com.comwave.core.platform.cookie;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CookieContext {

    private final Logger logger = LoggerFactory.getLogger(CookieContext.class);

    private final Map<String, String> cookies = new HashMap<>();
    private HttpServletResponse httpServletResponse;

    public <T> void setCookie(CookieSpec<T> spec, T value) {
        Cookie cookie = new Cookie(spec.name(), convertValue(value));
        setCookieAttributes(spec, cookie);

        assertHttpServletResponseRequired();
        httpServletResponse.addCookie(cookie);

        addCookie(cookie.getName(), cookie.getValue());
    }

    private <T> String convertValue(T value) {
        if (value == null)
            return null;
        return String.valueOf(value);
    }

    protected <T> void setCookieAttributes(CookieSpec<T> spec, Cookie cookie) {
        if (spec.pathAssigned())
            cookie.setPath(spec.path());
        if (spec.maxAgeAssigned())
            cookie.setMaxAge((int) spec.maxAge().toSeconds());

        if (spec.httpOnlyAssigned())
            cookie.setHttpOnly(spec.isHttpOnly());
        if (spec.secureAssigned())
            cookie.setSecure(spec.isSecure());
    }

    protected void addCookie(String name, String value) {
        cookies.put(name, value);
    }

    public <T> T getCookie(CookieSpec<T> spec) {
        String value = cookies.get(spec.name());
        return convertValue(value, spec.type());
    }

    @SuppressWarnings("rawtypes")
    public <T> void deleteCookie(CookieSpec spec) {
        Cookie cookie = new Cookie(spec.name(), null);
        if (spec.pathAssigned())
            cookie.setPath(spec.path());
        cookie.setMaxAge((int) CookieSpec.MAX_AGE_TO_DELETE.toSeconds());

        assertHttpServletResponseRequired();
        httpServletResponse.addCookie(cookie);
    }

    @SuppressWarnings("unchecked")
    private <T> T convertValue(String cookieValue, Class<T> type) {
        if (type.equals(String.class))
            return (T) cookieValue;

        try {
            if (type.equals(Integer.class))
                return (T) (Integer) Integer.parseInt(cookieValue);
        } catch (NumberFormatException e) {
            logger.warn("failed to convert cookie value, value={}, type={}", cookieValue, type, e);
            return null;
        }

        throw new IllegalStateException("unsupported cookie type, type=" + type);
    }

    void setHttpServletResponse(HttpServletResponse httpServletResponse) {
        this.httpServletResponse = httpServletResponse;
    }

    private void assertHttpServletResponseRequired() {
        AssertUtils.assertNotNull(httpServletResponse, "response is not injected, please check cookieInterceptor is added in WebConfig");
    }

}
