package com.comwave.core.log;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.pattern.PatternLayoutEncoderBase;

/**
 * @author Robin
 * @createdDate Sep 18, 2014
 */
public class FilterMessagePatternLayoutEncoder extends PatternLayoutEncoderBase<ILoggingEvent> {

    @Override
    public void start() {
        FilterMessagePatternLayout patternLayout = FilterMessagePatternLayout.get();
        patternLayout.setContext(context);
        patternLayout.start();
        this.layout = patternLayout;
        super.start();
    }

    @Override
    public void setPattern(String pattern) {
        FilterMessagePatternLayout.get().setPattern(pattern);
    }

}
