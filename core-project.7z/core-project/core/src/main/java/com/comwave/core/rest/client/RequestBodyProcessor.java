package com.comwave.core.rest.client;

import com.comwave.core.json.JSONBinder;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
class RequestBodyProcessor {

    private final int paramIndex;

    RequestBodyProcessor(int paramIndex) {
        this.paramIndex = paramIndex;
    }

    String body(Object[] params) {
        // TODO(Robin) only support JSON format now
        return JSONBinder.toJSON(params[paramIndex]);
    }

}
