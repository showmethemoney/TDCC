package com.comwave.core.rest.client;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
class PathVariablePosition {

    private final int index;
    private final String name;

    PathVariablePosition(int index, String name) {
        this.index = index;
        this.name = name;
    }

    public int index() {
        return index;
    }

    public String name() {
        return name;
    }

}
