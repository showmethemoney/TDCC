package com.comwave.core.http;

import org.apache.http.Header;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class HTTPResponse {

    private final int statusCode;
    private final Header[] headers;
    private final String responseText;

    public HTTPResponse(int statusCode, Header[] headers, String responseText) {
        this.statusCode = statusCode;
        this.headers = headers;
        this.responseText = responseText;
    }

    public int statusCode() {
        return statusCode;
    }

    public Header[] headers() {
        return headers;
    }

    public String header(String name) {
        if (headers != null && headers.length > 0) {
            for (int i = 0, length = headers.length; i < length; i++) {
                if (headers[i].getName().equals(name))
                    return headers[i].getValue();
            }
        }
        return null;
    }

    public String responseText() {
        return responseText;
    }

}
