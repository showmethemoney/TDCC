package com.comwave.core.cache;

import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface CacheRegistry {

    void register(String cacheName, TimeLength expirationTime);

}
