package com.comwave.core.platform.monitor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;

import com.comwave.core.platform.monitor.web.HealthCheckController;
import com.comwave.core.platform.monitor.web.MemoryUsageController;
import com.comwave.core.platform.monitor.web.ThreadInfoController;
import com.comwave.core.platform.monitor.web.URLMappingController;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class MonitorControllerConfig {
	
	protected static final Logger logger = LoggerFactory.getLogger( MonitorControllerConfig.class );
	
	public MonitorControllerConfig() {
		logger.info( "MonitorControllerConfig is stared..." );
	}
	
    @Bean
    public HealthCheckController healthCheckController() {
        return new HealthCheckController();
    }

    @Bean
    public URLMappingController urlMappingController() {
        return new URLMappingController();
    }

    @Bean
    public ThreadInfoController threadInfoController() {
        return new ThreadInfoController();
    }

    @Bean
    public MemoryUsageController memoryUsageController() {
        return new MemoryUsageController();
    }

}
