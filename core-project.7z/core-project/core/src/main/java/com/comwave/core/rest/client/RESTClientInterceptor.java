package com.comwave.core.rest.client;

import java.lang.reflect.Method;
import java.util.Map;

import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;

import com.comwave.core.exception.InvalidRequestException;
import com.comwave.core.exception.RemoteServiceException;
import com.comwave.core.http.HTTPClient;
import com.comwave.core.http.HTTPMethod;
import com.comwave.core.http.HTTPRequest;
import com.comwave.core.http.HTTPResponse;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.error.ErrorResponse;
import com.comwave.core.platform.error.FieldError;
import com.comwave.core.platform.error.ValidationErrorResponse;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RESTClientInterceptor implements MethodInterceptor {

    private final Logger logger = LoggerFactory.getLogger(RESTClientInterceptor.class);

    private final String serviceUrl;
    private final HTTPClient httpClient;
    private final Map<Method, PathVariableProcessor> pathVariableProcessors;
    private final Map<Method, RequestBodyProcessor> requestBodyProcessors;

    public RESTClientInterceptor(String serviceUrl, HTTPClient httpClient, Map<Method, PathVariableProcessor> pathVariableProcessors, Map<Method, RequestBodyProcessor> requestBodyProcessors) {
        this.serviceUrl = serviceUrl;
        this.httpClient = httpClient;
        this.pathVariableProcessors = pathVariableProcessors;
        this.requestBodyProcessors = requestBodyProcessors;
    }

    @Override
    public Object intercept(Object object, Method method, Object[] params, MethodProxy proxy) throws Throwable {
        RequestMapping requestMapping = method.getAnnotation(RequestMapping.class);

        // TODO(Robin) only intercept methods with @RequestMapping, may annotated on Class level
        if (requestMapping == null)
            return proxy.invokeSuper(object, params);

        String url = constructUrl(method, requestMapping.value()[0], params);

        // TODO(Robin) only support JSON format now
        HTTPRequest request = new HTTPRequest(url, getHttpMethod(requestMapping)).accept(ContentType.APPLICATION_JSON);

        RequestBodyProcessor requestBodyProcessor = requestBodyProcessors.get(method);
        if (requestBodyProcessor != null) {
            request.text(requestBodyProcessor.body(params), ContentType.APPLICATION_JSON);
        }

        HTTPResponse response = httpClient.execute(request);
        validateResponse(response);
        return convertResponse(method, response.responseText());
    }

    private void validateResponse(HTTPResponse response) {
        int statusCode = response.statusCode();
        if (statusCode >= HttpStatus.OK.value() && statusCode <= HttpStatus.IM_USED.value())
            return; // 2xx

        try {
            if (statusCode == HttpStatus.BAD_REQUEST.value()) {
                ValidationErrorResponse validationErrorResponse = JSONBinder.fromJSON(ValidationErrorResponse.class, response.responseText());
                FieldError fieldError = validationErrorResponse.getFieldErrors().get(0);
                throw new InvalidRequestException(fieldError.getField(), fieldError.getMessage());
            } else {
                ErrorResponse errorResponse = JSONBinder.fromJSON(ErrorResponse.class, response.responseText());
                throw new RemoteServiceException(errorResponse.getMessage(), errorResponse.getExceptionTrace());
            }
        } catch (RemoteServiceException | InvalidRequestException e) {
            throw e;
        } catch (Exception e) {
            logger.warn("failed to decode response, statusCode={}, responseText={}", statusCode, response.responseText(), e);
            throw new RemoteServiceException("received non 2xx status code, status=" + statusCode + ", remoteMessage=" + response.responseText(), e);
        }
    }

    private HTTPMethod getHttpMethod(RequestMapping requestMapping) {
        if (requestMapping.method().length == 0)
            return HTTPMethod.POST;
        return HTTPMethod.valueOf(requestMapping.method()[0].name());
    }

    private Object convertResponse(Method method, String responseBody) {
        Class<?> responseClass = method.getReturnType();
        if (Void.TYPE.equals(responseClass))
            return null;
        return JSONBinder.fromJSON(responseClass, responseBody);
    }

    private String constructUrl(Method method, String urlPattern, Object[] params) {
        PathVariableProcessor pathVariableProcessor = pathVariableProcessors.get(method);
        StringBuilder url = new StringBuilder(256).append(serviceUrl);
        if (pathVariableProcessor != null) {
            url.append(pathVariableProcessor.constructUrl(urlPattern, params));
        } else {
            url.append(urlPattern);
        }
        return url.toString();
    }

}
