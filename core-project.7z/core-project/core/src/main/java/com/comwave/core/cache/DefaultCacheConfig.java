package com.comwave.core.cache;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;

import com.comwave.core.cache.provider.CacheProviderCreator;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public abstract class DefaultCacheConfig implements CachingConfigurer {

    @Bean
    public CacheSettings cacheSettings() {
        return new CacheSettings();
    }

    @Bean
    @Override
    public KeyGenerator keyGenerator() {
        return new DefaultCacheKeyGenerator();
    }

    @Bean
    @Override
    public CacheManager cacheManager() {
        CacheManager cacheManager = CacheProviderCreator.create(cacheSettings());
        registerCaches((CacheRegistry) cacheManager);
        return cacheManager;
    }

    protected abstract void registerCaches(CacheRegistry registry);

}
