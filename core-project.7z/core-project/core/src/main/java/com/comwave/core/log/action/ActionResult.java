package com.comwave.core.log.action;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public enum ActionResult {

    SUCCESS, ERROR, WARNING

}
