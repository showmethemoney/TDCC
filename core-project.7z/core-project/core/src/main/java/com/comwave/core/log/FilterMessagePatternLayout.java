package com.comwave.core.log;

import java.util.Map;

import ch.qos.logback.classic.PatternLayout;

import com.comwave.core.log.filter.FilterMessageConverter;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class FilterMessagePatternLayout extends PatternLayout {

    private static final FilterMessagePatternLayout INSTANCE = new FilterMessagePatternLayout();

    public static FilterMessagePatternLayout get() {
        return INSTANCE;
    }

    public FilterMessagePatternLayout() {
        super();

        Map<String, String> converters = getInstanceConverterMap();
        converters.put("m", FilterMessageConverter.class.getName());
        converters.put("msg", FilterMessageConverter.class.getName());
        converters.put("message", FilterMessageConverter.class.getName());

        setPattern("%d [%thread] %-5level %logger{36} - %msg%n");
    }

}
