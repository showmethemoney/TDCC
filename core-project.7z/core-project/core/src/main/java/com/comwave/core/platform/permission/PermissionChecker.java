package com.comwave.core.platform.permission;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
public interface PermissionChecker {

    boolean checkPermission(String[] permissions);

}
