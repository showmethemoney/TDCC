package com.comwave.core.database;

/**
 * @author Robin
 * @createdDate Oct 27, 2014
 */
public class OrderBy {

    private final StringBuilder clause = new StringBuilder(64);

    private String field;
    private boolean asc = true;

    public OrderBy() {
    }

    public OrderBy(String field) {
        this.field = field;
    }

    public OrderBy(String field, boolean asc) {
        this.field = field;
        this.asc = asc;
    }

    public OrderBy and(String field) {
        return and(field, true);
    }

    public OrderBy and(String field, boolean asc) {
        if (clause.length() > 0)
            clause.append(", ");
        clause.append(field).append(asc ? " asc" : " desc");
        return this;
    }

    public String getClause() {
        StringBuilder result = new StringBuilder(64);
        result.append(field).append(asc ? " asc" : " desc");

        if (clause.length() > 0)
            result.append(", ");
        result.append(clause);
        return result.toString();
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public boolean isAsc() {
        return asc;
    }

    public void setAsc(boolean asc) {
        this.asc = asc;
    }

}
