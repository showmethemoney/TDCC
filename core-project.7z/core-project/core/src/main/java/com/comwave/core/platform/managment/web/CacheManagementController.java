package com.comwave.core.platform.managment.web;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.comwave.core.cache.DefaultCacheKeyGenerator;
import com.comwave.core.cache.ManagedCache;
import com.comwave.core.exception.InvalidRequestException;
import com.comwave.core.exception.ResourceNotFoundException;
import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.platform.request.RequestContext;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@RestController
public class CacheManagementController {

    private final Logger logger = LoggerFactory.getLogger(CacheManagementController.class);

    @Inject
    private SpringObjectFactory springObjectFactory;
    @Inject
    private RequestContext requestContext;

    @RequestMapping(value = "/management/cache/groups", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<String> getCacheGroups() {
        CacheManager cacheManager = cacheManager();
        return new ArrayList<>(cacheManager.getCacheNames());
    }

    @RequestMapping(value = "/management/cache/group/{group}", method = RequestMethod.DELETE)
    public String clearCacheGroup(@PathVariable("group") String group) {
        ManagedCache cache = cacheGroup(group);
        cache.clearAll();
        logger.info("clear cache group, group={}", group);
        return String.format("cache group cleared, group=%s", group);
    }

    // only support json because XMLBinder doesn't support dynamic Object field type
    @RequestMapping(value = "/management/cache/group/{group}/key/{key}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getCacheItem(@PathVariable("group") String group, @PathVariable("key") String key) {
        String encodedKey = convertCacheKey(key);
        ManagedCache cache = cacheGroup(group);
        return cache.getValue(encodedKey);
    }

    @RequestMapping(value = "/management/cache/group/{group}/key/{key}", method = RequestMethod.DELETE)
    public String deleteCacheItem(@PathVariable("group") String group, @PathVariable("key") String key) {
        String encodedKey = convertCacheKey(key);
        ManagedCache cache = cacheGroup(group);
        logger.info("clear cache, group={}, key={}, updatedBy={}", group, encodedKey, requestContext.clientIP());
        cache.evictValue(encodedKey);
        return String.format("cache item removed, group=%s, key=%s", group, encodedKey);
    }

    private String convertCacheKey(String key) {
        try {
            DefaultCacheKeyGenerator keyGenerator = springObjectFactory.bean(DefaultCacheKeyGenerator.class);
            return keyGenerator.buildKey(new String[] {key});
        } catch (NoSuchBeanDefinitionException e) {
            throw new InvalidRequestException("cache is not used in this application", e);
        }
    }

    private ManagedCache cacheGroup(String group) {
        CacheManager cacheManager = cacheManager();
        Cache cache = cacheManager.getCache(group);
        if (cache == null)
            throw new ResourceNotFoundException("cache group does not exist, group=" + group);
        return (ManagedCache) cache;
    }

    private CacheManager cacheManager() {
        try {
            return springObjectFactory.bean(CacheManager.class);
        } catch (NoSuchBeanDefinitionException e) {
            throw new InvalidRequestException("cache is not used in this application", e);
        }
    }

}
