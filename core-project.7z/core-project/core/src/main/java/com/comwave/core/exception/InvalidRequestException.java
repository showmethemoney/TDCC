package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@WarningException
public class InvalidRequestException extends RuntimeException {

    private String field;

    public InvalidRequestException(String message) {
        this(null, message, null);
    }

    public InvalidRequestException(String message, Throwable cause) {
        this(null, message, cause);
    }

    public InvalidRequestException(String field, String message) {
        this(field, message, null);
    }

    public InvalidRequestException(String field, String message, Throwable cause) {
        super(message, cause);
        this.field = field;
    }

    public String field() {
        return field;
    }

}
