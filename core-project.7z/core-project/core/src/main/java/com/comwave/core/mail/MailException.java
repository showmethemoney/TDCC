package com.comwave.core.mail;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class MailException extends RuntimeException {

    public MailException(Throwable cause) {
        super(cause);
    }

}
