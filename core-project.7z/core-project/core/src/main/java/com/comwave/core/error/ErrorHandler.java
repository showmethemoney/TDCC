package com.comwave.core.error;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;

import com.comwave.core.log.action.ActionResult;
import com.comwave.core.log.trace.TraceLogger;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ErrorHandler {

    private final Logger logger = LoggerFactory.getLogger(ErrorHandler.class);

    @Inject
    private TraceLogger traceLogger;

    public void handle(Throwable e) {
        if (ignore(e))
            return;

        if (warning(e)) {
            logWarning(e);
        } else {
            logError(e);
        }
    }

    private boolean ignore(Throwable e) {
        return null == e || e.getClass().isAnnotationPresent(IgnoredException.class);
    }

    private boolean warning(Throwable e) {
        return e.getClass().isAnnotationPresent(WarningException.class) || isWarningException(e);
    }

    private boolean isWarningException(Throwable e) {
        return e instanceof HttpRequestMethodNotSupportedException || e instanceof BindException || e instanceof UnsatisfiedServletRequestParameterException
                || e instanceof MissingServletRequestParameterException || e instanceof ServletRequestBindingException || e instanceof MethodArgumentNotValidException
                || e instanceof HttpMediaTypeNotSupportedException || e instanceof HttpMessageNotReadableException; // for invalid http message, like invalid json/xml
    }

    private void logWarning(Throwable e) {
        traceLogger.setResult(ActionResult.WARNING);
        logger.warn(e.getMessage(), e);

        traceLogger.logContext("ex", e.getClass().getName());
        traceLogger.logContext("msg", e.getMessage());
    }

    private void logError(Throwable e) {
        traceLogger.setResult(ActionResult.ERROR);
        logger.error(e.getMessage(), e);

        traceLogger.logContext("ex", e.getClass().getName());
        traceLogger.logContext("msg", e.getMessage());
    }

}
