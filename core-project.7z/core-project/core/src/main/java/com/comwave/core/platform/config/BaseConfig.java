package com.comwave.core.platform.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.comwave.core.error.ErrorHandler;
import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.log.trace.TraceLogger;
import com.comwave.core.platform.advice.RESTControllerAdvice;
import com.comwave.core.platform.error.ErrorResponseBuilder;
import com.comwave.core.scheduler.Scheduler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class BaseConfig {
	
	protected static final Logger logger = LoggerFactory.getLogger( BaseConfig.class );
	
	public BaseConfig() {
		logger.info( "BaseConfig is stared..." );
	}
	
    @Bean
    PropertySourcesPlaceholderConfigurer propertyLoader() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    SpringObjectFactory springObjectFactory() {
        return new SpringObjectFactory();
    }

    @Bean
    Scheduler scheduler() {
        return new Scheduler();
    }

    @Bean
    TraceLogger traceLogger() {
        return TraceLogger.get();
    }

    @Bean
    ErrorHandler errorHandler() {
        return new ErrorHandler();
    }

    @Bean
    ErrorResponseBuilder errorResponseBuilder() {
        return new ErrorResponseBuilder();
    }

    @Bean
    RESTControllerAdvice restControllerAdvice() {
        return new RESTControllerAdvice();
    }

}
