package com.comwave.core.platform.request;

import java.util.Date;

import com.comwave.core.util.ReadOnly;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RequestContextImpl implements RequestContext {

    private final ReadOnly<RequestWrapper> request = new ReadOnly<>();
    private final ReadOnly<String> requestId = new ReadOnly<>();
    private final ReadOnly<Date> requestDate = new ReadOnly<>();

    @Override
    public String serverName() {
        return request.value().getServerName();
    }

    @Override
    public boolean secure() {
        return request.value().isSecure();
    }

    @Override
    public String clientIP() {
        return request.value().clientIP();
    }

    @Override
    public String requestId() {
        return requestId.value();
    }

    @Override
    public Date requestDate() {
        return requestDate.value();
    }

    @Override
    public String header(String name) {
        return request.value().getHeader(name);
    }

    @Override
    public String contextPath() {
        return request.value().getContextPath();
    }

    @Override
    public String relativeUrl() {
        return request.value().relativeUrl();
    }

    @Override
    public String relativeUrlWithQueryString() {
        return request.value().relativeUrlWithQueryString();
    }

    public void setRequestId(String requestId) {
        this.requestId.set(requestId);
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate.set(requestDate);
    }

    public void setHTTPRequest(RequestWrapper request) {
        this.request.set(request);
    }

}
