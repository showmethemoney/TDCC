package com.comwave.core.platform.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;

import com.comwave.core.log.LogSettings;
import com.comwave.core.platform.handler.ExceptionTrackingHandler;
import com.comwave.core.platform.handler.ResourceNotFoundHandlerMapping;
import com.comwave.core.platform.managment.ManagementControllerConfig;
import com.comwave.core.platform.monitor.MonitorControllerConfig;
import com.comwave.core.platform.request.RequestContextImpl;
import com.comwave.core.platform.request.RequestContextInterceptor;
import com.comwave.core.platform.setting.RuntimeSettings;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@Import({BaseConfig.class, MonitorControllerConfig.class, ManagementControllerConfig.class})
public abstract class DefaultConfig extends AbstractWebConfig {
	
	protected static final Logger logger = LoggerFactory.getLogger( DefaultConfig.class );
	
	public DefaultConfig() {
		logger.info( "DefaultConfig is stared..." );
	}
	
    // -------------------- app setting --------------------

    @Bean
    public RuntimeSettings runtimeSettings() {
        return new RuntimeSettings();
    }

    @Bean
    public LogSettings logSettings() {
        return LogSettings.get();
    }

    // -------------------- request context --------------------

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    RequestContextImpl requestContext() {
        return new RequestContextImpl();
    }

    @Bean
    protected RequestContextInterceptor requestContextInterceptor() {
        return new RequestContextInterceptor();
    }

    // -------------------- error handling --------------------

    @Bean
    ExceptionTrackingHandler exceptionTrackingHandler() {
        return new ExceptionTrackingHandler();
    }

    @Bean
    ResourceNotFoundHandlerMapping resourceNotFoundHandlerMapping() {
        return new ResourceNotFoundHandlerMapping();
    }

}
