package com.comwave.core.platform.url;

import java.util.ArrayList;
import java.util.List;

import com.comwave.core.platform.scheme.HTTPScheme;
import com.comwave.core.util.AssertUtils;
import com.comwave.core.util.EncodingUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class UrlBuilder {

    private String scheme;
    private String serverName;
    private Integer serverPort;
    private String contextPath;
    private String logicalUrl;
    private List<UrlParam> params;

    /**
     * @return relative url, included contextPath
     */
    public String buildRelativeUrl() {
        StringBuilder builder = new StringBuilder(512);
        buildRelativeUrlPart(builder, logicalUrl);
        buildParameterPart(builder);
        return builder.toString();
    }

    public String buildFullUrl() {
        AssertUtils.assertHasText(scheme, "scheme is required to build full url");
        AssertUtils.assertHasText(serverName, "serverName is required to build full url");

        StringBuilder builder = new StringBuilder();
        buildUrlPrefix(builder);

        if (logicalUrl != null && !logicalUrl.startsWith("/"))
            buildRelativeUrlPart(builder, "/" + logicalUrl);
        else
            buildRelativeUrlPart(builder, logicalUrl);

        buildParameterPart(builder);
        return builder.toString();
    }

    private void buildRelativeUrlPart(StringBuilder builder, String logicalUrl) {
        if (logicalUrl != null && logicalUrl.startsWith("/")) {
            String context = contextPath();
            builder.append(context).append(logicalUrl);
        } else {
            builder.append(logicalUrl == null ? "" : logicalUrl);
        }
    }

    private void buildParameterPart(StringBuilder builder) {
        if (params == null)
            return;

        char connector = logicalUrl.indexOf('?') < 0 ? '?' : '&';
        builder.append(connector);

        boolean first = true;
        for (UrlParam param : params) {
            if (!first)
                builder.append('&');
            builder.append(EncodingUtils.encodeUrl(param.getName())).append('=').append(EncodingUtils.encodeUrl(param.getValue()));
            first = false;
        }
    }

    private String contextPath() {
        AssertUtils.assertNotNull(contextPath, "contextPath is required");

        if ("/".equals(contextPath))
            return ""; // because the url value contains '/' already
        return contextPath;
    }

    private void buildUrlPrefix(StringBuilder builder) {
        builder.append(scheme).append("://").append(serverName);
        int port = getTargetServerPort();
        if (!isDefaultPort(port)) {
            builder.append(':').append(port);
        }
    }

    private boolean isDefaultPort(int port) {
        return (HTTPScheme.HTTP.equals(scheme) && port == 80) || (HTTPScheme.HTTPS.equals(scheme) && port == 443);
    }

    private int getTargetServerPort() {
        if (serverPort != null)
            return serverPort;
        if (HTTPScheme.HTTP.equals(scheme))
            return 80;
        if (HTTPScheme.HTTPS.equals(scheme))
            return 443;
        throw new IllegalStateException("unknown scheme, scheme=" + scheme);
    }

    public void addParam(String name, String value) {
        if (params == null)
            params = new ArrayList<>();
        params.add(new UrlParam(name, value));
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme.toLowerCase();
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public void setLogicalUrl(String logicalURL) {
        this.logicalUrl = logicalURL;
    }

    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

}
