package com.comwave.core.platform.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.support.AbstractDispatcherServletInitializer;

import com.comwave.core.exception.RuntimeIOException;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.platform.i18n.Messages;
import com.comwave.core.platform.request.PlatformFilter;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@EnableWebMvc
public abstract class AbstractWebConfig extends WebMvcConfigurerAdapter implements WebApplicationInitializer {

    private static final String PLATFORM_FILTER = "platformFilter";
    
	protected static final Logger logger = LoggerFactory.getLogger( AbstractWebConfig.class );
	
	public AbstractWebConfig() {
		logger.info( "AbstractWebConfig is stared..." );
	}
    
    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        context.register(getClass());

        new PropertiesInitializer().initialize(context);

        ServletRegistration.Dynamic dispatcher = servletContext.addServlet(AbstractDispatcherServletInitializer.DEFAULT_SERVLET_NAME, new DispatcherServlet(context));
        dispatcher.addMapping("/*");
        dispatcher.setLoadOnStartup(1);

        servletContext.addFilter(PLATFORM_FILTER, new PlatformFilter()).addMappingForUrlPatterns(null, false, "/*");
    }

    @Bean
    public Messages messages() {
        try {
            Resource[] messageResources = new PathMatchingResourcePatternResolver().getResources("classpath*:messages/*.properties");
            Messages messages = new Messages();
            String[] baseNames = new String[messageResources.length];
            for (int i = 0, messageResourcesLength = messageResources.length; i < messageResourcesLength; i++) {
                Resource messageResource = messageResources[i];
                String filename = messageResource.getFilename();
                baseNames[i] = "messages/" + filename.substring(0, filename.indexOf('.'));
            }
            messages.setBasenames(baseNames);
            return messages;
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
    }

    @Override
    public Validator getValidator() {
        LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
        validator.setValidationMessageSource(messages());
        validator.afterPropertiesSet();
        return validator;
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(new ByteArrayHttpMessageConverter());

        StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
        stringConverter.setWriteAcceptCharset(false);
        ArrayList<MediaType> textTypes = new ArrayList<>();
        textTypes.add(MediaType.TEXT_PLAIN);
        textTypes.add(MediaType.TEXT_HTML);
        textTypes.add(MediaType.TEXT_XML);
        textTypes.add(MediaType.APPLICATION_XML);
        textTypes.add(MediaType.APPLICATION_JSON);
        stringConverter.setSupportedMediaTypes(textTypes);
        converters.add(stringConverter);

        converters.add(new Jaxb2RootElementHttpMessageConverter());

        converters.add(jsonConverter());
    }

    /**
     * can override this to provide a customized json converter
     */
    protected MappingJackson2HttpMessageConverter jsonConverter() {
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        jsonConverter.setObjectMapper(JSONBinder.objectMapper());
        return jsonConverter;
    }

}
