package com.comwave.core.platform.handler;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import com.comwave.core.error.ErrorHandler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ExceptionTrackingHandler extends AbstractHandlerExceptionResolver {

    @Inject
    private ErrorHandler errorHandler;

    public ExceptionTrackingHandler() {
        setOrder(HIGHEST_PRECEDENCE);
    }

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception e) {
        errorHandler.handle(e);
        return null;
    }

}
