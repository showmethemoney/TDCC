package com.comwave.core.cache.provider;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.support.AbstractCacheManager;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import com.comwave.core.cache.CacheRegistry;
import com.comwave.core.database.RedisAccess;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RedisCacheManager extends AbstractCacheManager implements CacheRegistry {

    private final Logger logger = LoggerFactory.getLogger(RedisCacheManager.class);

    private static final TimeLength REDIS_TIME_OUT = TimeLength.seconds(2);

    private final List<RedisCache> caches = new ArrayList<>();
    private final JedisPool redisPool;
    private final RedisAccess redisAccess;

    public RedisCacheManager(String remoteServer) {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxWaitMillis(REDIS_TIME_OUT.toMilliseconds());
        redisPool = new JedisPool(config, remoteServer);

        redisAccess = new RedisAccess();
        redisAccess.setRedisPool(redisPool);
    }

    @PreDestroy
    public void shutdown() {
        logger.info("shutdown redis pool");
        redisPool.destroy();
    }

    @Override
    protected Collection<? extends Cache> loadCaches() {
        return caches;
    }

    public void register(String cacheName, TimeLength expirationTime) {
        RedisCache cache = new RedisCache(cacheName, expirationTime, redisAccess);
        caches.add(cache);
    }

}
