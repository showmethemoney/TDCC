package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 16, 2014
 */
@WarningException
public class ResourceConflictedException extends RuntimeException {

    public ResourceConflictedException(String message) {
        super(message);
    }

    public ResourceConflictedException(String message, Throwable cause) {
        super(message, cause);
    }

}
