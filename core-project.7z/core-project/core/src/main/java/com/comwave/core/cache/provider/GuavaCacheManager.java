package com.comwave.core.cache.provider;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.cache.Cache;
import org.springframework.cache.support.AbstractCacheManager;

import com.comwave.core.cache.CacheRegistry;
import com.comwave.core.util.TimeLength;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.Lists;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class GuavaCacheManager extends AbstractCacheManager implements CacheRegistry {

    private static final int MAX_SIZE = 10000;

    private final List<GuavaCache> caches = Lists.newArrayList();

    @Override
    protected Collection<? extends Cache> loadCaches() {
        return caches;
    }

    @Override
    public void register(String cacheName, TimeLength expirationTime) {
        com.google.common.cache.Cache<Object, Object> cache = CacheBuilder.newBuilder().expireAfterWrite(expirationTime.toMilliseconds(), TimeUnit.MILLISECONDS).maximumSize(MAX_SIZE).build();
        caches.add(new GuavaCache(cacheName, cache));
    }

}
