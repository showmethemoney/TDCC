package com.comwave.core.platform.config;

import java.io.IOException;
import java.util.Properties;

import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * @author Robin
 * @createdDate Sep 25, 2014
 */
public class PropertyLoader extends PropertySourcesPlaceholderConfigurer {

    public Properties loadProperties() throws IOException {
        return mergeProperties();
    }

}
