package com.comwave.core.cache;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface CacheKeyGenerator {

    String buildCacheKey();

}
