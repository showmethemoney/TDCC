package com.comwave.core.exception;

import com.comwave.core.error.WarningException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@WarningException
public class LoginRequiredException extends RuntimeException {

    public LoginRequiredException(String message) {
        super(message);
    }

    public LoginRequiredException(String message, Throwable cause) {
        super(message, cause);
    }

}
