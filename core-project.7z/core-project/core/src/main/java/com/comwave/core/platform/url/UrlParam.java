package com.comwave.core.platform.url;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class UrlParam {

    private final String name;
    private final String value;

    public UrlParam(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

}
