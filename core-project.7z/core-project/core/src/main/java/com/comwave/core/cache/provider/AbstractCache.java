package com.comwave.core.cache.provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleValueWrapper;

import com.comwave.core.cache.CacheKey;
import com.comwave.core.cache.ManagedCache;
import com.comwave.core.json.JSONBinder;
import com.comwave.core.util.StopWatch;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
public abstract class AbstractCache implements Cache, ManagedCache {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    protected final String name;
    protected final TimeLength expirationTime;

    public AbstractCache(String name, TimeLength expirationTime) {
        this.name = name;
        this.expirationTime = expirationTime;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public ValueWrapper get(Object key) {
        StopWatch watch = new StopWatch();
        boolean hit = false;
        try {
            CacheKey cacheKey = (CacheKey) key;
            String value = getValue(cacheKey.key());

            if (value == null)
                return null;
            hit = true;

            return new SimpleValueWrapper(JSONBinder.fromJSON(cacheKey.type(), value));
        } catch (Throwable e) {
            logger.warn("failed to get, key={}", key, e);
            return null;
        } finally {
            logger.debug("get, key={}, hit={}, elapsedTime={}", key, hit, watch.elapsedTime());
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(Object key, Class<T> type) {
        ValueWrapper wrapper = get(key);
        if (wrapper == null)
            return null;

        Object value = wrapper.get();

        if (type != null && !type.isInstance(value))
            throw new IllegalStateException("cached value is not of required type [" + type.getName() + "]: " + value);
        return (T) value;
    }

    @Override
    public void put(Object key, Object value) {
        StopWatch watch = new StopWatch();
        try {
            CacheKey cacheKey = (CacheKey) key;
            putValue(cacheKey.key(), JSONBinder.toJSON(value));
        } catch (Throwable e) {
            logger.warn("failed to put, key={}", key, e);
        } finally {
            logger.debug("put, key={}, elapsedTime={}", key, watch.elapsedTime());
        }
    }

    @Override
    public void evict(Object key) {
        StopWatch watch = new StopWatch();
        try {
            CacheKey cacheKey = (CacheKey) key;
            evictValue(cacheKey.key());
        } catch (Throwable e) {
            logger.warn("failed to evict, key={}", key, e);
        } finally {
            logger.debug("evict, key={}, elapsedTime={}", key, watch.elapsedTime());
        }
    }

    @Override
    public void clear() {
        StopWatch watch = new StopWatch();
        try {
            clearAll();
        } catch (Throwable e) {
            logger.warn("failed to clear", e);
        } finally {
            logger.debug("clear, name={}, elapsedTime={}", name, watch.elapsedTime());
        }
    }

}
