package com.comwave.core.cache;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CacheSettings {

    private CacheProviderType cacheProviderType = CacheProviderType.LOCAL;
    private String remoteCacheServer;

    public CacheProviderType cacheProviderType() {
        return cacheProviderType;
    }

    public void setCacheProviderType(CacheProviderType cacheProviderType) {
        this.cacheProviderType = cacheProviderType;
    }

    public String remoteCacheServer() {
        return remoteCacheServer;
    }

    public void setRemoteCacheServer(String remoteCacheServer) {
        this.remoteCacheServer = remoteCacheServer;
    }

}
