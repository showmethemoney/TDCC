package com.comwave.core.scheduler;

import java.util.TimeZone;

import org.springframework.core.env.Environment;
import org.springframework.scheduling.config.CronTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import com.comwave.core.internal.SpringObjectFactory;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class JobRegistry {

    private final ScheduledTaskRegistrar schedulerRegistry;
    private final SpringObjectFactory springObjectFactory;
    private final Environment env;

    public JobRegistry(ScheduledTaskRegistrar schedulerRegistry, SpringObjectFactory springObjectFactory, Environment env) {
        this.schedulerRegistry = schedulerRegistry;
        this.springObjectFactory = springObjectFactory;
        this.env = env;
    }

    public void triggerWithFixedDelay(Job job, TimeLength delay) {
        schedulerRegistry.addFixedDelayTask(createJobProxy(job), delay.toMilliseconds());
    }

    public void triggerAtFixedRate(Job job, TimeLength interval) {
        schedulerRegistry.addFixedRateTask(createJobProxy(job), interval.toMilliseconds());
    }

    public void triggerByCronExpression(Job job, String cronExpression) {
        triggerByCronExpression(job, cronExpression, TimeZone.getDefault());
    }

    public void triggerByCronExpression(Job job, String cronExpression, TimeZone timeZone) {
        schedulerRegistry.addCronTask(new CronTask(createJobProxy(job), new CronTrigger(cronExpression, timeZone)));
    }

    private JobProxy createJobProxy(Job job) {
        return springObjectFactory.initialize(new JobProxy(springObjectFactory.initialize(job)));
    }

    public void registerJob(Class<? extends Job> jobClass, String key) {
        String value = env.getRequiredProperty(key);
        if ("OFF".equalsIgnoreCase(value))
            return;

        Job job = springObjectFactory.create(jobClass);

        if (isLongValue(value))
            triggerWithFixedDelay(job, TimeLength.seconds(Long.parseLong(value)));
        else
            triggerByCronExpression(job, value);
    }

    private boolean isLongValue(String value) {
        try {
            Long.parseLong(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

}
