package com.comwave.core.platform.session.provider;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.platform.session.SessionProvider;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.util.DateUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class LocalSessionProvider implements SessionProvider {

    private final Logger logger = LoggerFactory.getLogger(LocalSessionProvider.class);

    private final Map<String, SessionValue> values = new ConcurrentHashMap<>();

    @Inject
    private SiteSettings siteSettings;

    @Override
    public Map<String, String> getAndRefresh(String sessionId) {
        SessionValue sessionValue = values.get(sessionId);
        if (sessionValue == null)
            return null;

        if (new Date().after(sessionValue.expiredDate())) {
            values.remove(sessionId);
            logger.warn("session({}) expired", sessionId);
            return null;
        }

        Map<String, String> data = sessionValue.data();
        values.put(sessionId, new SessionValue(data, expirationTime()));
        return data;
    }

    @Override
    public void save(String sessionId, Map<String, String> sessionData) {
        values.put(sessionId, new SessionValue(sessionData, expirationTime()));
        logger.debug("save session({}), data size:{}, expiration time:{}", sessionId, sessionData != null ? sessionData.size() : 0, siteSettings.sessionTimeOut().toSeconds());
    }

    @Override
    public void clear(String sessionId) {
        values.remove(sessionId);
        logger.debug("clear session({})", sessionId);
    }

    private Date expirationTime() {
        return DateUtils.add(new Date(), Calendar.SECOND, (int) siteSettings.sessionTimeOut().toSeconds());
    }

    static class SessionValue {

        private final Map<String, String> datas;
        private final Date expiredTime;

        public SessionValue(Map<String, String> datas, Date expiredTime) {
            this.datas = datas;
            this.expiredTime = expiredTime;
        }

        public Date expiredDate() {
            return expiredTime;
        }

        public Map<String, String> data() {
            return datas;
        }
    }

}
