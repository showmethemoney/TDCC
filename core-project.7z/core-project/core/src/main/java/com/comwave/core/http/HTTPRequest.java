package com.comwave.core.http;

import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class HTTPRequest {

    private final Logger logger = LoggerFactory.getLogger(HTTPRequest.class);

    private final RequestBuilder builder;

    public HTTPRequest(String url, HTTPMethod method) {
        logger.debug("url={}, method={}", url, method);
        builder = RequestBuilder.create(method.name()).setUri(url);
    }

    public HTTPRequest accept(ContentType contentType) {
        return header(HttpHeaders.ACCEPT, contentType.toString());
    }

    public HTTPRequest header(String name, String value) {
        logger.debug("[header] {}={}", name, value);
        builder.setHeader(name, value);
        return this;
    }

    public HTTPRequest param(String name, String value) {
        logger.debug("[param] {}={}", name, value);
        builder.addParameter(name, value);
        return this;
    }

    public HTTPRequest text(String value, ContentType contentType) {
        logger.debug("[payload] contentType={}, value={}", contentType, value);
        builder.setEntity(new StringEntity(value, contentType));
        return this;
    }

    HttpUriRequest build() {
        return builder.build();
    }

}
