package com.comwave.core.platform.session.provider;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import com.comwave.core.database.RedisAccess;
import com.comwave.core.platform.session.SessionProvider;
import com.comwave.core.platform.setting.SiteSettings;
import com.comwave.core.util.TimeLength;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RedisSessionProvider implements SessionProvider {

    private final Logger logger = LoggerFactory.getLogger(RedisSessionProvider.class);

    private static final TimeLength REDIS_TIME_OUT = TimeLength.seconds(5);

    @Inject
    private SiteSettings siteSettings;
    private JedisPool redisPool;
    private RedisAccess redisAccess;

    @PostConstruct
    public void initialize() throws Exception {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxWaitMillis(REDIS_TIME_OUT.toMilliseconds());
        redisPool = new JedisPool(config, siteSettings.remoteSessionServer());

        redisAccess = new RedisAccess();
        redisAccess.setRedisPool(redisPool);
    }

    @PreDestroy
    public void shutdown() {
        redisPool.destroy();
        logger.debug("shutdown redis pool");
    }

    @Override
    public Map<String, String> getAndRefresh(String sessionId) {
        String key = sessionKey(sessionId);
        redisAccess.expire(key, siteSettings.sessionTimeOut());
        return redisAccess.hgetAll(key);
    }

    @Override
    public void save(String sessionId, Map<String, String> sessionData) {
        String key = sessionKey(sessionId);
        redisAccess.expire(key, siteSettings.sessionTimeOut());
        redisAccess.hmset(key, sessionData);
        logger.debug("save session({}), data size:{}, expiration time:{}", sessionId, sessionData != null ? sessionData.size() : 0, siteSettings.sessionTimeOut().toSeconds());
    }

    @Override
    public void clear(String sessionId) {
        String key = sessionKey(sessionId);
        redisAccess.del(key);
        logger.debug("clear session({})", sessionId);
    }

    private String sessionKey(String sessionId) {
        return "session:" + sessionId;
    }

}
