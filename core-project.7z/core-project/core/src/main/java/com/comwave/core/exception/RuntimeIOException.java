package com.comwave.core.exception;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class RuntimeIOException extends RuntimeException {

    public RuntimeIOException(Throwable cause) {
        super(cause);
    }

}
