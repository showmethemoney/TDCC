package com.comwave.core.util;

import java.util.Random;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class ThreadUtils {

    private static final Random RANDOM = new Random();

    private ThreadUtils() {
    }

    public static void sleep(TimeLength duration) throws InterruptedException {
        long milliseconds = duration.toMilliseconds();
        Thread.sleep(milliseconds);
    }

    public static void sleepRoughly(TimeLength duration) throws InterruptedException {
        long milliseconds = duration.toMilliseconds();
        double times = 1 + RANDOM.nextDouble() / 10 * 4 - 0.2; // +/-20% random
        long sleepTime = (long) (milliseconds * times);
        Thread.sleep(sleepTime);
    }

}
