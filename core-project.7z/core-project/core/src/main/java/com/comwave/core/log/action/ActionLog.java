package com.comwave.core.log.action;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.util.Convert;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ActionLog {

    private final Logger logger = LoggerFactory.getLogger(ActionLog.class);

    private static final String LOG_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss,SSS";
    private static final String LOG_SPLITTER = " | ";

    private final Date requestDate = new Date();
    private String requestId;
    private String action;
    private ActionResult result = ActionResult.SUCCESS;
    private final Map<String, String> context = new TreeMap<>();

    public void flush() {
        logContext("elapsed", String.valueOf(System.currentTimeMillis() - requestDate.getTime()));
        logger.info(buildActionLog());
    }

    private String buildActionLog() {
        StringBuilder builder = new StringBuilder(512);
        builder.append(Convert.toString(requestDate, LOG_DATE_FORMAT)).append(LOG_SPLITTER);
        builder.append(result).append(LOG_SPLITTER);
        builder.append(requestId == null ? "unknown" : requestId).append(LOG_SPLITTER);
        builder.append(action == null ? "unknown" : action);

        // TODO(Robin) to expand context fields to normal fields
        for (Map.Entry<String, String> entry : context.entrySet()) {
            String value = filterLineSeparator(entry.getValue());
            builder.append(LOG_SPLITTER).append(entry.getKey()).append('=').append(value);
        }
        return builder.toString();
    }

    protected String filterLineSeparator(String value) {
        StringBuilder builder = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (ch == '\n' || ch == '\r')
                builder.append(' ');
            else
                builder.append(ch);
        }
        return builder.toString();
    }

    public void logContext(String key, String value) {
        context.put(key, value);
    }

    public Date requestDate() {
        return requestDate;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String requestId() {
        return requestId;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String action() {
        return action;
    }

    public void setResult(ActionResult result) {
        this.result = result;
    }

}
