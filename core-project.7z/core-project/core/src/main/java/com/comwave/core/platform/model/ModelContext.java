package com.comwave.core.platform.model;

import java.util.HashMap;
import java.util.Map;

import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ModelContext {

    private final Map<String, Object> model = new HashMap<>();

    public Map<String, Object> getModel() {
        return model;
    }

    public void mergeTo(Map<String, Object> model) {
        for (Map.Entry<String, Object> entry : this.model.entrySet()) {
            String key = entry.getKey();
            Object previousValue = model.put(key, entry.getValue());
            AssertUtils.assertNull(previousValue, "duplicated key found in model, key={}", key);
        }
    }

}
