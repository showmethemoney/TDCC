package com.comwave.core.platform.model;

import java.lang.annotation.Annotation;
import java.util.Map;

import javax.inject.Inject;

import com.comwave.core.platform.login.LoginContext;
import com.comwave.core.platform.request.RequestContext;

/**
 * @author Robin
 * @createdDate Sep 19, 2014
 */
public class ExtraModelBuilder implements ModelBuilder {

    @Inject
    protected RequestContext requestContext;
    @Inject
    protected LoginContext loginContext;

    @Override
    public Class<? extends Annotation> requireAnnotation() {
        return RequireExtraModel.class;
    }

    @Override
    public void mergeTo(Map<String, Object> model) {
        model.put("contextPath", requestContext.contextPath());

        model.put("loginedUserId", loginContext.loginedUserId());
    }

}
