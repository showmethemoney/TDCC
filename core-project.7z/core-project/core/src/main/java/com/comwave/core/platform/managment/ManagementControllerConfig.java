package com.comwave.core.platform.managment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;

import com.comwave.core.platform.managment.web.CacheManagementController;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ManagementControllerConfig {
	
protected static final Logger logger = LoggerFactory.getLogger( ManagementControllerConfig.class );
	
	public ManagementControllerConfig() {
		logger.info( "ManagementControllerConfig is stared..." );
	}
	
    @Bean
    public CacheManagementController cacheManagementController() {
        return new CacheManagementController();
    }

}
