package com.comwave.core.platform.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.HttpRequestHandler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RedirectRequestHandler implements HttpRequestHandler {

    private final String redirectUrl;

    public RedirectRequestHandler(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);
        response.setHeader("Location", redirectUrl);
    }

}
