package com.comwave.core.cache;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public interface ManagedCache {

    void putValue(String key, String value);

    String getValue(String key);

    void evictValue(String key);

    void clearAll();

}
