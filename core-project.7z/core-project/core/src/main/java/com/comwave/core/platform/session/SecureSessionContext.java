package com.comwave.core.platform.session;

import com.comwave.core.util.AssertUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class SecureSessionContext extends SessionContext {

    private boolean underSecure;

    @Override
    public <T> T get(SessionKey<T> key) {
        AssertUtils.assertTrue(underSecure, "secure session can only be used under https");
        return super.get(key);
    }

    @Override
    public <T> void set(SessionKey<T> key, T value) {
        AssertUtils.assertTrue(underSecure, "secure session can only be used under https");
        super.set(key, value);
    }

    void underSecure() {
        underSecure = true;
    }

}
