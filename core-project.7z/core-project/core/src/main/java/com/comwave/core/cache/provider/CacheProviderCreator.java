package com.comwave.core.cache.provider;

import org.springframework.cache.CacheManager;

import com.comwave.core.cache.CacheProviderType;
import com.comwave.core.cache.CacheSettings;

/**
 * @author Robin
 * @createdDate Sep 15, 2014
 */
public class CacheProviderCreator {

    public static CacheManager create(CacheSettings cacheSettings) {
        CacheSettings settings = cacheSettings;
        CacheProviderType cacheProviderType = settings.cacheProviderType();

        if (CacheProviderType.LOCAL.equals(cacheProviderType)) {
            return new GuavaCacheManager();

        } else if (CacheProviderType.REDIS.equals(cacheProviderType)) {
            return new RedisCacheManager(settings.remoteCacheServer());
        }

        throw new IllegalStateException("not supported cache provider, provider=" + cacheProviderType);
    }

}
