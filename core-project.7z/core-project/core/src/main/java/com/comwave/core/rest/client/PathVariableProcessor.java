package com.comwave.core.rest.client;

import java.util.List;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
class PathVariableProcessor {

    private final PathVariablePosition[] positions;

    PathVariableProcessor(List<PathVariablePosition> positions) {
        this.positions = positions.toArray(new PathVariablePosition[positions.size()]);
    }

    String constructUrl(String pattern, Object[] arguments) {
        String url = pattern;
        for (PathVariablePosition position : positions) {
            url = url.replace("{" + position.name() + "}", String.valueOf(arguments[position.index()]));
        }
        return url;
    }

}
