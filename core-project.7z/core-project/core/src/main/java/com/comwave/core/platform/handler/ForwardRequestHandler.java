package com.comwave.core.platform.handler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.HttpRequestHandler;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ForwardRequestHandler implements HttpRequestHandler {

    private final String forwardUrl;

    public ForwardRequestHandler(String forwardUrl) {
        this.forwardUrl = forwardUrl;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(forwardUrl);
        dispatcher.forward(request, response);
    }

}
