package com.comwave.core.platform.scheme;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public final class HTTPScheme {

    public static final String HTTP = "http";
    public static final String HTTPS = "https";

}
