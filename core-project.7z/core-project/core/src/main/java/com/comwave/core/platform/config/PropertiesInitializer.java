package com.comwave.core.platform.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.comwave.core.exception.RuntimeIOException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class PropertiesInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    private final Logger logger = LoggerFactory.getLogger(PropertiesInitializer.class);

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        logger.info("start to load properties from classpath*:*.properties");
        ConfigurableEnvironment environment = applicationContext.getEnvironment();
        PropertyLoader propertyLoader = new PropertyLoader();
        try {
            propertyLoader.setLocations(new PathMatchingResourcePatternResolver().getResources("classpath*:*.properties"));
            environment.setIgnoreUnresolvableNestedPlaceholders(true);
            environment.getPropertySources().addLast(new PropertiesPropertySource("properties", propertyLoader.loadProperties()));
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
    }

}
