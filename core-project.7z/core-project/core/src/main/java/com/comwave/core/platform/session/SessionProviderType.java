package com.comwave.core.platform.session;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public enum SessionProviderType {

    LOCAL, MEMCACHED, REDIS

}
