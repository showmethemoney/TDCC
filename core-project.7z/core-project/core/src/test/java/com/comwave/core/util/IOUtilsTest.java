package com.comwave.core.util;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

import com.comwave.core.exception.RuntimeIOException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class IOUtilsTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void writeBytes() throws IOException {
        File tempFile = temporaryFolder.newFile("tempfile.txt");

        IOUtils.write(tempFile, new byte[10]);
        Assert.assertTrue(tempFile.exists());
        Assert.assertEquals(10, tempFile.length());
    }

    @Test
    public void readSingleLineText() {
        String input = "single line";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes());
        String result = IOUtils.text(inputStream);

        assertEquals(input, result);
    }

    @Test
    public void readMultipleLinesText() {
        String input = "multiple\nline\ntext";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes());
        String result = IOUtils.text(inputStream);

        assertEquals(input, result);
    }

    @Test
    public void throwExceptionIfFileNotExists() {
        exception.expect(RuntimeIOException.class);
        exception.expectMessage("java.io.FileNotFoundException");

        IOUtils.text(new File("not/exsit.file"));
    }

    @Test
    public void readAllFromReader() {
        String text = "text\ntext";
        StringReader reader = new StringReader(text);
        String readText = IOUtils.text(reader);

        Assert.assertEquals(text, readText);
    }
}
