package com.comwave.core.crypto;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class HMACTest {

    @Test
    public void authenticateByMD5() {
        HMAC hmac = HMAC.defaultHash().withSecretKey("4VPDEtyUE".getBytes());

        byte[] bytes = hmac.digest("hello");
        Assert.assertNotNull(bytes);
    }

    @Test
    public void authenticateBySHA1() {
        HMAC hmac = HMAC.hash(Hash.SHA1).withSecretKey("4VPDEtyUE".getBytes());

        byte[] bytes = hmac.digest("hello");
        Assert.assertNotNull(bytes);
    }

    @Test
    public void authenticateBySHA256() {
        HMAC hmac = HMAC.hash(Hash.SHA256).withSecretKey("4VPDEtyUE".getBytes());

        byte[] bytes = hmac.digest("hello");
        Assert.assertNotNull(bytes);
    }

    @Test
    public void authenticateBySHA512() {
        HMAC hmac = HMAC.hash(Hash.SHA512).withSecretKey("123456".getBytes());

        byte[] bytes = hmac.digest("hello");
        Assert.assertNotNull(bytes);
    }

    @Test
    public void generateKey() {
        HMAC hmac = HMAC.hash(Hash.SHA512);

        byte[] key = hmac.generateKey();
        hmac.withSecretKey(key);

        byte[] bytes = hmac.digest("hello");
        Assert.assertNotNull(bytes);
    }

}
