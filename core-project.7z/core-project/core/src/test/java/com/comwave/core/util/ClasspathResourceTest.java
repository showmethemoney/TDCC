package com.comwave.core.util;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ClasspathResourceTest {
    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Test
    public void shouldThrowExceptionIfResourceNotFound() {
        exception.expect(IllegalArgumentException.class);
        ClasspathResource.resource("not-existed-resource");
    }

}
