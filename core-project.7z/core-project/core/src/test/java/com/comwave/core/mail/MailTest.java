package com.comwave.core.mail;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class MailTest {
    @Test
    public void setHTMLContent() {
        Mail mail = new Mail();
        mail.withHtmlBody("<html/>");

        Assert.assertEquals(Mail.CONTENT_TYPE_HTML, mail.contentType());
    }
}
