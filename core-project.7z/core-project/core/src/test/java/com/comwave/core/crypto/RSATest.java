package com.comwave.core.crypto;

import java.nio.charset.Charset;
import java.security.KeyPair;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class RSATest {

    @Test
    public void encrypt() {
        RSA rsa = new RSA();

        KeyPair keyPair = rsa.generateKeyPair();
        rsa.withPrivateKey(keyPair.getPrivate().getEncoded());
        rsa.withPublicKey(keyPair.getPublic().getEncoded());

        String message = "test message";
        byte[] encryptedMessage = rsa.encrypt(message.getBytes());
        byte[] decryptedMessage = rsa.decrypt(encryptedMessage);

        Assert.assertEquals(message, new String(decryptedMessage, Charset.forName("UTF-8")));
    }

}
