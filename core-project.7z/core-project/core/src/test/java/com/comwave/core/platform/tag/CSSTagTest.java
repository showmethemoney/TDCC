package com.comwave.core.platform.tag;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import com.comwave.core.platform.scheme.HTTPScheme;
import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;

import freemarker.template.SimpleScalar;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class CSSTagTest {
    CSSTag cssTag;
    MockHttpServletRequest request;
    SiteSettings siteSettings;
    RuntimeSettings runtimeSettings;

    @Before
    public void createCDNTagSupport() {
        request = new MockHttpServletRequest();
        siteSettings = new SiteSettings();
        runtimeSettings = new RuntimeSettings();
        cssTag = new CSSTag(request, runtimeSettings, siteSettings);

        runtimeSettings.setVersion("1.0");
        siteSettings.setCSSDir("/static/css");
        request.setScheme(HTTPScheme.HTTP);
    }

    @Test
    public void buildSingleCSSTagWithAbsoluteHref() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("href", new SimpleScalar("/static/css/stylesheet.css"));
        String html = cssTag.buildResourceTag(params);
        Assert.assertEquals("<link type=\"text/css\" rel=\"stylesheet\" href=\"/static/css/stylesheet.css?version=1.0\"/>\n", html);
    }

    @Test
    public void buildSingleCSSTagWithRelativeHref() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("href", new SimpleScalar("stylesheet.css"));
        String html = cssTag.buildResourceTag(params);
        Assert.assertEquals("<link type=\"text/css\" rel=\"stylesheet\" href=\"/static/css/stylesheet.css?version=1.0\"/>\n", html);
    }

    @Test
    public void buildMultipleCSSTagWithRelativeHref() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("href", new SimpleScalar("css1.css, css2.css"));
        String html = cssTag.buildResourceTag(params);
        Assert.assertEquals("<link type=\"text/css\" rel=\"stylesheet\" href=\"/static/css/css1.css?version=1.0\"/>\n"
                + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/static/css/css2.css?version=1.0\"/>\n", html);
    }

    @Test
    public void buildSingleCSSTagWithExtAttributes() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("href", new SimpleScalar("stylesheet.css"));
        params.put("media", new SimpleScalar("screen and (max-width: 600px)"));
        String html = cssTag.buildResourceTag(params);
        Assert.assertEquals("<link type=\"text/css\" rel=\"stylesheet\" href=\"/static/css/stylesheet.css?version=1.0\" media=\"screen and (max-width: 600px)\"/>\n", html);
    }
}
