package com.comwave.core.platform.tag;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import com.comwave.core.platform.scheme.HTTPScheme;
import com.comwave.core.platform.setting.RuntimeSettings;
import com.comwave.core.platform.setting.SiteSettings;

import freemarker.template.SimpleScalar;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class JSTagTest {
    JSTag jsTag;
    MockHttpServletRequest request;
    RuntimeSettings runtimeSettings;
    SiteSettings siteSettings;

    @Before
    public void createCDNTagSupport() {
        request = new MockHttpServletRequest();
        siteSettings = new SiteSettings();
        runtimeSettings = new RuntimeSettings();
        jsTag = new JSTag(request, runtimeSettings, siteSettings);

        runtimeSettings.setVersion("1.0");
        siteSettings.setJSDir("/static/js");
        request.setScheme(HTTPScheme.HTTP);
    }

    @Test
    public void buildSingleJSTagWithAbsoluteSrc() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("src", new SimpleScalar("/static/js/zepto.min.js"));
        String html = jsTag.buildResourceTag(params);
        Assert.assertEquals("<script type=\"text/javascript\" src=\"/static/js/zepto.min.js?version=1.0\"></script>\n", html);
    }

    @Test
    public void buildSingleJSTagWithRelativeSrc() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("src", new SimpleScalar("zepto.min.js"));
        String html = jsTag.buildResourceTag(params);
        Assert.assertEquals("<script type=\"text/javascript\" src=\"/static/js/zepto.min.js?version=1.0\"></script>\n", html);
    }

    @Test
    public void buildMultipleJSTagWithRelativeSrc() throws Exception {
        HashMap<String, Object> params = new HashMap<>();
        params.put("src", new SimpleScalar("js1.js, js2.js"));
        String html = jsTag.buildResourceTag(params);
        Assert.assertEquals(
                "<script type=\"text/javascript\" src=\"/static/js/js1.js?version=1.0\"></script>\n" + "<script type=\"text/javascript\" src=\"/static/js/js2.js?version=1.0\"></script>\n", html);
    }

}
