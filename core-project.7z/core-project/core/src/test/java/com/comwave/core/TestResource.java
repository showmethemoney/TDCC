package com.comwave.core;

import java.io.InputStream;

import com.comwave.core.util.AssertUtils;
import com.comwave.core.util.IOUtils;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class TestResource {

    public static byte[] bytes(String testResourcePath) {
        InputStream stream = TestResource.class.getResourceAsStream(testResourcePath);
        AssertUtils.assertNotNull(stream, "resource does not exist, resource=" + testResourcePath);
        return IOUtils.bytes(stream);
    }

    public static String text(String testResourcePath) {
        InputStream stream = TestResource.class.getResourceAsStream(testResourcePath);
        AssertUtils.assertNotNull(stream, "resource does not exist, resource=" + testResourcePath);
        return IOUtils.text(stream);
    }

}
