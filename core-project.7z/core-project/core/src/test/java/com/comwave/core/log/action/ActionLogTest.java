package com.comwave.core.log.action;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ActionLogTest {

    ActionLog actionLog;

    @Before
    public void createActionLog() {
        actionLog = new ActionLog();
    }

    @Test
    public void filterLineSeparator() {
        String value = actionLog.filterLineSeparator("first_line\nsecond_line");
        Assert.assertEquals("first_line second_line", value);
    }

}
