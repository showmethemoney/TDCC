package com.comwave.core.cache;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comwave.core.platform.setting.RuntimeSettings;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class DefaultCacheKeyGeneratorTest {

    private final Logger logger = LoggerFactory.getLogger(DefaultCacheKeyGeneratorTest.class);

    private DefaultCacheKeyGenerator defaultCacheKeyGenerator;

    @Before
    public void createDefaultCacheKeyGenerator() {
        defaultCacheKeyGenerator = new DefaultCacheKeyGenerator();
        defaultCacheKeyGenerator.runtimeSettings = new RuntimeSettings();
    }

    @Test
    public void encodeKeyIfContainsIllegalChar() {
        String encodedKey = defaultCacheKeyGenerator.buildKey(new String[] {"contains space key"});
        logger.info("encoded key:{}", encodedKey);
        Assert.assertEquals("illegal key should be encoded by md5, which is 32 chars long", 32, encodedKey.length());
    }

}
