package com.comwave.core.util;

import static org.hamcrest.CoreMatchers.containsString;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
public class ExceptionUtilsTest {
    @Test
    public void getStackTrace() {
        RuntimeException exception = new RuntimeException();
        String trace = ExceptionUtils.stackTrace(exception);

        Assert.assertThat(trace, containsString(RuntimeException.class.getName()));
    }
}
