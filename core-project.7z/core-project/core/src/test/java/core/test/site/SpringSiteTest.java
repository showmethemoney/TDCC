package core.test.site;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.comwave.core.platform.config.PropertiesInitializer;
import com.comwave.core.platform.request.PlatformFilter;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebSiteConfig.class, initializers = PropertiesInitializer.class)
@TransactionConfiguration
@WebAppConfiguration
public abstract class SpringSiteTest {
    protected MockMvc mockMvc;
    @Inject
    WebApplicationContext webApplicationContext;

    @Before
    public void createMockMVC() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).addFilter(new PlatformFilter()).build();
    }
}
