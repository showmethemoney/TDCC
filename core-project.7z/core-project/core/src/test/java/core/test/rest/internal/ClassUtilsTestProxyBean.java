package core.test.rest.internal;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@Service
public class ClassUtilsTestProxyBean {
    @Transactional
    public void doTransaction() {

    }
}
