package core.test.rest;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

import com.comwave.core.cache.CacheRegistry;
import com.comwave.core.cache.DefaultCacheConfig;
import com.comwave.core.util.TimeLength;

import core.test.rest.cache.CacheTestRepository;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@Configuration
@EnableCaching(proxyTargetClass = true)
public class CacheConfig extends DefaultCacheConfig {
    @Override
    protected void registerCaches(CacheRegistry cacheRegistry) {
        cacheRegistry.register(CacheTestRepository.CACHE_NAME, TimeLength.hours(2));
    }
}
