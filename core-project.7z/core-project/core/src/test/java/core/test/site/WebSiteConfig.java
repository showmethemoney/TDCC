package core.test.site;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import com.comwave.core.platform.config.DefaultSiteConfig;
import com.comwave.core.platform.view.DefaultFreeMarkerConfigurer;
import com.comwave.core.platform.view.DefaultFreeMarkerView;
import com.comwave.core.platform.view.DefaultFreeMarkerViewResolver;
import com.google.common.base.Charsets;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@Configuration
@ComponentScan(basePackageClasses = WebSiteConfig.class)
@EnableTransactionManagement(proxyTargetClass = true)
public class WebSiteConfig extends DefaultSiteConfig {

    @Bean
    public DefaultFreeMarkerConfigurer freeMarkerConfigurer() {
        DefaultFreeMarkerConfigurer config = new DefaultFreeMarkerConfigurer();
        config.setTemplateLoaderPath("classpath:/templates/");
        Properties settings = new Properties();
        settings.setProperty(freemarker.template.Configuration.DEFAULT_ENCODING_KEY, Charsets.UTF_8.name());
        settings.setProperty(freemarker.template.Configuration.URL_ESCAPING_CHARSET_KEY, Charsets.UTF_8.name());
        settings.setProperty(freemarker.template.Configuration.NUMBER_FORMAT_KEY, "0.##");
        settings.setProperty(freemarker.template.Configuration.TEMPLATE_EXCEPTION_HANDLER_KEY, "rethrow");
        config.setFreemarkerSettings(settings);
        return config;
    }

    @Bean
    public DefaultFreeMarkerViewResolver freeMarkerViewResolver() {
        DefaultFreeMarkerViewResolver resolver = new DefaultFreeMarkerViewResolver();
        resolver.setPrefix("/");
        resolver.setSuffix(".ftl");
        resolver.setContentType("text/html; charset=UTF-8");
        resolver.setViewClass(DefaultFreeMarkerView.class);
        resolver.setExposeSpringMacroHelpers(false);
        resolver.setExposeRequestAttributes(true);
        resolver.setAllowRequestOverride(true);
        return resolver;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(requestContextInterceptor());
    }
}
