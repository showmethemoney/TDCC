package core.test.rest.cache;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

/**
 * @author Robin
 * @createdDate Sep 10, 2014
 */
@Repository
public class CacheTestRepository {
    public static final String CACHE_NAME = "entities";

    final ThreadLocal<Integer> methodCalled = new ThreadLocal<>();

    @Cacheable(CACHE_NAME)
    public Entity getEntityById(String id) {
        int count = methodCalled.get();
        methodCalled.set(count + 1);
        Entity entity = new Entity();
        entity.setId(id);
        return entity;
    }

    @CacheEvict(CACHE_NAME)
    public void evictEntityById(String id) {
        int count = methodCalled.get();
        methodCalled.set(count + 1);
    }

    @Cacheable(CACHE_NAME)
    public Entity getDefaultEntity() {
        int count = methodCalled.get();
        methodCalled.set(count + 1);
        Entity entity = new Entity();
        entity.setId("default");
        return entity;
    }

    @CacheEvict(CACHE_NAME)
    public void evictDefaultEntity() {
        int count = methodCalled.get();
        methodCalled.set(count + 1);
    }

    int getMethodCalled() {
        return methodCalled.get();
    }

    void resetMethodCalled() {
        methodCalled.set(0);
    }

    public static class Entity {
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}
